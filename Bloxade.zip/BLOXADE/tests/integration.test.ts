/**
 * End-to-end tests of the BLOXADE backend over HTTP, using the mock CLI fixtures in tests/fixtures
 * (they imitate the official Claude Code / Codex / Roblox Studio MCP protocols — no accounts needed).
 */
import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const port = 3300 + Math.floor(Math.random() * 500);
const base = `http://127.0.0.1:${port}`;
const argvLog = path.join(os.tmpdir(), `bx-argv-${port}.log`);
let projectDir = '';
const sse: { type: string; data: any }[] = [];
let sseAbort: AbortController;

async function call<T = any>(method: string, url: string, body?: unknown, headers: Record<string, string> = {}): Promise<{ status: number; data: T }> {
  const res = await fetch(base + url, { method, headers: { 'Content-Type': 'application/json', 'X-Bloxade': '1', ...headers }, body: body === undefined ? (method === 'GET' ? undefined : '{}') : JSON.stringify(body) });
  const text = await res.text();
  return { status: res.status, data: text ? JSON.parse(text) : null };
}
const get = <T = any>(u: string) => call<T>('GET', u).then((r) => r.data);
const post = <T = any>(u: string, b?: unknown) => call<T>('POST', u, b ?? {}).then((r) => r.data);

async function until<T>(fn: () => Promise<T | null | undefined | false>, timeoutMs = 15000): Promise<T> {
  const end = Date.now() + timeoutMs;
  while (Date.now() < end) {
    const v = await fn();
    if (v) return v as T;
    await new Promise((r) => setTimeout(r, 120));
  }
  throw new Error('condition not met in time');
}

beforeAll(async () => {
  const data = fs.mkdtempSync(path.join(os.tmpdir(), 'bx-it-'));
  projectDir = fs.mkdtempSync(path.join(os.tmpdir(), 'bx-it-proj-'));
  fs.writeFileSync(path.join(projectDir, 'Shop.lua'), 'local Shop = {}\nfunction Shop.buy() end\nreturn Shop\n');
  Object.assign(process.env, {
    BLOXADE_DATA_DIR: data,
    BLOXADE_QUIET: '1',
    BLOXADE_CLAUDE_PATH: path.join(here, 'fixtures', 'mock-claude.mjs'),
    BLOXADE_CODEX_PATH: path.join(here, 'fixtures', 'mock-codex.mjs'),
    MOCK_CLAUDE_ARGV_LOG: argvLog,
  });
  const { startServer } = await import('../src/server/main');
  await startServer({ port, background: true });
  sseAbort = new AbortController();
  void (async () => {
    const res = await fetch(base + '/api/events', { signal: sseAbort.signal });
    const reader = res.body!.getReader();
    let buf = '';
    for (;;) {
      const { value, done } = await reader.read().catch(() => ({ value: undefined, done: true }));
      if (done) break;
      buf += new TextDecoder().decode(value);
      let i;
      while ((i = buf.indexOf('\n\n')) >= 0) {
        const chunk = buf.slice(0, i);
        buf = buf.slice(i + 2);
        const line = chunk.split('\n').find((l) => l.startsWith('data: '));
        if (line) sse.push(JSON.parse(line.slice(6)));
      }
    }
  })();
});

afterAll(() => {
  sseAbort?.abort();
});

describe('server & security', () => {
  it('answers health checks', async () => {
    expect((await get('/api/health')).app).toBe('bloxade');
  });
  it('blocks cross-site and header-less mutations and foreign hosts', async () => {
    expect((await call('POST', '/api/chats', {}, { Origin: 'http://evil.example' })).status).toBe(403);
    const r = await fetch(base + '/api/chats', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
    expect(r.status).toBe(403);
  });
  it('persists settings', async () => {
    await call('PUT', '/api/settings', { appearance: { theme: 'midnight', accent: '#3FB98A' } });
    const s = await get('/api/settings');
    expect(s.appearance.theme).toBe('midnight');
    expect(s.appearance.accent).toBe('#3FB98A');
  });
});

describe('providers & accounts', () => {
  it('detects both CLIs', async () => {
    const p = await get('/api/providers?refresh=1');
    expect(p.claude.found).toBe(true);
    expect(p.codex.found).toBe(true);
  });
  it('adds multiple isolated accounts and reads their status', async () => {
    const c1 = await post('/api/accounts', { provider: 'claude', name: 'Claude 1' });
    const c2 = await post('/api/accounts', { provider: 'claude', name: 'Claude 2' });
    const x1 = await post('/api/accounts', { provider: 'codex', name: 'Codex 1' });
    expect(c1.profileDir).not.toBe(c2.profileDir);
    expect(c1.isDefault).toBe(true);
    const acc = await until(async () => {
      const list = await get('/api/accounts');
      return list.every((a: any) => a.status === 'signed_in') ? list : null;
    });
    expect(acc.find((a: any) => a.id === x1.id).email).toBe('mock@example.com');
    expect(acc.find((a: any) => a.id === c1.id).email).toBe('claude-mock@example.com');
  });
  it('discovers models with supported efforts', async () => {
    const cx = await post('/api/models/refresh', { provider: 'codex' });
    expect(cx.source).toBe('discovered');
    expect(cx.models[0]).toMatchObject({ id: 'mock-model', efforts: ['low', 'high'], defaultEffort: 'low' });
    const cl = await post('/api/models/refresh', { provider: 'claude' });
    expect(cl.models.find((m: any) => m.id === 'default').efforts).toEqual(['low', 'high']);
    expect(cl.models.some((m: any) => m.group === 'versions')).toBe(true);
  });
});

describe('chats', () => {
  let chatId = '';
  it('streams a Claude chat turn and persists it', async () => {
    const chat = await post('/api/chats', { provider: 'claude', model: 'haiku', effort: 'low', mode: 'chat' });
    chatId = chat.id;
    await post(`/api/chats/${chatId}/messages`, { text: 'hello there' });
    const done = await until(async () => {
      const c = await get(`/api/chats/${chatId}`);
      return c.messages[1]?.status === 'complete' ? c : null;
    });
    const a = done.messages[1];
    expect(a.content).toContain('Mock Claude (haiku) args=new tools=none');
    expect(a.usage).toMatchObject({ verified: true, inputTokens: 10, outputTokens: 20 });
    expect(a.providerRef.sessionId).toBeTruthy();
    expect(a.providerRef.lastAssistantUuid).toMatch(/^uuid-/);
    expect(done.chat.title).toBe('hello there');
    expect(sse.some((e) => e.type === 'chat.delta' && e.data.chatId === chatId)).toBe(true);
    const accounts = await get('/api/accounts');
    expect(accounts.find((x: any) => x.id === a.accountId).limits.windows[0].usedPercent).toBe(25);
  });
  it('continues the same provider session, then regenerates from a fork checkpoint', async () => {
    await post(`/api/chats/${chatId}/messages`, { text: 'second' });
    const second = await until(async () => {
      const c = await get(`/api/chats/${chatId}`);
      return c.messages[3]?.status === 'complete' ? c.messages[3] : null;
    });
    expect(second.content).toContain('args=resume');
    await post(`/api/chats/${chatId}/regenerate`);
    const regen = await until(async () => {
      const c = await get(`/api/chats/${chatId}`);
      return c.messages.length === 4 && c.messages[3].status === 'complete' && c.messages[3].id !== second.id ? c.messages[3] : null;
    });
    expect(regen.content).toContain('args=fork');
    const lines = fs.readFileSync(argvLog, 'utf8').trim().split('\n').map((l) => JSON.parse(l));
    const last = lines[lines.length - 1];
    expect(last).toContain('--resume-session-at');
    expect(last).toContain('--effort');
  });
  it('branches a chat into a new chat', async () => {
    const c = await get(`/api/chats/${chatId}`);
    const b = await post(`/api/chats/${chatId}/branch`, { messageId: c.messages[1].id });
    const bc = await get(`/api/chats/${b.id}`);
    expect(bc.messages).toHaveLength(2);
  });
  it('runs a Codex chat with streaming, verified usage and limits', async () => {
    const chat = await post('/api/chats', { provider: 'codex', model: 'mock-model', effort: 'high', mode: 'chat' });
    await post(`/api/chats/${chat.id}/messages`, { text: 'hi codex' });
    const msg = await until(async () => {
      const c = await get(`/api/chats/${chat.id}`);
      return c.messages[1]?.status !== 'streaming' ? c.messages[1] : null;
    });
    expect(msg.status).toBe('complete');
    expect(msg.content).toContain('Mock Codex reply');
    expect(msg.usage).toMatchObject({ verified: true, inputTokens: 1200, outputTokens: 40 });
    expect(msg.providerRef.threadId).toMatch(/^thr_/);
    const acc = (await get('/api/accounts')).find((a: any) => a.provider === 'codex');
    expect(acc.limits.windows.map((w: any) => w.label)).toContain('Weekly');
  });
  it('routes Codex command approvals to the user', async () => {
    const chat = await post('/api/chats', { provider: 'codex', model: 'mock-model', mode: 'cowork' });
    await post(`/api/chats/${chat.id}/messages`, { text: 'please run a command' });
    const ap = await until(async () => (await get('/api/approvals')).find((a: any) => a.requester.id === chat.id));
    expect(ap.kind).toBe('command');
    await post(`/api/approvals/${ap.id}`, { allow: true });
    const msg = await until(async () => {
      const c = await get(`/api/chats/${chat.id}`);
      return c.messages[1]?.status === 'complete' ? c.messages[1] : null;
    });
    const tool = msg.blocks.find((b: any) => b.type === 'tool');
    expect(tool).toMatchObject({ name: 'Shell', status: 'done' });
  });
  it('can stop a running turn', async () => {
    const chat = await post('/api/chats', { provider: 'claude', mode: 'chat' });
    await post(`/api/chats/${chat.id}/messages`, { text: 'slow please' });
    await new Promise((r) => setTimeout(r, 400));
    await post(`/api/chats/${chat.id}/stop`);
    const msg = await until(async () => {
      const c = await get(`/api/chats/${chat.id}`);
      return c.messages[1]?.status !== 'streaming' ? c.messages[1] : null;
    });
    expect(msg.status).toBe('cancelled');
  });
  it('searches chats', async () => {
    const r = await get('/api/search?q=hello%20there');
    expect(r.length).toBeGreaterThan(0);
  });
});

describe('projects, permissions and change tracking', () => {
  let projectId = '';
  it('creates a project and scopes file access', async () => {
    const p = await post('/api/projects', { name: 'Roblox — Test', folderPath: projectDir, instructions: 'Use Luau' });
    projectId = p.id;
    expect(p.robloxEnabled).toBe(true);
    const files = await get(`/api/projects/${projectId}/files`);
    expect(files.map((f: any) => f.name)).toContain('Shop.lua');
    expect((await call('GET', `/api/projects/${projectId}/file?path=../../etc/passwd`)).status).toBe(403);
    const pack = await post(`/api/projects/${projectId}/context-preview`, { query: 'shop buy' });
    expect(pack.text).toContain('Shop.lua');
  });
  it('asks before editing, applies the edit after approval and records a diff', async () => {
    await call('PUT', '/api/settings', { agents: { approvals: { edits: 'ask' } } });
    const chat = await post('/api/chats', { provider: 'claude', mode: 'cowork', projectId });
    const target = path.join(projectDir, 'New.lua');
    await post(`/api/chats/${chat.id}/messages`, { text: `write file ${target}` });
    const ap = await until(async () => (await get('/api/approvals')).find((a: any) => a.requester.id === chat.id));
    expect(ap.kind).toBe('file_edit');
    await post(`/api/approvals/${ap.id}`, { allow: true });
    await until(async () => {
      const c = await get(`/api/chats/${chat.id}`);
      return c.messages[1]?.status === 'complete';
    });
    expect(fs.readFileSync(target, 'utf8')).toContain('mock');
    const changes = await get(`/api/projects/${projectId}/changes`);
    expect(changes[0]).toMatchObject({ path: 'New.lua', change: 'added', source: 'chat' });
    await post(`/api/changes/${changes[0].id}/revert`);
    expect(fs.existsSync(target)).toBe(false);
  });
  it('denied edits are reported back to the agent', async () => {
    const chat = await post('/api/chats', { provider: 'claude', mode: 'cowork', projectId });
    const target = path.join(projectDir, 'Denied.lua');
    await post(`/api/chats/${chat.id}/messages`, { text: `write file ${target}` });
    const ap = await until(async () => (await get('/api/approvals')).find((a: any) => a.requester.id === chat.id));
    await post(`/api/approvals/${ap.id}`, { allow: false });
    const msg = await until(async () => {
      const c = await get(`/api/chats/${chat.id}`);
      return c.messages[1]?.status === 'complete' ? c.messages[1] : null;
    });
    expect(fs.existsSync(target)).toBe(false);
    expect(msg.blocks.find((b: any) => b.type === 'tool').status).toMatch(/denied|error/);
    await call('PUT', '/api/settings', { agents: { approvals: { edits: 'allow' } } });
  });
});

describe('roblox studio (mock MCP)', () => {
  it('connects, lists tools and studios, and runs tool calls through the queue', async () => {
    await call('PUT', '/api/settings', { roblox: { command: `"${process.execPath}" "${path.join(here, 'fixtures', 'mock-roblox-mcp.mjs')}"`, enabled: true } });
    const t = await post('/api/roblox/test');
    expect(t.ok).toBe(true);
    const st = await get('/api/roblox/status');
    expect(st.activeStudioId).toBe('studio-test-1');
    expect(st.tools.find((x: any) => x.name === 'multi_edit')).toMatchObject({ readOnly: false, policy: 'ask' });
    const r = await post('/api/roblox/call', { tool: 'script_read', args: { target_file: 'game.ServerScriptService.ShopServer' } });
    expect(r.content[0].text).toContain('local Shop');
  });
  it('serves agents through the MCP bridge with approval for writes and output trimming', async () => {
    const { createBridgeSession } = await import('../src/server/roblox/sessions');
    const token = createBridgeSession({ kind: 'task', id: 'task_x', label: 'Test Agent' });
    const rpc = (msg: any) => fetch(base + '/api/bridge/rpc', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-bloxade-bridge-token': token }, body: JSON.stringify(msg) }).then((r) => r.json());
    const init = await rpc({ jsonrpc: '2.0', id: 1, method: 'initialize', params: { protocolVersion: '2025-06-18' } });
    expect(init.response.result.serverInfo.name).toBe('bloxade-roblox');
    const list = await rpc({ jsonrpc: '2.0', id: 2, method: 'tools/list' });
    const me = list.response.result.tools.find((x: any) => x.name === 'multi_edit');
    expect(me.inputSchema.required).not.toContain('studio_id');
    const write = rpc({ jsonrpc: '2.0', id: 3, method: 'tools/call', params: { name: 'multi_edit', arguments: { file_path: 'game.ServerScriptService.ShopServer', datamodel_type: 'Edit', edits: [{ old_string: 'return Shop', new_string: 'Shop.v = 1\nreturn Shop' }] } } });
    const ap = await until(async () => (await get('/api/approvals')).find((a: any) => a.requester.id === 'task_x'));
    expect(ap.kind).toBe('studio');
    await post(`/api/approvals/${ap.id}`, { allow: true });
    const res = await write;
    expect(res.response.result.isError).toBe(false);
    const log = await rpc({ jsonrpc: '2.0', id: 4, method: 'tools/call', params: { name: 'get_console_output', arguments: {} } });
    expect(log.response.result.content[0].text).toMatch(/repeated|trimmed/);
    const bad = await fetch(base + '/api/bridge/rpc', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-bloxade-bridge-token': 'nope' }, body: JSON.stringify({ jsonrpc: '2.0', id: 9, method: 'tools/list' }) }).then((r) => r.json());
    expect(bad.response.error.code).toBe(-32001);
  });
});

describe('multi-agent runs', () => {
  it('runs parallel tasks, honours dependencies and writes a report', async () => {
    const projects = await get('/api/projects');
    const pid = projects[0].id;
    const a = path.join(projectDir, 'A.lua');
    const b = path.join(projectDir, 'B.lua');
    const run = await post('/api/runs', {
      projectId: pid,
      prompt: 'test run',
      strategy: 'manual',
      efficiency: 'economy',
      autoApprove: { edits: true },
      tasks: [
        { title: 'A', description: `write file ${a}`, ownedPaths: ['A.lua'], assignment: { provider: 'claude' } },
        { title: 'B', description: `write file ${b}`, ownedPaths: ['B.lua'], assignment: { provider: 'codex', model: 'mock-model' } },
        { title: 'Check', description: 'check both', dependsOn: ['t1', 't2'], assignment: { provider: 'claude' } },
      ],
      autoStart: true,
    });
    const done = await until(async () => {
      const r = await get(`/api/runs/${run.id}`);
      return ['completed', 'failed'].includes(r.status) ? r : null;
    }, 30000);
    expect(done.status).toBe('completed');
    expect(done.tasks.map((t: any) => t.status)).toEqual(['completed', 'completed', 'completed']);
    expect(done.tasks[0].filesTouched).toEqual(['A.lua']);
    const t3 = done.tasks[2];
    expect(t3.startedAt).toBeGreaterThanOrEqual(Math.max(done.tasks[0].finishedAt, done.tasks[1].finishedAt));
    expect(done.report).toContain('3 of 3');
    expect(fs.existsSync(a)).toBe(true);
  });
  it('reports usage with verified and estimated numbers separated', async () => {
    const u = await get('/api/usage?range=24h');
    expect(u.totals.verifiedInput).toBeGreaterThan(0);
    expect(u.totals.turns).toBeGreaterThan(3);
    expect(u.byProvider.map((p: any) => p.provider).sort()).toEqual(['claude', 'codex']);
  });
});
