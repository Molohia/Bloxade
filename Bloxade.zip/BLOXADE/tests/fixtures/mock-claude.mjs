#!/usr/bin/env node
// TEST FIXTURE ONLY — imitates the parts of the official Claude Code CLI that BLOXADE uses
// (`--version`, `auth status --json`, and `-p --input-format/--output-format stream-json` with the
// control protocol) so the integration tests run deterministically and without using any account.
import fs from 'node:fs';
import { randomUUID } from 'node:crypto';

const argv = process.argv.slice(2);
const out = (o) => process.stdout.write(JSON.stringify(o) + '\n');
if (argv[0] === '--version') {
  console.log('9.9.9 (Claude Code mock)');
  process.exit(0);
}
if (argv[0] === 'auth' && argv[1] === 'status') {
  console.log(JSON.stringify({ loggedIn: true, authMethod: 'oauth_token', apiProvider: 'firstParty', email: 'claude-mock@example.com' }));
  process.exit(0);
}
const flag = (name) => {
  const i = argv.indexOf(name);
  return i >= 0 ? argv[i + 1] : null;
};
if (process.env.MOCK_CLAUDE_ARGV_LOG) fs.appendFileSync(process.env.MOCK_CLAUDE_ARGV_LOG, JSON.stringify(argv) + '\n');
let session = flag('--session-id') || flag('--resume') || randomUUID();
if (argv.includes('--fork-session')) session = randomUUID();
const model = flag('--model') || 'default';
const pending = new Map();
let buf = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', (c) => {
  buf += c;
  let i;
  while ((i = buf.indexOf('\n')) >= 0) {
    const line = buf.slice(0, i).trim();
    buf = buf.slice(i + 1);
    if (line) void handle(JSON.parse(line));
  }
});
process.stdin.on('end', () => setTimeout(() => process.exit(0), 20));

function ask(request) {
  const id = randomUUID();
  out({ type: 'control_request', request_id: id, request });
  return new Promise((r) => pending.set(id, r));
}

async function handle(m) {
  if (m.type === 'control_response') {
    pending.get(m.response.request_id)?.(m.response.response);
    return;
  }
  if (m.type === 'control_request') {
    if (m.request.subtype === 'initialize') {
      out({ type: 'control_response', response: { subtype: 'success', request_id: m.request_id, response: { models: [{ value: 'default', resolvedModel: 'claude-mock-1', displayName: 'Default (recommended)', description: 'Mock', supportsEffort: true, supportedEffortLevels: ['low', 'high'] }, { value: 'haiku', resolvedModel: 'claude-mock-haiku', displayName: 'Haiku', supportedEffortLevels: ['low'] }], account: { subscriptionType: 'max', apiProvider: 'firstParty' } } } });
    } else if (m.request.subtype === 'interrupt') {
      out({ type: 'control_response', response: { subtype: 'success', request_id: m.request_id, response: {} } });
      out({ type: 'result', subtype: 'error_during_execution', is_error: true, result: 'Interrupted', session_id: session, usage: {} });
    }
    return;
  }
  if (m.type !== 'user') return;
  const text = m.message.content.filter((c) => c.type === 'text').map((c) => c.text).join('\n');
  out({ type: 'system', subtype: 'init', session_id: session, model: `mock-${model}`, tools: [] });
  out({ type: 'rate_limit_event', rate_limit_info: { status: 'allowed', unifiedWindows: { five_hour: { utilization: 0.25, resetsAt: Math.floor(Date.now() / 1000) + 3600, status: 'allowed' } } }, session_id: session });
  if (/slow/i.test(text)) await new Promise((r) => setTimeout(r, 3000));
  const writeMatch = /write file (\S+)/i.exec(text);
  if (writeMatch) {
    const file = writeMatch[1];
    const toolId = 'toolu_' + randomUUID().slice(0, 8);
    const input = { file_path: file, content: 'return "mock"\n' };
    out({ type: 'assistant', uuid: randomUUID(), message: { id: 'msg_t', model, content: [{ type: 'tool_use', id: toolId, name: 'Write', input }] }, parent_tool_use_id: null, session_id: session });
    const decision = await ask({ subtype: 'can_use_tool', tool_name: 'Write', input, tool_use_id: toolId });
    if (decision.behavior === 'allow') {
      fs.writeFileSync(file, input.content);
      out({ type: 'user', message: { content: [{ type: 'tool_result', tool_use_id: toolId, content: `File created successfully at: ${file}` }] }, parent_tool_use_id: null, session_id: session });
    } else {
      out({ type: 'user', message: { content: [{ type: 'tool_result', tool_use_id: toolId, content: decision.message, is_error: true }] }, parent_tool_use_id: null, session_id: session });
    }
  }
  const reply = `Mock Claude (${model}) args=${argv.includes('--fork-session') ? 'fork' : argv.includes('--resume') ? 'resume' : 'new'} tools=${flag('--tools') === '' ? 'none' : 'default'}: ${text.slice(-50)}`;
  const msgId = 'msg_' + randomUUID().slice(0, 8);
  out({ type: 'stream_event', event: { type: 'message_start', message: { id: msgId } }, parent_tool_use_id: null, session_id: session });
  for (const part of reply.match(/.{1,10}/gs)) out({ type: 'stream_event', event: { type: 'content_block_delta', index: 0, delta: { type: 'text_delta', text: part } }, parent_tool_use_id: null, session_id: session });
  out({ type: 'assistant', uuid: 'uuid-' + randomUUID().slice(0, 8), message: { id: msgId, model, content: [{ type: 'text', text: reply }] }, parent_tool_use_id: null, session_id: session });
  out({ type: 'result', subtype: 'success', is_error: false, result: reply, session_id: session, total_cost_usd: 0.0012, usage: { input_tokens: 10, output_tokens: 20, cache_read_input_tokens: 100, cache_creation_input_tokens: 5 } });
}
