#!/usr/bin/env node
// TEST FIXTURE ONLY — imitates `codex --version` and a small subset of the official `codex app-server`
// JSON-RPC protocol (v2 method names/shapes from `codex app-server generate-ts`), so BLOXADE's Codex
// integration can be tested without a signed-in ChatGPT account. Never used by the real app.
const args = process.argv.slice(2);
if (args[0] === '--version') {
  console.log('codex-cli 0.0.0-mock');
  process.exit(0);
}
if (args[0] !== 'app-server') {
  console.error('mock codex: only app-server is supported');
  process.exit(2);
}
let n = 0;
const out = (o) => process.stdout.write(JSON.stringify(o) + '\n');
const pending = new Map();
let nextReq = 1000;
const threads = new Map();
function serverRequest(method, params) {
  const id = nextReq++;
  out({ id, method, params });
  return new Promise((r) => pending.set(id, r));
}
async function runTurn(threadId, turnId, text) {
  out({ method: 'turn/started', params: { threadId, turn: { id: turnId, status: 'inProgress', items: [] } } });
  if (/run a command/i.test(text)) {
    const item = { type: 'commandExecution', id: 'cmd1', command: 'echo hi', cwd: '/', status: 'inProgress', commandActions: [], aggregatedOutput: null, exitCode: null };
    out({ method: 'item/started', params: { threadId, turnId, item } });
    const res = await serverRequest('item/commandExecution/requestApproval', { threadId, turnId, itemId: 'cmd1', command: 'echo hi', cwd: '/', startedAtMs: Date.now(), kind: 'command' });
    const ok = res?.decision === 'accept';
    out({ method: 'item/completed', params: { threadId, turnId, item: { ...item, status: ok ? 'completed' : 'declined', aggregatedOutput: ok ? 'hi\n' : null, exitCode: ok ? 0 : null } } });
  }
  const reply = `Mock Codex reply to: ${text.slice(-60)}`;
  for (const part of reply.match(/.{1,12}/g)) {
    out({ method: 'item/agentMessage/delta', params: { threadId, turnId, itemId: 'msg1', delta: part } });
    await new Promise((r) => setTimeout(r, 5));
  }
  out({ method: 'item/completed', params: { threadId, turnId, item: { type: 'agentMessage', id: 'msg1', text: reply } } });
  const t = threads.get(threadId);
  t.total = { totalTokens: 0, inputTokens: t.total.inputTokens + 1200, cachedInputTokens: t.total.cachedInputTokens + 800, cacheWriteInputTokens: 0, outputTokens: t.total.outputTokens + 40, reasoningOutputTokens: t.total.reasoningOutputTokens + 10 };
  out({ method: 'thread/tokenUsage/updated', params: { threadId, turnId, tokenUsage: { total: t.total, last: { totalTokens: 0, inputTokens: 1200, cachedInputTokens: 800, cacheWriteInputTokens: 0, outputTokens: 40, reasoningOutputTokens: 10 }, modelContextWindow: 400000 } } });
  out({ method: 'account/rateLimits/updated', params: { rateLimits: { primary: { usedPercent: 12, windowDurationMins: 300, resetsAt: Math.floor(Date.now() / 1000) + 3600 }, secondary: { usedPercent: 40, windowDurationMins: 10080, resetsAt: null } } } });
  out({ method: 'turn/completed', params: { threadId, turn: { id: turnId, status: 'completed', items: [], error: null } } });
}
let buf = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', (c) => {
  buf += c;
  let i;
  while ((i = buf.indexOf('\n')) >= 0) {
    const line = buf.slice(0, i).trim();
    buf = buf.slice(i + 1);
    if (!line) continue;
    const m = JSON.parse(line);
    if (m.id !== undefined && !m.method) {
      pending.get(m.id)?.(m.result);
      pending.delete(m.id);
      continue;
    }
    if (m.id === undefined) continue;
    const p = m.params ?? {};
    const reply = (result) => out({ id: m.id, result });
    switch (m.method) {
      case 'initialize':
        reply({ userAgent: 'mock', codexHome: process.env.CODEX_HOME ?? '', platformFamily: 'unix', platformOs: 'linux' });
        break;
      case 'account/read':
        reply({ account: { type: 'chatgpt', email: 'mock@example.com', planType: 'plus' }, requiresOpenaiAuth: true });
        break;
      case 'account/rateLimits/read':
        reply({ rateLimits: { primary: { usedPercent: 10, windowDurationMins: 300, resetsAt: null }, secondary: null, planType: 'plus' } });
        break;
      case 'model/list':
        reply({ data: [{ id: 'mock-model', model: 'mock-model', displayName: 'Mock Model', description: 'test', hidden: false, supportedReasoningEfforts: [{ reasoningEffort: 'low', description: '' }, { reasoningEffort: 'high', description: '' }], defaultReasoningEffort: 'low', isDefault: true }], nextCursor: null });
        break;
      case 'thread/start':
      case 'thread/fork': {
        const id = 'thr_' + ++n;
        threads.set(id, { total: { inputTokens: 0, cachedInputTokens: 0, outputTokens: 0, reasoningOutputTokens: 0 }, forkedFrom: p.threadId ?? null, lastTurnId: p.lastTurnId ?? null });
        reply({ thread: { id, forkedFromId: p.threadId ?? null } });
        break;
      }
      case 'thread/resume':
        if (!threads.has(p.threadId)) threads.set(p.threadId, { total: { inputTokens: 0, cachedInputTokens: 0, outputTokens: 0, reasoningOutputTokens: 0 } });
        reply({ thread: { id: p.threadId } });
        break;
      case 'turn/start': {
        const turnId = 'turn_' + ++n;
        reply({ turn: { id: turnId, status: 'inProgress', items: [] } });
        const text = (p.input ?? []).filter((x) => x.type === 'text').map((x) => x.text).join('\n');
        void runTurn(p.threadId, turnId, text);
        break;
      }
      case 'turn/interrupt':
        reply({});
        out({ method: 'turn/completed', params: { threadId: p.threadId, turn: { id: p.turnId, status: 'interrupted', items: [], error: null } } });
        break;
      default:
        out({ id: m.id, error: { code: -32601, message: `mock: ${m.method} not implemented` } });
    }
  }
});
process.stdin.on('end', () => process.exit(0));
