#!/usr/bin/env node
// TEST FIXTURE ONLY — a tiny stand-in for the official Roblox Studio MCP server (stdio, JSON-RPC 2.0).
// Used by automated tests to exercise BLOXADE's MCP client, queue, permissions and agent bridge
// on machines without Roblox Studio. It mirrors a subset of the real tool names and schemas.
const studio = { id: 'studio-test-1', name: 'Mock Place (placeId: 1)' };
const scripts = { 'game.ServerScriptService.ShopServer': 'local Shop = {}\nreturn Shop\n' };
const sid = { studio_id: { type: 'string', description: 'Selects Roblox Studio instance' } };
const tools = [
  { name: 'list_roblox_studios', description: 'Lists the connected Roblox Studio instances.', inputSchema: { type: 'object', properties: {} } },
  { name: 'get_studio_state', description: 'Get the state of the studio.', inputSchema: { type: 'object', properties: { ...sid }, required: ['studio_id'] } },
  { name: 'script_read', description: 'Reads a script.', inputSchema: { type: 'object', properties: { ...sid, target_file: { type: 'string' } }, required: ['target_file', 'studio_id'] } },
  {
    name: 'multi_edit',
    description: 'Makes multiple edits to a single script.',
    inputSchema: { type: 'object', properties: { ...sid, file_path: { type: 'string' }, datamodel_type: { type: 'string', enum: ['Edit'] }, className: { type: 'string' }, edits: { type: 'array', items: { type: 'object', properties: { old_string: { type: 'string' }, new_string: { type: 'string' } }, required: ['old_string', 'new_string'] } } }, required: ['file_path', 'edits', 'datamodel_type', 'studio_id'] },
  },
  { name: 'get_console_output', description: 'Get the console output.', inputSchema: { type: 'object', properties: { ...sid }, required: ['studio_id'] } },
];
const text = (t, isError = false) => ({ content: [{ type: 'text', text: t }], isError });
function call(name, a) {
  if (name !== 'list_roblox_studios' && a.studio_id !== studio.id) return text(`Unknown studio_id ${a.studio_id}`, true);
  switch (name) {
    case 'list_roblox_studios':
      return text(JSON.stringify({ studios: [studio] }));
    case 'get_studio_state':
      return text(JSON.stringify({ mode: 'Edit', datamodels: ['Edit'] }));
    case 'script_read': {
      const s = scripts[a.target_file];
      return s == null ? text(`Script not found: ${a.target_file}`, true) : text(s.split('\n').map((l, i) => `${i + 1}→${l}`).join('\n'));
    }
    case 'multi_edit': {
      let s = scripts[a.file_path];
      if (s == null) {
        if (!a.className) return text('className required to create script', true);
        s = '';
      }
      for (const e of a.edits ?? []) {
        if (e.old_string === '') s = e.new_string + s;
        else if (!s.includes(e.old_string)) return text(`old_string not found: ${e.old_string}`, true);
        else s = s.replace(e.old_string, e.new_string);
      }
      scripts[a.file_path] = s;
      return text(`Edited ${a.file_path}`);
    }
    case 'get_console_output':
      return text(Array.from({ length: 3000 }, (_, i) => `[info] line ${i % 3 === 0 ? "repeat" : i}`).join('\n'));
    default:
      return text(`Unknown tool ${name}`, true);
  }
}
let buf = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', (c) => {
  buf += c;
  let i;
  while ((i = buf.indexOf('\n')) >= 0) {
    const line = buf.slice(0, i).trim();
    buf = buf.slice(i + 1);
    if (!line) continue;
    const m = JSON.parse(line);
    if (m.id === undefined) continue;
    let result;
    if (m.method === 'initialize') result = { protocolVersion: m.params.protocolVersion, capabilities: { tools: {} }, serverInfo: { name: 'mock-roblox-studio', version: '0.0.1' } };
    else if (m.method === 'tools/list') result = { tools };
    else if (m.method === 'tools/call') result = call(m.params.name, m.params.arguments ?? {});
    else if (m.method === 'ping') result = {};
    else {
      process.stdout.write(JSON.stringify({ jsonrpc: '2.0', id: m.id, error: { code: -32601, message: 'not found' } }) + '\n');
      continue;
    }
    process.stdout.write(JSON.stringify({ jsonrpc: '2.0', id: m.id, result }) + '\n');
  }
});
process.stdin.on('end', () => process.exit(0));
