import { describe, expect, it, beforeAll } from 'vitest';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

let mod: {
  files: typeof import('../src/server/services/files');
  plan: typeof import('../src/server/agents/plan');
  context: typeof import('../src/server/services/context');
  mcp: typeof import('../src/server/roblox/mcpClient');
  claude: typeof import('../src/server/providers/claude');
  codex: typeof import('../src/server/providers/codex');
  util: typeof import('../src/server/core/util');
};

beforeAll(async () => {
  process.env.BLOXADE_DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'bx-unit-'));
  process.env.BLOXADE_QUIET = '1';
  mod = {
    files: await import('../src/server/services/files'),
    plan: await import('../src/server/agents/plan'),
    context: await import('../src/server/services/context'),
    mcp: await import('../src/server/roblox/mcpClient'),
    claude: await import('../src/server/providers/claude'),
    codex: await import('../src/server/providers/codex'),
    util: await import('../src/server/core/util'),
  };
});

describe('file ownership & scoping', () => {
  it('matches owned paths, folders and globs', () => {
    const { matchOwned } = mod.files;
    expect(matchOwned(['src/shop/'], 'src/shop/Ui.lua')).toBe(true);
    expect(matchOwned(['src/shop'], 'src/shop/Ui.lua')).toBe(true);
    expect(matchOwned(['src/**/*.lua'], 'src/a/b/c.lua')).toBe(true);
    expect(matchOwned(['src/*.lua'], 'src/a/b.lua')).toBe(false);
    expect(matchOwned(['src/Prices.lua'], 'src/Inventory.lua')).toBe(false);
    expect(matchOwned([], 'x')).toBe(false);
  });

  it('refuses paths that escape the project folder', () => {
    const root = fs.mkdtempSync(path.join(os.tmpdir(), 'bx-root-'));
    fs.writeFileSync(path.join(root, 'ok.txt'), 'hi');
    expect(mod.files.safeResolve(root, 'ok.txt')).toBe(path.join(root, 'ok.txt'));
    expect(() => mod.files.safeResolve(root, '../etc/passwd')).toThrow(/outside/);
    expect(() => mod.files.safeResolve(root, '/../../x')).toThrow();
  });

  it('lock table detects conflicting owners', () => {
    const t = new mod.files.LockTable();
    expect(t.claim('a/b.lua', { id: 't1', label: 'Agent 1' }).ok).toBe(true);
    expect(t.claim('a/b.lua', { id: 't1', label: 'Agent 1' }).ok).toBe(true);
    const r = t.claim('a/b.lua', { id: 't2', label: 'Agent 2' });
    expect(r.ok).toBe(false);
    t.release('t1');
    expect(t.claim('a/b.lua', { id: 't2', label: 'Agent 2' }).ok).toBe(true);
  });

  it('snapshots and diffs project files, and restores content', () => {
    const root = fs.mkdtempSync(path.join(os.tmpdir(), 'bx-snap-'));
    fs.writeFileSync(path.join(root, 'a.lua'), 'return 1\n');
    const before = mod.files.snapshot(root).snap;
    fs.writeFileSync(path.join(root, 'a.lua'), 'return 2\n');
    fs.writeFileSync(path.join(root, 'b.lua'), 'new\n');
    const changes = mod.files.diffSnapshots(before, mod.files.snapshot(root).snap);
    expect(changes.map((c) => `${c.change}:${c.path}`)).toEqual(['modified:a.lua', 'added:b.lua']);
    const diff = mod.files.unifiedDiff('a.lua', changes[0].beforeHash, changes[0].afterHash);
    expect(diff).toContain('-return 1');
    expect(diff).toContain('+return 2');
    mod.files.restoreFile(root, 'a.lua', changes[0].beforeHash);
    mod.files.restoreFile(root, 'b.lua', null);
    expect(fs.readFileSync(path.join(root, 'a.lua'), 'utf8')).toBe('return 1\n');
    expect(fs.existsSync(path.join(root, 'b.lua'))).toBe(false);
  });
});

describe('coordinator plan parsing', () => {
  it('extracts JSON from prose/code fences and limits task count', () => {
    const text = 'Here you go:\n```json\n{"rationale":"r","tasks":[{"key":"a","title":"A","description":"d","provider":"claude","ownedPaths":["src/a/"]},{"key":"b","title":"B","description":"d","ownedPaths":["src/b/"],"dependsOn":["a"]},{"key":"c","title":"C","description":"d"}]}\n```';
    const p = mod.plan.parsePlan(text, 2);
    expect(p.tasks).toHaveLength(2);
    expect(p.tasks[0].key).toBe('t1');
    expect(p.tasks[1].dependsOn).toEqual(['t1']);
    expect(p.tasks[1].provider).toBe('any');
  });

  it('removes dependency cycles', () => {
    const p = mod.plan.parsePlan(JSON.stringify({ tasks: [{ key: 't1', title: 'a', dependsOn: ['t2'] }, { key: 't2', title: 'b', dependsOn: ['t1'] }] }), 5);
    const edges = p.tasks.flatMap((t) => t.dependsOn.map((d) => `${t.key}->${d}`));
    expect(edges.length).toBe(1);
  });

  it('serializes parallel tasks that share files', () => {
    const p = mod.plan.parsePlan(JSON.stringify({ tasks: [{ key: 't1', title: 'ui', ownedPaths: ['src/shop/'] }, { key: 't2', title: 'server', ownedPaths: ['src/shop/Server.lua'] }, { key: 't3', title: 'data', ownedPaths: ['src/data/'] }] }), 5);
    expect(p.tasks[1].dependsOn).toContain('t1');
    expect(p.tasks[2].dependsOn).toEqual([]);
    expect(p.notes.join(' ')).toMatch(/share files/);
  });

  it('rejects text without a plan', () => {
    expect(() => mod.plan.parsePlan('no json here', 3)).toThrow();
  });
});

describe('context engine', () => {
  it('ranks relevant files and skips files already shared', () => {
    const root = fs.mkdtempSync(path.join(os.tmpdir(), 'bx-ctx-'));
    fs.mkdirSync(path.join(root, 'src'));
    fs.writeFileSync(path.join(root, 'src', 'ShopServer.lua'), 'local function purchase(player, item)\n  -- validate price\nend\n'.repeat(5));
    fs.writeFileSync(path.join(root, 'src', 'Weather.lua'), 'local rain = true\n'.repeat(20));
    const project: any = { id: 'p1', name: 'Test', memory: 'Uses Knit.', folderPath: root, description: '', instructions: '' };
    const pack = mod.context.buildContextPack({ project, query: 'fix the shop purchase validation', mode: 'balanced' })!;
    expect(pack.text).toContain('ShopServer.lua');
    expect(pack.text).not.toContain('Weather.lua"');
    expect(pack.text).toContain('Uses Knit.');
    const again = mod.context.buildContextPack({ project, query: 'fix the shop purchase validation', mode: 'balanced', alreadySent: pack.files, includeTree: false, includeMemory: false })!;
    expect(again.skippedUnchanged).toContain('src/ShopServer.lua');
    expect(again.text).not.toContain('local function purchase');
  });

  it('compresses large tool output (repeats + head/tail)', () => {
    const big = Array.from({ length: 2000 }, (_, i) => (i % 2 ? 'same line' : `unique ${i}`)).join('\n') + '\n' + 'x\n'.repeat(500);
    const r = mod.context.compressOutput(big, 3000);
    expect(r.text.length).toBeLessThan(3400);
    expect(r.text).toMatch(/BLOXADE trimmed|repeated/);
    expect(r.saved).toBeGreaterThan(0);
    expect(mod.context.compressOutput('small', 3000).text).toBe('small');
  });
});

describe('integration helpers', () => {
  it('parses the official Roblox MCP command line', () => {
    process.env.LOCALAPPDATA = 'C:\\Users\\me\\AppData\\Local';
    const r = mod.mcp.parseCommandLine('cmd.exe /c %LOCALAPPDATA%\\Roblox\\mcp.bat');
    expect(r).toEqual({ command: 'cmd.exe', args: ['/c', 'C:\\Users\\me\\AppData\\Local\\Roblox\\mcp.bat'] });
    expect(mod.mcp.parseCommandLine('"C:\\Program Files\\x.exe" --stdio').command).toBe('C:\\Program Files\\x.exe');
  });

  it('classifies Claude Code permission requests', () => {
    expect(mod.claude.classifyClaudeTool('Edit', { file_path: 'a.lua' }).kind).toBe('file_edit');
    expect(mod.claude.classifyClaudeTool('Bash', { command: 'ls' }).command).toBe('ls');
    expect(mod.claude.classifyClaudeTool('WebFetch', { url: 'x' }).kind).toBe('tool');
  });

  it('maps Codex rate limits to labelled windows', () => {
    const l = mod.codex.codexLimits({ primary: { usedPercent: 30, windowDurationMins: 300, resetsAt: 1 }, secondary: { usedPercent: 70, windowDurationMins: 10080, resetsAt: null } });
    expect(l.windows.map((w) => w.label)).toEqual(['5-hour window', 'Weekly']);
    expect(l.source).toBe('codex');
  });

  it('validates CLI-bound tokens', () => {
    expect(mod.util.safeToken('claude-opus-5-5', 'model')).toBe('claude-opus-5-5');
    expect(mod.util.safeToken('sonnet[1m]', 'model')).toBe('sonnet[1m]');
    expect(() => mod.util.safeToken('x; rm -rf /', 'model')).toThrow();
    expect(() => mod.util.safeToken('a"b', 'model')).toThrow();
  });
});
