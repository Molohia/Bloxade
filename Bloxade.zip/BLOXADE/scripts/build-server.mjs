// Bundles the backend, launcher and MCP bridge into self-contained ESM files under app/.
// The shipped app therefore needs only Node.js — no npm install on the user's machine.
import { build } from 'esbuild';
import { fileURLToPath } from 'node:url';
import { cpSync } from 'node:fs';

const root = fileURLToPath(new URL('..', import.meta.url));
const banner = {
  js: "import { createRequire as __bxCreateRequire } from 'node:module'; const require = __bxCreateRequire(import.meta.url);",
};
const common = {
  bundle: true,
  platform: 'node',
  format: 'esm',
  target: 'node22',
  external: ['node:*'],
  banner,
  logLevel: 'info',
  alias: { '@shared': root + 'src/shared' },
};
await build({ ...common, entryPoints: [root + 'src/server/main.ts'], outfile: root + 'app/server.mjs' });
await build({ ...common, entryPoints: [root + 'src/bridge/mcp-bridge.ts'], outfile: root + 'app/mcp-bridge.mjs' });
await build({ ...common, entryPoints: [root + 'src/server/launcher.ts'], outfile: root + 'app/launcher.mjs' });
cpSync(root + 'scripts/setup-node.ps1', root + 'app/setup-node.ps1');
