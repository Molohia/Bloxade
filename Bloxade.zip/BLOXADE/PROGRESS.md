# BLOXADE — implementation progress

This file tracks status so work can continue across sessions.

| Phase | Scope | Status |
|---|---|---|
| 1 | Localhost foundation, design system, five themes plus custom accent, collapsible navigation, SQLite, SSE | ✅ Done |
| 2 | Persistent chats; Claude Code (stream-json and control protocol) and Codex (`app-server`) integrations; model, effort and mode selection | ✅ Done |
| 3 | Multi-account manager: isolated profiles, official sign-in flows, status, reported usage windows | ✅ Done |
| 4 | Projects: scoped folders, file browser, change tracking with diff and revert, instructions, memory, defaults | ✅ Done |
| 5 | Roblox Studio MCP: client, write queue, permissions, script locks, read cache, output trimming, agent bridge, console, diagnostics | ✅ Done |
| 6 | Multi-agent orchestration: coordinator planning, ownership, dependencies, parallelism, conflict approvals, review/accept/revert, retries, report | ✅ Done |
| 7 | Context engine (context packs, dedupe, caching, efficiency modes) and usage analytics (verified kept separate from estimated) | ✅ Done |
| 8 | Onboarding, settings, launcher (portable Node), tests, documentation | ✅ Done |

## Verified facts this build relies on

- **Claude Code 2.1.312**
  - flags: `-p`, `--input-format/--output-format stream-json`, `--include-partial-messages`, `--permission-prompt-tool stdio`, `--effort low|medium|high|xhigh|max`, `--resume`, `--fork-session`, `--resume-session-at`, `--session-id`, `--tools ""`, `--mcp-config`, `--allowedTools`, `--append-system-prompt`
  - `claude auth login|status --json|logout`
  - `CLAUDE_CONFIG_DIR` gives per-account isolation
  - the `rate_limit_event` stream event carries the 5-hour and weekly utilization
  - the initialize control request returns models with their supported effort levels
- **Codex 0.165.0 `app-server` v2**
  - `initialize`, `account/read`, `account/login/start` (`chatgpt`, `chatgptDeviceCode`), `account/login/completed`, `account/rateLimits/read|updated`
  - `model/list` with `includeHidden`, `thread/start|resume|fork(lastTurnId)`, `turn/start` (with `effort`), `turn/interrupt`
  - item and approval notifications and requests
  - `config` dotted keys at thread start (MCP server launch confirmed)
- **Roblox Studio MCP:** official command `cmd.exe /c %LOCALAPPDATA%\Roblox\mcp.bat` over stdio. Every tool takes `studio_id`; `list_roblox_studios` returns the open instances.

## Known limitations

- The CLIs cannot be paused mid-task. *Pause* on a run stops new tasks from starting while the running ones finish.
- Codex sign-in uses port 1455, so sign in one Codex account at a time.
- Agents that write files with shell commands can't be blocked per file in advance. Those commands go through the *commands* approval policy, and any changes they make are still detected afterwards and attributed or flagged for review.
- Git worktree isolation per agent is not implemented. Isolation relies on file ownership, locks, conflict approvals and snapshot-based detection and revert.

## Ideas for next steps

- Optional git-worktree mode for projects that are git repositories.
- A system-tray launcher (Electron or Tauri) instead of the console window.
- More project-memory tooling, such as diffing memory versions.
