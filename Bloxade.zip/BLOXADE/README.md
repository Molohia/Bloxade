# BLOXADE

**BLOXADE is an independent, local-first AI development workspace built for Roblox creators.** It brings Claude Code, OpenAI Codex, project management, coordinated AI agents, and Roblox Studio tools into one interface so developers can plan, build, inspect, test, and improve Roblox experiences from a single Windows workspace.

The application runs locally at **http://127.0.0.1:3000**. It is a development tool, **not** a Roblox game, a Roblox Studio plugin by itself, or an official Roblox/OpenAI/Anthropic product.

### Creator

**Created and owned by Blox_soward** (Roblox), also known as **knz1w** (Discord) and **molohia** (GitHub).

| Platform | Creator handle |
|---|---|
| Roblox | `Blox_soward` |
| Discord | `knz1w` |
| GitHub | [`molohia`](https://github.com/molohia) |

For full project background, goals, features, architecture, and current limitations, see **[PROJECT_DESCRIPTION.md](PROJECT_DESCRIPTION.md)**. For attribution and publication notes, see **[AUTHORS.md](AUTHORS.md)**.

---

## Start it

1. Double-click **`START_BLOXADE.bat`**.
   - On first run it downloads a private, checksum-verified copy of Node.js into `%LOCALAPPDATA%\BLOXADE\runtime` (about 30 MB, no admin rights, no system changes). If Node.js 22.13+ is already installed, that copy is used instead.
   - It starts the server, waits until it answers, and opens your browser.
2. Keep the black BLOXADE window open while you work. Close it, or run `STOP_BLOXADE.bat`, to stop everything, including any running AI sessions.
3. The setup guide walks you through checking your tools, connecting accounts, connecting Roblox Studio, choosing a theme and creating your first project.

**Requirements:** Windows 10/11, plus at least one of:

- **Claude Code**. Install it in PowerShell with `irm https://claude.ai/install.ps1 | iex`.
- **Codex**. Use the official installer or the IDE extension; BLOXADE finds `codex.exe` automatically.

For Roblox work you also need Roblox Studio with the MCP server turned on (see below).

---

## What you get

| Area | What it does |
|---|---|
| **Chat** | Real streaming replies with Markdown, highlighted code and copy buttons, collapsible tool calls, thinking blocks, attachments (images, text, files), editing, regenerating, branching, search (Ctrl+K), pinning and renaming. Several chats can run at the same time. |
| **Every model, every effort** | Claude models come from the CLI's own model list (aliases plus every non-retired version). Codex models come from `codex app-server model/list`, including hidden models. Each model shows only the effort levels it supports (for example low → max, or low → ultra). You can also enter any custom model ID. |
| **Chat vs Cowork** | **Chat** is conversation only, with no file or tool access. **Cowork** lets the AI read and edit the project folder and use Roblox Studio, with approvals for risky actions. |
| **Accounts** | Unlimited Claude and Codex accounts. Each one has its own isolated profile (`CLAUDE_CONFIG_DIR` / `CODEX_HOME`) and signs in with the official flow. You can rename, set a default, enable or disable, sign out, remove, or open a terminal for any account. Account cards show the usage windows each CLI reports. |
| **Projects** | Each project has a folder, instructions, memory, chats, a file browser, a change history with diffs and one-click revert, agents, tasks and default model settings. |
| **Agents** | A coordinator splits a request into the fewest sensible tasks and assigns Claude and Codex agents. Tasks have file ownership, dependencies, parallel execution, locks, conflict approvals, review/accept/revert, retries, a live task graph, an inspect drawer and a unified final report. |
| **Roblox Studio** | BLOXADE connects once to the official Studio MCP server and routes every agent through one queue. That queue applies per-tool permissions (Allow/Ask/Block), script locks, a serialized write queue, a shared read cache and output trimming. The page also has a Studio console, diagnostics and an activity log. |
| **Efficiency engine** | Economy / Balanced / Performance / Maximum Quality modes control context budgets, parallelism, retries and how thorough the final check is. Targeted context packs replace whole files, files already shared aren't resent, project memory is reused, and big tool output is compressed. |
| **Usage** | Verified token counts and the CLI-reported cost, kept separate from BLOXADE's own estimates. Also shows task statistics, a timeline, provider and model comparisons, and account limits. |
| **Themes** | Dark, Light, Midnight, OLED Black, Slate, plus any accent color. Your choice persists. |

---

## Roblox Studio setup

1. Open Roblox Studio and open your place.
2. Go to **Assistant → ⋯ → Manage MCP Servers** and turn on **Enable Studio as MCP server**.
3. In BLOXADE, open **Connections → Roblox Studio** and press **Test connection**.

BLOXADE starts the official server with `cmd.exe /c %LOCALAPPDATA%\Roblox\mcp.bat`, the command Roblox documents. In any project with Roblox enabled, Cowork chats and agents automatically get the Studio tools.

---

## How sign-in and isolation work (and what BLOXADE never does)

- **Claude Code.** *Sign in* opens a window that runs the official `claude auth login` with that account's own `CLAUDE_CONFIG_DIR`. Your browser shows the official Claude page.
- **Codex.** *Sign in with ChatGPT* uses the official `account/login/start` flow of `codex app-server`, which opens the OpenAI page in your browser. A device-code option is also available.
- BLOXADE **never** asks for or stores passwords, API keys, OAuth tokens or cookies. It also never reads the credential files inside profile folders.
- Usage limits are shown **only when the CLI reports them**. BLOXADE never invents quotas or "messages left". It **does not** switch accounts automatically when a limit is hit; each account is subject to its provider's terms.
- Codex's ChatGPT sign-in uses a fixed local port (1455), so sign in one Codex account at a time.

---

## Where your data lives

| What | Where |
|---|---|
| App data (database, logs, attachments, profiles) | `%LOCALAPPDATA%\BLOXADE` (you can open it from Settings → Privacy) |
| Program files | This folder. Copy it anywhere. |
| Network | The server only binds to `127.0.0.1`, and requests from other websites are rejected. |

---

## For developers

```
npm install          # dev dependencies (only needed to change the code)
npm run dev:server   # backend on :3000 (tsx)
npm run dev:web      # Vite dev server on :5173 with /api proxy
npm run build        # typecheck + build frontend (app/public) + bundle backend (app/*.mjs)
npm test             # unit + integration tests (use the mock CLIs in tests/fixtures)
```

**Architecture**

- **Frontend:** React 19 + TypeScript + Vite + Tailwind 4 + Radix UI + Lucide + Zustand (`src/web`).
- **Backend:** Node.js + TypeScript, using the built-in `node:sqlite`. There is no native addon and no install step on the user's PC (`src/server`). esbuild bundles it into `app/server.mjs`.
- **Live updates:** one Server-Sent Events stream (`/api/events`).
- **Claude Code integration:** `claude -p --input-format/--output-format stream-json` with the CLI's control protocol for permission prompts, interrupts and model discovery. Session resume and fork use `--resume`, `--fork-session` and `--resume-session-at`.
- **Codex integration:** the official `codex app-server` JSON-RPC protocol (threads, turns, approvals, `model/list`, account and rate limits).
- **Roblox integration:** BLOXADE is an MCP **client** of Roblox Studio and an MCP **server** for the agent CLIs, through `app/mcp-bridge.mjs`.

See `PROGRESS.md` for implementation status and `TESTING.md` for the test checklist.

---

## Publishing and attribution

This repository identifies the project's creator using public handles only. **No personal email, real name, or account credentials are required to credit the creator.** If you publish the project, remember that showing all three handles links those identities publicly.

BLOXADE is an independent community-made development tool. Names such as Roblox, Roblox Studio, Claude, Claude Code, ChatGPT, and Codex refer to third-party products; their respective owners are not claimed to endorse or sponsor this project.

**License:** No open-source license is included in this archive. The presence of source code does not, by itself, grant permission for redistribution or modification. The owner should choose and add a `LICENSE` file before making licensing promises.

**Implementation status:** The included `PROGRESS.md` records completed implementation phases, and `TESTING.md` describes automated and manual testing. Those files are project records, not a guarantee that every integration works on every Windows computer or with future CLI/Studio releases.
