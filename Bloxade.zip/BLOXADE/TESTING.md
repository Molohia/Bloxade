# Testing BLOXADE

## Automated tests

```
npm test
```

There are 34 tests in two suites.

- **`tests/unit.test.ts`** covers:
  - file ownership globs and path-escape protection
  - lock table, snapshots, diffs and revert
  - coordinator plan parsing: cycle removal and serializing tasks that share files
  - context ranking, including not resending files the session already has
  - tool-output compression
  - Roblox MCP command parsing
  - permission classification, Codex limit mapping and CLI argument validation
- **`tests/integration.test.ts`** starts the real server and drives it over HTTP. It covers:
  - security: host and origin checks, and mutations without the required header
  - settings persistence and CLI detection
  - multiple isolated accounts
  - model and effort discovery for both providers
  - Claude chat: streaming, verified usage, resume, regenerate (fork) and branch
  - Codex chat: streaming, verified usage, rate limits and command approval
  - stopping a running turn and searching chats
  - project file scoping, plus edit approval, recorded diff, revert and denial
  - Roblox: connect, run tool calls, the agent bridge with write approval, output trimming and rejection of a bad token
  - parallel multi-agent run with dependency ordering and a final report
  - usage reporting

The integration tests use **test fixtures** in `tests/fixtures/` that imitate the official protocols (`mock-claude.mjs`, `mock-codex.mjs`, `mock-roblox-mcp.mjs`). They exist only for tests; the app itself always talks to the real CLIs and the real Studio server.

### Also verified during development against the real tools (Claude Code 2.1.312, Codex 0.165.0)

- Real Claude Code turns:
  - chat streaming
  - a Cowork edit of a Luau file with change tracking
  - a shell command
  - regenerate from a checkpoint
  - a Cowork turn that read and edited a Studio script through the BLOXADE bridge, including the write approval
- A real coordinator run, which planned one task (it judged one agent enough), executed it and wrote a report.
- A real three-task run with two agents in parallel plus a dependent check task.
- Real `codex app-server` handshake, `model/list`, `account/read`, and per-thread MCP server config. A ChatGPT sign-in was not possible in the build environment, so Codex turns are covered by the protocol fixture; check them on your PC with the checklist below.

## Manual checklist (on your PC)

### Startup

- [ ] Double-click `START_BLOXADE.bat`. On first run it downloads Node.js, then opens http://127.0.0.1:3000.
- [ ] Run `START_BLOXADE.bat` again while BLOXADE is running. It only opens the browser and says it is already running.
- [ ] Close the BLOXADE window. Refreshing the browser now shows "Can't reach the BLOXADE server".

### Claude account sign-in

- [ ] Accounts → Add account → Claude Code → *Use this computer's existing sign-in*. The card turns **Signed in** if `claude` is already logged in.
- [ ] Add account → Claude Code → *New isolated account* → Sign in. A console window runs `claude auth login` and your browser opens the Claude page. After approving, the card turns **Signed in** within a few seconds and shows your email.
- [ ] Add a second isolated Claude account with a different login. Both cards show different emails.
- [ ] Send a message with each account. After the first reply, the 5-hour and weekly bars appear.

### Codex account sign-in

- [ ] Add account → Codex → Sign in with ChatGPT. The browser opens the OpenAI page; after approving, the card shows **Signed in** with your email and plan.
- [ ] The rate-limit bars appear on the card (reported by Codex).
- [ ] Optional: try *Device code* in the add dialog.

### Chats

- [ ] The model picker lists the Claude models from your CLI plus specific versions; the Codex list comes from `model/list`.
- [ ] Changing the model changes the available effort levels.
- [ ] Chat mode: ask a question; the reply streams. Regenerate, edit your last message, and branch all work.
- [ ] Cowork mode in a project with a folder: ask for a small file change. If edits are set to *Ask*, an approval card appears top-right. The change then shows in Project → Files → Changes, and Revert works.
- [ ] Run two chats at the same time on different accounts.
- [ ] Stop a long reply with the stop button or Esc.

### Roblox Studio

- [ ] In Studio: Assistant → ⋯ → Manage MCP Servers → *Enable Studio as MCP server*.
- [ ] BLOXADE → Roblox Studio → Test connection. It shows *Connected* and your place name, and the tool list appears.
- [ ] Studio console: run `get_studio_state`, then `search_game_tree` with `{"datamodel_type":"Edit","max_depth":2}`.
- [ ] In a Roblox-enabled project, Cowork chat: "List the scripts in ServerScriptService". The tool calls show as *Studio · …*.
- [ ] Ask for a script change. The write request (`multi_edit` / `execute_luau`) shows an approval; after approval the change appears in Studio. The Activity page lists the calls.
- [ ] Set a tool to *Block* on the Roblox page and confirm agents can no longer use it.

### Agents

- [ ] Agents → New run: describe a feature and click Plan & start. The coordinator plans the tasks and the task graph appears.
- [ ] Tasks with separate paths run in parallel; dependent tasks wait for the ones they depend on.
- [ ] Inspect shows the live transcript. Stop and Retry work.
- [ ] Turn on Settings → Agents → *Require review*. Finished tasks wait in **Reviewing**; Accept and Revert both work.
- [ ] The final report appears when the run finishes.

### Settings and themes

- [ ] Switch through all five themes and a custom accent, restart BLOXADE, and confirm the theme is kept.
- [ ] Change the efficiency mode and confirm the context pack size changes (Project → Overview → Context pack).
