import { pathToFileURL } from 'node:url';
import type { Server } from 'node:http';
import { ensureDirs, PUBLIC_DIR, DATA_DIR } from './core/paths';
import { db } from './core/db';
import { getSettings } from './core/settings';
import { createServer } from './core/http';
import { events } from './core/events';
import { logger } from './core/log';
import { killAll } from './core/proc';
import { runtime, VERSION } from './core/runtime';
import { buildRoutes } from './api';
import { detectCli } from './providers/resolve';
import { refreshCatalog } from './providers/models';
import { stopAllCodex } from './providers/codex';
import { listAccounts, refreshAllAccounts, resolveAccount } from './services/accounts';
import { recoverInterrupted, stopAllChats } from './services/chats';
import { recoverRuns, stopAllTasks } from './agents/orchestrator';
import { denyAll } from './services/approvals';
import { roblox } from './roblox/manager';

const log = logger('server');

export interface StartOptions {
  port?: number;
  host?: string;
  background?: boolean;
}

let server: Server | null = null;
let stopping = false;

export function shutdown(code = 0) {
  if (stopping) return;
  stopping = true;
  log.info('shutting down');
  try {
    denyAll('BLOXADE is shutting down');
    stopAllChats();
    stopAllTasks();
    stopAllCodex();
    roblox.shutdown();
    events.closeAll();
    killAll();
    server?.close();
    db().close();
  } catch (e) {
    log.warn('error during shutdown', e);
  }
  setTimeout(() => process.exit(code), 300).unref();
}

export async function startServer(opts: StartOptions = {}): Promise<{ port: number; url: string }> {
  ensureDirs();
  db();
  const settings = getSettings();
  recoverInterrupted();
  recoverRuns();
  const host = opts.host ?? '127.0.0.1';
  const port = opts.port ?? Number(process.env.BLOXADE_PORT || settings.advanced.port || 3000);
  runtime.port = port;
  const router = buildRoutes({ shutdown: () => shutdown(0) });
  router.allowedHosts = new Set([`127.0.0.1:${port}`, `localhost:${port}`, `[::1]:${port}`]);
  server = createServer(router, PUBLIC_DIR);
  server.keepAliveTimeout = 65_000;
  server.requestTimeout = 0; // long-lived SSE + bridge calls
  await new Promise<void>((resolve, reject) => {
    server!.once('error', reject);
    server!.listen(port, host, () => resolve());
  });
  log.info(`BLOXADE ${VERSION} listening on http://${host}:${port}`, { data: DATA_DIR, public: PUBLIC_DIR });

  for (const sig of ['SIGINT', 'SIGTERM', 'SIGHUP', 'SIGBREAK'] as const) process.on(sig, () => shutdown(0));
  process.on('uncaughtException', (e) => log.error('uncaught exception', e));
  process.on('unhandledRejection', (e) => log.error('unhandled rejection', e as Error));

  // Background warm-up: CLI detection, account status, model lists, optional Studio auto-connect.
  if (!opts.background) {
    void (async () => {
      const [c1, c2] = await Promise.all([detectCli('claude'), detectCli('codex')]);
      log.info('CLI detection', { claude: c1.found ? c1.version : 'missing', codex: c2.found ? c2.version : 'missing' });
      events.emit('providers.updated', { claude: c1, codex: c2 });
      await refreshAllAccounts();
      for (const p of ['claude', 'codex'] as const) {
        if ((p === 'claude' ? c1 : c2).found && listAccounts().some((a) => a.provider === p)) {
          const cat = await refreshCatalog(p, resolveAccount(p));
          events.emit('models.updated', cat);
        }
      }
      if (getSettings().roblox.enabled && getSettings().roblox.autoConnect) roblox.connect().catch((e) => log.warn('Studio auto-connect failed', e.message));
    })().catch((e) => log.warn('warm-up failed', e));
  }
  return { port, url: `http://127.0.0.1:${port}` };
}

/** Port and browser preference saved in Settings (used by the launcher before starting). */
export function launchPreferences(): { port: number; openBrowser: boolean } {
  ensureDirs();
  const s = getSettings();
  return { port: s.advanced.port || 3000, openBrowser: s.general.openBrowserOnStart };
}

const isMain = (() => {
  try {
    return import.meta.url === pathToFileURL(process.argv[1] ?? '').href;
  } catch {
    return false;
  }
})();

if (isMain && process.env.BLOXADE_NO_AUTOSTART !== '1') {
  startServer().catch((e) => {
    console.error('\nBLOXADE could not start:', (e as Error).message);
    process.exit(1);
  });
}
