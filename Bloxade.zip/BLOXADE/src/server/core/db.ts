import { DatabaseSync, type SQLInputValue } from 'node:sqlite';
import path from 'node:path';
import fs from 'node:fs';
import { dirs } from './paths';
import { logger } from './log';

const log = logger('db');

const MIGRATIONS: string[] = [
  // 1 — initial schema
  `
  CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS accounts (
    id TEXT PRIMARY KEY, provider TEXT NOT NULL, name TEXT NOT NULL, profile_dir TEXT, is_system INTEGER NOT NULL DEFAULT 0,
    enabled INTEGER NOT NULL DEFAULT 1, is_default INTEGER NOT NULL DEFAULT 0, color TEXT NOT NULL DEFAULT '#6E7BFF',
    created_at INTEGER NOT NULL, last_used_at INTEGER, status TEXT NOT NULL DEFAULT 'unknown', status_detail TEXT,
    email TEXT, plan TEXT, auth_method TEXT, limits TEXT
  );
  CREATE TABLE IF NOT EXISTS projects (
    id TEXT PRIMARY KEY, name TEXT NOT NULL, icon TEXT NOT NULL, color TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
    folder_path TEXT, instructions TEXT NOT NULL DEFAULT '', memory TEXT NOT NULL DEFAULT '', memory_updated_at INTEGER,
    roblox_enabled INTEGER NOT NULL DEFAULT 0, defaults TEXT NOT NULL DEFAULT '{}', created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS chats (
    id TEXT PRIMARY KEY, title TEXT NOT NULL, project_id TEXT, pinned INTEGER NOT NULL DEFAULT 0, provider TEXT NOT NULL,
    account_id TEXT, model TEXT NOT NULL, effort TEXT NOT NULL, mode TEXT NOT NULL, created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL, preview TEXT, branched_from TEXT, provider_ref TEXT, context_sent TEXT
  );
  CREATE INDEX IF NOT EXISTS idx_chats_updated ON chats(updated_at DESC);
  CREATE INDEX IF NOT EXISTS idx_chats_project ON chats(project_id);
  CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY, chat_id TEXT NOT NULL, seq INTEGER NOT NULL, role TEXT NOT NULL, content TEXT NOT NULL,
    blocks TEXT NOT NULL DEFAULT '[]', status TEXT NOT NULL, attachments TEXT NOT NULL DEFAULT '[]', usage TEXT, error TEXT,
    provider TEXT, account_id TEXT, model TEXT, effort TEXT, mode TEXT, provider_ref TEXT, created_at INTEGER NOT NULL, duration_ms INTEGER
  );
  CREATE INDEX IF NOT EXISTS idx_messages_chat ON messages(chat_id, seq);
  CREATE TABLE IF NOT EXISTS attachments (
    id TEXT PRIMARY KEY, chat_id TEXT, name TEXT NOT NULL, mime TEXT NOT NULL, size INTEGER NOT NULL, kind TEXT NOT NULL,
    path TEXT NOT NULL, created_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS runs (
    id TEXT PRIMARY KEY, project_id TEXT, prompt TEXT NOT NULL, status TEXT NOT NULL, strategy TEXT NOT NULL,
    efficiency TEXT NOT NULL, coordinator TEXT NOT NULL, rationale TEXT, report TEXT, error TEXT, auto_approve TEXT NOT NULL,
    created_at INTEGER NOT NULL, started_at INTEGER, finished_at INTEGER
  );
  CREATE TABLE IF NOT EXISTS tasks (
    id TEXT PRIMARY KEY, run_id TEXT NOT NULL, key TEXT NOT NULL, title TEXT NOT NULL, description TEXT NOT NULL,
    status TEXT NOT NULL, agent_name TEXT NOT NULL, assignment TEXT NOT NULL, depends_on TEXT NOT NULL DEFAULT '[]',
    owned_paths TEXT NOT NULL DEFAULT '[]', files_touched TEXT NOT NULL DEFAULT '[]', tool_ops INTEGER NOT NULL DEFAULT 0,
    summary TEXT, error TEXT, attempts INTEGER NOT NULL DEFAULT 0, blocks TEXT NOT NULL DEFAULT '[]', usage TEXT,
    review TEXT, provider_ref TEXT, created_at INTEGER NOT NULL, started_at INTEGER, finished_at INTEGER
  );
  CREATE INDEX IF NOT EXISTS idx_tasks_run ON tasks(run_id);
  CREATE TABLE IF NOT EXISTS usage_events (
    id TEXT PRIMARY KEY, ts INTEGER NOT NULL, provider TEXT NOT NULL, account_id TEXT, model TEXT, kind TEXT NOT NULL,
    ref_id TEXT, input_tokens INTEGER NOT NULL DEFAULT 0, output_tokens INTEGER NOT NULL DEFAULT 0,
    cache_read INTEGER NOT NULL DEFAULT 0, cache_write INTEGER NOT NULL DEFAULT 0, reasoning INTEGER NOT NULL DEFAULT 0,
    cost_usd REAL, verified INTEGER NOT NULL DEFAULT 0, estimated_tokens INTEGER NOT NULL DEFAULT 0,
    context_saved INTEGER NOT NULL DEFAULT 0, duration_ms INTEGER, ok INTEGER NOT NULL DEFAULT 1
  );
  CREATE INDEX IF NOT EXISTS idx_usage_ts ON usage_events(ts);
  CREATE TABLE IF NOT EXISTS file_changes (
    id TEXT PRIMARY KEY, project_id TEXT NOT NULL, path TEXT NOT NULL, change TEXT NOT NULL, source TEXT NOT NULL,
    source_id TEXT, before_hash TEXT, after_hash TEXT, diff TEXT, created_at INTEGER NOT NULL, reverted INTEGER NOT NULL DEFAULT 0
  );
  CREATE INDEX IF NOT EXISTS idx_changes_project ON file_changes(project_id, created_at DESC);
  CREATE TABLE IF NOT EXISTS roblox_activity (
    id TEXT PRIMARY KEY, ts INTEGER NOT NULL, caller TEXT NOT NULL, tool TEXT NOT NULL, summary TEXT NOT NULL,
    status TEXT NOT NULL, duration_ms INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_roblox_ts ON roblox_activity(ts DESC);
  CREATE TABLE IF NOT EXISTS activity (
    id TEXT PRIMARY KEY, ts INTEGER NOT NULL, kind TEXT NOT NULL, label TEXT NOT NULL, detail TEXT NOT NULL DEFAULT '', ref_id TEXT
  );
  CREATE INDEX IF NOT EXISTS idx_activity_ts ON activity(ts DESC);
  CREATE TABLE IF NOT EXISTS kv_cache (key TEXT PRIMARY KEY, value TEXT NOT NULL, created_at INTEGER NOT NULL, expires_at INTEGER);
  `,
];

export class Db {
  readonly raw: DatabaseSync;
  readonly file: string;

  constructor(file = path.join(dirs.db, 'bloxade.sqlite')) {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    this.file = file;
    this.raw = new DatabaseSync(file);
    this.raw.exec('PRAGMA journal_mode = WAL; PRAGMA synchronous = NORMAL; PRAGMA foreign_keys = OFF; PRAGMA busy_timeout = 4000;');
    this.migrate();
  }

  private migrate() {
    this.raw.exec('CREATE TABLE IF NOT EXISTS _migrations (version INTEGER PRIMARY KEY, applied_at INTEGER NOT NULL)');
    const row = this.raw.prepare('SELECT MAX(version) AS v FROM _migrations').get() as { v: number | null };
    const current = row?.v ?? 0;
    for (let i = current; i < MIGRATIONS.length; i++) {
      this.raw.exec('BEGIN');
      try {
        this.raw.exec(MIGRATIONS[i]);
        this.raw.prepare('INSERT INTO _migrations (version, applied_at) VALUES (?, ?)').run(i + 1, Date.now());
        this.raw.exec('COMMIT');
        log.info(`applied migration ${i + 1}`);
      } catch (e) {
        this.raw.exec('ROLLBACK');
        throw e;
      }
    }
  }

  all<T = Record<string, unknown>>(sql: string, ...params: SQLInputValue[]): T[] {
    return this.raw.prepare(sql).all(...params) as T[];
  }

  get<T = Record<string, unknown>>(sql: string, ...params: SQLInputValue[]): T | undefined {
    return this.raw.prepare(sql).get(...params) as T | undefined;
  }

  run(sql: string, ...params: SQLInputValue[]) {
    return this.raw.prepare(sql).run(...params);
  }

  tx<T>(fn: () => T): T {
    this.raw.exec('BEGIN');
    try {
      const r = fn();
      this.raw.exec('COMMIT');
      return r;
    } catch (e) {
      this.raw.exec('ROLLBACK');
      throw e;
    }
  }

  /** Insert or replace a row from a plain object (keys = columns). */
  upsert(table: string, row: Record<string, SQLInputValue>) {
    const keys = Object.keys(row);
    const sql = `INSERT OR REPLACE INTO ${table} (${keys.join(',')}) VALUES (${keys.map(() => '?').join(',')})`;
    this.raw.prepare(sql).run(...keys.map((k) => row[k]));
  }

  update(table: string, id: string, patch: Record<string, SQLInputValue>) {
    const keys = Object.keys(patch);
    if (!keys.length) return;
    const sql = `UPDATE ${table} SET ${keys.map((k) => `${k} = ?`).join(', ')} WHERE id = ?`;
    this.raw.prepare(sql).run(...keys.map((k) => patch[k]), id);
  }

  sizeBytes(): number {
    try {
      return fs.statSync(this.file).size;
    } catch {
      return 0;
    }
  }

  close() {
    try {
      this.raw.close();
    } catch {
      /* ignore */
    }
  }
}

let instance: Db | null = null;
export function db(): Db {
  if (!instance) instance = new Db();
  return instance;
}
export function setDb(d: Db) {
  instance = d;
}

export const j = (v: unknown) => JSON.stringify(v ?? null);
export const b = (v: boolean | undefined | null) => (v ? 1 : 0);
