import http, { type IncomingMessage, type ServerResponse } from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { HttpError } from './util';
import { logger } from './log';

const log = logger('http');

export interface Ctx {
  req: IncomingMessage;
  res: ServerResponse;
  params: Record<string, string>;
  query: URLSearchParams;
  body: any;
}

type Handler = (ctx: Ctx) => unknown | Promise<unknown>;
interface Route {
  method: string;
  re: RegExp;
  keys: string[];
  handler: Handler;
  raw?: boolean;
}

const MIME: Record<string, string> = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.woff': 'font/woff',
  '.txt': 'text/plain; charset=utf-8',
  '.map': 'application/json',
};

export function mimeFor(file: string) {
  return MIME[path.extname(file).toLowerCase()] ?? 'application/octet-stream';
}

export class Router {
  private routes: Route[] = [];
  allowedHosts = new Set<string>();

  add(method: string, pattern: string, handler: Handler, opts: { raw?: boolean } = {}) {
    const keys: string[] = [];
    const re = new RegExp(
      '^' +
        pattern.replace(/\/:([a-zA-Z_]+)/g, (_m, k) => {
          keys.push(k);
          return '/([^/]+)';
        }) +
        '/?$',
    );
    this.routes.push({ method, re, keys, handler, raw: opts.raw });
  }
  get(p: string, h: Handler, o?: { raw?: boolean }) { this.add('GET', p, h, o); }
  post(p: string, h: Handler, o?: { raw?: boolean }) { this.add('POST', p, h, o); }
  patch(p: string, h: Handler) { this.add('PATCH', p, h); }
  put(p: string, h: Handler) { this.add('PUT', p, h); }
  delete(p: string, h: Handler) { this.add('DELETE', p, h); }

  /** Rejects requests that don't come from this app (DNS rebinding / cross-site requests). */
  private checkOrigin(req: IncomingMessage, isMutation: boolean, pathname: string): string | null {
    const host = (req.headers.host || '').toLowerCase();
    if (!this.allowedHosts.has(host)) return `Host '${host}' is not allowed`;
    const origin = req.headers.origin;
    if (origin) {
      try {
        const o = new URL(origin);
        if (!this.allowedHosts.has(o.host.toLowerCase())) return 'Cross-origin request blocked';
      } catch {
        return 'Invalid origin';
      }
    }
    if (isMutation && pathname.startsWith('/api/') && !pathname.startsWith('/api/bridge/')) {
      if (req.headers['x-bloxade'] !== '1') return 'Missing X-Bloxade header';
    }
    return null;
  }

  async handle(req: IncomingMessage, res: ServerResponse, publicDir: string) {
    const url = new URL(req.url || '/', 'http://localhost');
    const method = req.method || 'GET';
    const isMutation = !['GET', 'HEAD', 'OPTIONS'].includes(method);
    const blocked = this.checkOrigin(req, isMutation, url.pathname);
    if (blocked) {
      log.warn('blocked request', { path: url.pathname, reason: blocked });
      return sendJson(res, 403, { error: blocked });
    }
    if (method === 'OPTIONS') {
      res.writeHead(204);
      return res.end();
    }

    if (url.pathname.startsWith('/api/')) {
      for (const r of this.routes) {
        if (r.method !== method) continue;
        const m = r.re.exec(url.pathname);
        if (!m) continue;
        const params: Record<string, string> = {};
        r.keys.forEach((k, i) => (params[k] = decodeURIComponent(m[i + 1])));
        try {
          const body = isMutation && !r.raw ? await readJson(req) : undefined;
          const out = await r.handler({ req, res, params, query: url.searchParams, body });
          if (r.raw || res.headersSent) return;
          return sendJson(res, 200, out === undefined ? { ok: true } : out);
        } catch (e) {
          const err = e as HttpError;
          const status = err instanceof HttpError ? err.status : 500;
          if (status >= 500) log.error(`${method} ${url.pathname} failed`, e);
          if (!res.headersSent) sendJson(res, status, { error: err.message || 'Internal error', code: err.code });
          return;
        }
      }
      return sendJson(res, 404, { error: 'Not found' });
    }
    return serveStatic(res, publicDir, url.pathname);
  }
}

export function sendJson(res: ServerResponse, status: number, data: unknown) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
  });
  res.end(body);
}

const MAX_BODY = 40 * 1024 * 1024;
function readJson(req: IncomingMessage): Promise<any> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = [];
    let size = 0;
    req.on('data', (c: Buffer) => {
      size += c.length;
      if (size > MAX_BODY) {
        reject(new HttpError(413, 'Request body too large'));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')));
      } catch {
        reject(new HttpError(400, 'Invalid JSON body'));
      }
    });
    req.on('error', reject);
  });
}

function serveStatic(res: ServerResponse, publicDir: string, pathname: string) {
  const rel = decodeURIComponent(pathname).replace(/^\/+/, '');
  const target = path.resolve(publicDir, rel || 'index.html');
  const inside = target === publicDir || target.startsWith(publicDir + path.sep);
  let file = inside && fs.existsSync(target) && fs.statSync(target).isFile() ? target : path.join(publicDir, 'index.html');
  if (!fs.existsSync(file)) {
    res.writeHead(503, { 'Content-Type': 'text/plain; charset=utf-8' });
    return res.end('BLOXADE frontend build not found. Run `npm run build` in the BLOXADE folder.');
  }
  const isAsset = file.includes(`${path.sep}assets${path.sep}`);
  res.writeHead(200, {
    'Content-Type': mimeFor(file),
    'Cache-Control': isAsset ? 'public, max-age=31536000, immutable' : 'no-cache',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
  });
  fs.createReadStream(file).pipe(res);
}

export function createServer(router: Router, publicDir: string) {
  return http.createServer((req, res) => {
    router.handle(req, res, publicDir).catch((e) => {
      log.error('unhandled request error', e);
      if (!res.headersSent) sendJson(res, 500, { error: 'Internal error' });
    });
  });
}
