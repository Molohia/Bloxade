import path from 'node:path';
import os from 'node:os';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { IS_WIN } from './util';

/** Folder containing server.mjs (app/) in production, or src/server in dev. */
function detectAppDir(): string {
  try {
    const here = path.dirname(fileURLToPath(import.meta.url));
    return here;
  } catch {
    return process.cwd();
  }
}

export const APP_DIR = process.env.BLOXADE_APP_DIR || detectAppDir();

function findPublicDir(): string {
  const candidates = [
    path.join(APP_DIR, 'public'),
    path.join(APP_DIR, '..', 'app', 'public'),
    path.join(APP_DIR, '..', '..', 'app', 'public'),
    path.join(process.cwd(), 'app', 'public'),
  ];
  return candidates.find((p) => fs.existsSync(path.join(p, 'index.html'))) ?? candidates[0];
}

function findBridge(): string {
  const candidates = [
    path.join(APP_DIR, 'mcp-bridge.mjs'),
    path.join(APP_DIR, '..', 'app', 'mcp-bridge.mjs'),
    path.join(APP_DIR, '..', '..', 'app', 'mcp-bridge.mjs'),
    path.join(process.cwd(), 'app', 'mcp-bridge.mjs'),
  ];
  return candidates.find((p) => fs.existsSync(p)) ?? candidates[0];
}

export const PUBLIC_DIR = findPublicDir();
export const BRIDGE_SCRIPT = findBridge();

function defaultDataDir(): string {
  if (process.env.BLOXADE_DATA_DIR) return path.resolve(process.env.BLOXADE_DATA_DIR);
  if (IS_WIN) {
    const local = process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local');
    return path.join(local, 'BLOXADE');
  }
  return path.join(os.homedir(), '.bloxade');
}

export const DATA_DIR = defaultDataDir();

export const dirs = {
  data: DATA_DIR,
  db: path.join(DATA_DIR, 'db'),
  logs: path.join(DATA_DIR, 'logs'),
  profiles: path.join(DATA_DIR, 'profiles'),
  attachments: path.join(DATA_DIR, 'attachments'),
  blobs: path.join(DATA_DIR, 'blobs'),
  workspaces: path.join(DATA_DIR, 'workspaces'),
  runtime: path.join(DATA_DIR, 'runtime'),
};

export function ensureDirs() {
  for (const d of Object.values(dirs)) fs.mkdirSync(d, { recursive: true });
}

export function profileDir(provider: 'claude' | 'codex', accountId: string) {
  return path.join(dirs.profiles, provider, accountId);
}

/** Normalises a user-supplied absolute folder path (expands ~ and %VARS% on Windows). */
export function expandUserPath(p: string): string {
  let out = p.trim().replace(/^"(.*)"$/, '$1');
  if (out === '~' || out.startsWith('~/') || out.startsWith('~\\')) out = path.join(os.homedir(), out.slice(1));
  if (IS_WIN) out = out.replace(/%([^%]+)%/g, (m, name) => process.env[name] ?? m);
  return path.resolve(out);
}

export function toPosix(p: string) {
  return p.split(path.sep).join('/');
}
