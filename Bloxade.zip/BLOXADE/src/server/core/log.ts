import fs from 'node:fs';
import path from 'node:path';
import { dirs } from './paths';

type Level = 'debug' | 'info' | 'warn' | 'error';
const ORDER: Record<Level, number> = { debug: 10, info: 20, warn: 30, error: 40 };

export interface LogEntry {
  ts: number;
  level: Level;
  scope: string;
  msg: string;
  data?: unknown;
}

const ring: LogEntry[] = [];
let minLevel: Level = (process.env.BLOXADE_LOG_LEVEL as Level) || 'info';
let stream: fs.WriteStream | null = null;
let streamDay = '';

function fileStream() {
  const day = new Date().toISOString().slice(0, 10);
  if (stream && day === streamDay) return stream;
  try {
    stream?.end();
    fs.mkdirSync(dirs.logs, { recursive: true });
    stream = fs.createWriteStream(path.join(dirs.logs, `bloxade-${day}.log`), { flags: 'a' });
    streamDay = day;
  } catch {
    stream = null;
  }
  return stream;
}

export function setLogLevel(level: Level) {
  minLevel = level;
}

function scrub(data: unknown): unknown {
  if (data instanceof Error) return { error: data.message, stack: data.stack?.split('\n').slice(0, 4).join('\n') };
  return data;
}

function write(level: Level, scope: string, msg: string, data?: unknown) {
  const entry: LogEntry = { ts: Date.now(), level, scope, msg, data: scrub(data) };
  ring.push(entry);
  if (ring.length > 800) ring.splice(0, ring.length - 800);
  if (ORDER[level] < ORDER[minLevel]) return;
  const line = JSON.stringify(entry);
  fileStream()?.write(line + '\n');
  if (process.env.BLOXADE_QUIET !== '1') {
    const t = new Date(entry.ts).toLocaleTimeString();
    const tag = level === 'error' ? '\x1b[31mERR\x1b[0m' : level === 'warn' ? '\x1b[33mWRN\x1b[0m' : level === 'debug' ? '\x1b[90mDBG\x1b[0m' : '\x1b[36mINF\x1b[0m';
    const extra = data === undefined ? '' : ' ' + (typeof entry.data === 'string' ? entry.data : JSON.stringify(entry.data)).slice(0, 400);
    console.log(`${t} ${tag} [${scope}] ${msg}${extra}`);
  }
}

export function logger(scope: string) {
  return {
    debug: (msg: string, data?: unknown) => write('debug', scope, msg, data),
    info: (msg: string, data?: unknown) => write('info', scope, msg, data),
    warn: (msg: string, data?: unknown) => write('warn', scope, msg, data),
    error: (msg: string, data?: unknown) => write('error', scope, msg, data),
  };
}

export function recentLogs(limit = 300, level?: Level): LogEntry[] {
  const list = level ? ring.filter((e) => ORDER[e.level] >= ORDER[level]) : ring;
  return list.slice(-limit);
}
