import type { Settings } from '@shared/types';
import { db } from './db';
import { deepMerge, safeJson } from './util';
import { events } from './events';
import { setLogLevel } from './log';

export const DEFAULT_ROBLOX_COMMAND =
  process.platform === 'win32'
    ? 'cmd.exe /c %LOCALAPPDATA%\\Roblox\\mcp.bat'
    : process.platform === 'darwin'
      ? '/Applications/RobloxStudio.app/Contents/MacOS/StudioMCP'
      : '';

export const DEFAULT_SETTINGS: Settings = {
  general: {
    onboardingComplete: false,
    openBrowserOnStart: true,
    defaultProjectId: null,
    notifications: true,
    confirmDeletes: true,
    autoTitle: true,
  },
  appearance: {
    theme: 'dark',
    accent: '#7C7FFF',
    fontSize: 15,
    density: 'comfortable',
    sidebarCollapsed: false,
    reduceMotion: false,
  },
  providers: {
    claudePath: '',
    codexPath: '',
    defaultProvider: 'claude',
    defaultModels: { claude: 'default', codex: '' },
    defaultEfforts: { claude: '', codex: '' },
    defaultMode: 'chat',
    showHiddenModels: false,
    customModels: { claude: [], codex: [] },
  },
  agents: {
    maxConcurrent: null,
    routing: 'balanced',
    approvals: { edits: 'allow', commands: 'ask', unownedEdits: 'ask' },
    requireReview: false,
    approvalTimeoutSec: 600,
    useGitWorktrees: false,
  },
  context: {
    mode: 'balanced',
    budgetOverride: null,
    cache: true,
    primeChats: true,
    toolOutputCap: null,
    autoMemory: false,
  },
  roblox: {
    enabled: true,
    autoConnect: false,
    command: DEFAULT_ROBLOX_COMMAND,
    defaultStudioId: null,
    toolPolicies: {},
    cacheReads: true,
  },
  privacy: { keepAttachments: true, logPrompts: false },
  advanced: { port: 3000, logLevel: 'info', turnTimeoutMin: 45 },
};

let cache: Settings | null = null;

export function getSettings(): Settings {
  if (cache) return cache;
  const row = db().get<{ value: string }>('SELECT value FROM settings WHERE key = ?', 'app');
  cache = deepMerge(DEFAULT_SETTINGS, safeJson(row?.value, {}));
  setLogLevel(cache.advanced.logLevel);
  return cache;
}

export function updateSettings(patch: unknown): Settings {
  const next = deepMerge(getSettings(), patch);
  // clamp a few values that matter for safety/robustness
  next.appearance.fontSize = Math.min(20, Math.max(12, Number(next.appearance.fontSize) || 15));
  next.advanced.port = Math.min(65535, Math.max(1024, Number(next.advanced.port) || 3000));
  next.advanced.turnTimeoutMin = Math.min(240, Math.max(2, Number(next.advanced.turnTimeoutMin) || 45));
  next.agents.approvalTimeoutSec = Math.min(3600, Math.max(30, Number(next.agents.approvalTimeoutSec) || 600));
  if (next.agents.maxConcurrent != null) next.agents.maxConcurrent = Math.min(8, Math.max(1, Number(next.agents.maxConcurrent)));
  if (!/^#[0-9a-fA-F]{6}$/.test(next.appearance.accent)) next.appearance.accent = DEFAULT_SETTINGS.appearance.accent;
  db().run('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', 'app', JSON.stringify(next));
  cache = next;
  setLogLevel(next.advanced.logLevel);
  events.emit('settings.updated', next);
  return next;
}

/** Small persisted key/value store for internal state (model caches etc). */
export function kvGet<T>(key: string, fallback: T): T {
  const row = db().get<{ value: string; expires_at: number | null }>('SELECT value, expires_at FROM kv_cache WHERE key = ?', key);
  if (!row) return fallback;
  if (row.expires_at && row.expires_at < Date.now()) return fallback;
  return safeJson(row.value, fallback);
}

export function kvSet(key: string, value: unknown, ttlMs?: number) {
  db().run(
    'INSERT OR REPLACE INTO kv_cache (key, value, created_at, expires_at) VALUES (?, ?, ?, ?)',
    key,
    JSON.stringify(value),
    Date.now(),
    ttlMs ? Date.now() + ttlMs : null,
  );
}

export function kvDelete(prefix: string) {
  db().run("DELETE FROM kv_cache WHERE key LIKE ? || '%'", prefix);
}
