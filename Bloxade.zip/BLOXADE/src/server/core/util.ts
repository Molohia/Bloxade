import { randomBytes, createHash } from 'node:crypto';

const ALPHABET = '0123456789abcdefghijklmnopqrstuvwxyz';

/** Short, URL-safe, time-sortable id (prefix + base36 time + random). */
export function newId(prefix = ''): string {
  const t = Date.now().toString(36).padStart(9, '0');
  const bytes = randomBytes(8);
  let r = '';
  for (const b of bytes) r += ALPHABET[b % 36];
  return (prefix ? prefix + '_' : '') + t + r;
}

export function uuid(): string {
  return globalThis.crypto.randomUUID();
}

export const now = () => Date.now();

export function sha1(data: string | Buffer): string {
  return createHash('sha1').update(data).digest('hex');
}

export function sha256(data: string | Buffer): string {
  return createHash('sha256').update(data).digest('hex');
}

export function sleep(ms: number) {
  return new Promise<void>((r) => setTimeout(r, ms));
}

/** Rough token estimate (≈4 chars/token for English & code). Always labelled as an estimate in the UI. */
export function estimateTokens(text: string | number): number {
  const n = typeof text === 'number' ? text : text.length;
  return Math.ceil(n / 4);
}

export function truncate(text: string, max: number, suffix = '…'): string {
  if (text.length <= max) return text;
  return text.slice(0, Math.max(0, max - suffix.length)) + suffix;
}

export function safeJson<T>(text: string | null | undefined, fallback: T): T {
  if (text == null || text === '') return fallback;
  try {
    return JSON.parse(text) as T;
  } catch {
    return fallback;
  }
}

export function isPlainObject(v: unknown): v is Record<string, unknown> {
  return typeof v === 'object' && v !== null && !Array.isArray(v);
}

export function deepMerge<T>(base: T, patch: unknown): T {
  if (!isPlainObject(base) || !isPlainObject(patch)) return (patch === undefined ? base : (patch as T));
  const out: Record<string, unknown> = { ...(base as Record<string, unknown>) };
  for (const [k, v] of Object.entries(patch)) {
    if (v === undefined) continue;
    const cur = out[k];
    out[k] = isPlainObject(cur) && isPlainObject(v) ? deepMerge(cur, v) : v;
  }
  return out as T;
}

export class HttpError extends Error {
  constructor(public status: number, message: string, public code?: string) {
    super(message);
  }
}

export function assert(cond: unknown, status: number, message: string): asserts cond {
  if (!cond) throw new HttpError(status, message);
}

/** Validates a value against a tiny schema; throws 400 with a readable message. */
export function str(v: unknown, name: string, opts: { max?: number; min?: number; optional?: boolean } = {}): string {
  if (v == null && opts.optional) return '';
  if (typeof v !== 'string') throw new HttpError(400, `${name} must be text`);
  if (opts.min != null && v.trim().length < opts.min) throw new HttpError(400, `${name} is required`);
  if (opts.max != null && v.length > opts.max) throw new HttpError(400, `${name} is too long (max ${opts.max})`);
  return v;
}

export function oneOf<T extends string>(v: unknown, values: readonly T[], name: string, fallback?: T): T {
  if (v == null && fallback !== undefined) return fallback;
  if (typeof v === 'string' && (values as readonly string[]).includes(v)) return v as T;
  throw new HttpError(400, `${name} must be one of: ${values.join(', ')}`);
}

/** Model ids / effort names are passed as CLI arguments: keep them to a safe charset. */
export function safeToken(v: unknown, name: string, optional = false): string {
  if ((v == null || v === '') && optional) return '';
  if (typeof v !== 'string' || !/^[A-Za-z0-9._:\-[\]/@+]{1,120}$/.test(v)) {
    throw new HttpError(400, `${name} contains unsupported characters`);
  }
  return v;
}

export function debounce<A extends unknown[]>(fn: (...a: A) => void, ms: number) {
  let t: NodeJS.Timeout | null = null;
  let lastArgs: A;
  const d = (...a: A) => {
    lastArgs = a;
    if (t) return;
    t = setTimeout(() => {
      t = null;
      fn(...lastArgs);
    }, ms);
  };
  d.flush = () => {
    if (t) {
      clearTimeout(t);
      t = null;
      fn(...lastArgs);
    }
  };
  return d;
}

/** Collapse whitespace + make a one-line preview. */
export function preview(text: string, max = 140): string {
  return truncate(text.replace(/\s+/g, ' ').trim(), max);
}

export function titleFrom(text: string): string {
  const firstLine = text.replace(/```[\s\S]*?```/g, ' ').split('\n').map((l) => l.trim()).find(Boolean) ?? 'New chat';
  const clean = firstLine.replace(/^[#>*\-\s]+/, '').replace(/\s+/g, ' ');
  return truncate(clean || 'New chat', 60);
}

export const IS_WIN = process.platform === 'win32';
