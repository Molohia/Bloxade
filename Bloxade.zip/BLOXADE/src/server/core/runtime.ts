import fs from 'node:fs';
import path from 'node:path';
import { dirs, BRIDGE_SCRIPT } from './paths';

export const VERSION = '1.0.0';

export const runtime = {
  port: 3000,
  startedAt: Date.now(),
  get baseUrl() {
    return `http://127.0.0.1:${this.port}`;
  },
};

/** Writes an MCP config file that points a CLI at BLOXADE's Roblox bridge (stdio → BLOXADE → Studio). */
export function writeBridgeMcpConfig(token: string): string {
  const file = path.join(dirs.runtime, `mcp-${token.slice(0, 12)}.json`);
  const cfg = {
    mcpServers: {
      bloxade_roblox: {
        type: 'stdio',
        command: process.execPath,
        args: [BRIDGE_SCRIPT],
        env: { BLOXADE_URL: runtime.baseUrl, BLOXADE_BRIDGE_TOKEN: token },
      },
    },
  };
  fs.mkdirSync(dirs.runtime, { recursive: true });
  fs.writeFileSync(file, JSON.stringify(cfg, null, 2));
  return file;
}

export function bridgeServerSpec(token: string) {
  return {
    command: process.execPath,
    args: [BRIDGE_SCRIPT],
    env: { BLOXADE_URL: runtime.baseUrl, BLOXADE_BRIDGE_TOKEN: token },
  };
}

export function removeQuiet(file: string | null | undefined) {
  if (!file) return;
  try {
    fs.rmSync(file, { force: true });
  } catch {
    /* ignore */
  }
}
