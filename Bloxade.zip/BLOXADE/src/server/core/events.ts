import type { ServerResponse } from 'node:http';
import { EventEmitter } from 'node:events';

/** Server-Sent Events hub: one stream per browser tab carries every live update. */
class EventHub {
  private clients = new Set<ServerResponse>();
  private seq = 0;
  readonly local = new EventEmitter();
  private heartbeat: NodeJS.Timeout | null = null;

  constructor() {
    this.local.setMaxListeners(200);
  }

  attach(res: ServerResponse) {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive',
      'X-Accel-Buffering': 'no',
    });
    res.write(`retry: 1500\n\n`);
    this.clients.add(res);
    res.on('close', () => this.clients.delete(res));
    if (!this.heartbeat) {
      this.heartbeat = setInterval(() => {
        for (const c of this.clients) c.write(`: ping ${Date.now()}\n\n`);
      }, 15000);
      this.heartbeat.unref();
    }
  }

  emit(type: string, data: unknown) {
    const id = ++this.seq;
    const payload = `id: ${id}\nevent: message\ndata: ${JSON.stringify({ type, data })}\n\n`;
    for (const c of this.clients) {
      try {
        c.write(payload);
      } catch {
        this.clients.delete(c);
      }
    }
    this.local.emit(type, data);
  }

  get clientCount() {
    return this.clients.size;
  }

  closeAll() {
    for (const c of this.clients) {
      try {
        c.end();
      } catch {
        /* ignore */
      }
    }
    this.clients.clear();
    if (this.heartbeat) clearInterval(this.heartbeat);
    this.heartbeat = null;
  }
}

export const events = new EventHub();
