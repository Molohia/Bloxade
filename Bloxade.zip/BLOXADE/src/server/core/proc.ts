import { spawn, spawnSync, type ChildProcess, type SpawnOptions } from 'node:child_process';
import { IS_WIN, newId } from './util';
import { logger } from './log';

const log = logger('proc');

export interface TrackedProcess {
  id: string;
  pid: number | undefined;
  kind: string;
  label: string;
  startedAt: number;
  child: ChildProcess;
}

const registry = new Map<string, TrackedProcess>();

/** Spawns without a shell (arguments are never interpreted by cmd.exe/sh) and tracks the child for cleanup. */
export function spawnTracked(
  command: string,
  args: string[],
  opts: SpawnOptions & { kind: string; label: string },
): TrackedProcess {
  const { kind, label, ...spawnOpts } = opts;
  const child = spawn(command, args, {
    windowsHide: true,
    ...spawnOpts,
    shell: false,
  });
  const tp: TrackedProcess = { id: newId('p'), pid: child.pid, kind, label, startedAt: Date.now(), child };
  registry.set(tp.id, tp);
  const cleanup = () => registry.delete(tp.id);
  child.once('exit', cleanup);
  child.once('error', (e) => {
    log.warn(`process error (${label})`, e.message);
    cleanup();
  });
  log.debug(`spawned ${kind}`, { label, pid: child.pid });
  return tp;
}

/** Kill a process and its children (Windows needs taskkill /T for CLI trees). */
export function killTree(child: ChildProcess, force = true) {
  if (child.exitCode !== null || child.killed) return;
  const pid = child.pid;
  if (!pid) return;
  try {
    if (IS_WIN) {
      spawnSync('taskkill', ['/pid', String(pid), '/T', ...(force ? ['/F'] : [])], { windowsHide: true, timeout: 8000 });
    } else {
      try {
        process.kill(-pid, force ? 'SIGKILL' : 'SIGTERM');
      } catch {
        child.kill(force ? 'SIGKILL' : 'SIGTERM');
      }
    }
  } catch (e) {
    log.warn('killTree failed', (e as Error).message);
    try {
      child.kill('SIGKILL');
    } catch {
      /* ignore */
    }
  }
}

export function listProcesses() {
  return [...registry.values()].map((p) => ({ id: p.id, pid: p.pid, kind: p.kind, label: p.label, startedAt: p.startedAt }));
}

export function killAll() {
  for (const p of registry.values()) killTree(p.child, true);
  registry.clear();
}

/** Splits a stream into lines and calls back for each complete line. */
export function onLines(stream: NodeJS.ReadableStream | null | undefined, cb: (line: string) => void) {
  if (!stream) return;
  let buf = '';
  stream.setEncoding?.('utf8');
  stream.on('data', (chunk: string | Buffer) => {
    buf += chunk.toString();
    let idx: number;
    while ((idx = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, idx).replace(/\r$/, '');
      buf = buf.slice(idx + 1);
      if (line.trim()) cb(line);
    }
    if (buf.length > 64 * 1024 * 1024) buf = ''; // runaway guard
  });
  stream.on('end', () => {
    if (buf.trim()) cb(buf);
    buf = '';
  });
}

/** Runs a command to completion with a timeout; resolves with stdout/stderr (never rejects). */
export function runCapture(
  command: string,
  args: string[],
  opts: { env?: NodeJS.ProcessEnv; cwd?: string; timeoutMs?: number; input?: string } = {},
): Promise<{ code: number | null; stdout: string; stderr: string; error?: string }> {
  return new Promise((resolve) => {
    let child: ChildProcess;
    try {
      child = spawn(command, args, { env: opts.env, cwd: opts.cwd, windowsHide: true, shell: false });
    } catch (e) {
      resolve({ code: null, stdout: '', stderr: '', error: (e as Error).message });
      return;
    }
    let stdout = '';
    let stderr = '';
    const timer = setTimeout(() => {
      killTree(child);
      resolve({ code: null, stdout, stderr, error: 'timed out' });
    }, opts.timeoutMs ?? 20000);
    child.stdout?.on('data', (d) => (stdout += d.toString()));
    child.stderr?.on('data', (d) => (stderr += d.toString()));
    child.on('error', (e) => {
      clearTimeout(timer);
      resolve({ code: null, stdout, stderr, error: e.message });
    });
    child.on('close', (code) => {
      clearTimeout(timer);
      resolve({ code, stdout, stderr });
    });
    if (opts.input != null) child.stdin?.end(opts.input);
    else child.stdin?.end();
  });
}

/** Opens a URL in the user's default browser without involving a shell parser. */
export function openUrl(url: string) {
  if (!/^https?:\/\//i.test(url)) throw new Error('Only http(s) URLs can be opened');
  try {
    if (IS_WIN) spawn('rundll32', ['url.dll,FileProtocolHandler', url], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
    else if (process.platform === 'darwin') spawn('open', [url], { detached: true, stdio: 'ignore' }).unref();
    else spawn('xdg-open', [url], { detached: true, stdio: 'ignore' }).unref();
  } catch (e) {
    log.warn('could not open browser', (e as Error).message);
  }
}

/** Reveals a folder in Explorer/Finder. */
export function openFolder(dir: string) {
  try {
    if (IS_WIN) spawn('explorer.exe', [dir], { detached: true, stdio: 'ignore' }).unref();
    else if (process.platform === 'darwin') spawn('open', [dir], { detached: true, stdio: 'ignore' }).unref();
    else spawn('xdg-open', [dir], { detached: true, stdio: 'ignore' }).unref();
  } catch (e) {
    log.warn('could not open folder', (e as Error).message);
  }
}
