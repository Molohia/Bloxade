import { getBridgeSession } from './sessions';
import { roblox } from './manager';
import { VERSION } from '../core/runtime';
import { logger } from '../core/log';

const log = logger('bridge');

/**
 * BLOXADE acts as an MCP *server* for the agent CLIs (via the tiny stdio bridge in app/mcp-bridge.mjs),
 * and as an MCP *client* of the official Roblox Studio MCP server. Every agent call therefore passes through
 * one queue with permissions, locks, caching and output compression.
 */
export async function handleBridgeMessage(token: string | undefined, msg: any): Promise<any | null> {
  const session = getBridgeSession(token);
  const id = msg?.id;
  const reply = (result: any) => (id === undefined ? null : { jsonrpc: '2.0', id, result });
  const fail = (code: number, message: string) => (id === undefined ? null : { jsonrpc: '2.0', id, error: { code, message } });
  if (!session) return fail(-32001, 'BLOXADE bridge session expired or invalid');
  session.lastSeen = Date.now();
  const method = msg?.method;
  try {
    switch (method) {
      case 'initialize':
        session.initialized = true;
        return reply({
          protocolVersion: msg.params?.protocolVersion ?? '2025-06-18',
          capabilities: { tools: { listChanged: false } },
          serverInfo: { name: 'bloxade-roblox', version: VERSION },
          instructions:
            'Roblox Studio tools provided through BLOXADE. Calls are queued and may require user approval. studio_id may be omitted to target the active Studio place.',
        });
      case 'notifications/initialized':
      case 'notifications/cancelled':
        return null;
      case 'ping':
        return reply({});
      case 'tools/list': {
        const tools = await roblox.agentTools();
        return reply({ tools });
      }
      case 'tools/call': {
        const name = String(msg.params?.name ?? '');
        const result = await roblox.call(name, msg.params?.arguments ?? {}, session);
        return reply(result);
      }
      case 'resources/list':
        return reply({ resources: [] });
      case 'prompts/list':
        return reply({ prompts: [] });
      default:
        if (id === undefined) return null;
        return fail(-32601, `Method not found: ${method}`);
    }
  } catch (e) {
    log.warn('bridge call failed', { method, error: (e as Error).message });
    if (method === 'tools/call') return reply({ content: [{ type: 'text', text: `BLOXADE bridge error: ${(e as Error).message}` }], isError: true });
    return fail(-32000, (e as Error).message);
  }
}
