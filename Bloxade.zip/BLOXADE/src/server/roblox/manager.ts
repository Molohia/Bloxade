import fs from 'node:fs';
import type { PermissionPolicy, RobloxActivity, RobloxStatus, RobloxTool } from '@shared/types';
import { EFFICIENCY_PROFILES } from '@shared/types';
import { McpStdioClient, parseCommandLine, type McpCallResult, type McpTool } from './mcpClient';
import { connectedBridgeSessions, type BridgeCaller } from './sessions';
import { getSettings } from '../core/settings';
import { events } from '../core/events';
import { db } from '../core/db';
import { newId, now, truncate, IS_WIN } from '../core/util';
import { logger } from '../core/log';
import { runCapture } from '../core/proc';
import { requestApproval } from '../services/approvals';
import { studioLocks } from '../services/files';
import { compressOutput } from '../services/context';
import { activity } from '../services/activity';

const log = logger('roblox');

/** Tools of the official Roblox Studio MCP server that only read state. Anything else is treated as a write. */
const KNOWN_READ_ONLY = new Set([
  'list_roblox_studios', 'get_studio_state', 'get_console_output', 'inspect_instance', 'script_read', 'script_search', 'script_grep',
  'search_game_tree', 'search_asset', 'screen_capture', 'http_get', 'skill', 'wait_job_finished',
]);
const LONG_RUNNING = new Set(['generate_mesh', 'generate_material', 'generate_procedural_model', 'generate_texture', 'segment_mesh', 'wait_job_finished', 'subagent']);

class RobloxManager {
  private client: McpStdioClient | null = null;
  private tools: McpTool[] = [];
  private state: RobloxStatus['state'] = 'disconnected';
  private error: string | null = null;
  private studios: { id: string; name: string }[] = [];
  private activeStudioId: string | null = null;
  private studioState: string | null = null;
  private lastTest: RobloxStatus['lastTest'] = null;
  private connecting: Promise<void> | null = null;
  private connectedAt: number | null = null;
  private writeChain: Promise<unknown> = Promise.resolve();
  private writeQueueLen = 0;
  private runningWrite: string | null = null;
  private readsInFlight = 0;
  private cache = new Map<string, { at: number; result: McpCallResult }>();
  private autoApproveCallers = new Set<string>();

  isReadOnly(t: McpTool) {
    if (t.annotations?.readOnlyHint === true) return true;
    if (t.annotations?.readOnlyHint === false || t.annotations?.destructiveHint) return false;
    return KNOWN_READ_ONLY.has(t.name);
  }

  policyFor(t: McpTool): PermissionPolicy {
    const p = getSettings().roblox.toolPolicies[t.name];
    if (p) return p;
    return this.isReadOnly(t) ? 'allow' : 'ask';
  }

  status(): RobloxStatus {
    const s = getSettings().roblox;
    return {
      enabled: s.enabled,
      state: this.state,
      command: s.command,
      error: this.error,
      serverInfo: this.client?.serverInfo ?? null,
      tools: this.tools.map<RobloxTool>((t) => ({ name: t.name, description: (t.description ?? '').split('\n')[0].slice(0, 300), readOnly: this.isReadOnly(t), policy: this.policyFor(t) })),
      studios: this.studios,
      activeStudioId: this.activeStudioId,
      studioState: this.studioState,
      lastTest: this.lastTest,
      connectedAgents: connectedBridgeSessions(),
      queue: { pending: this.writeQueueLen, running: this.runningWrite },
      stderrTail: this.client?.stderrTail.slice(-12) ?? [],
      connectedAt: this.connectedAt,
    };
  }

  private emit() {
    events.emit('roblox.status', this.status());
  }

  setAutoApprove(callerId: string, on: boolean) {
    if (on) this.autoApproveCallers.add(callerId);
    else this.autoApproveCallers.delete(callerId);
  }

  async connect(): Promise<void> {
    if (this.state === 'connected' && this.client?.alive) return;
    if (this.connecting) return this.connecting;
    this.connecting = this.doConnect().finally(() => (this.connecting = null));
    return this.connecting;
  }

  private async doConnect() {
    const s = getSettings().roblox;
    if (!s.enabled) throw new Error('Roblox Studio integration is turned off in Settings → Roblox Studio');
    if (!s.command.trim()) throw new Error('No Roblox Studio MCP command configured (Settings → Roblox Studio)');
    this.state = 'connecting';
    this.error = null;
    this.emit();
    this.client?.stop();
    const client = new McpStdioClient(s.command);
    this.client = client;
    client.on('exit', () => {
      if (this.client !== client) return;
      this.state = 'disconnected';
      this.error = this.error ?? 'Roblox Studio MCP server stopped';
      this.connectedAt = null;
      this.cache.clear();
      this.emit();
      activity('roblox', 'Roblox Studio disconnected', this.error ?? '');
    });
    client.on('notification', (method: string) => {
      if (method === 'notifications/tools/list_changed') void this.refreshTools();
    });
    try {
      await client.start();
      this.tools = await client.listTools();
      this.state = 'connected';
      this.connectedAt = now();
      await this.refreshStudios().catch((e) => log.warn('studio list failed', e.message));
      activity('roblox', 'Roblox Studio connected', `${this.tools.length} tools · ${this.studios.map((x) => x.name).join(', ') || 'no open places reported'}`);
    } catch (e) {
      this.state = 'error';
      this.error = this.explain((e as Error).message);
      client.stop();
      this.emit();
      throw new Error(this.error);
    }
    this.emit();
  }

  private explain(msg: string) {
    if (/ENOENT|not recognized|cannot find/i.test(msg) || /exited \(code 1\)/.test(msg)) {
      return `${msg}\nMake sure Roblox Studio is installed and open, and that “Enable Studio as MCP server” is on (Studio → Assistant → … → Manage MCP Servers).`;
    }
    if (/timed out/i.test(msg)) return `${msg}\nRoblox Studio may be closed or the MCP server toggle is off.`;
    return msg;
  }

  async refreshTools() {
    if (!this.client?.alive) return;
    this.tools = await this.client.listTools();
    this.emit();
  }

  async refreshStudios() {
    if (!this.client?.alive) throw new Error('Not connected');
    if (this.tools.some((t) => t.name === 'list_roblox_studios')) {
      const r = await this.client.callTool('list_roblox_studios', {}, 20000);
      const text = textOf(r);
      try {
        const data = JSON.parse(text);
        this.studios = (data.studios ?? data ?? []).map((x: any) => ({ id: String(x.id), name: String(x.name ?? x.id) }));
      } catch {
        this.studios = [];
      }
    }
    const pref = getSettings().roblox.defaultStudioId;
    if (!this.activeStudioId || !this.studios.some((x) => x.id === this.activeStudioId)) {
      this.activeStudioId = this.studios.find((x) => x.id === pref)?.id ?? this.studios[0]?.id ?? null;
    }
    if (this.activeStudioId && this.tools.some((t) => t.name === 'get_studio_state')) {
      const st = await this.client.callTool('get_studio_state', { studio_id: this.activeStudioId }, 20000).catch(() => null);
      this.studioState = st ? truncate(textOf(st), 600) : null;
    }
    this.emit();
  }

  selectStudio(id: string) {
    if (!this.studios.some((s) => s.id === id)) throw new Error('That Studio instance is not connected');
    this.activeStudioId = id;
    this.cache.clear();
    this.emit();
  }

  disconnect() {
    const c = this.client;
    this.client = null;
    c?.stop();
    this.state = 'disconnected';
    this.error = null;
    this.tools = [];
    this.connectedAt = null;
    this.cache.clear();
    this.emit();
  }

  async test(): Promise<NonNullable<RobloxStatus['lastTest']>> {
    const t0 = now();
    try {
      await this.connect();
      await this.refreshStudios();
      const msg = this.studios.length ? `Connected · ${this.studios.length} Studio instance${this.studios.length === 1 ? '' : 's'}: ${this.studios.map((s) => s.name).join(', ')}` : 'MCP server answered, but no open Studio place was reported. Open a place in Roblox Studio.';
      this.lastTest = { ok: this.studios.length > 0, at: now(), latencyMs: now() - t0, message: msg };
    } catch (e) {
      this.lastTest = { ok: false, at: now(), latencyMs: now() - t0, message: (e as Error).message };
    }
    this.emit();
    return this.lastTest!;
  }

  /** Tools exposed to agents through the BLOXADE bridge (deny-listed tools hidden, studio_id optional). */
  async agentTools(): Promise<McpTool[]> {
    try {
      await this.connect();
    } catch (e) {
      log.warn('agent requested Studio tools but connection failed', (e as Error).message);
      return [];
    }
    return this.tools
      .filter((t) => this.policyFor(t) !== 'deny')
      .map((t) => {
        const schema = t.inputSchema ? JSON.parse(JSON.stringify(t.inputSchema)) : { type: 'object', properties: {} };
        if (Array.isArray(schema.required)) schema.required = schema.required.filter((r: string) => r !== 'studio_id');
        const ro = this.isReadOnly(t);
        return {
          name: t.name,
          description: `${t.description ?? ''}${ro ? '' : '\n\n[BLOXADE] Write action: may need user approval and runs in a shared queue with other agents.'}${schema.properties?.studio_id ? '\n[BLOXADE] studio_id is optional — the active Studio instance is used when omitted.' : ''}`,
          inputSchema: schema,
          annotations: { ...(t.annotations ?? {}), readOnlyHint: ro },
        };
      });
  }

  /** Central entry point for every Studio tool call (agents, chats and the manual console). */
  async call(name: string, rawArgs: any, caller: BridgeCaller): Promise<McpCallResult> {
    const t0 = now();
    await this.connect();
    const tool = this.tools.find((t) => t.name === name);
    if (!tool) return errorResult(`Unknown Roblox Studio tool '${name}'`);
    const args = { ...(rawArgs ?? {}) };
    if (tool.inputSchema?.properties?.studio_id && !args.studio_id) {
      if (!this.activeStudioId) await this.refreshStudios().catch(() => undefined);
      if (this.activeStudioId) args.studio_id = this.activeStudioId;
    }
    const readOnly = this.isReadOnly(tool);
    const policy = this.policyFor(tool);
    const summary = summarize(name, args);

    if (policy === 'deny' && caller.kind !== 'user') {
      this.log(caller, name, summary, 'denied', t0);
      return errorResult(`BLOXADE settings block the Roblox Studio tool '${name}'.`);
    }

    // Script ownership between agents (multi_edit target path)
    const lockKey = name === 'multi_edit' && typeof args.file_path === 'string' ? `script:${String(args.file_path).replace(/^game\./i, '').toLowerCase()}` : null;
    if (lockKey && caller.kind !== 'user') {
      const holder = studioLocks.holder(lockKey);
      if (holder && holder.id !== caller.id) {
        const d = await requestApproval({
          kind: 'conflict',
          title: 'Conflicting Studio script edit',
          detail: `${caller.label} wants to edit ${args.file_path}, which ${holder.label} is currently editing.`,
          toolName: name,
          input: args,
          requester: { kind: caller.kind, id: caller.id, label: caller.label },
        });
        if (!d.allow) {
          this.log(caller, name, summary, 'denied', t0);
          return errorResult(`${args.file_path} is being edited by ${holder.label}. Do not edit it now; describe the change you need in your report.`);
        }
      }
    }

    if (!readOnly && policy === 'ask' && caller.kind !== 'user' && !this.autoApproveCallers.has(caller.id) && !(caller.runId && this.autoApproveCallers.has(caller.runId))) {
      const d = await requestApproval({
        kind: 'studio',
        title: `Roblox Studio: ${name}`,
        detail: `${caller.label} wants to run ${name} in ${this.studios.find((s) => s.id === args.studio_id)?.name ?? 'Roblox Studio'}.\n\n${truncate(JSON.stringify(args, null, 2), 3500)}`,
        toolName: name,
        input: args,
        requester: { kind: caller.kind, id: caller.id, label: caller.label },
        rememberKey: `studio:${name}`,
      });
      if (!d.allow) {
        this.log(caller, name, summary, 'denied', t0);
        return errorResult(d.message || 'The user denied this Roblox Studio action.');
      }
    }
    if (lockKey && caller.kind !== 'user') studioLocks.claim(lockKey, { id: caller.id, label: caller.label, runId: caller.runId ?? null });

    const cacheKey = readOnly && getSettings().roblox.cacheReads && name !== 'get_console_output' && name !== 'screen_capture' && name !== 'get_studio_state' ? `${name}:${stableStringify(args)}` : null;
    if (cacheKey) {
      const c = this.cache.get(cacheKey);
      if (c && now() - c.at < 30_000) {
        this.log(caller, name, summary, 'cached', t0);
        return withNote(c.result, '[BLOXADE] Result served from the shared Studio cache (no change since it was last read).');
      }
    }

    const timeout = LONG_RUNNING.has(name) ? 11 * 60_000 : name === 'execute_luau' ? 3 * 60_000 : 2 * 60_000;
    const exec = async () => {
      if (!this.client?.alive) await this.connect();
      return this.client!.callTool(name, args, timeout);
    };

    let result: McpCallResult;
    try {
      if (readOnly) {
        this.readsInFlight++;
        try {
          result = await exec();
        } finally {
          this.readsInFlight--;
        }
      } else {
        this.writeQueueLen++;
        this.emit();
        const run = this.writeChain.then(async () => {
          this.writeQueueLen--;
          this.runningWrite = `${name} (${caller.label})`;
          this.emit();
          try {
            return await exec();
          } finally {
            this.runningWrite = null;
            this.cache.clear();
            this.emit();
          }
        });
        this.writeChain = run.catch(() => undefined);
        result = await run;
      }
    } catch (e) {
      this.log(caller, name, summary, 'error', t0);
      return errorResult(`Roblox Studio call failed: ${(e as Error).message}`);
    }

    // Compress large text outputs before they reach an agent
    const cap = getSettings().context.toolOutputCap ?? EFFICIENCY_PROFILES[getSettings().context.mode].toolOutputCap;
    let saved = 0;
    const content = (result.content ?? []).map((c: any) => {
      if (c?.type === 'text' && typeof c.text === 'string' && caller.kind !== 'user') {
        const r = compressOutput(c.text, cap);
        saved += r.saved;
        return { ...c, text: r.text };
      }
      return c;
    });
    const out: McpCallResult = { ...result, content };
    if (cacheKey && !result.isError) this.cache.set(cacheKey, { at: now(), result: out });
    if (name === 'list_roblox_studios' && !result.isError) {
      try {
        const data = JSON.parse(textOf(result));
        this.studios = (data.studios ?? []).map((x: any) => ({ id: String(x.id), name: String(x.name ?? x.id) }));
      } catch {
        /* ignore */
      }
    }
    this.log(caller, name, summary + (saved ? ` · trimmed ~${saved} tokens` : ''), result.isError ? 'error' : 'ok', t0);
    return out;
  }

  private log(caller: BridgeCaller, tool: string, summary: string, status: RobloxActivity['status'], t0: number) {
    const e: RobloxActivity = { id: newId('rbx'), ts: now(), caller: caller.label, tool, summary: truncate(summary, 300), status, durationMs: now() - t0 };
    try {
      db().run('INSERT INTO roblox_activity (id, ts, caller, tool, summary, status, duration_ms) VALUES (?, ?, ?, ?, ?, ?, ?)', e.id, e.ts, e.caller, e.tool, e.summary, e.status, e.durationMs);
    } catch {
      /* ignore */
    }
    events.emit('roblox.activity', e);
  }

  releaseCaller(callerId: string) {
    studioLocks.release(callerId);
    this.autoApproveCallers.delete(callerId);
  }

  async diagnostics() {
    const s = getSettings().roblox;
    const out: Record<string, unknown> = { command: s.command, enabled: s.enabled, state: this.state, error: this.error };
    try {
      const { command, args } = parseCommandLine(s.command);
      out.parsed = { command, args };
      const bat = args.find((a) => /\.bat$|StudioMCP/i.test(a)) ?? (/StudioMCP/i.test(command) ? command : null);
      if (bat) out.launcherExists = fs.existsSync(bat);
    } catch (e) {
      out.parseError = (e as Error).message;
    }
    if (IS_WIN) {
      const r = await runCapture('tasklist', ['/FI', 'IMAGENAME eq RobloxStudioBeta.exe', '/NH'], { timeoutMs: 8000 });
      out.studioProcessRunning = /RobloxStudioBeta\.exe/i.test(r.stdout);
    }
    return out;
  }

  shutdown() {
    this.client?.stop();
    this.client = null;
  }
}

function textOf(r: McpCallResult | null | undefined): string {
  return (r?.content ?? []).filter((c: any) => c?.type === 'text').map((c: any) => c.text).join('\n');
}

function errorResult(text: string): McpCallResult {
  return { content: [{ type: 'text', text }], isError: true };
}

function withNote(r: McpCallResult, note: string): McpCallResult {
  return { ...r, content: [...(r.content ?? []), { type: 'text', text: note }] };
}

function stableStringify(v: any): string {
  if (v && typeof v === 'object' && !Array.isArray(v)) return '{' + Object.keys(v).sort().map((k) => JSON.stringify(k) + ':' + stableStringify(v[k])).join(',') + '}';
  return JSON.stringify(v);
}

function summarize(name: string, args: any): string {
  const pick = args.file_path ?? args.target_file ?? args.path ?? args.instance_path ?? args.query ?? args.keywords ?? args.prompt ?? args.textPrompt ?? (args.code ? String(args.code).split('\n')[0] : null);
  return pick ? truncate(String(pick).replace(/\s+/g, ' '), 160) : name;
}

export const roblox = new RobloxManager();

/** True when Studio tools should be offered to Cowork chats/agents. */
export function robloxAvailableFor(): boolean {
  const s = getSettings().roblox;
  return s.enabled && !!s.command.trim();
}

export function listRobloxActivity(limit = 150): RobloxActivity[] {
  return db()
    .all<any>('SELECT * FROM roblox_activity ORDER BY ts DESC LIMIT ?', limit)
    .map((r) => ({ id: r.id, ts: r.ts, caller: r.caller, tool: r.tool, summary: r.summary, status: r.status, durationMs: r.duration_ms }));
}
