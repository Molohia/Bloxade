import { EventEmitter } from 'node:events';
import { spawnTracked, killTree, onLines, type TrackedProcess } from '../core/proc';
import { safeJson } from '../core/util';
import { logger } from '../core/log';
import { VERSION } from '../core/runtime';

const log = logger('mcp');

export interface McpTool {
  name: string;
  description?: string;
  inputSchema?: any;
  annotations?: { readOnlyHint?: boolean; destructiveHint?: boolean; title?: string } | null;
}

export interface McpCallResult {
  content: any[];
  isError?: boolean;
  structuredContent?: unknown;
}

/** Splits "cmd.exe /c %LOCALAPPDATA%\Roblox\mcp.bat" into command + args (quotes respected, %VARS% expanded). */
export function parseCommandLine(line: string): { command: string; args: string[] } {
  const expanded = line.replace(/%([^%]+)%/g, (m, n) => process.env[n] ?? m).replace(/\$\{?([A-Z_][A-Z0-9_]*)\}?/g, (m, n) => process.env[n] ?? m);
  const parts: string[] = [];
  let cur = '';
  let q: string | null = null;
  for (const ch of expanded.trim()) {
    if (q) {
      if (ch === q) q = null;
      else cur += ch;
    } else if (ch === '"' || ch === "'") q = ch;
    else if (/\s/.test(ch)) {
      if (cur) parts.push(cur);
      cur = '';
    } else cur += ch;
  }
  if (cur) parts.push(cur);
  if (!parts.length) throw new Error('No MCP server command configured');
  return { command: parts[0], args: parts.slice(1) };
}

/** Minimal MCP client over stdio (newline-delimited JSON-RPC 2.0), per the MCP specification. */
export class McpStdioClient extends EventEmitter {
  private proc: TrackedProcess | null = null;
  private nextId = 1;
  private pending = new Map<number, { resolve: (v: any) => void; reject: (e: Error) => void; timer: NodeJS.Timeout }>();
  stderrTail: string[] = [];
  serverInfo: { name?: string; version?: string } | null = null;
  capabilities: any = null;

  constructor(private commandLine: string, private label = 'Roblox Studio MCP') {
    super();
  }

  get alive() {
    return !!this.proc && this.proc.child.exitCode === null;
  }

  async start(timeoutMs = 25000) {
    const { command, args } = parseCommandLine(this.commandLine);
    this.proc = spawnTracked(command, args, { stdio: ['pipe', 'pipe', 'pipe'], kind: 'mcp', label: this.label });
    const child = this.proc.child;
    onLines(child.stdout, (l) => this.onLine(l));
    onLines(child.stderr, (l) => {
      this.stderrTail.push(l);
      if (this.stderrTail.length > 60) this.stderrTail.shift();
    });
    child.on('exit', (code) => {
      for (const p of this.pending.values()) {
        clearTimeout(p.timer);
        p.reject(new Error(`MCP server exited (code ${code}). ${this.stderrTail.slice(-2).join(' ')}`));
      }
      this.pending.clear();
      this.proc = null;
      this.emit('exit', code);
    });
    await new Promise<void>((resolve, reject) => {
      child.once('spawn', () => resolve());
      child.once('error', (e) => reject(new Error(`Could not start '${command}': ${e.message}`)));
    });
    const init = await this.request(
      'initialize',
      { protocolVersion: '2025-06-18', capabilities: { roots: { listChanged: false } }, clientInfo: { name: 'bloxade', title: 'BLOXADE', version: VERSION } },
      timeoutMs,
    );
    this.serverInfo = init?.serverInfo ?? null;
    this.capabilities = init?.capabilities ?? null;
    this.notify('notifications/initialized', {});
    return init;
  }

  private write(obj: any) {
    const stdin = this.proc?.child.stdin;
    if (!stdin || stdin.destroyed) throw new Error('MCP server is not running');
    stdin.write(JSON.stringify({ jsonrpc: '2.0', ...obj }) + '\n');
  }

  request(method: string, params: any, timeoutMs = 60000): Promise<any> {
    const id = this.nextId++;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`MCP '${method}' timed out after ${Math.round(timeoutMs / 1000)}s`));
      }, timeoutMs);
      this.pending.set(id, { resolve, reject, timer });
      try {
        this.write({ id, method, params });
      } catch (e) {
        clearTimeout(timer);
        this.pending.delete(id);
        reject(e as Error);
      }
    });
  }

  notify(method: string, params: any) {
    try {
      this.write({ method, params });
    } catch {
      /* ignore */
    }
  }

  private onLine(line: string) {
    const msg = safeJson<any>(line, null);
    if (!msg || typeof msg !== 'object') return;
    if (msg.id !== undefined && msg.method === undefined) {
      const p = this.pending.get(msg.id);
      if (!p) return;
      clearTimeout(p.timer);
      this.pending.delete(msg.id);
      if (msg.error) p.reject(new Error(msg.error.message ?? 'MCP error'));
      else p.resolve(msg.result);
      return;
    }
    if (msg.method && msg.id !== undefined) {
      // server → client requests
      let result: any = {};
      if (msg.method === 'roots/list') result = { roots: [] };
      else if (msg.method === 'ping') result = {};
      else if (msg.method === 'elicitation/create') result = { action: 'decline' };
      else {
        this.write({ id: msg.id, error: { code: -32601, message: `BLOXADE does not support ${msg.method}` } });
        return;
      }
      this.write({ id: msg.id, result });
      return;
    }
    if (msg.method) this.emit('notification', msg.method, msg.params);
  }

  async listTools(): Promise<McpTool[]> {
    const tools: McpTool[] = [];
    let cursor: string | undefined;
    for (let i = 0; i < 20; i++) {
      const r = await this.request('tools/list', cursor ? { cursor } : {}, 30000);
      tools.push(...(r?.tools ?? []));
      cursor = r?.nextCursor;
      if (!cursor) break;
    }
    return tools;
  }

  callTool(name: string, args: unknown, timeoutMs: number): Promise<McpCallResult> {
    return this.request('tools/call', { name, arguments: args ?? {} }, timeoutMs);
  }

  stop() {
    if (this.proc) {
      log.info('stopping MCP server');
      killTree(this.proc.child);
    }
    this.proc = null;
  }
}
