import { randomBytes } from 'node:crypto';

export interface BridgeCaller {
  kind: 'chat' | 'task' | 'user';
  id: string;
  label: string;
  runId?: string | null;
}

interface BridgeSession extends BridgeCaller {
  token: string;
  createdAt: number;
  lastSeen: number | null;
  initialized: boolean;
}

const sessions = new Map<string, BridgeSession>();

/** A bridge token lets one CLI process (one chat turn or agent task) talk to Studio through BLOXADE. */
export function createBridgeSession(caller: BridgeCaller): string {
  const token = randomBytes(24).toString('hex');
  sessions.set(token, { ...caller, token, createdAt: Date.now(), lastSeen: null, initialized: false });
  return token;
}

export function getBridgeSession(token: string | undefined | null): BridgeSession | null {
  if (!token) return null;
  return sessions.get(token) ?? null;
}

export function revokeBridgeSession(token: string | null | undefined) {
  if (token) sessions.delete(token);
}

export function connectedBridgeSessions() {
  return [...sessions.values()].filter((s) => s.initialized).map((s) => ({ id: s.id, label: s.label, since: s.lastSeen ?? s.createdAt }));
}
