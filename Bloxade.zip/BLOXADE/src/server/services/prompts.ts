import type { ChatMode, Project } from '@shared/types';

/** Short system additions — kept compact on purpose (they are sent with every new session). */
export function systemPrompt(opts: { mode: ChatMode; project: Project | null; roblox: boolean; cwd: string; role?: string }): string {
  const parts: string[] = [];
  parts.push('You are running inside BLOXADE, a local AI development workspace. Format answers in Markdown.');
  if (opts.mode === 'chat') {
    parts.push('Mode: Chat — you have no file, shell or Studio access in this mode. Answer from the conversation and any <bloxade_context> provided. If the user needs changes applied to files or Roblox Studio, tell them to switch to Cowork mode.');
  } else {
    parts.push(`Mode: Cowork — you may read and edit files in ${opts.cwd}. Change only what the request needs, prefer small targeted edits, and finish with a short summary listing the files you changed.`);
    parts.push('Some actions may require approval from the user in BLOXADE; if one is denied, adapt instead of retrying the same action.');
  }
  if (opts.roblox && opts.mode === 'cowork') {
    parts.push(
      'Roblox Studio is connected through the `bloxade_roblox` MCP tools (the official Roblox Studio MCP, routed through BLOXADE’s queue). Call list_roblox_studios once to get the studio_id. Inspect before editing (search_game_tree, script_search, script_grep, script_read); edit scripts with multi_edit; use execute_luau for object/property changes; check get_console_output after changes. Studio write actions may need user approval and are serialized with other agents.',
    );
  }
  if (opts.role) parts.push(opts.role);
  if (opts.project) {
    parts.push(`Project: ${opts.project.name}${opts.project.description ? ' — ' + opts.project.description : ''}`);
    if (opts.project.instructions.trim()) parts.push(`Project instructions (from the user):\n${opts.project.instructions.trim()}`);
  }
  return parts.join('\n\n');
}
