import type { Block } from '@shared/types';
import type { TurnEvent } from '../providers/types';
import { truncate } from '../core/util';

export interface BlockSink {
  block(index: number, block: Block): void;
  delta(index: number, kind: 'text' | 'thinking', text: string): void;
}

const MAX_TOOL_OUTPUT = 20_000;

function toolTitle(name: string, input: any): string | undefined {
  if (!input || typeof input !== 'object') return undefined;
  const v = input.file_path ?? input.path ?? input.command ?? input.pattern ?? input.query ?? input.url ?? input.target_file ?? input.description;
  return typeof v === 'string' ? truncate(v.replace(/\s+/g, ' '), 120) : undefined;
}

/** Turns a provider event stream into ordered message blocks (text, thinking, tool calls, notices). */
export class BlockStream {
  blocks: Block[];
  toolOps = 0;
  filesTouched = new Set<string>();
  currentActivity: string | null = null;

  constructor(initial: Block[] = [], private sink?: BlockSink) {
    this.blocks = initial;
  }

  get text() {
    return this.blocks
      .filter((b) => b.type === 'text')
      .map((b) => (b as { text: string }).text)
      .join('\n\n')
      .trim();
  }

  private push(b: Block) {
    this.blocks.push(b);
    this.sink?.block(this.blocks.length - 1, b);
  }

  notice(level: 'info' | 'warning' | 'error', text: string) {
    this.push({ type: 'notice', level, text });
  }

  apply(e: TurnEvent) {
    const last = this.blocks[this.blocks.length - 1];
    switch (e.type) {
      case 'text':
        if (!e.text) return;
        if (last?.type === 'text' && !e.newBlock) {
          last.text += e.text;
          this.sink?.delta(this.blocks.length - 1, 'text', e.text);
        } else this.push({ type: 'text', text: e.text });
        this.currentActivity = 'Writing response';
        return;
      case 'thinking':
        if (last?.type === 'thinking') {
          last.text += e.text;
          this.sink?.delta(this.blocks.length - 1, 'thinking', e.text);
        } else this.push({ type: 'thinking', text: e.text });
        this.currentActivity = 'Thinking';
        return;
      case 'tool_start': {
        this.toolOps++;
        const title = e.title ?? toolTitle(e.name, e.input);
        this.push({ type: 'tool', id: e.id, name: e.name, input: e.input, status: 'running', title, server: e.server });
        this.currentActivity = `${e.name}${title ? ': ' + title : ''}`;
        return;
      }
      case 'tool_end': {
        const idx = this.blocks.findIndex((b) => b.type === 'tool' && b.id === e.id);
        if (idx < 0) return;
        const b = this.blocks[idx] as Extract<Block, { type: 'tool' }>;
        b.status = e.denied ? 'denied' : e.isError ? 'error' : 'done';
        b.output = e.output.length > MAX_TOOL_OUTPUT ? e.output.slice(0, MAX_TOOL_OUTPUT) + `\n… (${e.output.length - MAX_TOOL_OUTPUT} more characters)` : e.output;
        this.sink?.block(idx, b);
        return;
      }
      case 'notice':
        this.notice(e.level, e.text);
        return;
      case 'file_change':
        for (const p of e.paths) this.filesTouched.add(p);
        return;
      default:
        return;
    }
  }
}
