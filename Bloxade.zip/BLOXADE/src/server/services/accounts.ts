import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import type { Account, AccountLimits, AccountStatus, Provider } from '@shared/types';
import { db, b, j } from '../core/db';
import { newId, now, safeJson, HttpError, IS_WIN, str, oneOf } from '../core/util';
import { profileDir, dirs } from '../core/paths';
import { events } from '../core/events';
import { logger } from '../core/log';
import { openUrl } from '../core/proc';
import { claudeAuthStatus, claudeLogout } from '../providers/claude';
import { codexAccountRead, codexLoginCancel, codexLoginStart, codexLogout, codexRateLimits, codexServer, stopCodexServer } from '../providers/codex';
import { findCli } from '../providers/resolve';
import { providerEnv } from '../providers/env';
import { activity } from './activity';

const log = logger('accounts');

const COLORS = ['#E58A5B', '#7C7FFF', '#3FB98A', '#E0B341', '#D9608C', '#4FA8E8', '#A678E8', '#8DB34A'];

interface Row {
  id: string; provider: Provider; name: string; profile_dir: string | null; is_system: number; enabled: number; is_default: number;
  color: string; created_at: number; last_used_at: number | null; status: AccountStatus; status_detail: string | null;
  email: string | null; plan: string | null; auth_method: string | null; limits: string | null;
}

const loginState = new Map<string, Account['login']>();
const sessionCounters: (() => Map<string, number>)[] = [];
export function registerSessionCounter(fn: () => Map<string, number>) {
  sessionCounters.push(fn);
}

function activeSessions(id: string) {
  let n = 0;
  for (const f of sessionCounters) n += f().get(id) ?? 0;
  return n;
}

function toAccount(r: Row): Account {
  return {
    id: r.id,
    provider: r.provider,
    name: r.name,
    profileDir: r.profile_dir,
    isSystem: !!r.is_system,
    enabled: !!r.enabled,
    isDefault: !!r.is_default,
    color: r.color,
    createdAt: r.created_at,
    lastUsedAt: r.last_used_at,
    status: loginState.get(r.id) ? 'signing_in' : r.status,
    statusDetail: r.status_detail,
    email: r.email,
    plan: r.plan,
    authMethod: r.auth_method,
    limits: safeJson<AccountLimits | null>(r.limits, null),
    activeSessions: activeSessions(r.id),
    login: loginState.get(r.id) ?? null,
  };
}

export function listAccounts(): Account[] {
  return db().all<Row>('SELECT * FROM accounts ORDER BY provider, created_at').map(toAccount);
}

export function getAccount(id: string | null | undefined): Account | null {
  if (!id) return null;
  const r = db().get<Row>('SELECT * FROM accounts WHERE id = ?', id);
  return r ? toAccount(r) : null;
}

export function mustAccount(id: string): Account {
  const a = getAccount(id);
  if (!a) throw new HttpError(404, 'Account not found');
  return a;
}

/** Picks the account to use: explicit → provider default → first enabled signed-in → first enabled. */
export function resolveAccount(provider: Provider, id?: string | null): Account | null {
  const a = id ? getAccount(id) : null;
  if (a && a.provider === provider) return a;
  const all = listAccounts().filter((x) => x.provider === provider && x.enabled);
  return all.find((x) => x.isDefault) ?? all.find((x) => x.status === 'signed_in') ?? all[0] ?? null;
}

function emit(id: string) {
  const a = getAccount(id);
  if (a) events.emit('account.updated', a);
}

export function createAccount(body: any): Account {
  const provider = oneOf(body?.provider, ['claude', 'codex'] as const, 'provider');
  const useSystem = !!body?.useSystem;
  const existing = listAccounts().filter((a) => a.provider === provider);
  if (useSystem && existing.some((a) => a.isSystem)) throw new HttpError(409, 'The system sign-in is already added as an account');
  const id = newId('acc');
  const name = str(body?.name || (useSystem ? `${provider === 'claude' ? 'Claude' : 'Codex'} (this PC)` : `${provider === 'claude' ? 'Claude' : 'Codex'} Account ${existing.length + 1}`), 'name', { max: 60, min: 1 }).trim();
  const dir = useSystem ? null : profileDir(provider, id);
  if (dir) fs.mkdirSync(dir, { recursive: true });
  db().upsert('accounts', {
    id, provider, name, profile_dir: dir, is_system: b(useSystem), enabled: 1, is_default: b(existing.length === 0),
    color: COLORS[(existing.length + (provider === 'codex' ? 3 : 0)) % COLORS.length], created_at: now(), last_used_at: null,
    status: 'unknown', status_detail: null, email: null, plan: null, auth_method: null, limits: null,
  });
  activity('account', `Added ${provider === 'claude' ? 'Claude' : 'Codex'} account “${name}”`, useSystem ? 'Uses this computer’s existing sign-in' : 'Isolated profile');
  emit(id);
  void refreshStatus(id);
  return getAccount(id)!;
}

export function updateAccount(id: string, body: any): Account {
  const a = mustAccount(id);
  const patch: Record<string, any> = {};
  if (body.name !== undefined) patch.name = str(body.name, 'name', { max: 60, min: 1 }).trim();
  if (body.enabled !== undefined) patch.enabled = b(!!body.enabled);
  if (body.color !== undefined && /^#[0-9a-fA-F]{6}$/.test(body.color)) patch.color = body.color;
  db().update('accounts', a.id, patch);
  if (body.isDefault) setDefault(id);
  emit(id);
  return getAccount(id)!;
}

export function setDefault(id: string) {
  const a = mustAccount(id);
  db().tx(() => {
    db().run('UPDATE accounts SET is_default = 0 WHERE provider = ?', a.provider);
    db().run('UPDATE accounts SET is_default = 1 WHERE id = ?', id);
  });
  for (const x of listAccounts()) events.emit('account.updated', x);
}

export function deleteAccount(id: string, removeProfile: boolean) {
  const a = mustAccount(id);
  if (a.activeSessions) throw new HttpError(409, 'This account has running sessions. Stop them first.');
  if (a.provider === 'codex') stopCodexServer(a.id);
  db().run('DELETE FROM accounts WHERE id = ?', id);
  if (removeProfile && a.profileDir && a.profileDir.startsWith(dirs.profiles)) {
    try {
      fs.rmSync(a.profileDir, { recursive: true, force: true });
    } catch (e) {
      log.warn('could not remove profile folder', (e as Error).message);
    }
  }
  if (a.isDefault) {
    const next = listAccounts().find((x) => x.provider === a.provider);
    if (next) setDefault(next.id);
  }
  activity('account', `Removed account “${a.name}”`, removeProfile ? 'Profile folder deleted' : 'Profile folder kept');
  events.emit('account.deleted', { id });
}

export function touchAccount(id: string) {
  db().run('UPDATE accounts SET last_used_at = ? WHERE id = ?', now(), id);
}

export function recordLimits(id: string, limits: AccountLimits) {
  const a = getAccount(id);
  if (!a) return;
  const prev = a.limits;
  const merged = prev && prev.source === limits.source ? { ...limits, windows: mergeWindows(prev.windows, limits.windows) } : limits;
  db().update('accounts', id, { limits: j(merged) });
  emit(id);
}

function mergeWindows(a: AccountLimits['windows'], bList: AccountLimits['windows']) {
  const m = new Map(a.map((w) => [w.id, w]));
  for (const w of bList) m.set(w.id, w);
  return [...m.values()];
}

function setStatus(id: string, status: AccountStatus, patch: Record<string, any> = {}) {
  db().update('accounts', id, { status, ...patch });
  emit(id);
}

const refreshing = new Map<string, Promise<Account>>();

export function refreshStatus(id: string): Promise<Account> {
  const inflight = refreshing.get(id);
  if (inflight) return inflight;
  const p = doRefresh(id).finally(() => refreshing.delete(id));
  refreshing.set(id, p);
  return p;
}

async function doRefresh(id: string): Promise<Account> {
  const a = mustAccount(id);
  if (!findCli(a.provider)) {
    setStatus(id, 'cli_missing', { status_detail: `${a.provider === 'claude' ? 'Claude Code' : 'Codex'} CLI not found` });
    return getAccount(id)!;
  }
  db().update('accounts', id, { status: 'checking' });
  emit(id);
  try {
    if (a.provider === 'claude') {
      const s = await claudeAuthStatus(a);
      if (s.error && !s.loggedIn) {
        setStatus(id, 'error', { status_detail: s.error });
      } else {
        setStatus(id, s.loggedIn ? 'signed_in' : 'signed_out', {
          status_detail: s.loggedIn ? null : 'Not signed in',
          auth_method: s.authMethod ?? null,
          email: s.email ?? a.email ?? null,
          plan: s.raw?.subscriptionType ?? a.plan ?? null,
        });
      }
    } else {
      const r = await codexAccountRead(a);
      const acct = r.account;
      if (acct) {
        setStatus(id, 'signed_in', { status_detail: null, auth_method: acct.type, email: acct.email ?? null, plan: acct.planType ?? null });
        const lim = await codexRateLimits(a);
        if (lim) recordLimits(id, lim);
      } else {
        setStatus(id, 'signed_out', { status_detail: r.requiresOpenaiAuth ? 'Sign in with ChatGPT to use this account' : 'Not signed in', email: null, plan: null });
      }
    }
  } catch (e) {
    setStatus(id, 'error', { status_detail: (e as Error).message.slice(0, 400) });
  }
  return getAccount(id)!;
}

// ---------- sign-in flows (always the providers' own official flows) ----------

function writeTerminalScript(a: Account, title: string, commandLine: string, footer: string): string {
  const file = path.join(dirs.runtime, `terminal-${a.id}.cmd`);
  const envLine = a.profileDir ? (a.provider === 'claude' ? `set "CLAUDE_CONFIG_DIR=${a.profileDir}"` : `set "CODEX_HOME=${a.profileDir}"`) : 'rem using this computer\'s default sign-in location';
  const body = [
    '@echo off',
    `title ${title.replace(/[&|<>^%]/g, '')}`,
    envLine,
    'echo.',
    `echo   BLOXADE  -  ${title.replace(/[&|<>^%]/g, '')}`,
    'echo   This window runs the official CLI. BLOXADE never sees your password or tokens.',
    'echo.',
    commandLine,
    'echo.',
    `echo   ${footer}`,
    'echo.',
  ].join('\r\n');
  fs.mkdirSync(dirs.runtime, { recursive: true });
  fs.writeFileSync(file, body + '\r\n');
  return file;
}

function quoteCmd(s: string) {
  return `"${s.replace(/"/g, '')}"`;
}

/** Opens a visible console window on Windows running the given CLI arguments with the account's profile. */
function openConsole(a: Account, title: string, cliArgs: string[] | null, footer: string, keepOpen: boolean) {
  const cli = findCli(a.provider);
  if (!cli) throw new HttpError(400, `${a.provider === 'claude' ? 'Claude Code' : 'Codex'} CLI not found`);
  if (!IS_WIN) {
    const envStr = a.profileDir ? `${a.provider === 'claude' ? 'CLAUDE_CONFIG_DIR' : 'CODEX_HOME'}="${a.profileDir}" ` : '';
    return { manual: `${envStr}${[cli.command, ...cli.prefixArgs, ...(cliArgs ?? [])].map((x) => (/\s/.test(x) ? `"${x}"` : x)).join(' ')}` };
  }
  const exe = [cli.command, ...cli.prefixArgs].map(quoteCmd).join(' ');
  const line = cliArgs ? exe + (cliArgs.length ? ' ' + cliArgs.join(' ') : '') : `doskey ${a.provider}=${exe} $*\r\necho   Type ${a.provider} to start the CLI with this account's profile.`;
  const script = writeTerminalScript(a, title, line, footer);
  // `start` opens a new console window; the script path is generated by BLOXADE (no user text is interpolated).
  spawn(`start "BLOXADE" cmd.exe ${keepOpen ? '/k' : '/c'} ${quoteCmd(script)}${keepOpen ? '' : ' ^& pause'}`, {
    shell: true,
    detached: true,
    stdio: 'ignore',
    windowsHide: false,
    env: providerEnv(a),
  }).unref();
  return { manual: null };
}

const loginTimers: Record<string, NodeJS.Timeout> = {};
const loginIds: Record<string, string> = {};

export async function startLogin(id: string, method: 'browser' | 'device' = 'browser') {
  const a = mustAccount(id);
  if (a.provider === 'claude') {
    const r = openConsole(a, `Sign in to Claude - ${a.name}`, ['auth', 'login'], 'When it says you are signed in, close this window and return to BLOXADE.', true);
    loginState.set(id, { kind: 'terminal', startedAt: now() });
    emit(id);
    pollClaudeLogin(id);
    activity('account', `Sign-in started for “${a.name}”`, 'Claude Code sign-in window opened');
    return { kind: 'terminal', manualCommand: r.manual };
  }
  // Codex: official ChatGPT login served by the Codex app-server (local callback on port 1455).
  for (const [otherId, st] of loginState) {
    if (otherId !== id && st && getAccount(otherId)?.provider === 'codex') throw new HttpError(409, 'Another Codex sign-in is in progress. Finish or cancel it first.');
  }
  const r = await codexLoginStart(a, method);
  const url = r.authUrl ?? r.verificationUrl;
  loginState.set(id, { kind: method === 'device' ? 'device' : 'browser', url, code: r.userCode, startedAt: now() });
  emit(id);
  const server = codexServer(a);
  const off = server.onGlobal((m, p) => {
    if (m === 'account/login/completed' && (!p.loginId || p.loginId === r.loginId)) {
      off();
      loginState.delete(id);
      if (!p.success) {
        clearTimeout(loginTimers[id]);
        setStatus(id, 'error', { status_detail: p.error || 'Sign-in was not completed' });
      } else {
        clearTimeout(loginTimers[id]);
        activity('account', `Signed in “${a.name}”`, 'ChatGPT sign-in completed');
        void refreshStatus(id);
      }
      emit(id);
    }
  });
  clearTimeout(loginTimers[id]);
  loginTimers[id] = setTimeout(() => {
    off();
    if (loginState.has(id)) {
      loginState.delete(id);
      void codexLoginCancel(a, r.loginId);
      setStatus(id, 'signed_out', { status_detail: 'Sign-in timed out' });
    }
  }, 10 * 60_000);
  loginIds[id] = r.loginId;
  if (url && method === 'browser') openUrl(url);
  return { kind: method, url, code: r.userCode ?? null };
}

function pollClaudeLogin(id: string) {
  const started = now();
  const tick = async () => {
    if (!loginState.has(id)) return;
    const a = getAccount(id);
    if (!a) return;
    try {
      const s = await claudeAuthStatus(a);
      if (s.loggedIn) {
        loginState.delete(id);
        activity('account', `Signed in “${a.name}”`, 'Claude Code sign-in completed');
        await refreshStatus(id);
        return;
      }
    } catch {
      /* keep polling */
    }
    if (now() - started > 8 * 60_000) {
      loginState.delete(id);
      emit(id);
      return;
    }
    setTimeout(tick, 3000);
  };
  setTimeout(tick, 4000);
}

export async function cancelLogin(id: string) {
  const a = mustAccount(id);
  loginState.delete(id);
  clearTimeout(loginTimers[id]);
  if (a.provider === 'codex' && loginIds[id]) await codexLoginCancel(a, loginIds[id]);
  await refreshStatus(id);
}

export async function logout(id: string) {
  const a = mustAccount(id);
  if (a.provider === 'claude') await claudeLogout(a);
  else await codexLogout(a);
  db().update('accounts', id, { limits: null, email: null, plan: null });
  activity('account', `Signed out “${a.name}”`, '');
  return refreshStatus(id);
}

export function openTerminal(id: string) {
  const a = mustAccount(id);
  return openConsole(a, `${a.provider === 'claude' ? 'Claude Code' : 'Codex'} - ${a.name}`, null, 'Type exit to close this window.', true);
}

export async function refreshAllAccounts() {
  for (const a of listAccounts()) {
    if (a.enabled) await refreshStatus(a.id).catch(() => undefined);
  }
}
