import type { Approval } from '@shared/types';
import { newId, now, HttpError } from '../core/util';
import { events } from '../core/events';
import { getSettings } from '../core/settings';
import { activity } from './activity';

interface PendingApproval {
  approval: Approval;
  resolve: (d: ApprovalDecision) => void;
  timer: NodeJS.Timeout;
}

export interface ApprovalDecision {
  allow: boolean;
  remember: 'once' | 'session';
  message?: string;
}

const pending = new Map<string, PendingApproval>();
/** requesterId → set of remembered keys ("allow for this chat/task"). */
const remembered = new Map<string, Set<string>>();

export function rememberedAllow(requesterId: string, key: string) {
  return remembered.get(requesterId)?.has(key) ?? false;
}

export function forgetRequester(requesterId: string) {
  remembered.delete(requesterId);
  for (const p of pending.values()) {
    if (p.approval.requester.id === requesterId) decide(p.approval.id, { allow: false, remember: 'once', message: 'Session ended' });
  }
}

export function listApprovals(): Approval[] {
  return [...pending.values()].map((p) => p.approval);
}

/** Asks the user (via the UI) and waits. Times out to "deny" so agents never hang forever. */
export function requestApproval(input: Omit<Approval, 'id' | 'createdAt' | 'expiresAt'> & { rememberKey?: string }): Promise<ApprovalDecision> {
  const { rememberKey, ...rest } = input;
  if (rememberKey && rememberedAllow(rest.requester.id, rememberKey)) return Promise.resolve({ allow: true, remember: 'session' });
  const timeoutSec = getSettings().agents.approvalTimeoutSec;
  const approval: Approval = { ...rest, id: newId('apr'), createdAt: now(), expiresAt: now() + timeoutSec * 1000 };
  return new Promise((resolve) => {
    const timer = setTimeout(() => decide(approval.id, { allow: false, remember: 'once', message: 'No answer — denied automatically after timeout' }), timeoutSec * 1000);
    pending.set(approval.id, {
      approval,
      timer,
      resolve: (d) => {
        if (d.allow && d.remember === 'session' && rememberKey) {
          if (!remembered.has(rest.requester.id)) remembered.set(rest.requester.id, new Set());
          remembered.get(rest.requester.id)!.add(rememberKey);
        }
        resolve(d);
      },
    });
    events.emit('approval.created', approval);
  });
}

export function decide(id: string, d: ApprovalDecision) {
  const p = pending.get(id);
  if (!p) throw new HttpError(404, 'This approval request is no longer pending');
  clearTimeout(p.timer);
  pending.delete(id);
  p.resolve(d);
  events.emit('approval.resolved', { id, allow: d.allow });
  activity('approval', `${d.allow ? 'Approved' : 'Denied'}: ${p.approval.title}`, `${p.approval.requester.label}${d.message ? ' — ' + d.message : ''}`, p.approval.requester.id);
}

export function denyAll(reason: string) {
  for (const id of [...pending.keys()]) decide(id, { allow: false, remember: 'once', message: reason });
}
