import { db } from '../core/db';
import { newId, now } from '../core/util';
import { events } from '../core/events';

export interface ActivityEntry {
  id: string;
  ts: number;
  kind: string;
  label: string;
  detail: string;
  refId: string | null;
}

/** Human-readable activity feed (shown on the Activity page and Usage dashboard). */
export function activity(kind: string, label: string, detail = '', refId: string | null = null) {
  const e: ActivityEntry = { id: newId('ev'), ts: now(), kind, label, detail: detail.slice(0, 500), refId };
  try {
    db().run('INSERT INTO activity (id, ts, kind, label, detail, ref_id) VALUES (?, ?, ?, ?, ?, ?)', e.id, e.ts, e.kind, e.label, e.detail, e.refId);
  } catch {
    /* db not ready */
  }
  events.emit('activity', e);
  return e;
}

export function listActivity(limit = 200, before?: number): ActivityEntry[] {
  const rows = before
    ? db().all<any>('SELECT * FROM activity WHERE ts < ? ORDER BY ts DESC LIMIT ?', before, limit)
    : db().all<any>('SELECT * FROM activity ORDER BY ts DESC LIMIT ?', limit);
  return rows.map((r) => ({ id: r.id, ts: r.ts, kind: r.kind, label: r.label, detail: r.detail, refId: r.ref_id }));
}
