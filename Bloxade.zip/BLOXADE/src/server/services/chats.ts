import fs from 'node:fs';
import path from 'node:path';
import type { AttachmentRef, Block, Chat, ChatMode, Message, Provider, ProviderRef, UsageInfo } from '@shared/types';
import { db, b, j } from '../core/db';
import { newId, now, safeJson, HttpError, str, oneOf, safeToken, preview, titleFrom, estimateTokens, debounce } from '../core/util';
import { dirs } from '../core/paths';
import { events } from '../core/events';
import { getSettings } from '../core/settings';
import { logger } from '../core/log';
import { resolveAccount, registerSessionCounter } from './accounts';
import { getProject, recordChanges, touchProject } from './projects';
import { buildContextPack } from './context';
import { BlockStream } from './blocks';
import { makePermissionHandler } from './policy';
import { systemPrompt } from './prompts';
import { recordUsage } from './usage';
import { forgetRequester } from './approvals';
import { activity } from './activity';
import { fileLocks, snapshot, diffSnapshots, type Snapshot } from './files';
import { runTurn } from '../providers';
import type { TurnResult } from '../providers/types';
import { createBridgeSession, revokeBridgeSession } from '../roblox/sessions';
import { roblox, robloxAvailableFor } from '../roblox/manager';

const log = logger('chat');

interface ChatRow {
  id: string; title: string; project_id: string | null; pinned: number; provider: Provider; account_id: string | null; model: string;
  effort: string; mode: ChatMode; created_at: number; updated_at: number; preview: string | null; branched_from: string | null;
  provider_ref: string | null; context_sent: string | null;
}
interface MsgRow {
  id: string; chat_id: string; seq: number; role: 'user' | 'assistant'; content: string; blocks: string; status: Message['status'];
  attachments: string; usage: string | null; error: string | null; provider: Provider | null; account_id: string | null; model: string | null;
  effort: string | null; mode: ChatMode | null; provider_ref: string | null; created_at: number; duration_ms: number | null;
}

interface ActiveRun {
  chatId: string;
  messageId: string;
  accountId: string;
  abort: AbortController;
  startedAt: number;
}
const active = new Map<string, ActiveRun>();

registerSessionCounter(() => {
  const m = new Map<string, number>();
  for (const r of active.values()) m.set(r.accountId, (m.get(r.accountId) ?? 0) + 1);
  return m;
});

export function runningChatIds() {
  return [...active.keys()];
}

function toChat(r: ChatRow): Chat {
  return {
    id: r.id,
    title: r.title,
    projectId: r.project_id,
    pinned: !!r.pinned,
    provider: r.provider,
    accountId: r.account_id,
    model: r.model,
    effort: r.effort,
    mode: r.mode,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
    preview: r.preview ?? '',
    running: active.has(r.id),
    branchedFrom: safeJson(r.branched_from, null),
  };
}

function toMessage(r: MsgRow): Message {
  return {
    id: r.id,
    chatId: r.chat_id,
    role: r.role,
    content: r.content,
    blocks: safeJson<Block[]>(r.blocks, []),
    status: r.status,
    attachments: safeJson<AttachmentRef[]>(r.attachments, []),
    usage: safeJson<UsageInfo | null>(r.usage, null),
    error: r.error,
    provider: r.provider,
    accountId: r.account_id,
    model: r.model,
    effort: r.effort,
    mode: r.mode,
    providerRef: safeJson<ProviderRef | null>(r.provider_ref, null),
    createdAt: r.created_at,
    durationMs: r.duration_ms,
  };
}

export function listChats(opts: { projectId?: string | null; limit?: number } = {}): Chat[] {
  const rows = opts.projectId
    ? db().all<ChatRow>('SELECT * FROM chats WHERE project_id = ? ORDER BY pinned DESC, updated_at DESC LIMIT ?', opts.projectId, opts.limit ?? 500)
    : db().all<ChatRow>('SELECT * FROM chats ORDER BY pinned DESC, updated_at DESC LIMIT ?', opts.limit ?? 300);
  return rows.map(toChat);
}

export function getChatRow(id: string) {
  const r = db().get<ChatRow>('SELECT * FROM chats WHERE id = ?', id);
  if (!r) throw new HttpError(404, 'Chat not found');
  return r;
}

export function getChat(id: string): { chat: Chat; messages: Message[] } {
  const r = getChatRow(id);
  const msgs = db().all<MsgRow>('SELECT * FROM messages WHERE chat_id = ? ORDER BY seq ASC', id).map(toMessage);
  return { chat: { ...toChat(r), messageCount: msgs.length }, messages: msgs };
}

export function searchChats(q: string) {
  const like = `%${q.replace(/[%_]/g, (m) => '\\' + m)}%`;
  const titleHits = db().all<ChatRow>("SELECT * FROM chats WHERE title LIKE ? ESCAPE '\\' ORDER BY updated_at DESC LIMIT 30", like).map(toChat);
  const msgHits = db().all<{ chat_id: string; id: string; content: string; role: string }>(
    "SELECT chat_id, id, content, role FROM messages WHERE content LIKE ? ESCAPE '\\' ORDER BY created_at DESC LIMIT 60",
    like,
  );
  const results: { chat: Chat; messageId: string | null; snippet: string }[] = titleHits.map((c) => ({ chat: c, messageId: null, snippet: c.preview ?? '' }));
  const seen = new Set(titleHits.map((c) => c.id));
  for (const m of msgHits) {
    if (seen.has(m.chat_id)) continue;
    const row = db().get<ChatRow>('SELECT * FROM chats WHERE id = ?', m.chat_id);
    if (!row) continue;
    seen.add(m.chat_id);
    const i = m.content.toLowerCase().indexOf(q.toLowerCase());
    const snippet = (i > 40 ? '…' : '') + m.content.slice(Math.max(0, i - 40), i + 120).replace(/\s+/g, ' ');
    results.push({ chat: toChat(row), messageId: m.id, snippet });
    if (results.length >= 40) break;
  }
  return results;
}

function emitChat(id: string) {
  const r = db().get<ChatRow>('SELECT * FROM chats WHERE id = ?', id);
  if (r) events.emit('chat.updated', toChat(r));
}

export function createChat(body: any): Chat {
  const s = getSettings();
  const project = body?.projectId ? getProject(body.projectId) : null;
  if (body?.projectId && !project) throw new HttpError(404, 'Project not found');
  const provider = oneOf(body?.provider ?? project?.defaults.provider ?? s.providers.defaultProvider, ['claude', 'codex'] as const, 'provider');
  const account = resolveAccount(provider, body?.accountId ?? project?.defaults.accountId ?? null);
  const id = newId('chat');
  const model = safeToken(body?.model ?? project?.defaults.model ?? s.providers.defaultModels[provider] ?? '', 'model', true);
  const effort = safeToken(body?.effort ?? project?.defaults.effort ?? s.providers.defaultEfforts[provider] ?? '', 'effort', true);
  const mode = oneOf(body?.mode ?? project?.defaults.mode ?? s.providers.defaultMode, ['chat', 'cowork'] as const, 'mode');
  db().upsert('chats', {
    id, title: str(body?.title ?? 'New chat', 'title', { max: 200 }) || 'New chat', project_id: project?.id ?? null, pinned: 0, provider,
    account_id: account?.id ?? null, model, effort, mode, created_at: now(), updated_at: now(), preview: '', branched_from: null,
    provider_ref: null, context_sent: null,
  });
  emitChat(id);
  return toChat(getChatRow(id));
}

export function updateChat(id: string, body: any): Chat {
  const cur = getChatRow(id);
  const patch: Record<string, any> = {};
  if (body.title !== undefined) patch.title = str(body.title, 'title', { min: 1, max: 200 }).trim();
  if (body.pinned !== undefined) patch.pinned = b(!!body.pinned);
  if (body.projectId !== undefined) {
    if (body.projectId && !getProject(body.projectId)) throw new HttpError(404, 'Project not found');
    patch.project_id = body.projectId || null;
    patch.context_sent = null;
  }
  const sessionAffecting: string[] = [];
  if (body.provider !== undefined) {
    const p = oneOf(body.provider, ['claude', 'codex'] as const, 'provider');
    if (p !== cur.provider) sessionAffecting.push('provider');
    patch.provider = p;
  }
  if (body.accountId !== undefined) {
    if (body.accountId !== cur.account_id) sessionAffecting.push('account');
    patch.account_id = body.accountId || null;
  }
  if (body.model !== undefined) patch.model = safeToken(body.model, 'model', true);
  if (body.effort !== undefined) patch.effort = safeToken(body.effort, 'effort', true);
  if (body.mode !== undefined) patch.mode = oneOf(body.mode, ['chat', 'cowork'] as const, 'mode');
  if (sessionAffecting.length) {
    // A different provider/account cannot continue the same provider session — start a fresh one seeded with a transcript.
    patch.provider_ref = j({ reseed: true });
    patch.context_sent = null;
  }
  if (Object.keys(patch).length) db().update('chats', id, { ...patch, updated_at: body.title !== undefined || body.pinned !== undefined ? cur.updated_at : now() });
  emitChat(id);
  return toChat(getChatRow(id));
}

export function deleteChat(id: string) {
  getChatRow(id);
  stopChat(id);
  const atts = db().all<{ path: string }>('SELECT path FROM attachments WHERE chat_id = ?', id);
  db().tx(() => {
    db().run('DELETE FROM messages WHERE chat_id = ?', id);
    db().run('DELETE FROM attachments WHERE chat_id = ?', id);
    db().run('DELETE FROM chats WHERE id = ?', id);
  });
  for (const a of atts) {
    try {
      fs.rmSync(path.dirname(a.path), { recursive: true, force: true });
    } catch {
      /* ignore */
    }
  }
  events.emit('chat.deleted', { id });
}

// ---------- attachments ----------

const TEXT_EXT = new Set(['.txt', '.md', '.lua', '.luau', '.json', '.ts', '.tsx', '.js', '.jsx', '.py', '.css', '.html', '.xml', '.yaml', '.yml', '.toml', '.csv', '.log', '.rs', '.go', '.java', '.c', '.cpp', '.h', '.cs', '.sh', '.ps1', '.bat', '.sql', '.ini', '.cfg', '.rbxlx', '.rbxmx']);
const IMAGE_MIME = new Set(['image/png', 'image/jpeg', 'image/gif', 'image/webp']);

export function saveAttachment(body: any): AttachmentRef {
  const name = path.basename(str(body?.name, 'name', { min: 1, max: 200 })).replace(/[<>:"|?*\x00-\x1f]/g, '_');
  const mime = typeof body?.mime === 'string' ? body.mime.slice(0, 100) : 'application/octet-stream';
  const data = Buffer.from(str(body?.data, 'data', { min: 1, max: 40 * 1024 * 1024 }), 'base64');
  if (data.length > 25 * 1024 * 1024) throw new HttpError(413, 'Attachments are limited to 25 MB');
  const id = newId('att');
  const dir = path.join(dirs.attachments, id);
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, name);
  fs.writeFileSync(file, data);
  const ext = path.extname(name).toLowerCase();
  const kind: AttachmentRef['kind'] = IMAGE_MIME.has(mime) && data.length < 5 * 1024 * 1024 ? 'image' : (mime.startsWith('text/') || TEXT_EXT.has(ext)) && data.length < 400 * 1024 ? 'text' : 'file';
  db().upsert('attachments', { id, chat_id: body?.chatId ?? null, name, mime, size: data.length, kind, path: file, created_at: now() });
  return { id, name, mime, size: data.length, kind };
}

export function attachmentFile(id: string): { path: string; mime: string; name: string } {
  const r = db().get<{ path: string; mime: string; name: string }>('SELECT path, mime, name FROM attachments WHERE id = ?', id);
  if (!r || !fs.existsSync(r.path)) throw new HttpError(404, 'Attachment not found');
  return r;
}

// ---------- messaging ----------

function nextSeq(chatId: string) {
  return (db().get<{ s: number | null }>('SELECT MAX(seq) AS s FROM messages WHERE chat_id = ?', chatId)?.s ?? 0) + 1;
}

function insertMessage(m: Message, seq: number) {
  db().upsert('messages', {
    id: m.id, chat_id: m.chatId, seq, role: m.role, content: m.content, blocks: j(m.blocks), status: m.status, attachments: j(m.attachments),
    usage: j(m.usage ?? null), error: m.error ?? null, provider: m.provider ?? null, account_id: m.accountId ?? null, model: m.model ?? null,
    effort: m.effort ?? null, mode: m.mode ?? null, provider_ref: j(m.providerRef ?? null), created_at: m.createdAt, duration_ms: m.durationMs ?? null,
  });
}

function persistMessage(m: Message) {
  db().update('messages', m.id, {
    content: m.content, blocks: j(m.blocks), status: m.status, usage: j(m.usage ?? null), error: m.error ?? null, provider_ref: j(m.providerRef ?? null),
    duration_ms: m.durationMs ?? null, model: m.model ?? null,
  });
}

function resolveAttachments(ids: unknown): AttachmentRef[] {
  if (!Array.isArray(ids)) return [];
  return ids
    .slice(0, 12)
    .map((id) => db().get<any>('SELECT * FROM attachments WHERE id = ?', String(id)))
    .filter(Boolean)
    .map((r) => ({ id: r.id, name: r.name, mime: r.mime, size: r.size, kind: r.kind }));
}

export function sendMessage(chatId: string, body: any) {
  const row = getChatRow(chatId);
  if (active.has(chatId)) throw new HttpError(409, 'This chat is already generating a response. Stop it or wait for it to finish.');
  const text = str(body?.text ?? '', 'message', { max: 200_000 });
  const attachments = resolveAttachments(body?.attachmentIds);
  if (!text.trim() && !attachments.length) throw new HttpError(400, 'Message is empty');
  for (const a of attachments) db().run('UPDATE attachments SET chat_id = ? WHERE id = ?', chatId, a.id);
  const userMsg: Message = { id: newId('msg'), chatId, role: 'user', content: text, blocks: [{ type: 'text', text }], status: 'complete', attachments, createdAt: now() };
  insertMessage(userMsg, nextSeq(chatId));
  events.emit('chat.message', userMsg);
  if ((row.title === 'New chat' || !row.title) && getSettings().general.autoTitle && text.trim()) {
    db().update('chats', chatId, { title: titleFrom(text) });
    emitChat(chatId);
  }
  const ref = safeJson<(ProviderRef & { reseed?: boolean; fork?: boolean }) | null>(row.provider_ref, null);
  let opts: { resume: ProviderRef | null; forkFrom: ProviderRef | null; reseed: boolean };
  if (ref?.fork) opts = { resume: null, forkFrom: ref, reseed: false };
  else if (ref?.reseed) opts = { resume: null, forkFrom: null, reseed: true };
  else opts = { resume: ref, forkFrom: null, reseed: false };
  const assistant = startTurn(chatId, userMsg, opts);
  return { userMessage: userMsg, assistantMessage: assistant };
}

function previousAssistant(chatId: string, beforeSeq: number): MsgRow | undefined {
  return db().get<MsgRow>("SELECT * FROM messages WHERE chat_id = ? AND role = 'assistant' AND seq < ? AND status = 'complete' ORDER BY seq DESC LIMIT 1", chatId, beforeSeq);
}

function forkPointBefore(chatId: string, seq: number): ProviderRef {
  const prev = previousAssistant(chatId, seq);
  const ref = prev ? safeJson<ProviderRef | null>(prev.provider_ref, null) : null;
  return ref ?? {}; // {} → fresh provider session
}

/** Regenerates the last assistant answer from the exact provider checkpoint before it. */
export function regenerate(chatId: string) {
  getChatRow(chatId);
  if (active.has(chatId)) throw new HttpError(409, 'Wait for the current response to finish');
  const lastUser = db().get<MsgRow>("SELECT * FROM messages WHERE chat_id = ? AND role = 'user' ORDER BY seq DESC LIMIT 1", chatId);
  if (!lastUser) throw new HttpError(400, 'Nothing to regenerate');
  const forkFrom = forkPointBefore(chatId, lastUser.seq);
  db().run('DELETE FROM messages WHERE chat_id = ? AND seq > ?', chatId, lastUser.seq);
  events.emit('chat.reload', { chatId });
  const assistant = startTurn(chatId, toMessage(lastUser), { resume: null, forkFrom, reseed: false, needsTranscript: !forkFrom.sessionId && !forkFrom.threadId && lastUser.seq > 1 });
  return { assistantMessage: assistant };
}

/** Edits a user message and continues from there (later messages are replaced). */
export function editMessage(chatId: string, messageId: string, body: any) {
  getChatRow(chatId);
  if (active.has(chatId)) throw new HttpError(409, 'Wait for the current response to finish');
  const msg = db().get<MsgRow>('SELECT * FROM messages WHERE id = ? AND chat_id = ?', messageId, chatId);
  if (!msg || msg.role !== 'user') throw new HttpError(400, 'Only your own messages can be edited');
  const text = str(body?.text, 'message', { min: 1, max: 200_000 });
  const forkFrom = forkPointBefore(chatId, msg.seq);
  db().run('DELETE FROM messages WHERE chat_id = ? AND seq > ?', chatId, msg.seq);
  db().update('messages', messageId, { content: text, blocks: j([{ type: 'text', text }]) });
  events.emit('chat.reload', { chatId });
  const updated = { ...toMessage(msg), content: text, blocks: [{ type: 'text' as const, text }] };
  const assistant = startTurn(chatId, updated, { resume: null, forkFrom, reseed: false, needsTranscript: !forkFrom.sessionId && !forkFrom.threadId && msg.seq > 1 });
  return { assistantMessage: assistant };
}

/** Copies the conversation up to a message into a new chat that forks the provider session at that point. */
export function branchChat(chatId: string, messageId: string): Chat {
  const row = getChatRow(chatId);
  const msg = db().get<MsgRow>('SELECT * FROM messages WHERE id = ? AND chat_id = ?', messageId, chatId);
  if (!msg) throw new HttpError(404, 'Message not found');
  const upto = msg.role === 'assistant' ? msg.seq : msg.seq - 1;
  const rows = db().all<MsgRow>('SELECT * FROM messages WHERE chat_id = ? AND seq <= ? ORDER BY seq', chatId, upto);
  const lastAssistant = [...rows].reverse().find((r) => r.role === 'assistant' && r.status === 'complete');
  const ref = lastAssistant ? safeJson<ProviderRef | null>(lastAssistant.provider_ref, null) : null;
  const id = newId('chat');
  db().tx(() => {
    db().upsert('chats', {
      id, title: `${row.title} (branch)`.slice(0, 200), project_id: row.project_id, pinned: 0, provider: row.provider, account_id: row.account_id,
      model: row.model, effort: row.effort, mode: row.mode, created_at: now(), updated_at: now(), preview: row.preview,
      branched_from: j({ chatId, messageId }), provider_ref: j(ref ? { ...ref, fork: true } : { reseed: rows.length > 0 }), context_sent: null,
    });
    rows.forEach((r, i) => insertMessage({ ...toMessage(r), id: newId('msg'), chatId: id }, i + 1));
  });
  activity('chat', `Branched “${row.title}”`, `${rows.length} messages copied`, id);
  emitChat(id);
  return toChat(getChatRow(id));
}

export function stopChat(chatId: string) {
  const r = active.get(chatId);
  if (r) r.abort.abort();
}

export function stopAllChats() {
  for (const r of active.values()) r.abort.abort();
}

/** Compressed transcript used when a provider session cannot be continued (provider/account switch, branch without checkpoint). */
function transcriptFor(chatId: string, beforeSeq: number, maxChars: number): string {
  const rows = db().all<MsgRow>('SELECT role, content, seq FROM messages WHERE chat_id = ? AND seq < ? ORDER BY seq DESC LIMIT 40', chatId, beforeSeq) as MsgRow[];
  const lines: string[] = [];
  let used = 0;
  for (const r of rows) {
    const t = `${r.role === 'user' ? 'User' : 'Assistant'}: ${r.content.length > 1500 ? r.content.slice(0, 1500) + ' …' : r.content}`;
    if (used + t.length > maxChars) break;
    lines.unshift(t);
    used += t.length;
  }
  return lines.length ? `<previous_conversation note="Earlier messages from this BLOXADE chat (compressed)">\n${lines.join('\n\n')}\n</previous_conversation>\n\n` : '';
}

function buildPrompt(row: ChatRow, user: Message, needsTranscript: boolean, userSeq: number) {
  const project = getProject(row.project_id);
  const s = getSettings();
  let prompt = '';
  let estSaved = 0;
  let packFiles: Record<string, string> = {};
  if (needsTranscript) prompt += transcriptFor(row.id, userSeq, 12000);
  if (project && s.context.primeChats) {
    const sent = safeJson<Record<string, string>>(row.context_sent, {});
    const firstTurn = Object.keys(sent).length === 0 && !safeJson<any>(row.provider_ref, null)?.sessionId && !safeJson<any>(row.provider_ref, null)?.threadId;
    const pack = buildContextPack({ project, query: user.content, alreadySent: sent, includeTree: firstTurn, includeMemory: firstTurn });
    if (pack) {
      prompt += pack.text + '\n\n';
      estSaved = pack.savedTokens;
      packFiles = pack.files;
    }
  }
  const images: { path: string; mime: string }[] = [];
  const fileNotes: string[] = [];
  for (const a of user.attachments) {
    const f = db().get<{ path: string }>('SELECT path FROM attachments WHERE id = ?', a.id);
    if (!f) continue;
    if (a.kind === 'image') images.push({ path: f.path, mime: a.mime });
    else if (a.kind === 'text') {
      const content = fs.readFileSync(f.path, 'utf8');
      prompt += `<attachment name="${a.name.replace(/"/g, '')}">\n${content.slice(0, 120_000)}\n</attachment>\n\n`;
    } else fileNotes.push(`- ${a.name} (${Math.round(a.size / 1024)} KB) saved at: ${f.path}`);
  }
  if (fileNotes.length) prompt += `Attached files:\n${fileNotes.join('\n')}\n${row.mode === 'chat' ? '(Binary files can only be opened by the AI in Cowork mode.)\n' : ''}\n`;
  prompt += user.content;
  return { prompt, images, project, estSaved, packFiles };
}

function startTurn(chatId: string, user: Message, opts: { resume: ProviderRef | null; forkFrom: ProviderRef | null; reseed: boolean; needsTranscript?: boolean }): Message {
  const row = getChatRow(chatId);
  const s = getSettings();
  const account = resolveAccount(row.provider, row.account_id);
  const assistant: Message = {
    id: newId('msg'), chatId, role: 'assistant', content: '', blocks: [], status: 'streaming', attachments: [], createdAt: now(),
    provider: row.provider, accountId: account?.id ?? null, model: row.model, effort: row.effort, mode: row.mode,
  };
  insertMessage(assistant, nextSeq(chatId));
  events.emit('chat.message', assistant);

  if (!account) {
    assistant.status = 'error';
    assistant.error = `No ${row.provider === 'claude' ? 'Claude' : 'Codex'} account is connected. Open Accounts to add one.`;
    persistMessage(assistant);
    events.emit('chat.done', assistant);
    return assistant;
  }
  if (!account.enabled) {
    assistant.status = 'error';
    assistant.error = `The account “${account.name}” is disabled. Enable it in Accounts or pick another account.`;
    persistMessage(assistant);
    events.emit('chat.done', assistant);
    return assistant;
  }

  const abort = new AbortController();
  active.set(chatId, { chatId, messageId: assistant.id, accountId: account.id, abort, startedAt: now() });
  emitChat(chatId);
  events.emit('account.updated', { ...account, activeSessions: (account.activeSessions ?? 0) + 1 });

  void (async () => {
    const userSeq = db().get<{ seq: number }>('SELECT seq FROM messages WHERE id = ?', user.id)?.seq ?? 0;
    const { prompt, images, project, estSaved, packFiles } = buildPrompt(row, user, opts.reseed || !!opts.needsTranscript, userSeq);
    const robloxOn = row.mode === 'cowork' && !!project?.robloxEnabled && robloxAvailableFor();
    const workspace = path.join(dirs.workspaces, chatId);
    fs.mkdirSync(workspace, { recursive: true });
    const cwd = row.mode === 'cowork' && project?.folderPath && fs.existsSync(project.folderPath) ? project.folderPath : workspace;
    const label = `Chat “${row.title === 'New chat' ? titleFrom(user.content) : row.title}”`;
    const bridgeToken = robloxOn ? createBridgeSession({ kind: 'chat', id: chatId, label }) : null;
    let before: Snapshot | null = null;
    if (row.mode === 'cowork' && project?.folderPath && cwd === project.folderPath) {
      try {
        before = snapshot(project.folderPath).snap;
      } catch (e) {
        log.warn('snapshot failed', (e as Error).message);
      }
    }

    const persist = debounce(() => persistMessage(assistant), 700);
    const stream = new BlockStream(assistant.blocks, {
      block: (index, block) => {
        assistant.content = stream.text;
        events.emit('chat.block', { chatId, messageId: assistant.id, index, block });
        persist();
      },
      delta: (index, kind, text) => {
        assistant.content = stream.text;
        events.emit('chat.delta', { chatId, messageId: assistant.id, index, kind, text });
        persist();
      },
    });
    if (opts.reseed) stream.notice('info', 'Started a new provider session for this chat (provider or account changed); earlier messages were passed as compressed context.');

    const result = await runTurn(row.provider, {
      account,
      model: row.model,
      effort: row.effort,
      mode: row.mode,
      cwd,
      addDirs: [path.join(dirs.attachments)],
      systemAppend: systemPrompt({ mode: row.mode, project, roblox: robloxOn, cwd }),
      prompt,
      images,
      resume: opts.resume,
      forkFrom: opts.forkFrom,
      bridgeToken,
      permissionMode: 'ask',
      onPermission: makePermissionHandler({ kind: 'chat', id: chatId, label, cwd, projectRoot: project?.folderPath ?? null, extraRoots: [workspace, dirs.attachments] }),
      onEvent: (e) => stream.apply(e),
      signal: abort.signal,
      timeoutMs: s.advanced.turnTimeoutMin * 60_000,
      label,
    }).catch((e): TurnResult => ({ ok: false, cancelled: false, text: '', ref: {}, usage: null, error: (e as Error).message, durationMs: 0 }));

    persist.flush();
    revokeBridgeSession(bridgeToken);
    fileLocks.release(chatId);
    roblox.releaseCaller(chatId);
    forgetRequester(chatId);
    active.delete(chatId);

    assistant.content = stream.text;
    assistant.usage = result.usage ? { ...result.usage, contextTokensSaved: estSaved } : null;
    assistant.durationMs = result.durationMs;
    assistant.providerRef = result.ref;
    assistant.model = result.model ?? row.model;
    if (result.cancelled) {
      assistant.status = 'cancelled';
      if (!assistant.blocks.length) stream.notice('info', 'Stopped before any output.');
    } else if (!result.ok) {
      assistant.status = 'error';
      assistant.error = result.error ?? 'The provider returned an error';
    } else assistant.status = 'complete';

    // File change tracking for Cowork turns
    if (before && project?.folderPath) {
      try {
        const after = snapshot(project.folderPath).snap;
        const changes = diffSnapshots(before, after);
        if (changes.length) {
          recordChanges(project.id, changes, 'chat', chatId);
          stream.notice('info', `Changed ${changes.length} file${changes.length === 1 ? '' : 's'}: ${changes.slice(0, 6).map((c) => c.path).join(', ')}${changes.length > 6 ? '…' : ''} — review in Project → Files → Changes.`);
        }
      } catch (e) {
        log.warn('change detection failed', (e as Error).message);
      }
    }
    persistMessage(assistant);

    // Chat bookkeeping: session pointer, already-shared context, title, preview
    const chatPatch: Record<string, any> = { updated_at: now(), preview: preview(stream.text || user.content) };
    if (result.ref && (result.ref.sessionId || result.ref.threadId) && (result.ok || result.cancelled)) {
      chatPatch.provider_ref = j(result.ref);
      const prevSent = opts.resume ? safeJson<Record<string, string>>(row.context_sent, {}) : {};
      chatPatch.context_sent = j({ ...prevSent, ...packFiles });
    }
    const count = db().get<{ n: number }>("SELECT COUNT(*) AS n FROM messages WHERE chat_id = ? AND role = 'user'", chatId)?.n ?? 0;
    if (count <= 1 && (row.title === 'New chat' || !row.title) && s.general.autoTitle) chatPatch.title = titleFrom(user.content);
    db().update('chats', chatId, chatPatch);
    if (project) touchProject(project.id);

    recordUsage({
      provider: row.provider, accountId: account.id, model: assistant.model ?? null, kind: 'chat', refId: chatId, usage: result.usage,
      estimatedTokens: estimateTokens(prompt) + estimateTokens(stream.text), contextSaved: estSaved, durationMs: result.durationMs, ok: result.ok,
    });
    events.emit('chat.done', assistant);
    emitChat(chatId);
    const acc = resolveAccount(row.provider, account.id);
    if (acc) events.emit('account.updated', acc);
  })().catch((e) => {
    log.error('chat turn crashed', e);
    active.delete(chatId);
    assistant.status = 'error';
    assistant.error = (e as Error).message;
    persistMessage(assistant);
    events.emit('chat.done', assistant);
    emitChat(chatId);
  });
  return assistant;
}

/** Marks messages left "streaming" by a previous BLOXADE process as interrupted. */
export function recoverInterrupted() {
  const n = db().run("UPDATE messages SET status = 'error', error = 'Interrupted — BLOXADE was closed while this response was generating.' WHERE status = 'streaming'");
  if (Number(n.changes)) log.info(`marked ${n.changes} interrupted messages`);
}

export function chatTranscriptForMemory(chatId: string, maxChars = 16000) {
  return transcriptFor(chatId, Number.MAX_SAFE_INTEGER, maxChars);
}
