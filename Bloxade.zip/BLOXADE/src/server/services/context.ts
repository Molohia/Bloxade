import fs from 'node:fs';
import path from 'node:path';
import type { EfficiencyMode, Project } from '@shared/types';
import { EFFICIENCY_PROFILES } from '@shared/types';
import { walk, readText, isProbablyText, type WalkEntry } from './files';
import { estimateTokens, sha1 } from '../core/util';
import { getSettings } from '../core/settings';

/**
 * BLOXADE context & efficiency engine.
 *  - Builds small, targeted "context packs" (memory + compressed tree + relevant snippets) instead of whole projects.
 *  - Remembers which file versions were already shared with a provider session and does not resend them.
 *  - Caches project indexes / file contents (invalidated by size+mtime).
 *  - Compresses large tool outputs before they go back to an agent.
 * All token numbers produced here are ESTIMATES (≈4 chars/token) and are labelled as such in the UI.
 */

interface IndexEntry extends WalkEntry {
  ext: string;
}
interface ProjectIndex {
  root: string;
  files: IndexEntry[];
  truncated: boolean;
  builtAt: number;
  totalTextBytes: number;
}

const indexes = new Map<string, ProjectIndex>();
const contentCache = new Map<string, { key: string; text: string; terms: Map<string, number> }>();
let contentBytes = 0;
const stats = { indexHits: 0, indexBuilds: 0, contentHits: 0, contentReads: 0 };

export function cacheStats() {
  return { ...stats, indexes: indexes.size, cachedFiles: contentCache.size, cachedBytes: contentBytes };
}

export function invalidateProject(projectId: string) {
  indexes.delete(projectId);
}

export function getIndex(projectId: string, root: string, force = false): ProjectIndex {
  const cur = indexes.get(projectId);
  const useCache = getSettings().context.cache;
  if (cur && !force && useCache && cur.root === root && Date.now() - cur.builtAt < 15_000) {
    stats.indexHits++;
    return cur;
  }
  const { files, truncated } = walk(root, { maxFiles: 25000 });
  const entries = files.map((f) => ({ ...f, ext: path.extname(f.rel).toLowerCase() }));
  const totalTextBytes = entries.filter((f) => isProbablyText(f.rel) && f.size < 1_000_000).reduce((n, f) => n + f.size, 0);
  const idx: ProjectIndex = { root, files: entries, truncated, builtAt: Date.now(), totalTextBytes };
  indexes.set(projectId, idx);
  stats.indexBuilds++;
  return idx;
}

const STOP = new Set(
  'the a an and or but if then else for to of in on at by with from into this that these those is are was were be been it its as do does did make add create build fix update change use using please can could would should my our your their game script code file files new also just like want need get set via all any some more most'.split(
    ' ',
  ),
);

export function terms(text: string): string[] {
  const out: string[] = [];
  const raw = text
    .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
    .replace(/[_\-./\\:]+/g, ' ')
    .toLowerCase()
    .split(/[^a-z0-9]+/);
  for (const t of raw) if (t.length >= 3 && !STOP.has(t) && !/^\d+$/.test(t)) out.push(t);
  return out;
}

function fileContent(f: IndexEntry): { text: string; terms: Map<string, number> } | null {
  if (!isProbablyText(f.rel) || f.size > 400_000) return null;
  const key = `${f.size}|${f.mtime}`;
  const c = contentCache.get(f.abs);
  if (c && c.key === key) {
    stats.contentHits++;
    return c;
  }
  try {
    const r = readText(f.abs, 400_000);
    if (r.binary) return null;
    const tf = new Map<string, number>();
    for (const t of terms(r.content)) tf.set(t, (tf.get(t) ?? 0) + 1);
    const entry = { key, text: r.content, terms: tf };
    if (c) contentBytes -= c.text.length;
    contentCache.set(f.abs, entry);
    contentBytes += r.content.length;
    stats.contentReads++;
    if (contentBytes > 48 * 1024 * 1024) {
      // drop oldest half
      let i = 0;
      for (const [k, v] of contentCache) {
        if (i++ > contentCache.size / 2) break;
        contentBytes -= v.text.length;
        contentCache.delete(k);
      }
    }
    return entry;
  } catch {
    return null;
  }
}

export interface RankedFile {
  rel: string;
  score: number;
  entry: IndexEntry;
}

/** BM25-style ranking with filename/path boosts. */
export function rankFiles(idx: ProjectIndex, query: string, limit = 12): RankedFile[] {
  const q = [...new Set(terms(query))];
  if (!q.length) return [];
  const candidates = idx.files.filter((f) => isProbablyText(f.rel) && f.size <= 400_000).slice(0, 6000);
  const docs: { f: IndexEntry; tf: Map<string, number>; len: number }[] = [];
  const df = new Map<string, number>();
  for (const f of candidates) {
    const c = fileContent(f);
    if (!c) continue;
    let len = 0;
    for (const v of c.terms.values()) len += v;
    docs.push({ f, tf: c.terms, len });
    for (const t of q) if (c.terms.has(t)) df.set(t, (df.get(t) ?? 0) + 1);
  }
  const N = docs.length || 1;
  const avg = docs.reduce((n, d) => n + d.len, 0) / N || 1;
  const k1 = 1.2;
  const bb = 0.75;
  const scored: RankedFile[] = [];
  for (const d of docs) {
    let s = 0;
    const pathTerms = new Set(terms(d.f.rel));
    const base = path.basename(d.f.rel).toLowerCase();
    for (const t of q) {
      const tf = d.tf.get(t) ?? 0;
      if (tf) {
        const idf = Math.log(1 + (N - (df.get(t) ?? 0) + 0.5) / ((df.get(t) ?? 0) + 0.5));
        s += (idf * (tf * (k1 + 1))) / (tf + k1 * (1 - bb + (bb * d.len) / avg));
      }
      if (pathTerms.has(t)) s += 2.5;
      if (base.includes(t)) s += 3;
    }
    if (s > 0) scored.push({ rel: d.f.rel, score: s, entry: d.f });
  }
  return scored.sort((a, b) => b.score - a.score).slice(0, limit);
}

/** Picks the most relevant line windows of a file for the query terms. */
export function snippets(text: string, query: string, maxChars: number): { text: string; ranges: [number, number][] } {
  const lines = text.split('\n');
  if (text.length <= maxChars) return { text, ranges: [[1, lines.length]] };
  const q = new Set(terms(query));
  const hits: number[] = [];
  lines.forEach((l, i) => {
    const lt = terms(l);
    if (lt.some((t) => q.has(t))) hits.push(i);
  });
  if (!hits.length) {
    const head = lines.slice(0, 40).join('\n');
    return { text: head.slice(0, maxChars), ranges: [[1, Math.min(40, lines.length)]] };
  }
  const ranges: [number, number][] = [];
  for (const h of hits) {
    const s = Math.max(0, h - 8);
    const e = Math.min(lines.length - 1, h + 12);
    const last = ranges[ranges.length - 1];
    if (last && s <= last[1] + 2) last[1] = Math.max(last[1], e);
    else ranges.push([s, e]);
  }
  let out = '';
  const used: [number, number][] = [];
  for (const [s, e] of ranges) {
    const chunk = lines.slice(s, e + 1).map((l, i) => `${s + i + 1}| ${l}`).join('\n');
    if (out.length + chunk.length + 8 > maxChars) {
      if (!out) out = chunk.slice(0, maxChars);
      break;
    }
    out += (out ? '\n…\n' : '') + chunk;
    used.push([s + 1, e + 1]);
  }
  return { text: out, ranges: used };
}

/** Compressed directory tree: directories with counts, files only near the top. */
export function treeSummary(idx: ProjectIndex, maxLines = 60): string {
  const dirCounts = new Map<string, number>();
  for (const f of idx.files) {
    const parts = f.rel.split('/');
    for (let i = 1; i < parts.length; i++) {
      const d = parts.slice(0, i).join('/');
      dirCounts.set(d, (dirCounts.get(d) ?? 0) + 1);
    }
  }
  const lines: string[] = [];
  const top = idx.files.filter((f) => !f.rel.includes('/')).map((f) => f.rel);
  const dirsSorted = [...dirCounts.entries()].filter(([d]) => d.split('/').length <= 3).sort((a, b) => a[0].localeCompare(b[0]));
  for (const [d, n] of dirsSorted) {
    if (lines.length >= maxLines) break;
    const depth = d.split('/').length - 1;
    lines.push(`${'  '.repeat(depth)}${d.split('/').pop()}/ (${n} files)`);
  }
  for (const f of top.slice(0, Math.max(5, maxLines - lines.length))) lines.push(f);
  if (idx.truncated) lines.push('… (project is large; index truncated)');
  return lines.join('\n');
}

export interface ContextPack {
  text: string;
  files: Record<string, string>; // rel → content hash included
  estTokens: number;
  naiveTokens: number;
  savedTokens: number;
  skippedUnchanged: string[];
}

export function budgetFor(mode: EfficiencyMode): number {
  const s = getSettings().context;
  return s.budgetOverride ?? EFFICIENCY_PROFILES[mode].contextBudget;
}

/**
 * Builds a context pack for a prompt. `alreadySent` maps rel path → content hash already shared in this provider
 * session; those files are referenced by name instead of being resent.
 */
export function buildContextPack(opts: {
  project: Project;
  query: string;
  mode?: EfficiencyMode;
  alreadySent?: Record<string, string>;
  includeTree?: boolean;
  includeMemory?: boolean;
  budgetTokens?: number;
}): ContextPack | null {
  const { project } = opts;
  const mode = opts.mode ?? getSettings().context.mode;
  const budgetChars = (opts.budgetTokens ?? budgetFor(mode)) * 4;
  const sections: string[] = [];
  const included: Record<string, string> = {};
  const skipped: string[] = [];
  let used = 0;

  if (opts.includeMemory !== false && project.memory.trim()) {
    const mem = project.memory.trim().slice(0, Math.floor(budgetChars * 0.2));
    sections.push(`<project_memory>\n${mem}\n</project_memory>`);
    used += mem.length;
  }

  let naiveChars = project.memory.length;
  if (project.folderPath && fs.existsSync(project.folderPath)) {
    const idx = getIndex(project.id, project.folderPath);
    naiveChars += idx.totalTextBytes;
    if (opts.includeTree !== false) {
      const tree = treeSummary(idx, mode === 'economy' ? 25 : mode === 'balanced' ? 45 : 80).slice(0, Math.floor(budgetChars * 0.2));
      sections.push(`<project_tree root="${project.folderPath.replace(/"/g, '')}">\n${tree}\n</project_tree>`);
      used += tree.length;
    }
    const maxFiles = EFFICIENCY_PROFILES[mode].primeSnippets;
    const ranked = rankFiles(idx, opts.query, maxFiles);
    const parts: string[] = [];
    for (const r of ranked) {
      const remaining = budgetChars - used;
      if (remaining < 400) break;
      const c = fileContent(r.entry);
      if (!c) continue;
      const hash = sha1(c.text);
      if (opts.alreadySent?.[r.rel] === hash) {
        skipped.push(r.rel);
        continue;
      }
      const perFile = Math.min(remaining - 100, Math.max(800, Math.floor((budgetChars * 0.6) / Math.max(1, ranked.length))));
      const snip = snippets(c.text, opts.query, perFile);
      parts.push(`<file path="${r.rel}" lines="${snip.ranges.map((x) => x.join('-')).join(',')}">\n${snip.text}\n</file>`);
      used += snip.text.length + 40;
      included[r.rel] = hash;
    }
    if (parts.length) sections.push(`<relevant_files note="Selected excerpts; read full files yourself if needed.">\n${parts.join('\n')}\n</relevant_files>`);
    if (skipped.length) sections.push(`<unchanged_files note="Already shared earlier in this conversation and unchanged">${skipped.join(', ')}</unchanged_files>`);
  }
  if (!sections.length) return null;
  const text = `<bloxade_context project="${project.name.replace(/"/g, '')}">\n${sections.join('\n')}\n</bloxade_context>`;
  const estTokens = estimateTokens(text);
  const naiveTokens = estimateTokens(naiveChars);
  return { text, files: included, estTokens, naiveTokens, savedTokens: Math.max(0, naiveTokens - estTokens), skippedUnchanged: skipped };
}

/** Shrinks big tool output: collapses repeated lines and keeps head + tail within the cap. */
export function compressOutput(text: string, cap: number): { text: string; saved: number } {
  if (text.length <= cap) return { text, saved: 0 };
  const lines = text.split('\n');
  const collapsed: string[] = [];
  let prev: string | null = null;
  let rep = 0;
  for (const l of lines) {
    if (l === prev) {
      rep++;
      continue;
    }
    if (rep > 0) collapsed.push(`… (previous line repeated ${rep}×)`);
    rep = 0;
    collapsed.push(l);
    prev = l;
  }
  if (rep > 0) collapsed.push(`… (previous line repeated ${rep}×)`);
  let out = collapsed.join('\n');
  if (out.length > cap) {
    const head = out.slice(0, Math.floor(cap * 0.6));
    const tail = out.slice(out.length - Math.floor(cap * 0.35));
    const omittedLines = out.slice(head.length, out.length - tail.length).split('\n').length;
    out = `${head}\n\n… [BLOXADE trimmed ${omittedLines} lines / ${out.length - head.length - tail.length} chars to save context — call again with a narrower query or path for details] …\n\n${tail}`;
  }
  return { text: out, saved: Math.max(0, estimateTokens(text) - estimateTokens(out)) };
}
