import fs from 'node:fs';
import path from 'node:path';
import { createTwoFilesPatch } from 'diff';
import type { FileEntry } from '@shared/types';
import { dirs } from '../core/paths';
import { sha1, HttpError, IS_WIN } from '../core/util';

export const IGNORE_DIRS = new Set([
  'node_modules', '.git', '.svn', '.hg', 'dist', 'build', 'out', '.next', '.nuxt', '.cache', '__pycache__', '.venv', 'venv',
  'target', '.idea', '.bloxade', '.turbo', 'coverage', '.pytest_cache', 'DevPackages', '.gradle', 'bin', 'obj',
]);

const BINARY_EXT = new Set([
  '.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp', '.ico', '.tga', '.psd', '.mp3', '.wav', '.ogg', '.mp4', '.mov', '.zip', '.rar',
  '.7z', '.gz', '.exe', '.dll', '.so', '.dylib', '.pdf', '.rbxl', '.rbxm', '.fbx', '.obj', '.blend', '.woff', '.woff2', '.ttf',
  '.otf', '.sqlite', '.db', '.bin', '.lockb', '.class', '.jar', '.pyc',
]);

export function isProbablyText(file: string): boolean {
  return !BINARY_EXT.has(path.extname(file).toLowerCase());
}

function norm(p: string) {
  return IS_WIN ? p.toLowerCase() : p;
}

export function isInside(root: string, target: string): boolean {
  const r = norm(path.resolve(root));
  const t = norm(path.resolve(target));
  return t === r || t.startsWith(r.endsWith(path.sep) ? r : r + path.sep);
}

/** Resolves a project-relative path and refuses anything that escapes the project folder (incl. via symlinks). */
export function safeResolve(root: string, rel: string): string {
  if (!root) throw new HttpError(400, 'This project has no folder');
  const cleaned = (rel || '').replace(/\\/g, '/').replace(/^\/+/, '');
  const abs = path.resolve(root, cleaned);
  if (!isInside(root, abs)) throw new HttpError(403, 'Path is outside the project folder');
  try {
    const real = fs.realpathSync(abs);
    const realRoot = fs.realpathSync(root);
    if (!isInside(realRoot, real)) throw new HttpError(403, 'Path resolves outside the project folder');
  } catch (e) {
    if (e instanceof HttpError) throw e;
  }
  return abs;
}

export function relPath(root: string, abs: string) {
  return path.relative(root, abs).split(path.sep).join('/');
}

export function listDir(root: string, rel: string): FileEntry[] {
  const abs = safeResolve(root, rel);
  let entries: fs.Dirent[];
  try {
    entries = fs.readdirSync(abs, { withFileTypes: true });
  } catch {
    throw new HttpError(404, 'Folder not found');
  }
  const out: FileEntry[] = [];
  for (const e of entries) {
    if (e.name === '.DS_Store') continue;
    const full = path.join(abs, e.name);
    const r = relPath(root, full);
    if (e.isDirectory()) out.push({ name: e.name, path: r, type: 'dir' });
    else if (e.isFile()) {
      try {
        const st = fs.statSync(full);
        out.push({ name: e.name, path: r, type: 'file', size: st.size, mtime: st.mtimeMs });
      } catch {
        /* vanished */
      }
    }
  }
  return out.sort((a, b) => (a.type === b.type ? a.name.localeCompare(b.name) : a.type === 'dir' ? -1 : 1));
}

export interface WalkEntry {
  rel: string;
  abs: string;
  size: number;
  mtime: number;
}

export function walk(root: string, opts: { maxFiles?: number; includeIgnored?: boolean } = {}): { files: WalkEntry[]; truncated: boolean } {
  const max = opts.maxFiles ?? 20000;
  const files: WalkEntry[] = [];
  const stack = [root];
  let truncated = false;
  while (stack.length) {
    const dir = stack.pop()!;
    let entries: fs.Dirent[];
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      continue;
    }
    for (const e of entries) {
      const full = path.join(dir, e.name);
      if (e.isDirectory()) {
        if (!opts.includeIgnored && (IGNORE_DIRS.has(e.name) || (e.name.startsWith('.') && e.name !== '.github'))) continue;
        stack.push(full);
      } else if (e.isFile()) {
        if (files.length >= max) {
          truncated = true;
          return { files, truncated };
        }
        try {
          const st = fs.statSync(full);
          files.push({ rel: relPath(root, full), abs: full, size: st.size, mtime: st.mtimeMs });
        } catch {
          /* vanished */
        }
      }
    }
  }
  return { files, truncated };
}

export function readText(abs: string, maxBytes = 512 * 1024): { content: string; truncated: boolean; binary: boolean; size: number } {
  const st = fs.statSync(abs);
  const fd = fs.openSync(abs, 'r');
  try {
    const len = Math.min(st.size, maxBytes);
    const buf = Buffer.alloc(len);
    fs.readSync(fd, buf, 0, len, 0);
    const sample = buf.subarray(0, Math.min(len, 8000));
    const binary = !isProbablyText(abs) || sample.includes(0);
    return { content: binary ? '' : buf.toString('utf8'), truncated: st.size > maxBytes, binary, size: st.size };
  } finally {
    fs.closeSync(fd);
  }
}

// ---------- content-addressed blob store (for diffs and safe revert) ----------

function blobPath(hash: string) {
  return path.join(dirs.blobs, hash.slice(0, 2), hash);
}

export function putBlob(data: Buffer): string {
  const hash = sha1(data);
  const p = blobPath(hash);
  if (!fs.existsSync(p)) {
    fs.mkdirSync(path.dirname(p), { recursive: true });
    fs.writeFileSync(p, data);
  }
  return hash;
}

export function getBlob(hash: string): Buffer | null {
  try {
    return fs.readFileSync(blobPath(hash));
  } catch {
    return null;
  }
}

export interface SnapEntry {
  hash: string;
  size: number;
  mtime: number;
}
export type Snapshot = Map<string, SnapEntry>;

const memo = new Map<string, SnapEntry>(); // abs|size|mtime → entry

/** Snapshot of all text files (≤2 MB) under root; unchanged files are not re-read. */
export function snapshot(root: string, maxFiles = 15000): { snap: Snapshot; truncated: boolean } {
  const { files, truncated } = walk(root, { maxFiles });
  const snap: Snapshot = new Map();
  for (const f of files) {
    if (f.size > 2 * 1024 * 1024 || !isProbablyText(f.abs)) continue;
    const key = `${f.abs}|${f.size}|${f.mtime}`;
    let e = memo.get(key);
    if (!e) {
      try {
        const data = fs.readFileSync(f.abs);
        e = { hash: putBlob(data), size: f.size, mtime: f.mtime };
        memo.set(key, e);
        if (memo.size > 60000) memo.clear();
      } catch {
        continue;
      }
    }
    snap.set(f.rel, e);
  }
  return { snap, truncated };
}

export interface SnapChange {
  path: string;
  change: 'added' | 'modified' | 'deleted';
  beforeHash: string | null;
  afterHash: string | null;
}

export function diffSnapshots(before: Snapshot, after: Snapshot, only?: Set<string>): SnapChange[] {
  const out: SnapChange[] = [];
  for (const [p, a] of after) {
    if (only && !only.has(p)) continue;
    const bEntry = before.get(p);
    if (!bEntry) out.push({ path: p, change: 'added', beforeHash: null, afterHash: a.hash });
    else if (bEntry.hash !== a.hash) out.push({ path: p, change: 'modified', beforeHash: bEntry.hash, afterHash: a.hash });
  }
  for (const [p, bEntry] of before) {
    if (only && !only.has(p)) continue;
    if (!after.has(p)) out.push({ path: p, change: 'deleted', beforeHash: bEntry.hash, afterHash: null });
  }
  return out.sort((x, y) => x.path.localeCompare(y.path));
}

export function unifiedDiff(file: string, beforeHash: string | null, afterHash: string | null, maxChars = 120_000): string {
  const a = beforeHash ? getBlob(beforeHash)?.toString('utf8') ?? '' : '';
  const b = afterHash ? getBlob(afterHash)?.toString('utf8') ?? '' : '';
  const patch = createTwoFilesPatch(beforeHash ? `a/${file}` : '/dev/null', afterHash ? `b/${file}` : '/dev/null', a, b, '', '', { context: 3 });
  return patch.length > maxChars ? patch.slice(0, maxChars) + '\n… diff truncated …' : patch;
}

/** Restores a file to a previous blob (or deletes it if it did not exist before). */
export function restoreFile(root: string, rel: string, beforeHash: string | null) {
  const abs = safeResolve(root, rel);
  if (beforeHash == null) {
    fs.rmSync(abs, { force: true });
    return;
  }
  const data = getBlob(beforeHash);
  if (!data) throw new HttpError(410, `The original content of ${rel} is no longer available`);
  fs.mkdirSync(path.dirname(abs), { recursive: true });
  fs.writeFileSync(abs, data);
}

// ---------- lock table for file / Studio script ownership ----------

export interface LockOwner {
  id: string; // task id or chat id
  label: string;
  runId?: string | null;
}

export class LockTable {
  private locks = new Map<string, LockOwner & { since: number }>();

  private key(k: string) {
    const n = k.replace(/\\/g, '/');
    return IS_WIN ? n.toLowerCase() : n;
  }

  claim(k: string, owner: LockOwner): { ok: true } | { ok: false; holder: LockOwner } {
    const key = this.key(k);
    const cur = this.locks.get(key);
    if (cur && cur.id !== owner.id) return { ok: false, holder: cur };
    if (!cur) this.locks.set(key, { ...owner, since: Date.now() });
    return { ok: true };
  }

  holder(k: string) {
    return this.locks.get(this.key(k)) ?? null;
  }

  release(ownerId: string) {
    for (const [k, v] of this.locks) if (v.id === ownerId) this.locks.delete(k);
  }

  list() {
    return [...this.locks.entries()].map(([key, v]) => ({ key, ...v }));
  }
}

export const fileLocks = new LockTable();
export const studioLocks = new LockTable();

/** Very small glob matcher for ownership patterns: `**`, `*`, exact paths and folder prefixes ending in `/`. */
export function matchOwned(patterns: string[], rel: string): boolean {
  const target = rel.replace(/\\/g, '/').replace(/^\.\//, '');
  const t = IS_WIN ? target.toLowerCase() : target;
  return patterns.some((raw) => {
    let p = raw.trim().replace(/\\/g, '/').replace(/^\.\//, '');
    if (!p) return false;
    if (IS_WIN) p = p.toLowerCase();
    if (p.endsWith('/')) return t.startsWith(p);
    if (!p.includes('*')) return t === p || t.startsWith(p + '/');
    const re = new RegExp(
      '^' +
        p
          .split('**')
          .map((seg) => seg.split('*').map((s) => s.replace(/[.+?^${}()|[\]\\]/g, '\\$&')).join('[^/]*'))
          .join('.*') +
        '$',
    );
    return re.test(t);
  });
}
