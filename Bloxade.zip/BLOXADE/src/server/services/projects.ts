import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import type { FileChange, Project } from '@shared/types';
import { db, b, j } from '../core/db';
import { newId, now, safeJson, HttpError, str } from '../core/util';
import { expandUserPath } from '../core/paths';
import { events } from '../core/events';
import { activity } from './activity';
import { invalidateProject } from './context';
import { restoreFile, unifiedDiff, type SnapChange } from './files';

interface Row {
  id: string; name: string; icon: string; color: string; description: string; folder_path: string | null; instructions: string;
  memory: string; memory_updated_at: number | null; roblox_enabled: number; defaults: string; created_at: number; updated_at: number;
}

const ICONS = ['cuboid', 'gamepad', 'rocket', 'sparkles', 'box', 'layers', 'zap', 'star', 'blocks', 'code', 'flame', 'heart'];

function toProject(r: Row): Project {
  const chats = db().get<{ n: number }>('SELECT COUNT(*) AS n FROM chats WHERE project_id = ?', r.id)?.n ?? 0;
  const runs = db().get<{ n: number }>('SELECT COUNT(*) AS n FROM runs WHERE project_id = ?', r.id)?.n ?? 0;
  return {
    id: r.id,
    name: r.name,
    icon: r.icon,
    color: r.color,
    description: r.description,
    folderPath: r.folder_path,
    instructions: r.instructions,
    memory: r.memory,
    memoryUpdatedAt: r.memory_updated_at,
    robloxEnabled: !!r.roblox_enabled,
    defaults: safeJson(r.defaults, {}),
    createdAt: r.created_at,
    updatedAt: r.updated_at,
    stats: { chats, runs },
  };
}

export function listProjects(): Project[] {
  return db().all<Row>('SELECT * FROM projects ORDER BY updated_at DESC').map(toProject);
}

export function getProject(id: string | null | undefined): Project | null {
  if (!id) return null;
  const r = db().get<Row>('SELECT * FROM projects WHERE id = ?', id);
  return r ? toProject(r) : null;
}

export function mustProject(id: string): Project {
  const p = getProject(id);
  if (!p) throw new HttpError(404, 'Project not found');
  return p;
}

const BLOCKED_ROOTS = (() => {
  const list = [os.homedir(), path.parse(os.homedir()).root];
  if (process.platform === 'win32') list.push('C:\\Windows', 'C:\\Program Files', 'C:\\Program Files (x86)');
  else list.push('/', '/etc', '/usr', '/bin', '/System');
  return list.map((p) => path.resolve(p).toLowerCase());
})();

export function validateFolder(input: string | null | undefined, create = false): string | null {
  if (!input || !String(input).trim()) return null;
  const abs = expandUserPath(String(input));
  if (BLOCKED_ROOTS.includes(abs.toLowerCase()) || BLOCKED_ROOTS.some((r) => r.length > 3 && abs.toLowerCase().startsWith(r + path.sep) && /windows|program files/i.test(r))) {
    throw new HttpError(400, 'Choose a specific project folder — your whole home folder, a drive root or system folders cannot be used.');
  }
  if (!fs.existsSync(abs)) {
    if (!create) throw new HttpError(400, `Folder does not exist: ${abs}`);
    fs.mkdirSync(abs, { recursive: true });
  }
  if (!fs.statSync(abs).isDirectory()) throw new HttpError(400, 'That path is a file, not a folder');
  return abs;
}

function emit(id: string) {
  const p = getProject(id);
  if (p) events.emit('project.updated', p);
}

export function createProject(body: any): Project {
  const name = str(body?.name, 'Project name', { min: 1, max: 80 }).trim();
  const id = newId('prj');
  const count = db().get<{ n: number }>('SELECT COUNT(*) AS n FROM projects')?.n ?? 0;
  const folder = validateFolder(body?.folderPath, !!body?.createFolder);
  db().upsert('projects', {
    id,
    name,
    icon: typeof body?.icon === 'string' && body.icon.length < 30 ? body.icon : ICONS[count % ICONS.length],
    color: /^#[0-9a-fA-F]{6}$/.test(body?.color ?? '') ? body.color : ['#7C7FFF', '#3FB98A', '#E58A5B', '#D9608C', '#4FA8E8', '#E0B341'][count % 6],
    description: str(body?.description ?? '', 'description', { max: 2000, optional: true }),
    folder_path: folder,
    instructions: str(body?.instructions ?? '', 'instructions', { max: 20000, optional: true }),
    memory: '',
    memory_updated_at: null,
    roblox_enabled: b(body?.robloxEnabled ?? /roblox/i.test(name + ' ' + (body?.description ?? ''))),
    defaults: j(body?.defaults ?? {}),
    created_at: now(),
    updated_at: now(),
  });
  activity('project', `Created project “${name}”`, folder ?? 'No folder linked');
  emit(id);
  return getProject(id)!;
}

export function updateProject(id: string, body: any): Project {
  const p = mustProject(id);
  const patch: Record<string, any> = { updated_at: now() };
  if (body.name !== undefined) patch.name = str(body.name, 'Project name', { min: 1, max: 80 }).trim();
  if (body.icon !== undefined) patch.icon = String(body.icon).slice(0, 30);
  if (body.color !== undefined && /^#[0-9a-fA-F]{6}$/.test(body.color)) patch.color = body.color;
  if (body.description !== undefined) patch.description = str(body.description, 'description', { max: 2000, optional: true });
  if (body.instructions !== undefined) patch.instructions = str(body.instructions, 'instructions', { max: 20000, optional: true });
  if (body.memory !== undefined) {
    patch.memory = str(body.memory, 'memory', { max: 20000, optional: true });
    patch.memory_updated_at = now();
  }
  if (body.folderPath !== undefined) {
    patch.folder_path = validateFolder(body.folderPath, !!body.createFolder);
    invalidateProject(id);
  }
  if (body.robloxEnabled !== undefined) patch.roblox_enabled = b(!!body.robloxEnabled);
  if (body.defaults !== undefined) patch.defaults = j({ ...p.defaults, ...body.defaults });
  db().update('projects', id, patch);
  emit(id);
  return getProject(id)!;
}

export function touchProject(id: string) {
  db().run('UPDATE projects SET updated_at = ? WHERE id = ?', now(), id);
}

export function deleteProject(id: string) {
  const p = mustProject(id);
  db().tx(() => {
    db().run('UPDATE chats SET project_id = NULL WHERE project_id = ?', id);
    db().run('DELETE FROM file_changes WHERE project_id = ?', id);
    db().run('DELETE FROM projects WHERE id = ?', id);
  });
  invalidateProject(id);
  activity('project', `Deleted project “${p.name}”`, 'Chats were kept and moved out of the project. No files were deleted.');
  events.emit('project.deleted', { id });
}

// ---------- change tracking ----------

export function recordChanges(projectId: string, changes: SnapChange[], source: FileChange['source'], sourceId: string | null): FileChange[] {
  const out: FileChange[] = [];
  for (const c of changes.slice(0, 500)) {
    const fc: FileChange = {
      id: newId('chg'),
      projectId,
      path: c.path,
      change: c.change,
      source,
      sourceId,
      diff: unifiedDiff(c.path, c.beforeHash, c.afterHash),
      createdAt: now(),
      reverted: false,
    };
    db().upsert('file_changes', {
      id: fc.id, project_id: projectId, path: fc.path, change: fc.change, source, source_id: sourceId, before_hash: c.beforeHash,
      after_hash: c.afterHash, diff: fc.diff, created_at: fc.createdAt, reverted: 0,
    });
    out.push(fc);
  }
  if (out.length) {
    invalidateProject(projectId);
    events.emit('project.changes', { projectId, count: out.length, source, sourceId });
  }
  return out;
}

export function listChanges(projectId: string, opts: { sourceId?: string; limit?: number } = {}): FileChange[] {
  const rows = opts.sourceId
    ? db().all<any>('SELECT * FROM file_changes WHERE project_id = ? AND source_id = ? ORDER BY created_at DESC LIMIT ?', projectId, opts.sourceId, opts.limit ?? 500)
    : db().all<any>('SELECT * FROM file_changes WHERE project_id = ? ORDER BY created_at DESC LIMIT ?', projectId, opts.limit ?? 300);
  return rows.map((r) => ({ id: r.id, projectId: r.project_id, path: r.path, change: r.change, source: r.source, sourceId: r.source_id, diff: r.diff, createdAt: r.created_at, reverted: !!r.reverted }));
}

export function changesBySource(sourceId: string): (FileChange & { beforeHash: string | null })[] {
  return db()
    .all<any>('SELECT * FROM file_changes WHERE source_id = ? ORDER BY created_at ASC', sourceId)
    .map((r) => ({ id: r.id, projectId: r.project_id, path: r.path, change: r.change, source: r.source, sourceId: r.source_id, diff: r.diff, createdAt: r.created_at, reverted: !!r.reverted, beforeHash: r.before_hash }));
}

/** Reverts one recorded change (restores the content from before it). */
export function revertChange(changeId: string) {
  const r = db().get<any>('SELECT * FROM file_changes WHERE id = ?', changeId);
  if (!r) throw new HttpError(404, 'Change not found');
  if (r.reverted) return;
  const p = mustProject(r.project_id);
  if (!p.folderPath) throw new HttpError(400, 'Project has no folder');
  restoreFile(p.folderPath, r.path, r.before_hash);
  db().run('UPDATE file_changes SET reverted = 1 WHERE id = ?', changeId);
  invalidateProject(p.id);
  activity('files', `Reverted ${r.path}`, `Project “${p.name}”`, p.id);
  events.emit('project.changes', { projectId: p.id, count: 1, source: 'revert', sourceId: r.source_id });
}
