import path from 'node:path';
import type { PermissionPolicy } from '@shared/types';
import type { PermissionHandler, PermissionRequest } from '../providers/types';
import { getSettings } from '../core/settings';
import { requestApproval } from './approvals';
import { fileLocks, isInside, matchOwned } from './files';
import { truncate } from '../core/util';

export interface RequesterCtx {
  kind: 'chat' | 'task';
  id: string;
  label: string;
  cwd: string;
  projectRoot: string | null;
  extraRoots: string[];
  task?: { runId: string; ownedPaths: string[]; autoApprove: { edits: boolean; commands: boolean } };
  onDenied?: (req: PermissionRequest, reason: string) => void;
  onEditAllowed?: (absPaths: string[]) => void;
}

/** Central permission policy for provider tool requests (Claude can_use_tool, Codex approvals). */
export function makePermissionHandler(ctx: RequesterCtx): PermissionHandler {
  const s = () => getSettings().agents.approvals;
  const requester = { kind: ctx.kind, id: ctx.id, label: ctx.label } as const;

  const ask = async (title: string, detail: string, req: PermissionRequest, rememberKey: string, kind: 'command' | 'file_edit' | 'tool' | 'conflict') => {
    const d = await requestApproval({ kind, title, detail: truncate(detail, 4000), toolName: req.toolName, input: req.input, requester, rememberKey });
    return { allow: d.allow, message: d.allow ? undefined : d.message || 'The user denied this action in BLOXADE.' };
  };

  const byPolicy = async (policy: PermissionPolicy, title: string, detail: string, req: PermissionRequest, rememberKey: string, kind: 'command' | 'file_edit' | 'tool'): Promise<{ allow: boolean; message?: string }> => {
    if (policy === 'allow') return { allow: true };
    if (policy === 'deny') return { allow: false, message: `BLOXADE settings do not allow ${kind === 'command' ? 'running commands' : 'this action'} here.` };
    return ask(title, detail, req, rememberKey, kind);
  };

  return async (req) => {
    if (req.toolName.startsWith('mcp__bloxade_roblox')) return { allow: true }; // Studio policy is enforced centrally by the Roblox manager

    if (req.kind === 'file_edit') {
      const abs = req.paths.map((p) => path.resolve(ctx.cwd, p));
      if (!abs.length) return byPolicy(s().edits, 'Edit files', req.description, req, 'edit:*', 'file_edit');
      const roots = [ctx.projectRoot, ...ctx.extraRoots].filter(Boolean) as string[];
      const outside = abs.filter((a) => !roots.some((r) => isInside(r, a)));
      if (outside.length) {
        const r = await ask('Edit a file outside the project folder', `${ctx.label} wants to modify:\n${outside.join('\n')}`, req, `edit-outside:${outside.join('|')}`, 'file_edit');
        if (r.allow) ctx.onEditAllowed?.(abs);
        return r;
      }
      // Ownership / conflict checks
      for (const a of abs) {
        const holder = fileLocks.holder(a);
        if (holder && holder.id !== ctx.id) {
          const rel = ctx.projectRoot ? path.relative(ctx.projectRoot, a) : a;
          const r = await ask(
            'Possible conflicting edit',
            `${ctx.label} wants to edit ${rel}, which is currently being edited by ${holder.label}.\nAllowing this may overwrite their work.`,
            req,
            `conflict:${a}`,
            'conflict',
          );
          if (!r.allow) {
            const msg = `${rel} is owned by ${holder.label} right now. Do not edit it; describe the change you need in your final report instead.`;
            ctx.onDenied?.(req, msg);
            return { allow: false, message: msg };
          }
        }
      }
      let decision: { allow: boolean; message?: string };
      if (ctx.task) {
        const rels = abs.map((a) => (ctx.projectRoot ? path.relative(ctx.projectRoot, a).split(path.sep).join('/') : a));
        const allOwned = ctx.task.ownedPaths.length > 0 && rels.every((r) => matchOwned(ctx.task!.ownedPaths, r));
        if (allOwned) decision = ctx.task.autoApprove.edits ? { allow: true } : await byPolicy(s().edits, 'Edit files', `${ctx.label}: ${rels.join(', ')}`, req, 'edit:owned', 'file_edit');
        else if (ctx.task.autoApprove.edits && s().unownedEdits !== 'deny') decision = { allow: true };
        else decision = await byPolicy(s().unownedEdits, 'Edit a file outside this agent’s assignment', `${ctx.label} wants to edit ${rels.join(', ')} (not in its assigned files: ${ctx.task.ownedPaths.join(', ') || 'none'})`, req, `edit:${rels.join('|')}`, 'file_edit');
      } else {
        decision = await byPolicy(s().edits, 'Edit files', `${ctx.label} wants to modify:\n${req.paths.join('\n')}`, req, 'edit:*', 'file_edit');
      }
      if (decision.allow) {
        for (const a of abs) fileLocks.claim(a, { id: ctx.id, label: ctx.label, runId: ctx.task?.runId ?? null });
        ctx.onEditAllowed?.(abs);
      } else ctx.onDenied?.(req, decision.message ?? 'denied');
      return decision;
    }

    if (req.kind === 'command') {
      if (ctx.task?.autoApprove.commands) return { allow: true };
      const d = await byPolicy(s().commands, 'Run a command', `${ctx.label} wants to run:\n${req.command || req.description}`, req, 'command', 'command');
      if (!d.allow) ctx.onDenied?.(req, d.message ?? 'denied');
      return d;
    }

    // Other tools that the provider asked about (web fetch, etc.)
    if (ctx.task?.autoApprove.commands) return { allow: true };
    return byPolicy(s().commands === 'deny' ? 'ask' : s().commands, `Use ${req.toolName}`, `${ctx.label} wants to use ${req.toolName}:\n${truncate(JSON.stringify(req.input ?? {}, null, 2), 1500)}`, req, `tool:${req.toolName}`, 'tool');
  };
}
