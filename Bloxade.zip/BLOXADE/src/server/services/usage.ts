import type { Provider, UsageInfo, UsageSummary } from '@shared/types';
import { db } from '../core/db';
import { newId, now } from '../core/util';
import { events } from '../core/events';
import { listAccounts } from './accounts';
import { listActivity } from './activity';

export function recordUsage(e: {
  provider: Provider;
  accountId: string | null;
  model: string | null;
  kind: 'chat' | 'task' | 'coordinator' | 'memory';
  refId: string | null;
  usage: UsageInfo | null;
  estimatedTokens: number;
  contextSaved: number;
  durationMs: number;
  ok: boolean;
}) {
  const u = e.usage;
  const verified = !!u?.verified;
  db().upsert('usage_events', {
    id: newId('use'),
    ts: now(),
    provider: e.provider,
    account_id: e.accountId,
    model: e.model,
    kind: e.kind,
    ref_id: e.refId,
    input_tokens: verified ? u?.inputTokens ?? 0 : 0,
    output_tokens: verified ? u?.outputTokens ?? 0 : 0,
    cache_read: verified ? u?.cacheReadTokens ?? 0 : 0,
    cache_write: verified ? u?.cacheWriteTokens ?? 0 : 0,
    reasoning: verified ? u?.reasoningTokens ?? 0 : 0,
    cost_usd: u?.costUsd ?? null,
    verified: verified ? 1 : 0,
    estimated_tokens: Math.round(e.estimatedTokens),
    context_saved: Math.round(e.contextSaved),
    duration_ms: e.durationMs,
    ok: e.ok ? 1 : 0,
  });
  events.emit('usage.recorded', { provider: e.provider });
}

export function usageSummary(range: '24h' | '7d' | '30d' | 'all', live: { agents: number; chats: number; sessions: number }): UsageSummary {
  const span = range === '24h' ? 86400e3 : range === '7d' ? 7 * 86400e3 : range === '30d' ? 30 * 86400e3 : 3650 * 86400e3;
  const since = now() - span;
  const t = db().get<any>(
    `SELECT COALESCE(SUM(CASE WHEN verified=1 THEN input_tokens END),0) vi, COALESCE(SUM(CASE WHEN verified=1 THEN output_tokens END),0) vo,
      COALESCE(SUM(CASE WHEN verified=1 THEN cache_read END),0) cr, COALESCE(SUM(CASE WHEN verified=1 THEN cache_write END),0) cw,
      COALESCE(SUM(cost_usd),0) cost, COALESCE(SUM(estimated_tokens),0) est, COALESCE(SUM(context_saved),0) saved, COUNT(*) turns
     FROM usage_events WHERE ts >= ?`,
    since,
  );
  const byProvider = db()
    .all<any>(
      `SELECT provider, COUNT(*) turns, COALESCE(SUM(input_tokens),0) input, COALESCE(SUM(output_tokens),0) output, COALESCE(SUM(cost_usd),0) cost
       FROM usage_events WHERE ts >= ? GROUP BY provider`,
      since,
    )
    .map((r) => ({ provider: r.provider, turns: r.turns, input: r.input, output: r.output, costUsd: r.cost }));
  const byModel = db()
    .all<any>(
      `SELECT COALESCE(model,'(default)') model, provider, COUNT(*) turns, COALESCE(SUM(input_tokens),0) input, COALESCE(SUM(output_tokens),0) output
       FROM usage_events WHERE ts >= ? GROUP BY model, provider ORDER BY turns DESC LIMIT 12`,
      since,
    )
    .map((r) => ({ model: r.model, provider: r.provider, turns: r.turns, input: r.input, output: r.output }));
  const bucketMs = range === '24h' ? 3600e3 : 86400e3;
  const buckets = range === '24h' ? 24 : range === '7d' ? 7 : range === '30d' ? 30 : 30;
  const start = Math.floor((now() - (buckets - 1) * bucketMs) / bucketMs) * bucketMs;
  const rows = db().all<any>(`SELECT CAST(ts / ? AS INTEGER) * ? AS bucket, provider, COUNT(*) n FROM usage_events WHERE ts >= ? GROUP BY bucket, provider`, bucketMs, bucketMs, start);
  const timeline: UsageSummary['timeline'] = [];
  for (let i = 0; i < buckets; i++) {
    const bucket = start + i * bucketMs;
    timeline.push({ bucket, claude: rows.find((r) => r.bucket === bucket && r.provider === 'claude')?.n ?? 0, codex: rows.find((r) => r.bucket === bucket && r.provider === 'codex')?.n ?? 0 });
  }
  const tk = db().get<any>(
    `SELECT SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) completed, SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END) failed,
      SUM(CASE WHEN status='working' THEN 1 ELSE 0 END) running,
      AVG(CASE WHEN status='completed' AND started_at IS NOT NULL AND finished_at IS NOT NULL THEN finished_at - started_at END) avgms
     FROM tasks WHERE created_at >= ?`,
    since,
  );
  return {
    range,
    totals: {
      verifiedInput: t.vi,
      verifiedOutput: t.vo,
      verifiedCacheRead: t.cr,
      verifiedCacheWrite: t.cw,
      reportedCostUsd: t.cost,
      estimatedTokens: t.est,
      contextSavedEstimate: t.saved,
      turns: t.turns,
    },
    byProvider,
    byModel,
    timeline,
    tasks: { completed: tk?.completed ?? 0, failed: tk?.failed ?? 0, running: tk?.running ?? 0, avgDurationMs: tk?.avgms ?? null },
    active: live,
    accounts: listAccounts().map((a) => ({ id: a.id, name: a.name, provider: a.provider, limits: a.limits ?? null })),
    recentActivity: listActivity(30).map((a) => ({ ts: a.ts, kind: a.kind, label: a.label, detail: a.detail })),
  };
}
