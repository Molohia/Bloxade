/**
 * BLOXADE launcher (run by START_BLOXADE.bat):
 *  1. checks the Node.js version and data folder,
 *  2. detects an already-running BLOXADE (just opens the browser) or a port conflict,
 *  3. starts the server in this process, waits until it answers, then opens the browser.
 */
import http from 'node:http';
import path from 'node:path';
import fs from 'node:fs';
import os from 'node:os';
import { spawn } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const args = process.argv.slice(2);
const noBrowser = args.includes('--no-browser');
const portArg = args.find((a) => a.startsWith('--port='));
const C = { dim: '\x1b[90m', cyan: '\x1b[36m', green: '\x1b[32m', red: '\x1b[31m', yellow: '\x1b[33m', bold: '\x1b[1m', reset: '\x1b[0m' };

function banner() {
  console.log(`\n${C.bold}${C.cyan}  ▣ BLOXADE${C.reset}${C.dim}  local AI development workspace${C.reset}\n`);
}

function fail(title: string, detail: string): never {
  console.log(`\n${C.red}${C.bold}  ✖ ${title}${C.reset}\n`);
  console.log(detail.split('\n').map((l) => '    ' + l).join('\n'));
  console.log(`\n${C.dim}    Logs: ${logDir()}${C.reset}\n`);
  process.exit(1);
}

function logDir() {
  const base = process.env.BLOXADE_DATA_DIR || (process.platform === 'win32' ? path.join(process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local'), 'BLOXADE') : path.join(os.homedir(), '.bloxade'));
  return path.join(base, 'logs');
}

function probe(port: number): Promise<'bloxade' | 'other' | 'free'> {
  return new Promise((resolve) => {
    const req = http.get({ host: '127.0.0.1', port, path: '/api/health', timeout: 1500 }, (res) => {
      let body = '';
      res.on('data', (d) => (body += d));
      res.on('end', () => resolve(body.includes('"app":"bloxade"') ? 'bloxade' : 'other'));
    });
    req.on('timeout', () => {
      req.destroy();
      resolve('other');
    });
    req.on('error', (e: NodeJS.ErrnoException) => resolve(e.code === 'ECONNREFUSED' ? 'free' : 'other'));
  });
}

function openBrowser(url: string) {
  try {
    if (process.platform === 'win32') spawn('rundll32', ['url.dll,FileProtocolHandler', url], { detached: true, stdio: 'ignore' }).unref();
    else if (process.platform === 'darwin') spawn('open', [url], { detached: true, stdio: 'ignore' }).unref();
    else spawn('xdg-open', [url], { detached: true, stdio: 'ignore' }).unref();
  } catch {
    console.log(`    Open ${url} in your browser.`);
  }
}

async function main() {
  banner();
  const [maj, min] = process.versions.node.split('.').map(Number);
  if (maj < 22 || (maj === 22 && min < 13)) fail('Node.js is too old', `BLOXADE needs Node.js 22.13 or newer (found ${process.version}).\nDelete %LOCALAPPDATA%\\BLOXADE\\runtime and run START_BLOXADE.bat again to download a private copy,\nor install the current LTS from https://nodejs.org.`);
  try {
    await import('node:sqlite');
  } catch {
    fail('Built-in SQLite unavailable', `This Node.js build (${process.version}) has no node:sqlite module. Install Node.js 22.13+ (LTS recommended).`);
  }
  const serverFile = path.join(here, 'server.mjs');
  if (!fs.existsSync(serverFile)) fail('App files missing', `Could not find ${serverFile}.\nRe-copy the BLOXADE folder or run "npm run build".`);
  if (!fs.existsSync(path.join(here, 'public', 'index.html'))) fail('Frontend build missing', 'app/public/index.html was not found. Run "npm run build" in the BLOXADE folder.');

  process.env.BLOXADE_APP_DIR = here;
  const mod = await import(pathToFileURL(serverFile).href);
  let prefs = { port: 3000, openBrowser: true };
  try {
    prefs = mod.launchPreferences();
  } catch (e) {
    fail('Could not open the BLOXADE data folder', (e as Error).message);
  }
  const wantBrowser = !noBrowser && prefs.openBrowser;
  let port = portArg ? Number(portArg.split('=')[1]) : Number(process.env.BLOXADE_PORT || prefs.port || 3000);
  const state = await probe(port);
  if (state === 'bloxade') {
    const url = `http://127.0.0.1:${port}`;
    console.log(`${C.green}  ✔ BLOXADE is already running${C.reset} at ${url}`);
    openBrowser(url);
    setTimeout(() => process.exit(0), 600);
    return;
  }
  if (state === 'other') {
    console.log(`${C.yellow}  ! Port ${port} is used by another program.${C.reset} Looking for a free port nearby…`);
    let found = 0;
    for (let p = port + 1; p <= port + 20; p++) {
      if ((await probe(p)) === 'free') {
        found = p;
        break;
      }
    }
    if (!found) fail('No free port', `Ports ${port}-${port + 20} are all in use. Close the other program or run START_BLOXADE.bat --port=4000`);
    port = found;
  }

  console.log(`${C.dim}  Starting server…${C.reset}`);
  let started: { url: string };
  try {
    started = await mod.startServer({ port });
  } catch (e) {
    const msg = (e as Error).message;
    fail('BLOXADE could not start', msg.includes('EADDRINUSE') ? `Port ${port} is already in use.` : msg);
  }
  // readiness check
  for (let i = 0; i < 40; i++) {
    if ((await probe(port)) === 'bloxade') break;
    await new Promise((r) => setTimeout(r, 250));
  }
  console.log(`\n${C.green}${C.bold}  ✔ BLOXADE is running${C.reset}  →  ${C.bold}${started!.url}${C.reset}`);
  console.log(`${C.dim}    Keep this window open while you use BLOXADE. Press Ctrl+C (or close the window) to stop.${C.reset}`);
  console.log(`${C.dim}    Logs: ${logDir()}${C.reset}\n`);
  if (wantBrowser) openBrowser(started!.url);
}

main().catch((e) => fail('Unexpected launcher error', (e as Error).stack ?? String(e)));
