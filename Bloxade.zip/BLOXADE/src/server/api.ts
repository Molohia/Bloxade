import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import type { Bootstrap, Provider } from '@shared/types';
import { Router, mimeFor, sendJson } from './core/http';
import { events } from './core/events';
import { getSettings, updateSettings, kvDelete } from './core/settings';
import { HttpError, oneOf, str, IS_WIN } from './core/util';
import { DATA_DIR, dirs, expandUserPath } from './core/paths';
import { db } from './core/db';
import { recentLogs } from './core/log';
import { listProcesses, openFolder, openUrl, runCapture } from './core/proc';
import { VERSION, runtime } from './core/runtime';
import { detectCli, cachedCli } from './providers/resolve';
import { cachedCatalog, refreshCatalog } from './providers/models';
import * as accounts from './services/accounts';
import * as chats from './services/chats';
import * as projects from './services/projects';
import { listDir, readText, safeResolve } from './services/files';
import { buildContextPack, cacheStats, getIndex, invalidateProject } from './services/context';
import { listApprovals, decide } from './services/approvals';
import { listActivity } from './services/activity';
import { usageSummary } from './services/usage';
import * as agents from './agents/orchestrator';
import { roblox, listRobloxActivity } from './roblox/manager';
import { handleBridgeMessage } from './roblox/bridge';
import { complete } from './providers';
import { resolveAccount } from './services/accounts';
import { estimateTokens } from './core/util';
import { recordUsage } from './services/usage';

export function buildRoutes(opts: { shutdown: () => void }): Router {
  const r = new Router();

  // ---------- system ----------
  r.get('/api/health', () => ({ ok: true, app: 'bloxade', version: VERSION, uptimeMs: Date.now() - runtime.startedAt }));
  r.get('/api/events', ({ res }) => events.attach(res), { raw: true });

  r.get('/api/bootstrap', async (): Promise<Bootstrap> => {
    const clis = { claude: cachedCli('claude'), codex: cachedCli('codex') };
    if (!clis.claude.checkedAt) clis.claude = await detectCli('claude');
    if (!clis.codex.checkedAt) clis.codex = await detectCli('codex');
    return {
      version: VERSION,
      settings: getSettings(),
      accounts: accounts.listAccounts(),
      projects: projects.listProjects(),
      chats: chats.listChats({ limit: 300 }),
      clis,
      roblox: roblox.status(),
      approvals: listApprovals(),
      platform: process.platform,
      dataDir: DATA_DIR,
      runningChats: chats.runningChatIds(),
    };
  });

  r.get('/api/settings', () => getSettings());
  r.put('/api/settings', ({ body }) => updateSettings(body));

  r.get('/api/system/diagnostics', async () => ({
    version: VERSION,
    node: process.version,
    platform: `${process.platform} ${os.release()} (${process.arch})`,
    dataDir: DATA_DIR,
    port: runtime.port,
    uptimeMs: Date.now() - runtime.startedAt,
    dbBytes: db().sizeBytes(),
    sseClients: events.clientCount,
    processes: listProcesses(),
    clis: { claude: await detectCli('claude', true), codex: await detectCli('codex', true) },
    git: (await runCapture('git', ['--version'], { timeoutMs: 8000 })).stdout.trim() || 'not found',
    roblox: await roblox.diagnostics(),
    context: cacheStats(),
    memory: process.memoryUsage(),
  }));
  r.get('/api/system/logs', ({ query }) => recentLogs(Number(query.get('limit') ?? 300), (query.get('level') as any) || undefined));
  r.post('/api/system/open-data', ({ body }) => {
    const which = oneOf(body?.which ?? 'data', ['data', 'logs'] as const, 'which');
    openFolder(which === 'logs' ? dirs.logs : dirs.data);
  });
  r.post('/api/system/open-url', ({ body }) => openUrl(str(body?.url, 'url', { min: 8, max: 4000 })));
  r.post('/api/system/clear-history', ({ body }) => {
    const what = oneOf(body?.what ?? 'chats', ['chats', 'usage', 'activity', 'runs', 'cache'] as const, 'what');
    if (what === 'chats') {
      chats.stopAllChats();
      db().tx(() => {
        db().run('DELETE FROM messages');
        db().run('DELETE FROM chats');
        db().run('DELETE FROM attachments');
      });
      fs.rmSync(dirs.attachments, { recursive: true, force: true });
      fs.mkdirSync(dirs.attachments, { recursive: true });
    } else if (what === 'usage') db().run('DELETE FROM usage_events');
    else if (what === 'activity') {
      db().run('DELETE FROM activity');
      db().run('DELETE FROM roblox_activity');
    } else if (what === 'runs') {
      agents.stopAllTasks();
      db().run('DELETE FROM tasks');
      db().run('DELETE FROM runs');
    } else kvDelete('');
    events.emit('history.cleared', { what });
  });
  r.post('/api/system/shutdown', () => {
    setTimeout(opts.shutdown, 200);
    return { ok: true };
  });

  /** Lists sub-folders so the UI can offer a folder picker (names only, read-only). */
  r.post('/api/fs/browse', ({ body }) => {
    const raw = typeof body?.path === 'string' && body.path.trim() ? body.path : os.homedir();
    const abs = expandUserPath(raw);
    let entries: fs.Dirent[] = [];
    try {
      entries = fs.readdirSync(abs, { withFileTypes: true });
    } catch {
      throw new HttpError(404, `Cannot open ${abs}`);
    }
    const list = entries.filter((e) => e.isDirectory() && !e.name.startsWith('$') && e.name !== 'node_modules').map((e) => e.name).sort((a, b) => a.localeCompare(b));
    const parent = path.dirname(abs) === abs ? null : path.dirname(abs);
    const drives = IS_WIN ? 'CDEFGHIJ'.split('').map((d) => `${d}:\\`).filter((d) => fs.existsSync(d)) : [];
    return { path: abs, parent, dirs: list.slice(0, 500), drives, home: os.homedir() };
  });
  r.post('/api/fs/native-pick', async () => {
    if (!IS_WIN) throw new HttpError(400, 'The native folder dialog is only available on Windows');
    const ps = "Add-Type -AssemblyName System.Windows.Forms; $f = New-Object System.Windows.Forms.FolderBrowserDialog; $f.Description = 'Choose a project folder for BLOXADE'; $f.ShowNewFolderButton = $true; $top = New-Object System.Windows.Forms.Form; $top.TopMost = $true; if ($f.ShowDialog($top) -eq 'OK') { $f.SelectedPath }";
    const out = await runCapture('powershell.exe', ['-NoProfile', '-STA', '-Command', ps], { timeoutMs: 10 * 60_000 });
    return { path: out.stdout.trim() || null };
  });

  // ---------- providers & models ----------
  r.get('/api/providers', async ({ query }) => {
    const force = query.get('refresh') === '1';
    return { claude: await detectCli('claude', force), codex: await detectCli('codex', force) };
  });
  r.get('/api/models', ({ query }) => {
    const provider = oneOf(query.get('provider'), ['claude', 'codex'] as const, 'provider');
    return cachedCatalog(provider);
  });
  r.post('/api/models/refresh', async ({ body }) => {
    const provider = oneOf(body?.provider, ['claude', 'codex'] as const, 'provider') as Provider;
    const acc = accounts.resolveAccount(provider, body?.accountId ?? null);
    return refreshCatalog(provider, acc);
  });

  // ---------- accounts ----------
  r.get('/api/accounts', () => accounts.listAccounts());
  r.post('/api/accounts', ({ body }) => accounts.createAccount(body));
  r.patch('/api/accounts/:id', ({ params, body }) => accounts.updateAccount(params.id, body));
  r.delete('/api/accounts/:id', ({ params, query }) => accounts.deleteAccount(params.id, query.get('removeProfile') === '1'));
  r.post('/api/accounts/:id/refresh', ({ params }) => accounts.refreshStatus(params.id));
  r.post('/api/accounts/:id/default', ({ params }) => accounts.setDefault(params.id));
  r.post('/api/accounts/:id/login', ({ params, body }) => accounts.startLogin(params.id, body?.method === 'device' ? 'device' : 'browser'));
  r.post('/api/accounts/:id/login/cancel', ({ params }) => accounts.cancelLogin(params.id));
  r.post('/api/accounts/:id/logout', ({ params }) => accounts.logout(params.id));
  r.post('/api/accounts/:id/terminal', ({ params }) => accounts.openTerminal(params.id));

  // ---------- chats ----------
  r.get('/api/chats', ({ query }) => chats.listChats({ projectId: query.get('projectId'), limit: Number(query.get('limit') ?? 300) }));
  r.post('/api/chats', ({ body }) => chats.createChat(body));
  r.get('/api/chats/:id', ({ params }) => chats.getChat(params.id));
  r.patch('/api/chats/:id', ({ params, body }) => chats.updateChat(params.id, body));
  r.delete('/api/chats/:id', ({ params }) => chats.deleteChat(params.id));
  r.post('/api/chats/:id/messages', ({ params, body }) => chats.sendMessage(params.id, body));
  r.post('/api/chats/:id/stop', ({ params }) => chats.stopChat(params.id));
  r.post('/api/chats/:id/regenerate', ({ params }) => chats.regenerate(params.id));
  r.post('/api/chats/:id/messages/:mid/edit', ({ params, body }) => chats.editMessage(params.id, params.mid, body));
  r.post('/api/chats/:id/branch', ({ params, body }) => chats.branchChat(params.id, str(body?.messageId, 'messageId', { min: 1 })));
  r.post('/api/chats/:id/memory', async ({ params }) => {
    const { chat } = chats.getChat(params.id);
    if (!chat.projectId) throw new HttpError(400, 'This chat is not part of a project');
    const project = projects.mustProject(chat.projectId);
    const acc = resolveAccount(chat.provider, chat.accountId);
    if (!acc) throw new HttpError(400, 'No account available');
    const transcript = chats.chatTranscriptForMemory(chat.id);
    const prompt = `Update the project memory with durable facts from this conversation (decisions, names, architecture, conventions, open TODOs). Under 350 words, concise bullet points. Return ONLY the full updated memory.\n\n<current_memory>\n${project.memory || '(empty)'}\n</current_memory>\n\n${transcript}`;
    const res = await complete(chat.provider, { account: acc, model: chat.model, effort: 'low', cwd: path.join(dirs.workspaces, chat.id), prompt, signal: new AbortController().signal, timeoutMs: 5 * 60_000, label: 'Memory summary' });
    recordUsage({ provider: chat.provider, accountId: acc.id, model: res.model ?? chat.model, kind: 'memory', refId: chat.id, usage: res.usage, estimatedTokens: estimateTokens(prompt), contextSaved: 0, durationMs: res.durationMs, ok: res.ok });
    if (!res.ok) throw new HttpError(502, res.error ?? 'Summary failed');
    return projects.updateProject(project.id, { memory: res.text.trim().slice(0, 20000) });
  });
  r.get('/api/search', ({ query }) => {
    const q = (query.get('q') ?? '').trim();
    if (q.length < 2) return [];
    return chats.searchChats(q);
  });
  r.post('/api/attachments', ({ body }) => chats.saveAttachment(body));
  r.get(
    '/api/attachments/:id',
    ({ params, res }) => {
      const f = chats.attachmentFile(params.id);
      res.writeHead(200, { 'Content-Type': mimeFor(f.path) === 'application/octet-stream' ? f.mime : mimeFor(f.path), 'Cache-Control': 'private, max-age=3600', 'Content-Disposition': `inline; filename="${encodeURIComponent(f.name)}"`, 'X-Content-Type-Options': 'nosniff' });
      fs.createReadStream(f.path).pipe(res);
    },
    { raw: true },
  );

  // ---------- projects ----------
  r.get('/api/projects', () => projects.listProjects());
  r.post('/api/projects', ({ body }) => projects.createProject(body));
  r.get('/api/projects/:id', ({ params }) => projects.mustProject(params.id));
  r.patch('/api/projects/:id', ({ params, body }) => projects.updateProject(params.id, body));
  r.delete('/api/projects/:id', ({ params }) => projects.deleteProject(params.id));
  r.get('/api/projects/:id/files', ({ params, query }) => {
    const p = projects.mustProject(params.id);
    if (!p.folderPath) throw new HttpError(400, 'Link a folder to this project first');
    return listDir(p.folderPath, query.get('path') ?? '');
  });
  r.get('/api/projects/:id/file', ({ params, query }) => {
    const p = projects.mustProject(params.id);
    if (!p.folderPath) throw new HttpError(400, 'Link a folder to this project first');
    const abs = safeResolve(p.folderPath, query.get('path') ?? '');
    if (!fs.existsSync(abs) || !fs.statSync(abs).isFile()) throw new HttpError(404, 'File not found');
    return readText(abs, 1024 * 1024);
  });
  r.get('/api/projects/:id/stats', ({ params }) => {
    const p = projects.mustProject(params.id);
    if (!p.folderPath || !fs.existsSync(p.folderPath)) return { files: 0, textBytes: 0, truncated: false, estTokensAll: 0 };
    const idx = getIndex(p.id, p.folderPath, true);
    return { files: idx.files.length, textBytes: idx.totalTextBytes, truncated: idx.truncated, estTokensAll: estimateTokens(idx.totalTextBytes) };
  });
  r.post('/api/projects/:id/context-preview', ({ params, body }) => {
    const p = projects.mustProject(params.id);
    invalidateProject(p.id);
    return buildContextPack({ project: p, query: str(body?.query ?? '', 'query', { max: 5000 }), mode: body?.mode });
  });
  r.get('/api/projects/:id/changes', ({ params, query }) => projects.listChanges(params.id, { sourceId: query.get('sourceId') ?? undefined }));
  r.post('/api/changes/:id/revert', ({ params }) => projects.revertChange(params.id));
  r.post('/api/projects/:id/open-folder', ({ params }) => {
    const p = projects.mustProject(params.id);
    if (!p.folderPath) throw new HttpError(400, 'No folder linked');
    openFolder(p.folderPath);
  });

  // ---------- agents ----------
  r.get('/api/runs', ({ query }) => agents.listRuns(query.get('projectId'), Number(query.get('limit') ?? 50)));
  r.post('/api/runs', ({ body }) => agents.createRun(body));
  r.get('/api/runs/:id', ({ params }) => agents.getRun(params.id));
  r.delete('/api/runs/:id', ({ params }) => agents.deleteRun(params.id));
  r.post('/api/runs/:id/start', ({ params }) => agents.startRun(params.id));
  r.post('/api/runs/:id/pause', ({ params }) => agents.pauseRun(params.id));
  r.post('/api/runs/:id/resume', ({ params }) => agents.startRun(params.id));
  r.post('/api/runs/:id/cancel', ({ params }) => agents.cancelRun(params.id));
  r.post('/api/runs/:id/tasks', ({ params, body }) => agents.addTask(params.id, body));
  r.get('/api/tasks/:id', ({ params }) => agents.getTask(params.id));
  r.patch('/api/tasks/:id', ({ params, body }) => agents.updateTask(params.id, body));
  r.delete('/api/tasks/:id', ({ params }) => agents.removeTask(params.id));
  r.post('/api/tasks/:id/stop', ({ params }) => agents.stopTask(params.id));
  r.post('/api/tasks/:id/retry', ({ params }) => agents.retryTask(params.id));
  r.post('/api/tasks/:id/accept', ({ params }) => agents.acceptTask(params.id));
  r.post('/api/tasks/:id/revert', ({ params }) => agents.revertTask(params.id));

  // ---------- approvals ----------
  r.get('/api/approvals', () => listApprovals());
  r.post('/api/approvals/:id', ({ params, body }) => decide(params.id, { allow: !!body?.allow, remember: body?.remember === 'session' ? 'session' : 'once', message: body?.message }));

  // ---------- roblox ----------
  r.get('/api/roblox/status', () => roblox.status());
  r.post('/api/roblox/connect', async () => {
    await roblox.connect();
    return roblox.status();
  });
  r.post('/api/roblox/disconnect', () => {
    roblox.disconnect();
    return roblox.status();
  });
  r.post('/api/roblox/test', () => roblox.test());
  r.post('/api/roblox/refresh', async () => {
    await roblox.refreshTools();
    await roblox.refreshStudios();
    return roblox.status();
  });
  r.post('/api/roblox/studio', ({ body }) => {
    roblox.selectStudio(str(body?.studioId, 'studioId', { min: 1 }));
    return roblox.status();
  });
  r.post('/api/roblox/call', async ({ body }) => roblox.call(str(body?.tool, 'tool', { min: 1, max: 100 }), body?.args ?? {}, { kind: 'user', id: 'user', label: 'You (Studio console)' }));
  r.get('/api/roblox/activity', ({ query }) => listRobloxActivity(Number(query.get('limit') ?? 150)));
  r.get('/api/roblox/diagnostics', () => roblox.diagnostics());

  /** MCP bridge endpoint used by app/mcp-bridge.mjs (token-authenticated, localhost only). */
  r.post('/api/bridge/rpc', async ({ req, body, res }) => {
    const token = req.headers['x-bloxade-bridge-token'];
    const response = await handleBridgeMessage(Array.isArray(token) ? token[0] : token, body);
    sendJson(res, 200, { response });
  });

  // ---------- activity & usage ----------
  r.get('/api/activity', ({ query }) => listActivity(Number(query.get('limit') ?? 200), query.get('before') ? Number(query.get('before')) : undefined));
  r.get('/api/usage', ({ query }) => {
    const range = oneOf(query.get('range') ?? '7d', ['24h', '7d', '30d', 'all'] as const, 'range');
    return usageSummary(range, { agents: agents.activeAgentCount(), chats: chats.runningChatIds().length, sessions: listProcesses().filter((p) => p.kind === 'claude' || p.kind === 'codex-app-server').length });
  });

  return r;
}
