import type { Account, AccountLimits, ChatMode, ProviderRef, UsageInfo } from '@shared/types';

export interface PermissionRequest {
  kind: 'command' | 'file_edit' | 'tool';
  toolName: string;
  input: unknown;
  paths: string[];
  command?: string;
  description: string;
}

export interface PermissionDecision {
  allow: boolean;
  message?: string;
}

export type PermissionHandler = (req: PermissionRequest) => Promise<PermissionDecision>;

export type TurnEvent =
  | { type: 'session'; ref: ProviderRef; model?: string | null }
  | { type: 'text'; text: string; newBlock?: boolean }
  | { type: 'thinking'; text: string }
  | { type: 'tool_start'; id: string; name: string; input: unknown; server?: string; title?: string }
  | { type: 'tool_end'; id: string; output: string; isError: boolean; denied?: boolean }
  | { type: 'usage'; usage: UsageInfo }
  | { type: 'limits'; limits: AccountLimits }
  | { type: 'notice'; level: 'info' | 'warning' | 'error'; text: string }
  | { type: 'file_change'; paths: string[] };

export interface ImageInput {
  path: string;
  mime: string;
}

export interface TurnRequest {
  account: Account;
  model: string;
  effort: string;
  mode: ChatMode;
  cwd: string;
  addDirs?: string[];
  systemAppend?: string;
  prompt: string;
  images?: ImageInput[];
  /** Continue this provider conversation (normal follow-up turn). */
  resume?: ProviderRef | null;
  /** Start from this checkpoint in a new provider conversation (regenerate / edit / branch). `{}` = fresh. */
  forkFrom?: ProviderRef | null;
  bridgeToken?: string | null;
  permissionMode?: 'ask' | 'acceptEdits' | 'full';
  onPermission: PermissionHandler;
  onEvent: (e: TurnEvent) => void;
  signal: AbortSignal;
  timeoutMs: number;
  label: string;
}

export interface TurnResult {
  ok: boolean;
  cancelled: boolean;
  text: string;
  ref: ProviderRef;
  usage: UsageInfo | null;
  error?: string;
  durationMs: number;
  model?: string | null;
}

export type TurnRunner = (req: TurnRequest) => Promise<TurnResult>;
