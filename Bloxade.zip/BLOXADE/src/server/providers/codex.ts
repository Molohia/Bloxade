import type { Account, AccountLimits, ModelInfo, UsageInfo } from '@shared/types';
import { requireCli } from './resolve';
import { providerEnv } from './env';
import { spawnTracked, killTree, onLines, type TrackedProcess } from '../core/proc';
import { logger } from '../core/log';
import { safeJson, truncate } from '../core/util';
import { bridgeServerSpec } from '../core/runtime';
import { VERSION } from '../core/runtime';
import type { TurnRequest, TurnResult } from './types';

const log = logger('codex');

type Json = any;
interface Pending {
  resolve: (v: Json) => void;
  reject: (e: Error) => void;
  timer: NodeJS.Timeout;
  method: string;
}

type ServerRequestHandler = (method: string, params: Json) => Promise<Json>;

/**
 * Client for the official `codex app-server` JSON-RPC protocol (the interface used by Codex's IDE integrations).
 * One app-server process per BLOXADE account; each runs with its own CODEX_HOME.
 */
export class CodexAppServer {
  private proc: TrackedProcess | null = null;
  private nextId = 1;
  private pending = new Map<number | string, Pending>();
  private threadListeners = new Map<string, (method: string, params: Json) => void>();
  private threadRequestHandlers = new Map<string, ServerRequestHandler>();
  private globalListeners = new Set<(method: string, params: Json) => void>();
  private starting: Promise<void> | null = null;
  private idleTimer: NodeJS.Timeout | null = null;
  readonly loadedThreads = new Set<string>();
  readonly threadTotals = new Map<string, { input: number; cached: number; output: number; reasoning: number }>();
  activeTurns = 0;
  stderrTail: string[] = [];
  lastLimits: AccountLimits | null = null;

  constructor(public account: Account) {}

  get running() {
    return !!this.proc && this.proc.child.exitCode === null;
  }

  async ensure(): Promise<void> {
    if (this.running && !this.starting) return;
    if (this.starting) return this.starting;
    this.starting = this.start().finally(() => (this.starting = null));
    return this.starting;
  }

  private async start() {
    const cli = requireCli('codex');
    const proc = spawnTracked(cli.command, [...cli.prefixArgs, 'app-server'], {
      env: providerEnv(this.account),
      stdio: ['pipe', 'pipe', 'pipe'],
      kind: 'codex-app-server',
      label: `Codex app-server (${this.account.name})`,
    });
    this.proc = proc;
    this.loadedThreads.clear();
    onLines(proc.child.stdout, (line) => this.onLine(line));
    onLines(proc.child.stderr, (line) => {
      this.stderrTail.push(line);
      if (this.stderrTail.length > 50) this.stderrTail.shift();
    });
    proc.child.on('exit', (code) => {
      log.info(`app-server exited (${this.account.name})`, { code });
      for (const [, p] of this.pending) {
        clearTimeout(p.timer);
        p.reject(new Error(`Codex app-server stopped (code ${code}). ${this.stderrTail.slice(-3).join(' ')}`));
      }
      this.pending.clear();
      for (const [threadId, l] of this.threadListeners) l('bloxade/serverExited', { threadId, code });
      this.proc = null;
    });
    proc.child.on('error', (e) => log.warn('app-server spawn error', e.message));
    await this.rawRequest('initialize', { clientInfo: { name: 'bloxade', title: 'BLOXADE', version: VERSION }, capabilities: null }, 30000);
    this.write({ method: 'initialized' });
    this.touch();
  }

  private write(obj: Json) {
    const stdin = this.proc?.child.stdin;
    if (!stdin || stdin.destroyed) throw new Error('Codex app-server is not running');
    stdin.write(JSON.stringify(obj) + '\n');
  }

  private rawRequest(method: string, params: Json, timeoutMs = 60000): Promise<Json> {
    const id = this.nextId++;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`Codex did not answer '${method}' within ${Math.round(timeoutMs / 1000)}s`));
      }, timeoutMs);
      this.pending.set(id, { resolve, reject, timer, method });
      try {
        this.write({ id, method, params });
      } catch (e) {
        clearTimeout(timer);
        this.pending.delete(id);
        reject(e as Error);
      }
    });
  }

  async request(method: string, params: Json, timeoutMs = 60000): Promise<Json> {
    await this.ensure();
    this.touch();
    return this.rawRequest(method, params, timeoutMs);
  }

  private onLine(line: string) {
    const msg = safeJson<Json>(line, null);
    if (!msg || typeof msg !== 'object') return;
    if (msg.id !== undefined && (msg.result !== undefined || msg.error !== undefined) && !msg.method) {
      const p = this.pending.get(msg.id);
      if (!p) return;
      clearTimeout(p.timer);
      this.pending.delete(msg.id);
      if (msg.error) p.reject(new Error(msg.error.message || JSON.stringify(msg.error)));
      else p.resolve(msg.result);
      return;
    }
    if (msg.method && msg.id !== undefined) {
      void this.onServerRequest(msg.id, msg.method, msg.params ?? {});
      return;
    }
    if (msg.method) {
      const params = msg.params ?? {};
      if (msg.method === 'account/rateLimits/updated' && params.rateLimits) {
        this.lastLimits = mergeLimits(this.lastLimits, codexLimits(params.rateLimits));
      }
      const tid = params.threadId ?? params.thread?.id;
      if (tid && this.threadListeners.has(tid)) this.threadListeners.get(tid)!(msg.method, params);
      for (const g of this.globalListeners) g(msg.method, params);
    }
  }

  private async onServerRequest(id: number | string, method: string, params: Json) {
    const tid = params.threadId;
    const handler = tid ? this.threadRequestHandlers.get(tid) : undefined;
    try {
      if (!handler) throw new Error(`No active BLOXADE turn for ${method}`);
      const result = await handler(method, params);
      this.write({ id, result });
    } catch (e) {
      try {
        this.write({ id, error: { code: -32000, message: (e as Error).message } });
      } catch {
        /* server gone */
      }
    }
  }

  onThread(threadId: string, listener: (method: string, params: Json) => void, handler: ServerRequestHandler) {
    this.threadListeners.set(threadId, listener);
    this.threadRequestHandlers.set(threadId, handler);
    return () => {
      this.threadListeners.delete(threadId);
      this.threadRequestHandlers.delete(threadId);
    };
  }

  onGlobal(listener: (method: string, params: Json) => void) {
    this.globalListeners.add(listener);
    return () => this.globalListeners.delete(listener);
  }

  private touch() {
    if (this.idleTimer) clearTimeout(this.idleTimer);
    this.idleTimer = setTimeout(() => {
      if (this.activeTurns === 0 && this.globalListeners.size === 0) this.stop();
      else this.touch();
    }, 10 * 60_000);
    this.idleTimer.unref();
  }

  stop() {
    if (this.proc) killTree(this.proc.child);
    this.proc = null;
  }
}

const servers = new Map<string, CodexAppServer>();

export function codexServer(account: Account): CodexAppServer {
  let s = servers.get(account.id);
  if (!s) {
    s = new CodexAppServer(account);
    servers.set(account.id, s);
  } else {
    s.account = account;
  }
  return s;
}

export function stopCodexServer(accountId: string) {
  servers.get(accountId)?.stop();
  servers.delete(accountId);
}

export function stopAllCodex() {
  for (const s of servers.values()) s.stop();
  servers.clear();
}

// ---------- mapping helpers ----------

export function codexLimits(rl: Json): AccountLimits {
  const windows: AccountLimits['windows'] = [];
  const label = (mins: number | null | undefined, fallback: string) => {
    if (!mins) return fallback;
    if (mins === 300) return '5-hour window';
    if (mins === 10080) return 'Weekly';
    if (mins % 1440 === 0) return `${mins / 1440}-day window`;
    if (mins % 60 === 0) return `${mins / 60}-hour window`;
    return `${mins}-minute window`;
  };
  if (rl?.primary) windows.push({ id: 'primary', label: label(rl.primary.windowDurationMins, 'Primary'), usedPercent: rl.primary.usedPercent, resetsAt: rl.primary.resetsAt, windowMins: rl.primary.windowDurationMins });
  if (rl?.secondary) windows.push({ id: 'secondary', label: label(rl.secondary.windowDurationMins, 'Secondary'), usedPercent: rl.secondary.usedPercent, resetsAt: rl.secondary.resetsAt, windowMins: rl.secondary.windowDurationMins });
  const credits = rl?.credits;
  return {
    source: 'codex',
    updatedAt: Date.now(),
    windows,
    note: credits && typeof credits === 'object' && 'balance' in credits ? `Credits: ${credits.balance}` : rl?.planType ? `Plan: ${rl.planType}` : undefined,
  };
}

function mergeLimits(prev: AccountLimits | null, next: AccountLimits): AccountLimits {
  if (!prev) return next;
  const byId = new Map(prev.windows.map((w) => [w.id, w]));
  for (const w of next.windows) byId.set(w.id, w);
  return { ...prev, ...next, windows: [...byId.values()], note: next.note ?? prev.note };
}

function itemOutputText(item: Json): string {
  if (item?.type === 'commandExecution') return item.aggregatedOutput ?? '';
  if (item?.type === 'fileChange') return (item.changes ?? []).map((c: Json) => `${c.kind?.type ?? 'update'} ${c.path}\n${c.diff ?? ''}`).join('\n');
  if (item?.type === 'mcpToolCall') {
    if (item.error) return item.error.message ?? 'MCP tool failed';
    return (item.result?.content ?? []).map((c: Json) => (c?.type === 'text' ? c.text : c?.type === 'image' ? '[image]' : JSON.stringify(c))).join('\n');
  }
  if (item?.type === 'dynamicToolCall') return (item.contentItems ?? []).map((c: Json) => c.text ?? JSON.stringify(c)).join('\n');
  if (item?.type === 'webSearch') return item.query ? `Searched: ${item.query}` : 'Web search finished';
  return '';
}

function itemTool(item: Json): { name: string; input: unknown; server?: string; title?: string } | null {
  switch (item?.type) {
    case 'commandExecution':
      return { name: 'Shell', input: { command: item.command, cwd: item.cwd }, title: truncate(String(item.command ?? ''), 120) };
    case 'fileChange':
      return { name: 'Edit files', input: { files: (item.changes ?? []).map((c: Json) => c.path) }, title: (item.changes ?? []).map((c: Json) => c.path).join(', ') };
    case 'mcpToolCall':
      return { name: `${item.server}.${item.tool}`, input: item.arguments, server: item.server };
    case 'webSearch':
      return { name: 'Web search', input: { query: item.query }, title: item.query };
    case 'dynamicToolCall':
      return { name: item.tool, input: item.arguments };
    case 'collabAgentToolCall':
      return { name: 'Sub-agent', input: { prompt: item.prompt }, title: truncate(String(item.prompt ?? ''), 100) };
    case 'imageView':
      return { name: 'View image', input: { path: item.path } };
    case 'imageGeneration':
      return { name: 'Generate image', input: {} };
    default:
      return null;
  }
}

function friendlyCodexError(msg: string): string {
  const t = msg.toLowerCase();
  if (t.includes('401') || t.includes('unauthorized') || t.includes('not logged in') || t.includes('login') && t.includes('required') || t.includes('requiresopenaiauth'))
    return 'This Codex account is not signed in. Open Accounts and press "Sign in with ChatGPT".';
  if (t.includes('usage limit') || t.includes('rate limit')) return 'Codex usage limit reached for this account. ' + truncate(msg, 300);
  return truncate(msg, 1200);
}

export async function runCodexTurn(req: TurnRequest): Promise<TurnResult> {
  const server = codexServer(req.account);
  const started = Date.now();
  await server.ensure();

  const sandbox = req.mode === 'chat' ? 'read-only' : req.permissionMode === 'full' ? 'danger-full-access' : 'workspace-write';
  const approvalPolicy = req.mode === 'chat' ? 'never' : req.permissionMode === 'full' ? 'never' : 'on-request';
  const config: Record<string, Json> = {};
  if (req.bridgeToken && req.mode === 'cowork') {
    const spec = bridgeServerSpec(req.bridgeToken);
    config['mcp_servers.bloxade_roblox.command'] = spec.command;
    config['mcp_servers.bloxade_roblox.args'] = spec.args;
    config['mcp_servers.bloxade_roblox.env'] = spec.env;
  }
  const threadParams: Json = {
    model: req.model || null,
    cwd: req.cwd,
    approvalPolicy,
    sandbox,
    developerInstructions: req.systemAppend?.trim() ? req.systemAppend.slice(0, 24000) : null,
    config: Object.keys(config).length ? config : null,
  };

  let threadId: string | null = null;
  try {
    if (req.forkFrom) {
      if (req.forkFrom.threadId) {
        const r = await server.request('thread/fork', { threadId: req.forkFrom.threadId, lastTurnId: req.forkFrom.turnId ?? null, ...threadParams, excludeTurns: true });
        threadId = r.thread.id;
      } else {
        const r = await server.request('thread/start', threadParams);
        threadId = r.thread.id;
      }
    } else if (req.resume?.threadId) {
      threadId = req.resume.threadId;
      if (!server.loadedThreads.has(threadId)) {
        try {
          await server.request('thread/resume', { threadId, ...threadParams, excludeTurns: true });
        } catch (e) {
          req.onEvent({ type: 'notice', level: 'warning', text: `Could not resume the previous Codex thread (${(e as Error).message}). Started a new thread.` });
          const r = await server.request('thread/start', threadParams);
          threadId = r.thread.id;
        }
      }
    } else {
      const r = await server.request('thread/start', threadParams);
      threadId = r.thread.id;
    }
  } catch (e) {
    return { ok: false, cancelled: false, text: '', ref: { threadId: req.resume?.threadId ?? null }, usage: null, error: friendlyCodexError((e as Error).message), durationMs: Date.now() - started };
  }
  const tid = threadId!;
  server.loadedThreads.add(tid);
  req.onEvent({ type: 'session', ref: { threadId: tid }, model: req.model || null });

  return await new Promise<TurnResult>((resolve) => {
    let turnId: string | null = null;
    let finalText = '';
    let lastTextItem: string | null = null;
    const deltaItems = new Set<string>();
    const fileChangeItems = new Map<string, string[]>();
    const openTools = new Set<string>();
    let usage: UsageInfo | null = null;
    let errorMsg: string | null = null;
    let cancelled = false;
    let settled = false;
    const baseline = server.threadTotals.get(tid) ?? null;

    const finish = (r: Partial<TurnResult>) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      req.signal.removeEventListener('abort', onAbort);
      server.activeTurns = Math.max(0, server.activeTurns - 1);
      unsubscribe();
      for (const id of openTools) req.onEvent({ type: 'tool_end', id, output: cancelled ? 'Cancelled' : '', isError: cancelled });
      if (server.lastLimits) req.onEvent({ type: 'limits', limits: server.lastLimits });
      resolve({ ok: false, cancelled, text: finalText, ref: { threadId: tid, turnId }, usage, durationMs: Date.now() - started, model: req.model, ...r });
    };

    const interrupt = () => {
      if (turnId) server.request('turn/interrupt', { threadId: tid, turnId }, 15000).catch(() => undefined);
    };
    const onAbort = () => {
      cancelled = true;
      interrupt();
      setTimeout(() => finish({ ok: false, cancelled: true, error: 'Stopped' }), 8000);
    };
    req.signal.addEventListener('abort', onAbort);
    const timer = setTimeout(() => {
      errorMsg = 'Timed out';
      req.onEvent({ type: 'notice', level: 'error', text: `Turn exceeded the ${Math.round(req.timeoutMs / 60000)} minute limit and was stopped.` });
      interrupt();
      setTimeout(() => finish({ ok: false, error: 'Timed out' }), 8000);
    }, req.timeoutMs);

    const listener = (method: string, p: Json) => {
      if (p.turnId && turnId && p.turnId !== turnId && method !== 'thread/tokenUsage/updated') return;
      switch (method) {
        case 'turn/started':
          if (!turnId && p.turn?.id) turnId = p.turn.id;
          return;
        case 'item/agentMessage/delta': {
          if (!p.delta) return;
          deltaItems.add(p.itemId);
          const newBlock = finalText.length > 0 && lastTextItem !== p.itemId;
          lastTextItem = p.itemId;
          finalText += (newBlock ? '\n\n' : '') + p.delta;
          req.onEvent({ type: 'text', text: p.delta, newBlock });
          return;
        }
        case 'item/reasoning/summaryTextDelta':
        case 'item/reasoning/textDelta':
          if (p.delta) req.onEvent({ type: 'thinking', text: p.delta });
          return;
        case 'item/started': {
          const item = p.item;
          if (item?.type === 'fileChange') fileChangeItems.set(item.id, (item.changes ?? []).map((c: Json) => c.path));
          const t = itemTool(item);
          if (t) {
            openTools.add(item.id);
            req.onEvent({ type: 'tool_start', id: item.id, name: t.name, input: t.input, server: t.server, title: t.title });
          }
          return;
        }
        case 'item/completed': {
          const item = p.item;
          if (item?.type === 'agentMessage') {
            if (!deltaItems.has(item.id) && item.text) {
              const newBlock = finalText.length > 0;
              finalText += (newBlock ? '\n\n' : '') + item.text;
              req.onEvent({ type: 'text', text: item.text, newBlock });
            }
            return;
          }
          if (item?.type === 'fileChange' && item.status !== 'failed' && item.status !== 'declined') {
            req.onEvent({ type: 'file_change', paths: (item.changes ?? []).map((c: Json) => c.path) });
          }
          if (openTools.has(item?.id)) {
            openTools.delete(item.id);
            const isError = item.status === 'failed' || item.status === 'declined' || (item.type === 'commandExecution' && item.exitCode != null && item.exitCode !== 0) || !!item.error;
            req.onEvent({ type: 'tool_end', id: item.id, output: itemOutputText(item), isError, denied: item.status === 'declined' });
          }
          return;
        }
        case 'thread/tokenUsage/updated': {
          const t = p.tokenUsage?.total;
          const l = p.tokenUsage?.last;
          if (!t) return;
          const base = baseline ?? (l ? { input: t.inputTokens - l.inputTokens, cached: t.cachedInputTokens - l.cachedInputTokens, output: t.outputTokens - l.outputTokens, reasoning: t.reasoningOutputTokens - l.reasoningOutputTokens } : { input: 0, cached: 0, output: 0, reasoning: 0 });
          server.threadTotals.set(tid, { input: t.inputTokens, cached: t.cachedInputTokens, output: t.outputTokens, reasoning: t.reasoningOutputTokens });
          usage = {
            inputTokens: Math.max(0, t.inputTokens - base.input),
            cacheReadTokens: Math.max(0, t.cachedInputTokens - base.cached),
            outputTokens: Math.max(0, t.outputTokens - base.output),
            reasoningTokens: Math.max(0, t.reasoningOutputTokens - base.reasoning),
            costUsd: null,
            verified: true,
          };
          req.onEvent({ type: 'usage', usage });
          return;
        }
        case 'error':
          if (p.willRetry) req.onEvent({ type: 'notice', level: 'warning', text: `Codex: ${p.error?.message ?? 'temporary error'} — retrying…` });
          else errorMsg = friendlyCodexError(p.error?.message ?? 'Codex reported an error');
          return;
        case 'turn/completed': {
          const turn = p.turn ?? {};
          if (turnId && turn.id && turn.id !== turnId) return;
          if (turn.status === 'completed') return finish({ ok: true });
          if (turn.status === 'interrupted') return finish({ ok: false, cancelled: true, error: cancelled ? 'Stopped' : errorMsg ?? 'Interrupted' });
          return finish({ ok: false, error: friendlyCodexError(turn.error?.message ?? errorMsg ?? 'Codex turn failed') });
        }
        case 'bloxade/serverExited':
          return finish({ ok: false, error: `Codex app-server stopped unexpectedly. ${server.stderrTail.slice(-3).join(' ')}` });
        default:
          return;
      }
    };

    const handler: ServerRequestHandler = async (method, p) => {
      if (method === 'item/commandExecution/requestApproval') {
        const cmd = String(p.command ?? '');
        const dec = await req.onPermission({ kind: 'command', toolName: 'Shell', input: { command: cmd, cwd: p.cwd, reason: p.reason }, paths: [], command: cmd, description: p.reason ? `${cmd}\n\nReason: ${p.reason}` : cmd });
        return { decision: dec.allow ? 'accept' : 'decline' };
      }
      if (method === 'item/fileChange/requestApproval') {
        const paths = fileChangeItems.get(p.itemId) ?? (p.grantRoot ? [p.grantRoot] : []);
        const dec = await req.onPermission({ kind: 'file_edit', toolName: 'Edit files', input: { paths, reason: p.reason }, paths, description: p.reason || `Edit ${paths.join(', ')}` });
        return { decision: dec.allow ? 'accept' : 'decline' };
      }
      if (method === 'mcpServer/elicitation/request') {
        if (p.serverName === 'bloxade_roblox') return { action: 'accept', content: {}, _meta: null };
        return { action: 'decline', content: null, _meta: null };
      }
      throw new Error(`BLOXADE does not support '${method}' yet`);
    };

    const unsubscribe = server.onThread(tid, listener, handler);
    server.activeTurns++;

    const input: Json[] = [{ type: 'text', text: req.prompt, text_elements: [] }];
    for (const img of req.images ?? []) input.push({ type: 'localImage', path: img.path });
    server
      .request('turn/start', { threadId: tid, input, model: req.model || null, effort: req.effort || null, cwd: req.cwd, approvalPolicy }, 60000)
      .then((r) => {
        if (r?.turn?.id) turnId = r.turn.id;
        if (cancelled) interrupt();
      })
      .catch((e) => finish({ ok: false, error: friendlyCodexError((e as Error).message) }));
  });
}

// ---------- account + models ----------

export async function codexAccountRead(account: Account) {
  const s = codexServer(account);
  const r = await s.request('account/read', { refreshToken: false }, 30000);
  return r as { account: { type: string; email?: string | null; planType?: string } | null; requiresOpenaiAuth: boolean };
}

export async function codexRateLimits(account: Account): Promise<AccountLimits | null> {
  const s = codexServer(account);
  try {
    const r = await s.request('account/rateLimits/read', {}, 30000);
    const lim = codexLimits(r.rateLimits);
    s.lastLimits = lim;
    return lim;
  } catch (e) {
    log.debug('rate limits unavailable', (e as Error).message);
    return s.lastLimits;
  }
}

export async function codexModels(account: Account): Promise<ModelInfo[]> {
  const s = codexServer(account);
  const out: ModelInfo[] = [];
  let cursor: string | null = null;
  for (let page = 0; page < 10; page++) {
    const r: Json = await s.request('model/list', { includeHidden: true, cursor, limit: 100 }, 45000);
    for (const m of r.data ?? []) {
      out.push({
        id: m.model || m.id,
        label: m.displayName || m.model || m.id,
        description: m.description ?? '',
        efforts: (m.supportedReasoningEfforts ?? []).map((e: Json) => e.reasoningEffort),
        defaultEffort: m.defaultReasoningEffort ?? null,
        group: m.hidden ? 'hidden' : 'recommended',
        isDefault: !!m.isDefault,
        source: 'discovered',
      });
    }
    cursor = r.nextCursor ?? null;
    if (!cursor) break;
  }
  return out;
}

export async function codexLoginStart(account: Account, kind: 'browser' | 'device') {
  const s = codexServer(account);
  const r = await s.request('account/login/start', kind === 'device' ? { type: 'chatgptDeviceCode' } : { type: 'chatgpt' }, 30000);
  return r as { type: string; loginId: string; authUrl?: string; verificationUrl?: string; userCode?: string };
}

export async function codexLoginCancel(account: Account, loginId: string) {
  return codexServer(account).request('account/login/cancel', { loginId }, 15000).catch(() => undefined);
}

export async function codexLogout(account: Account) {
  return codexServer(account).request('account/logout', {}, 20000);
}
