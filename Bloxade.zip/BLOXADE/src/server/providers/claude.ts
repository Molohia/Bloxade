import fs from 'node:fs';
import type { Account, AccountLimits, ModelInfo, UsageInfo } from '@shared/types';
import { requireCli } from './resolve';
import { providerEnv } from './env';
import { spawnTracked, killTree, onLines, runCapture } from '../core/proc';
import { logger } from '../core/log';
import { uuid, safeJson, truncate } from '../core/util';
import { writeBridgeMcpConfig, removeQuiet } from '../core/runtime';
import type { PermissionRequest, TurnRequest, TurnResult } from './types';

const log = logger('claude');

const EDIT_TOOLS = new Set(['Write', 'Edit', 'MultiEdit', 'NotebookEdit']);
const COMMAND_TOOLS = new Set(['Bash', 'PowerShell', 'BashOutput', 'KillShell', 'KillBash']);

/** Maps a Claude Code can_use_tool request onto BLOXADE's permission model. */
export function classifyClaudeTool(toolName: string, input: any, description?: string): PermissionRequest {
  if (EDIT_TOOLS.has(toolName)) {
    const p = input?.file_path || input?.notebook_path || input?.path;
    return { kind: 'file_edit', toolName, input, paths: p ? [String(p)] : [], description: description || `${toolName} ${p ?? ''}` };
  }
  if (COMMAND_TOOLS.has(toolName)) {
    return { kind: 'command', toolName, input, paths: [], command: String(input?.command ?? ''), description: description || String(input?.command ?? toolName) };
  }
  return { kind: 'tool', toolName, input, paths: [], description: description || toolName };
}

function stringifyToolResult(content: unknown): string {
  if (typeof content === 'string') return content;
  if (Array.isArray(content)) {
    return content
      .map((c: any) => (c?.type === 'text' ? c.text : c?.type === 'image' ? '[image]' : JSON.stringify(c)))
      .join('\n');
  }
  return content == null ? '' : JSON.stringify(content);
}

function toLimits(info: any): AccountLimits | null {
  if (!info) return null;
  const windows: AccountLimits['windows'] = [];
  const uw = info.unifiedWindows || {};
  const labels: Record<string, string> = { five_hour: '5-hour window', seven_day: 'Weekly', seven_day_opus: 'Weekly (Opus)', seven_day_sonnet: 'Weekly (Sonnet)' };
  for (const [k, v] of Object.entries<any>(uw)) {
    if (typeof v?.utilization !== 'number') continue;
    windows.push({ id: k, label: labels[k] ?? k.replace(/_/g, ' '), usedPercent: Math.round(v.utilization * 1000) / 10, resetsAt: v.resetsAt ?? null, status: v.status ?? null });
  }
  if (!windows.length && info.rateLimitType) {
    windows.push({ id: info.rateLimitType, label: labels[info.rateLimitType] ?? info.rateLimitType, usedPercent: typeof info.utilization === 'number' ? info.utilization * 100 : NaN, resetsAt: info.resetsAt ?? null, status: info.status ?? null });
  }
  const statusText: Record<string, string> = { allowed_warning: 'Approaching the usage limit', rejected: 'Usage limit reached' };
  return { source: 'claude-code', updatedAt: Date.now(), windows, note: info.status && info.status !== 'allowed' ? statusText[info.status] ?? `Status: ${info.status}` : undefined };
}

function usageFromResult(d: any): UsageInfo {
  const u = d?.usage ?? {};
  return {
    inputTokens: u.input_tokens ?? 0,
    outputTokens: u.output_tokens ?? 0,
    cacheReadTokens: u.cache_read_input_tokens ?? 0,
    cacheWriteTokens: u.cache_creation_input_tokens ?? 0,
    reasoningTokens: u.output_tokens_details?.thinking_tokens ?? undefined,
    costUsd: typeof d?.total_cost_usd === 'number' ? d.total_cost_usd : null,
    verified: true,
  };
}

function friendlyError(raw: string): string {
  const t = raw.toLowerCase();
  if (t.includes('please run /login') || t.includes('invalid api key') || t.includes('not logged in') || t.includes('oauth token has expired') || t.includes('authentication_error'))
    return 'This Claude account is not signed in (or its sign-in expired). Open Accounts and press "Sign in".';
  if (t.includes('rate_limit') || t.includes('usage limit') || t.includes('limit reached')) return 'Claude usage limit reached for this account. ' + truncate(raw, 300);
  return truncate(raw, 1200);
}

export async function runClaudeTurn(req: TurnRequest): Promise<TurnResult> {
  const cli = requireCli('claude');
  const started = Date.now();
  const args = [...cli.prefixArgs, '-p', '--input-format', 'stream-json', '--output-format', 'stream-json', '--verbose', '--include-partial-messages', '--permission-prompt-tool', 'stdio'];
  if (req.model && req.model !== 'default') args.push('--model', req.model);
  if (req.effort) args.push('--effort', req.effort);

  // Session handling: resume in place, or fork from a checkpoint (regenerate / edit / branch).
  let sessionId: string | null = null;
  if (req.forkFrom) {
    if (req.forkFrom.sessionId) {
      args.push('--resume', req.forkFrom.sessionId, '--fork-session');
      if (req.forkFrom.lastAssistantUuid) args.push('--resume-session-at', req.forkFrom.lastAssistantUuid);
    } else {
      sessionId = uuid();
      args.push('--session-id', sessionId);
    }
  } else if (req.resume?.sessionId) {
    sessionId = req.resume.sessionId;
    args.push('--resume', sessionId);
  } else {
    sessionId = uuid();
    args.push('--session-id', sessionId);
  }

  let mcpFile: string | null = null;
  if (req.mode === 'chat') {
    args.push('--tools', '', '--strict-mcp-config', '--permission-mode', 'default');
  } else {
    const pm = req.permissionMode === 'full' ? 'bypassPermissions' : req.permissionMode === 'acceptEdits' ? 'acceptEdits' : 'default';
    args.push('--permission-mode', pm);
    if (req.bridgeToken) {
      mcpFile = writeBridgeMcpConfig(req.bridgeToken);
      args.push('--mcp-config', mcpFile, '--allowedTools', 'mcp__bloxade_roblox');
    }
    for (const d of req.addDirs ?? []) args.push('--add-dir', d);
  }
  if (req.systemAppend?.trim()) args.push('--append-system-prompt', req.systemAppend.slice(0, 24000));

  const proc = spawnTracked(cli.command, args, {
    cwd: req.cwd,
    env: providerEnv(req.account),
    stdio: ['pipe', 'pipe', 'pipe'],
    kind: 'claude',
    label: req.label,
  });
  const child = proc.child;

  const content: any[] = [{ type: 'text', text: req.prompt }];
  for (const img of req.images ?? []) {
    try {
      const data = fs.readFileSync(img.path).toString('base64');
      content.push({ type: 'image', source: { type: 'base64', media_type: img.mime, data } });
    } catch (e) {
      log.warn('could not attach image', (e as Error).message);
    }
  }

  const send = (obj: unknown) => {
    if (child.stdin && !child.stdin.destroyed && child.stdin.writable) child.stdin.write(JSON.stringify(obj) + '\n');
  };

  return await new Promise<TurnResult>((resolve) => {
    let finalText = '';
    const streamedForMessage = new Set<string>();
    let currentMsgId: string | null = null;
    let textSinceMessageStart = false;
    let anyText = false;
    let lastAssistantUuid: string | null = req.resume?.lastAssistantUuid ?? null;
    let model: string | null = null;
    let usage: UsageInfo | null = null;
    let resultSeen = false;
    let resultError: string | null = null;
    let cancelled = false;
    const stderrTail: string[] = [];
    const openTools = new Set<string>();
    const toolMeta = new Map<string, { name: string; input: any }>();
    let settled = false;

    const finish = (r: Partial<TurnResult>) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      req.signal.removeEventListener('abort', onAbort);
      removeQuiet(mcpFile);
      for (const id of openTools) req.onEvent({ type: 'tool_end', id, output: cancelled ? 'Cancelled' : '', isError: cancelled });
      resolve({
        ok: false,
        cancelled,
        text: finalText,
        ref: { sessionId, lastAssistantUuid },
        usage,
        durationMs: Date.now() - started,
        model,
        ...r,
      });
    };

    const onAbort = () => {
      cancelled = true;
      send({ type: 'control_request', request_id: uuid(), request: { subtype: 'interrupt' } });
      setTimeout(() => {
        if (!settled) killTree(child);
      }, 4000);
    };
    req.signal.addEventListener('abort', onAbort);
    const timer = setTimeout(() => {
      req.onEvent({ type: 'notice', level: 'error', text: `Turn exceeded the ${Math.round(req.timeoutMs / 60000)} minute limit and was stopped.` });
      resultError = 'Timed out';
      killTree(child);
    }, req.timeoutMs);

    onLines(child.stderr, (line) => {
      stderrTail.push(line);
      if (stderrTail.length > 40) stderrTail.shift();
    });

    onLines(child.stdout, (line) => {
      const d = safeJson<any>(line, null);
      if (!d || typeof d !== 'object') return;
      try {
        handle(d);
      } catch (e) {
        log.warn('event handling failed', (e as Error).message);
      }
    });

    const handle = (d: any) => {
      const topLevel = d.parent_tool_use_id == null;
      switch (d.type) {
        case 'system':
          if (d.subtype === 'init') {
            if (d.session_id) sessionId = d.session_id;
            model = d.model ?? model;
            req.onEvent({ type: 'session', ref: { sessionId, lastAssistantUuid }, model });
          } else if (d.subtype === 'compact_boundary') {
            req.onEvent({ type: 'notice', level: 'info', text: 'Claude Code compacted the conversation context.' });
          }
          return;
        case 'stream_event': {
          if (!topLevel) return;
          const ev = d.event;
          if (ev?.type === 'message_start') {
            currentMsgId = ev.message?.id ?? null;
            textSinceMessageStart = false;
          } else if (ev?.type === 'content_block_delta') {
            if (ev.delta?.type === 'text_delta' && ev.delta.text) {
              if (currentMsgId) streamedForMessage.add(currentMsgId);
              req.onEvent({ type: 'text', text: ev.delta.text, newBlock: anyText && !textSinceMessageStart });
              textSinceMessageStart = true;
              anyText = true;
              finalText += ev.delta.text;
            } else if (ev.delta?.type === 'thinking_delta' && ev.delta.thinking) {
              req.onEvent({ type: 'thinking', text: ev.delta.thinking });
            }
          }
          return;
        }
        case 'assistant': {
          if (!topLevel) return;
          if (d.uuid) lastAssistantUuid = d.uuid;
          const msg = d.message ?? {};
          model = msg.model ?? model;
          for (const block of msg.content ?? []) {
            if (block.type === 'text' && block.text && !streamedForMessage.has(msg.id)) {
              req.onEvent({ type: 'text', text: block.text, newBlock: anyText });
              anyText = true;
              finalText += block.text;
            } else if (block.type === 'tool_use') {
              openTools.add(block.id);
              toolMeta.set(block.id, { name: block.name, input: block.input });
              const server = String(block.name).startsWith('mcp__') ? String(block.name).split('__')[1] : undefined;
              req.onEvent({ type: 'tool_start', id: block.id, name: block.name, input: block.input, server });
            }
          }
          return;
        }
        case 'user': {
          if (!topLevel) return;
          for (const block of d.message?.content ?? []) {
            if (block?.type === 'tool_result') {
              openTools.delete(block.tool_use_id);
              const output = stringifyToolResult(block.content);
              req.onEvent({ type: 'tool_end', id: block.tool_use_id, output, isError: !!block.is_error });
              const meta = toolMeta.get(block.tool_use_id);
              if (meta && !block.is_error && EDIT_TOOLS.has(meta.name)) {
                const p = meta.input?.file_path || meta.input?.notebook_path;
                if (p) req.onEvent({ type: 'file_change', paths: [String(p)] });
              }
            }
          }
          return;
        }
        case 'rate_limit_event': {
          const lim = toLimits(d.rate_limit_info);
          if (lim) req.onEvent({ type: 'limits', limits: lim });
          return;
        }
        case 'control_request': {
          const r = d.request ?? {};
          if (r.subtype === 'can_use_tool') {
            const pr = classifyClaudeTool(r.tool_name, r.input, r.description);
            req
              .onPermission(pr)
              .then((dec) => {
                send({
                  type: 'control_response',
                  response: {
                    subtype: 'success',
                    request_id: d.request_id,
                    response: dec.allow ? { behavior: 'allow', updatedInput: r.input ?? {} } : { behavior: 'deny', message: dec.message || 'Denied in BLOXADE' },
                  },
                });
                if (!dec.allow && r.tool_use_id) req.onEvent({ type: 'tool_end', id: r.tool_use_id, output: dec.message || 'Denied', isError: true, denied: true });
              })
              .catch((e) => {
                send({ type: 'control_response', response: { subtype: 'success', request_id: d.request_id, response: { behavior: 'deny', message: String(e?.message ?? e) } } });
              });
          } else {
            send({ type: 'control_response', response: { subtype: 'error', request_id: d.request_id, error: `BLOXADE does not handle '${r.subtype}' requests` } });
          }
          return;
        }
        case 'result': {
          resultSeen = true;
          usage = usageFromResult(d);
          req.onEvent({ type: 'usage', usage });
          if (d.is_error || (d.subtype && d.subtype !== 'success')) {
            const raw = typeof d.result === 'string' && d.result ? d.result : Array.isArray(d.errors) ? d.errors.join('\n') : d.subtype;
            if (!cancelled) resultError = friendlyError(String(raw));
          }
          if (!finalText && typeof d.result === 'string' && !d.is_error) {
            finalText = d.result;
            req.onEvent({ type: 'text', text: d.result });
          }
          if (d.session_id) sessionId = d.session_id;
          try {
            child.stdin?.end();
          } catch {
            /* ignore */
          }
          return;
        }
        default:
          return;
      }
    };

    try {
      send({ type: 'user', message: { role: 'user', content }, parent_tool_use_id: null, session_id: '' });
    } catch (e) {
      finish({ ok: false, error: `Could not start Claude Code: ${(e as Error).message}` });
      return;
    }

    child.on('error', (e) => finish({ ok: false, error: `Could not start Claude Code: ${e.message}` }));
    child.on('exit', (code) => {
      setTimeout(() => {
        if (cancelled) return finish({ ok: false, cancelled: true, error: 'Stopped' });
        if (resultError) return finish({ ok: false, error: resultError });
        if (!resultSeen) {
          const tail = stderrTail.join('\n').trim();
          return finish({ ok: false, error: friendlyError(tail || `Claude Code exited (code ${code}) before finishing the turn.`) });
        }
        finish({ ok: true });
      }, 50);
    });
  });
}

export interface ClaudeDiscovery {
  models: ModelInfo[];
  account: { email?: string | null; plan?: string | null; apiProvider?: string | null; organization?: string | null } | null;
  version?: string | null;
}

/** Uses the CLI's own initialize handshake (the same one the official Agent SDK uses) to list the models available to an account. */
export async function discoverClaude(account: Account | null): Promise<ClaudeDiscovery> {
  const cli = requireCli('claude');
  const args = [...cli.prefixArgs, '-p', '--input-format', 'stream-json', '--output-format', 'stream-json', '--verbose', '--tools', '', '--strict-mcp-config', '--no-session-persistence'];
  const proc = spawnTracked(cli.command, args, { env: providerEnv(account), stdio: ['pipe', 'pipe', 'pipe'], kind: 'claude-discovery', label: 'model discovery', cwd: process.cwd() });
  const child = proc.child;
  return await new Promise((resolve, reject) => {
    const reqId = 'bx_init_' + Date.now();
    const timer = setTimeout(() => {
      killTree(child);
      reject(new Error('Claude Code did not answer the initialize request in time'));
    }, 30000);
    let stderr = '';
    child.stderr?.on('data', (d) => (stderr += d.toString()));
    child.on('error', (e) => {
      clearTimeout(timer);
      reject(e);
    });
    child.on('exit', (code) => {
      clearTimeout(timer);
      reject(new Error(`Claude Code exited (${code}) during discovery. ${stderr.trim().slice(0, 300)}`));
    });
    onLines(child.stdout, (line) => {
      const d = safeJson<any>(line, null);
      if (d?.type !== 'control_response') return;
      const r = d.response ?? {};
      if (r.request_id && r.request_id !== reqId) return;
      clearTimeout(timer);
      const resp = r.response ?? {};
      const models: ModelInfo[] = (resp.models ?? []).map((m: any) => ({
        id: String(m.value),
        label: String(m.displayName ?? m.value),
        description: m.description ?? '',
        resolvedModel: m.resolvedModel ?? null,
        efforts: Array.isArray(m.supportedEffortLevels) ? m.supportedEffortLevels : m.supportsEffort ? ['low', 'medium', 'high'] : [],
        defaultEffort: null,
        group: 'recommended',
        isDefault: m.value === 'default',
        source: 'discovered',
      }));
      const a = resp.account ?? null;
      killTree(child);
      child.removeAllListeners('exit');
      resolve({
        models,
        account: a ? { email: a.email ?? a.emailAddress ?? null, plan: a.subscriptionType ?? null, apiProvider: a.apiProvider ?? null, organization: a.organization ?? a.organizationName ?? null } : null,
        version: resp.claude_code_version ?? null,
      });
    });
    child.stdin?.write(JSON.stringify({ type: 'control_request', request_id: reqId, request: { subtype: 'initialize' } }) + '\n');
  });
}

export async function claudeAuthStatus(account: Account | null): Promise<{ loggedIn: boolean; authMethod?: string; email?: string | null; raw?: any; error?: string }> {
  const cli = requireCli('claude');
  const out = await runCapture(cli.command, [...cli.prefixArgs, 'auth', 'status', '--json'], { env: providerEnv(account), timeoutMs: 25000 });
  const data = safeJson<any>(out.stdout.trim(), null);
  if (!data) return { loggedIn: false, error: out.error || out.stderr.trim().slice(0, 300) || 'Could not read auth status' };
  return {
    loggedIn: !!data.loggedIn,
    authMethod: data.authMethod,
    email: data.email ?? data.emailAddress ?? data.account?.email ?? null,
    raw: { authMethod: data.authMethod, apiProvider: data.apiProvider, subscriptionType: data.subscriptionType ?? null, orgName: data.orgName ?? data.organizationName ?? null },
  };
}

export async function claudeLogout(account: Account | null) {
  const cli = requireCli('claude');
  return runCapture(cli.command, [...cli.prefixArgs, 'auth', 'logout'], { env: providerEnv(account), timeoutMs: 20000 });
}

export function claudeLoginCommand(): { command: string; args: string[] } {
  const cli = requireCli('claude');
  return { command: cli.command, args: [...cli.prefixArgs, 'auth', 'login'] };
}
