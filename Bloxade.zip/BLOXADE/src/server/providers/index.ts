import type { Provider } from '@shared/types';
import { runClaudeTurn } from './claude';
import { runCodexTurn } from './codex';
import type { TurnRequest, TurnResult } from './types';
import { recordLimits, touchAccount } from '../services/accounts';

/** Runs one provider turn and keeps account bookkeeping (last-used, verified usage windows) up to date. */
export async function runTurn(provider: Provider, req: TurnRequest): Promise<TurnResult> {
  touchAccount(req.account.id);
  const onEvent = req.onEvent;
  const wrapped: TurnRequest = {
    ...req,
    onEvent: (e) => {
      if (e.type === 'limits') recordLimits(req.account.id, e.limits);
      onEvent(e);
    },
  };
  return provider === 'claude' ? runClaudeTurn(wrapped) : runCodexTurn(wrapped);
}

/** One-shot, tool-less completion (used by the coordinator and memory summaries). */
export async function complete(
  provider: Provider,
  req: Omit<TurnRequest, 'mode' | 'onPermission' | 'onEvent' | 'resume' | 'forkFrom'> & { onText?: (t: string) => void },
): Promise<TurnResult> {
  return runTurn(provider, {
    ...req,
    mode: 'chat',
    resume: null,
    forkFrom: null,
    onPermission: async () => ({ allow: false, message: 'Tools are disabled for this request' }),
    onEvent: (e) => {
      if (e.type === 'text') req.onText?.(e.text);
    },
  });
}
