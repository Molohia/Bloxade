import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import type { CliInfo, Provider } from '@shared/types';
import { IS_WIN } from '../core/util';
import { runCapture } from '../core/proc';
import { getSettings } from '../core/settings';
import { expandUserPath } from '../core/paths';
import { logger } from '../core/log';

const log = logger('cli');

/** How to launch a CLI without a shell: `command args... <cli args>` */
export interface ResolvedCli {
  provider: Provider;
  command: string;
  prefixArgs: string[];
  display: string;
}

const BIN: Record<Provider, string> = { claude: 'claude', codex: 'codex' };

function pathDirs(): string[] {
  return (process.env.PATH || process.env.Path || '').split(path.delimiter).filter(Boolean);
}

function isFile(p: string) {
  try {
    return fs.statSync(p).isFile();
  } catch {
    return false;
  }
}

function knownLocations(provider: Provider): string[] {
  const home = os.homedir();
  const local = process.env.LOCALAPPDATA || path.join(home, 'AppData', 'Local');
  const roaming = process.env.APPDATA || path.join(home, 'AppData', 'Roaming');
  if (IS_WIN) {
    if (provider === 'claude') {
      return [
        path.join(home, '.local', 'bin', 'claude.exe'),
        path.join(roaming, 'npm', 'claude.cmd'),
        path.join(local, 'Programs', 'claude', 'claude.exe'),
        path.join(local, 'AnthropicClaude', 'claude.exe'),
      ];
    }
    const list = [
      path.join(local, 'Programs', 'OpenAI', 'Codex', 'codex.exe'),
      path.join(local, 'Programs', 'OpenAI', 'Codex', 'bin', 'codex.exe'),
      path.join(home, '.local', 'bin', 'codex.exe'),
      path.join(roaming, 'npm', 'codex.cmd'),
      path.join(home, '.codex', 'bin', 'codex.exe'),
    ];
    // VS Code / Cursor "Codex" extension ships the official CLI binary too.
    for (const extRoot of [path.join(home, '.vscode', 'extensions'), path.join(home, '.cursor', 'extensions')]) {
      try {
        const exts = fs
          .readdirSync(extRoot)
          .filter((n) => n.startsWith('openai.chatgpt-'))
          .sort()
          .reverse();
        for (const e of exts) list.push(path.join(extRoot, e, 'bin', 'windows-x86_64', 'codex.exe'));
      } catch {
        /* no extensions folder */
      }
    }
    return list;
  }
  return [path.join(home, '.local', 'bin', BIN[provider]), path.join(home, '.npm-global', 'bin', BIN[provider]), `/usr/local/bin/${BIN[provider]}`, `/opt/homebrew/bin/${BIN[provider]}`];
}

/** npm on Windows installs `.cmd` shims; spawning those needs a shell, so we run the JS target with Node instead. */
function fromCmdShim(cmdPath: string, provider: Provider): ResolvedCli | null {
  try {
    const text = fs.readFileSync(cmdPath, 'utf8');
    const m = text.match(/"%(?:~dp0|dp0%)\\?([^"]+?\.(?:js|cjs|mjs|exe))"/i) || text.match(/%~dp0\\([^\s"]+?\.(?:js|cjs|mjs|exe))/i);
    if (!m) return null;
    const target = path.resolve(path.dirname(cmdPath), m[1]);
    if (!isFile(target)) return null;
    if (/\.exe$/i.test(target)) return { provider, command: target, prefixArgs: [], display: target };
    return { provider, command: process.execPath, prefixArgs: [target], display: `node ${target}` };
  } catch {
    return null;
  }
}

function asResolved(file: string, provider: Provider): ResolvedCli | null {
  if (!isFile(file)) return null;
  const ext = path.extname(file).toLowerCase();
  if (IS_WIN && (ext === '.cmd' || ext === '.bat')) return fromCmdShim(file, provider);
  if (['.js', '.mjs', '.cjs'].includes(ext)) return { provider, command: process.execPath, prefixArgs: [file], display: `node ${file}` };
  return { provider, command: file, prefixArgs: [], display: file };
}

export function findCli(provider: Provider): ResolvedCli | null {
  const s = getSettings();
  const override = (provider === 'claude' ? s.providers.claudePath : s.providers.codexPath) || process.env[`BLOXADE_${provider.toUpperCase()}_PATH`] || '';
  if (override.trim()) {
    const r = asResolved(expandUserPath(override), provider);
    if (r) return r;
    log.warn(`configured ${provider} path not usable`, override);
  }
  const exts = IS_WIN ? ['.exe', '.cmd', '.bat', ''] : [''];
  for (const dir of pathDirs()) {
    for (const ext of exts) {
      const r = asResolved(path.join(dir, BIN[provider] + ext), provider);
      if (r) return r;
    }
  }
  for (const loc of knownLocations(provider)) {
    const r = asResolved(loc, provider);
    if (r) return r;
  }
  return null;
}

const cache = new Map<Provider, CliInfo>();

export async function detectCli(provider: Provider, force = false): Promise<CliInfo> {
  const cached = cache.get(provider);
  if (cached && !force && Date.now() - cached.checkedAt < 5 * 60_000) return cached;
  const r = findCli(provider);
  let info: CliInfo;
  if (!r) {
    info = { provider, found: false, checkedAt: Date.now(), error: `${provider === 'claude' ? 'Claude Code' : 'Codex'} CLI not found on this computer` };
  } else {
    const out = await runCapture(r.command, [...r.prefixArgs, '--version'], { timeoutMs: 20000 });
    const version = (out.stdout || out.stderr).trim().split('\n')[0]?.trim() || null;
    info = {
      provider,
      found: out.code === 0,
      path: r.display,
      launch: r.command,
      version,
      error: out.code === 0 ? null : out.error || out.stderr.trim().slice(0, 300) || 'CLI did not start',
      checkedAt: Date.now(),
    };
  }
  cache.set(provider, info);
  return info;
}

export function cachedCli(provider: Provider): CliInfo {
  return cache.get(provider) ?? { provider, found: false, checkedAt: 0, error: 'Not checked yet' };
}

export function requireCli(provider: Provider): ResolvedCli {
  const r = findCli(provider);
  if (!r) {
    throw new Error(
      provider === 'claude'
        ? 'Claude Code is not installed (or not on PATH). Install it from https://claude.com/claude-code, then press Refresh in Settings → AI Providers.'
        : 'Codex CLI is not installed (or not on PATH). Install it from https://developers.openai.com/codex, then press Refresh in Settings → AI Providers.',
    );
  }
  return r;
}
