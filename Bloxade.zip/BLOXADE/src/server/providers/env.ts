import fs from 'node:fs';
import type { Account } from '@shared/types';

/**
 * Environment for a provider CLI child process.
 * Account isolation uses the providers' documented config-directory variables:
 *   Claude Code → CLAUDE_CONFIG_DIR, Codex → CODEX_HOME.
 * BLOXADE never reads or copies the credentials stored inside those folders.
 */
export function providerEnv(account: Account | null, extra: Record<string, string> = {}): NodeJS.ProcessEnv {
  const env: NodeJS.ProcessEnv = { ...process.env };
  // Markers that make Claude Code believe it is nested inside another Claude Code session.
  for (const k of ['CLAUDECODE', 'CLAUDE_CODE_SESSION_ID', 'CLAUDE_CODE_SSE_PORT', 'CLAUDE_CODE_CHILD_SESSION']) delete env[k];
  if (process.env.BLOXADE_KEEP_ENV !== '1') delete env.CLAUDE_CODE_ENTRYPOINT;
  if (account?.profileDir) {
    fs.mkdirSync(account.profileDir, { recursive: true });
    if (account.provider === 'claude') env.CLAUDE_CONFIG_DIR = account.profileDir;
    else env.CODEX_HOME = account.profileDir;
  }
  env.BLOXADE = '1';
  return { ...env, ...extra };
}
