import type { Account, ModelCatalog, ModelInfo, Provider } from '@shared/types';
import { discoverClaude } from './claude';
import { codexModels } from './codex';
import { kvGet, kvSet, getSettings } from '../core/settings';
import { logger } from '../core/log';

const log = logger('models');

const CLAUDE_EFFORTS = ['low', 'medium', 'high', 'xhigh', 'max'];

/**
 * Specific Claude model versions (from Anthropic's model status table, Oct 2026).
 * Claude Code accepts full model names via --model; availability depends on the signed-in plan.
 * Retired models are intentionally omitted.
 */
const CLAUDE_VERSIONS: [string, string, string?][] = [
  ['claude-fable-5-1', 'Claude Fable 5.1'],
  ['claude-fable-5', 'Claude Fable 5'],
  ['claude-mythos-5-1', 'Claude Mythos 5.1', 'Availability depends on your plan'],
  ['claude-mythos-5', 'Claude Mythos 5', 'Availability depends on your plan'],
  ['claude-opus-5-5', 'Claude Opus 5.5'],
  ['claude-opus-5', 'Claude Opus 5'],
  ['claude-opus-4-8', 'Claude Opus 4.8'],
  ['claude-opus-4-7', 'Claude Opus 4.7'],
  ['claude-opus-4-6', 'Claude Opus 4.6'],
  ['claude-opus-4-5-20251101', 'Claude Opus 4.5'],
  ['claude-sonnet-5-5', 'Claude Sonnet 5.5'],
  ['claude-sonnet-5', 'Claude Sonnet 5'],
  ['claude-sonnet-4-6', 'Claude Sonnet 4.6'],
  ['claude-sonnet-4-5-20250929', 'Claude Sonnet 4.5', 'Deprecated — retires Nov 30, 2026'],
  ['claude-haiku-5-5', 'Claude Haiku 5.5'],
  ['claude-haiku-4-5-20251001', 'Claude Haiku 4.5'],
];

const CLAUDE_FALLBACK_ALIASES: ModelInfo[] = [
  { id: 'default', label: 'Default (recommended)', description: 'Claude Code picks the recommended model for your plan', efforts: CLAUDE_EFFORTS, group: 'recommended', isDefault: true, source: 'catalog' },
  { id: 'opus', label: 'Opus', description: 'Latest Opus', efforts: CLAUDE_EFFORTS, group: 'recommended', source: 'catalog' },
  { id: 'sonnet', label: 'Sonnet', description: 'Latest Sonnet', efforts: CLAUDE_EFFORTS, group: 'recommended', source: 'catalog' },
  { id: 'haiku', label: 'Haiku', description: 'Latest Haiku', efforts: CLAUDE_EFFORTS, group: 'recommended', source: 'catalog' },
  { id: 'fable', label: 'Fable', description: 'Latest Fable', efforts: CLAUDE_EFFORTS, group: 'recommended', source: 'catalog' },
];

/** Shown only until the installed Codex CLI reports its own list (model/list). */
const CODEX_FALLBACK: ModelInfo[] = [
  ['gpt-6.1-sol', 'GPT-6.1-Sol'],
  ['gpt-6.1-terra', 'GPT-6.1 Terra'],
  ['gpt-6-astra', 'GPT-6-Astra'],
  ['gpt-6-sol', 'GPT-6-Sol'],
  ['gpt-6-luna', 'GPT-6-Luna'],
  ['gpt-5.6-sol', 'GPT-5.6-Sol'],
  ['gpt-5.6-terra', 'GPT-5.6-Terra'],
  ['gpt-5.6-luna', 'GPT-5.6-Luna'],
  ['gpt-5.5', 'GPT-5.5'],
].map(([id, label], i) => ({ id, label, efforts: ['low', 'medium', 'high', 'xhigh'], group: 'recommended' as const, isDefault: i === 0, source: 'catalog' as const, note: 'Not yet verified with your Codex CLI' }));

function claudeCatalog(discovered: ModelInfo[] | null): ModelInfo[] {
  const base = discovered && discovered.length ? discovered : CLAUDE_FALLBACK_ALIASES;
  const effortsFor = (id: string) => base.find((m) => m.resolvedModel === id)?.efforts ?? CLAUDE_EFFORTS;
  const versions: ModelInfo[] = CLAUDE_VERSIONS.map(([id, label, note]) => ({
    id,
    label,
    description: base.find((m) => m.resolvedModel === id) ? `Current target of “${base.find((m) => m.resolvedModel === id)!.label}”` : 'Pinned version',
    efforts: effortsFor(id),
    group: 'versions',
    source: 'catalog',
    note,
  }));
  return [...base, ...versions];
}

function withCustom(provider: Provider, list: ModelInfo[]): ModelInfo[] {
  const custom = getSettings().providers.customModels[provider] ?? [];
  const ids = new Set(list.map((m) => m.id));
  const extra = custom
    .filter((id) => !ids.has(id))
    .map<ModelInfo>((id) => ({ id, label: id, description: 'Custom model ID', efforts: provider === 'claude' ? CLAUDE_EFFORTS : ['low', 'medium', 'high'], group: 'versions', source: 'catalog', note: 'Added by you' }));
  return [...list, ...extra];
}

export function cachedCatalog(provider: Provider): ModelCatalog {
  const c = kvGet<ModelCatalog | null>(`models:${provider}`, null);
  if (c) return { ...c, models: withCustom(provider, c.models) };
  const models = provider === 'claude' ? claudeCatalog(null) : CODEX_FALLBACK;
  return { provider, models: withCustom(provider, models), discoveredAt: null, source: 'catalog' };
}

const inflight = new Map<Provider, Promise<ModelCatalog>>();

export function refreshCatalog(provider: Provider, account: Account | null): Promise<ModelCatalog> {
  const existing = inflight.get(provider);
  if (existing) return existing;
  const p = Promise.resolve().then(async () => {
    try {
      let models: ModelInfo[];
      if (provider === 'claude') {
        const d = await discoverClaude(account);
        models = claudeCatalog(d.models);
      } else {
        if (!account) throw new Error('Add a Codex account first');
        models = await codexModels(account);
        if (!models.length) throw new Error('Codex returned no models');
      }
      const cat: ModelCatalog = { provider, models, discoveredAt: Date.now(), source: 'discovered' };
      kvSet(`models:${provider}`, cat);
      return { ...cat, models: withCustom(provider, cat.models) };
    } catch (e) {
      log.warn(`model discovery failed for ${provider}`, (e as Error).message);
      const prev = cachedCatalog(provider);
      return { ...prev, error: (e as Error).message };
    } finally {
      inflight.delete(provider);
    }
  });
  inflight.set(provider, p);
  return p;
}
