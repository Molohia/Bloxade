import type { Provider } from '@shared/types';
import { matchOwned } from '../services/files';

export interface PlannedTask {
  key: string;
  title: string;
  description: string;
  provider: Provider | 'any';
  ownedPaths: string[];
  dependsOn: string[];
}

function extractJson(text: string): any {
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const candidates = [fenced?.[1], text];
  for (const c of candidates) {
    if (!c) continue;
    const start = c.indexOf('{');
    const end = c.lastIndexOf('}');
    if (start < 0 || end <= start) continue;
    try {
      return JSON.parse(c.slice(start, end + 1));
    } catch {
      /* try next */
    }
  }
  throw new Error('no JSON object found');
}

function overlap(a: string[], b: string[]) {
  return a.some((pa) => b.some((pb) => matchOwned([pa], pb.replace(/\*.*$/, '')) || matchOwned([pb], pa.replace(/\*.*$/, ''))));
}

/** Parses and validates a coordinator plan: unique keys, known deps, no cycles, and no parallel tasks sharing paths. */
export function parsePlan(text: string, maxTasks: number): { rationale: string; tasks: PlannedTask[]; notes: string[] } {
  const raw = extractJson(text);
  const list: any[] = Array.isArray(raw?.tasks) ? raw.tasks : Array.isArray(raw) ? raw : [];
  if (!list.length) throw new Error('plan has no tasks');
  const notes: string[] = [];
  let tasks: PlannedTask[] = list.slice(0, maxTasks).map((t, i) => ({
    key: typeof t?.key === 'string' && /^[A-Za-z0-9_-]{1,12}$/.test(t.key) ? t.key : `t${i + 1}`,
    title: String(t?.title ?? `Task ${i + 1}`).slice(0, 200),
    description: String(t?.description ?? t?.title ?? '').slice(0, 30000),
    provider: t?.provider === 'claude' || t?.provider === 'codex' ? t.provider : 'any',
    ownedPaths: Array.isArray(t?.ownedPaths) ? t.ownedPaths.map(String).filter(Boolean).slice(0, 40) : [],
    dependsOn: Array.isArray(t?.dependsOn) ? t.dependsOn.map(String) : [],
  }));
  if (list.length > maxTasks) notes.push(`Coordinator proposed ${list.length} tasks; limited to ${maxTasks} by the efficiency mode.`);
  // unique keys
  const seen = new Set<string>();
  tasks.forEach((t, i) => {
    if (seen.has(t.key)) t.key = `t${i + 1}_${i}`;
    seen.add(t.key);
  });
  // normalise keys to t1..tn while remapping dependencies
  const remap = new Map<string, string>();
  tasks.forEach((t, i) => remap.set(t.key, `t${i + 1}`));
  tasks = tasks.map((t) => ({ ...t, key: remap.get(t.key)!, dependsOn: t.dependsOn.map((d) => remap.get(d)).filter((d): d is string => !!d) }));
  tasks.forEach((t) => (t.dependsOn = [...new Set(t.dependsOn.filter((d) => d !== t.key))]));

  // break cycles (drop the back edge)
  const byKey = new Map(tasks.map((t) => [t.key, t]));
  const state = new Map<string, 0 | 1 | 2>();
  const visit = (k: string) => {
    state.set(k, 1);
    const t = byKey.get(k)!;
    t.dependsOn = t.dependsOn.filter((d) => {
      if (state.get(d) === 1) {
        notes.push(`Removed circular dependency ${k} → ${d}.`);
        return false;
      }
      if (!state.get(d)) visit(d);
      return true;
    });
    state.set(k, 2);
  };
  for (const t of tasks) if (!state.get(t.key)) visit(t.key);

  // dependency closure to know which tasks may run in parallel
  const ancestors = (k: string, acc = new Set<string>()): Set<string> => {
    for (const d of byKey.get(k)?.dependsOn ?? []) if (!acc.has(d)) {
      acc.add(d);
      ancestors(d, acc);
    }
    return acc;
  };
  for (let i = 0; i < tasks.length; i++) {
    for (let j2 = i + 1; j2 < tasks.length; j2++) {
      const a = tasks[i];
      const b2 = tasks[j2];
      if (!overlap(a.ownedPaths, b2.ownedPaths)) continue;
      if (ancestors(b2.key).has(a.key) || ancestors(a.key).has(b2.key)) continue;
      b2.dependsOn.push(a.key); // serialize: never edit the same files in parallel
      notes.push(`${a.key} and ${b2.key} share files, so ${b2.key} will run after ${a.key}.`);
    }
  }
  const rationale = [String(raw?.rationale ?? '').slice(0, 2000), ...notes].filter(Boolean).join('\n');
  return { rationale, tasks, notes };
}
