import fs from 'node:fs';
import path from 'node:path';
import type { AgentAssignment, AgentRun, AgentTask, Block, EfficiencyMode, Provider, RunStatus, TaskStatus, UsageInfo } from '@shared/types';
import { EFFICIENCY_PROFILES, PROVIDER_LABEL } from '@shared/types';
import { db, j } from '../core/db';
import { newId, now, safeJson, HttpError, str, oneOf, safeToken, truncate, debounce, estimateTokens } from '../core/util';
import { dirs } from '../core/paths';
import { events } from '../core/events';
import { getSettings } from '../core/settings';
import { logger } from '../core/log';
import { listAccounts, resolveAccount, registerSessionCounter } from '../services/accounts';
import { getProject, recordChanges, changesBySource, revertChange, updateProject } from '../services/projects';
import { buildContextPack } from '../services/context';
import { BlockStream } from '../services/blocks';
import { makePermissionHandler } from '../services/policy';
import { systemPrompt } from '../services/prompts';
import { recordUsage } from '../services/usage';
import { activity } from '../services/activity';
import { forgetRequester } from '../services/approvals';
import { fileLocks, snapshot, diffSnapshots, matchOwned, type Snapshot } from '../services/files';
import { runTurn, complete } from '../providers';
import type { TurnResult } from '../providers/types';
import { findCli } from '../providers/resolve';
import { createBridgeSession, revokeBridgeSession } from '../roblox/sessions';
import { roblox, robloxAvailableFor } from '../roblox/manager';
import { parsePlan, type PlannedTask } from './plan';

const log = logger('agents');

interface ActiveTask {
  abort: AbortController;
  accountId: string;
  runId: string;
}
const activeTasks = new Map<string, ActiveTask>();
const briefs = new Map<string, string>();
const scheduling = new Set<string>();

registerSessionCounter(() => {
  const m = new Map<string, number>();
  for (const t of activeTasks.values()) m.set(t.accountId, (m.get(t.accountId) ?? 0) + 1);
  return m;
});

export function activeAgentCount() {
  return activeTasks.size;
}

// ---------- persistence ----------

function toTask(r: any): AgentTask {
  return {
    id: r.id,
    runId: r.run_id,
    key: r.key,
    title: r.title,
    description: r.description,
    status: r.status,
    agentName: r.agent_name,
    assignment: safeJson(r.assignment, { provider: 'claude', accountId: null, model: '', effort: '' }),
    dependsOn: safeJson(r.depends_on, []),
    ownedPaths: safeJson(r.owned_paths, []),
    filesTouched: safeJson(r.files_touched, []),
    toolOps: r.tool_ops,
    summary: r.summary,
    error: r.error,
    attempts: r.attempts,
    blocks: safeJson<Block[]>(r.blocks, []),
    usage: safeJson<UsageInfo | null>(r.usage, null),
    createdAt: r.created_at,
    startedAt: r.started_at,
    finishedAt: r.finished_at,
    review: safeJson(r.review, null),
    currentActivity: liveActivity.get(r.id) ?? null,
  };
}
const liveActivity = new Map<string, string | null>();

function toRun(r: any, withBlocks = false): AgentRun {
  const tasks = db()
    .all<any>('SELECT * FROM tasks WHERE run_id = ? ORDER BY key', r.id)
    .map(toTask)
    .map((t) => (withBlocks ? t : { ...t, blocks: [] }));
  return {
    id: r.id,
    projectId: r.project_id,
    prompt: r.prompt,
    status: r.status,
    strategy: r.strategy,
    efficiency: r.efficiency,
    coordinator: safeJson(r.coordinator, { provider: 'claude', accountId: null, model: '', effort: '' }),
    rationale: r.rationale,
    report: r.report,
    error: r.error,
    createdAt: r.created_at,
    startedAt: r.started_at,
    finishedAt: r.finished_at,
    tasks: tasks.sort((a, b) => Number(a.key.replace(/\D/g, '')) - Number(b.key.replace(/\D/g, ''))),
    autoApprove: safeJson(r.auto_approve, { edits: true, commands: false, studioWrites: false }),
  };
}

export function listRuns(projectId?: string | null, limit = 50): AgentRun[] {
  const rows = projectId
    ? db().all<any>('SELECT * FROM runs WHERE project_id = ? ORDER BY created_at DESC LIMIT ?', projectId, limit)
    : db().all<any>('SELECT * FROM runs ORDER BY created_at DESC LIMIT ?', limit);
  return rows.map((r) => toRun(r));
}

export function getRun(id: string, withBlocks = false): AgentRun {
  const r = db().get<any>('SELECT * FROM runs WHERE id = ?', id);
  if (!r) throw new HttpError(404, 'Run not found');
  return toRun(r, withBlocks);
}

export function getTask(id: string): AgentTask {
  const r = db().get<any>('SELECT * FROM tasks WHERE id = ?', id);
  if (!r) throw new HttpError(404, 'Task not found');
  return toTask(r);
}

function emitRun(id: string) {
  try {
    events.emit('run.updated', getRun(id));
  } catch {
    /* deleted */
  }
}

function setRun(id: string, patch: Record<string, any>) {
  db().update('runs', id, patch);
  emitRun(id);
}

function setTask(id: string, patch: Record<string, any>) {
  db().update('tasks', id, patch);
  const t = getTask(id);
  events.emit('task.updated', { ...t, blocks: undefined });
}

// ---------- agent assignment ----------

function availableProviders(): Provider[] {
  const out: Provider[] = [];
  for (const p of ['claude', 'codex'] as Provider[]) {
    if (listAccounts().some((a) => a.provider === p && a.enabled && a.status !== 'signed_out' && a.status !== 'cli_missing') && findCli(p)) out.push(p);
  }
  return out;
}

function defaultAssignment(provider: Provider, accountId: string | null, overrides?: Partial<Record<Provider, { model?: string; effort?: string }>>): AgentAssignment {
  const s = getSettings().providers;
  return {
    provider,
    accountId,
    model: overrides?.[provider]?.model ?? s.defaultModels[provider] ?? '',
    effort: overrides?.[provider]?.effort ?? s.defaultEfforts[provider] ?? '',
  };
}

function assignAgents(tasks: PlannedTask[], overrides?: Partial<Record<Provider, { model?: string; effort?: string }>>): { assignment: AgentAssignment; agentName: string }[] {
  const routing = getSettings().agents.routing;
  let avail = availableProviders();
  if (routing === 'claude-only') avail = avail.filter((p) => p === 'claude');
  if (routing === 'codex-only') avail = avail.filter((p) => p === 'codex');
  if (!avail.length) avail = [getSettings().providers.defaultProvider];
  const load: Record<Provider, number> = { claude: 0, codex: 0 };
  const accountLoad = new Map<string, number>();
  const counters: Record<Provider, number> = { claude: 0, codex: 0 };
  return tasks.map((t) => {
    let provider: Provider;
    if (t.provider !== 'any' && avail.includes(t.provider)) provider = t.provider;
    else if (routing === 'prefer-claude' && avail.includes('claude')) provider = 'claude';
    else if (routing === 'prefer-codex' && avail.includes('codex')) provider = 'codex';
    else provider = avail.length === 1 ? avail[0] : load.claude <= load.codex ? (avail.includes('claude') ? 'claude' : avail[0]) : avail.includes('codex') ? 'codex' : avail[0];
    load[provider]++;
    const accounts = listAccounts().filter((a) => a.provider === provider && a.enabled && a.status !== 'signed_out');
    const acc = accounts.sort((a, b) => (accountLoad.get(a.id) ?? 0) - (accountLoad.get(b.id) ?? 0) || Number(b.isDefault) - Number(a.isDefault))[0] ?? resolveAccount(provider);
    if (acc) accountLoad.set(acc.id, (accountLoad.get(acc.id) ?? 0) + 1);
    counters[provider]++;
    return { assignment: defaultAssignment(provider, acc?.id ?? null, overrides), agentName: `${provider === 'claude' ? 'Claude' : 'Codex'} Agent ${counters[provider]}` };
  });
}

function parseAssignment(v: any, fallbackProvider: Provider): AgentAssignment {
  const provider = oneOf(v?.provider ?? fallbackProvider, ['claude', 'codex'] as const, 'provider');
  const acc = resolveAccount(provider, v?.accountId ?? null);
  return { provider, accountId: acc?.id ?? null, model: safeToken(v?.model ?? getSettings().providers.defaultModels[provider] ?? '', 'model', true), effort: safeToken(v?.effort ?? '', 'effort', true) };
}

// ---------- run lifecycle ----------

export function createRun(body: any): AgentRun {
  const prompt = str(body?.prompt, 'Request', { min: 1, max: 50_000 });
  const project = body?.projectId ? getProject(body.projectId) : null;
  if (body?.projectId && !project) throw new HttpError(404, 'Project not found');
  const s = getSettings();
  const efficiency = oneOf(body?.efficiency ?? s.context.mode, ['economy', 'balanced', 'performance', 'max'] as const, 'efficiency');
  const strategy = oneOf(body?.strategy ?? 'auto', ['auto', 'manual'] as const, 'strategy');
  const coordinator = parseAssignment(body?.coordinator, s.providers.defaultProvider);
  const autoApprove = { edits: body?.autoApprove?.edits ?? true, commands: !!body?.autoApprove?.commands, studioWrites: !!body?.autoApprove?.studioWrites };
  const id = newId('run');
  db().upsert('runs', {
    id, project_id: project?.id ?? null, prompt, status: strategy === 'auto' ? 'planning' : 'ready', strategy, efficiency, coordinator: j(coordinator),
    rationale: null, report: null, error: null, auto_approve: j(autoApprove), created_at: now(), started_at: null, finished_at: null,
  });
  if (strategy === 'manual') {
    const list: any[] = Array.isArray(body?.tasks) && body.tasks.length ? body.tasks : [{ title: truncate(prompt.split('\n')[0], 80), description: prompt }];
    list.slice(0, 12).forEach((t, i) => insertTask(id, `t${i + 1}`, t, parseAssignment(t.assignment ?? coordinator, coordinator.provider)));
    setRun(id, { rationale: 'Manual plan.' });
  }
  activity('agents', `New agent run${project ? ` in “${project.name}”` : ''}`, truncate(prompt, 200), id);
  emitRun(id);
  if (strategy === 'auto') void plan(id, !!body?.autoStart, body?.agentDefaults);
  else if (body?.autoStart) startRun(id);
  return getRun(id);
}

function insertTask(runId: string, key: string, t: any, assignment: AgentAssignment, agentName?: string, deps: string[] = []) {
  const counter = db().get<{ n: number }>("SELECT COUNT(*) AS n FROM tasks WHERE run_id = ? AND json_extract(assignment, '$.provider') = ?", runId, assignment.provider)?.n ?? 0;
  db().upsert('tasks', {
    id: newId('task'), run_id: runId, key, title: truncate(str(t.title ?? key, 'title', { max: 300 }) || key, 200),
    description: str(t.description ?? '', 'description', { max: 30_000, optional: true }), status: 'pending',
    agent_name: agentName ?? `${assignment.provider === 'claude' ? 'Claude' : 'Codex'} Agent ${counter + 1}`, assignment: j(assignment),
    depends_on: j(Array.isArray(t.dependsOn) ? t.dependsOn.map(String) : deps), owned_paths: j(Array.isArray(t.ownedPaths) ? t.ownedPaths.map(String).slice(0, 40) : []),
    files_touched: '[]', tool_ops: 0, summary: null, error: null, attempts: 0, blocks: '[]', usage: null, review: null, provider_ref: null,
    created_at: now(), started_at: null, finished_at: null,
  });
}

function runCwd(runId: string, projectFolder: string | null | undefined) {
  if (projectFolder && fs.existsSync(projectFolder)) return projectFolder;
  const d = path.join(dirs.workspaces, runId);
  fs.mkdirSync(d, { recursive: true });
  return d;
}

function projectBrief(runId: string, project: ReturnType<typeof getProject>, prompt: string, mode: EfficiencyMode): string {
  const cached = briefs.get(runId);
  if (cached !== undefined) return cached;
  if (!project) {
    briefs.set(runId, '');
    return '';
  }
  const pack = buildContextPack({ project, query: prompt, mode, includeTree: true, includeMemory: true, budgetTokens: Math.min(EFFICIENCY_PROFILES[mode].contextBudget, 9000) });
  const text = pack?.text ?? '';
  briefs.set(runId, text);
  return text;
}

async function plan(runId: string, autoStart: boolean, agentDefaults?: any) {
  const run = getRun(runId);
  const project = getProject(run.projectId);
  const profile = EFFICIENCY_PROFILES[run.efficiency];
  const avail = availableProviders();
  const accounts = listAccounts().filter((a) => a.enabled);
  const brief = projectBrief(runId, project, run.prompt, run.efficiency);
  const agentsText = avail.length
    ? avail.map((p) => `${p}: ${accounts.filter((a) => a.provider === p).length} account(s) available`).join('\n')
    : 'Only one provider is available.';
  const planningPrompt = [
    'You are the BLOXADE coordinator. Split the user request into the smallest sensible set of subtasks for coding agents that work at the same time on the same project.',
    'Rules:',
    `- Use as FEW tasks as possible (maximum ${profile.maxTasks}). If one agent can do it well, return exactly ONE task. Never split just to use more agents.`,
    '- Every task owns a distinct set of paths ("ownedPaths": project-relative files, folders ending with "/", or globs; for Roblox Studio scripts use "studio:<dot.path>", e.g. "studio:ServerScriptService.ShopServer"). Two tasks that can run in parallel must never own the same path.',
    '- Use "dependsOn" (list of task keys) when a task needs another task’s result — e.g. tests or integration checks after implementation.',
    '- "provider" is "claude", "codex" or "any".',
    '- Each "description" must be a complete, self-contained instruction for an agent that has NOT seen the user request: goal, exact location, and the interfaces/names it must agree on with sibling tasks.',
    '- Do not inspect files yourself; the project context below is all you need for planning.',
    'Respond with ONLY a JSON object, no prose, in this shape:',
    '{"rationale":"one or two sentences","tasks":[{"key":"t1","title":"short title","description":"…","provider":"any","ownedPaths":["src/shop/"],"dependsOn":[]}]}',
    `<available_agents>\n${agentsText}\n</available_agents>`,
    brief ? brief : '<project_context>No project folder linked.</project_context>',
    `<user_request>\n${run.prompt}\n</user_request>`,
  ].join('\n\n');

  const acc = resolveAccount(run.coordinator.provider, run.coordinator.accountId);
  let planned: { rationale: string; tasks: PlannedTask[] } | null = null;
  let note = '';
  if (!acc) {
    note = `No ${PROVIDER_LABEL[run.coordinator.provider]} account available for the coordinator, so the request was planned as a single task.`;
  } else {
    const t0 = now();
    const res = await complete(run.coordinator.provider, {
      account: acc,
      model: run.coordinator.model,
      effort: run.coordinator.effort || 'low',
      cwd: runCwd(runId, null),
      prompt: planningPrompt,
      signal: new AbortController().signal,
      timeoutMs: 8 * 60_000,
      label: 'Coordinator (planning)',
    });
    recordUsage({ provider: run.coordinator.provider, accountId: acc.id, model: res.model ?? run.coordinator.model, kind: 'coordinator', refId: runId, usage: res.usage, estimatedTokens: estimateTokens(planningPrompt) + estimateTokens(res.text), contextSaved: 0, durationMs: now() - t0, ok: res.ok });
    if (res.ok) {
      try {
        planned = parsePlan(res.text, profile.maxTasks);
      } catch (e) {
        note = `The coordinator’s plan could not be parsed (${(e as Error).message}); planned as a single task.`;
      }
    } else note = `Coordinator failed: ${res.error}. Planned as a single task.`;
  }
  if (!planned) planned = { rationale: note, tasks: [{ key: 't1', title: truncate(run.prompt.split('\n')[0], 80), description: run.prompt, provider: 'any', ownedPaths: [], dependsOn: [] }] };
  else if (note) planned.rationale = `${planned.rationale}\n${note}`;

  try {
    getRun(runId);
  } catch {
    return; // deleted while planning
  }
  const assigned = assignAgents(planned.tasks, agentDefaults);
  db().tx(() => {
    db().run('DELETE FROM tasks WHERE run_id = ?', runId);
    planned!.tasks.forEach((t, i) => insertTask(runId, t.key, t, assigned[i].assignment, assigned[i].agentName, t.dependsOn));
  });
  setRun(runId, { status: 'ready', rationale: planned.rationale });
  activity('agents', `Plan ready: ${planned.tasks.length} task${planned.tasks.length === 1 ? '' : 's'}`, planned.rationale, runId);
  if (autoStart) startRun(runId);
}

export function startRun(id: string) {
  const run = getRun(id);
  if (!['ready', 'paused', 'failed', 'completed'].includes(run.status)) throw new HttpError(409, `Run is ${run.status}`);
  if (!run.tasks.length) throw new HttpError(400, 'This run has no tasks');
  setRun(id, { status: 'running', started_at: run.startedAt ?? now(), finished_at: null, error: null });
  if (run.autoApprove.studioWrites) roblox.setAutoApprove(id, true);
  schedule(id);
}

export function pauseRun(id: string) {
  const run = getRun(id);
  if (run.status !== 'running') throw new HttpError(409, 'Only running runs can be paused');
  setRun(id, { status: 'paused' });
  activity('agents', 'Run paused', 'Working agents finish their current task; no new tasks start.', id);
}

export function cancelRun(id: string) {
  const run = getRun(id);
  for (const t of run.tasks) {
    if (t.status === 'working') activeTasks.get(t.id)?.abort.abort();
    if (t.status === 'pending' || t.status === 'blocked') setTask(t.id, { status: 'cancelled', finished_at: now() });
  }
  setRun(id, { status: 'cancelled', finished_at: now() });
  roblox.releaseCaller(id);
}

export function deleteRun(id: string) {
  const run = getRun(id);
  if (run.tasks.some((t) => t.status === 'working')) throw new HttpError(409, 'Stop the run before deleting it');
  db().run('DELETE FROM tasks WHERE run_id = ?', id);
  db().run('DELETE FROM runs WHERE id = ?', id);
  briefs.delete(id);
  events.emit('run.deleted', { id });
}

export function updateTask(taskId: string, body: any): AgentTask {
  const t = getTask(taskId);
  if (t.status === 'working') throw new HttpError(409, 'This task is running');
  const patch: Record<string, any> = {};
  if (body.title !== undefined) patch.title = str(body.title, 'title', { min: 1, max: 200 });
  if (body.description !== undefined) patch.description = str(body.description, 'description', { max: 30_000, optional: true });
  if (body.assignment !== undefined) patch.assignment = j(parseAssignment({ ...t.assignment, ...body.assignment }, t.assignment.provider));
  if (body.ownedPaths !== undefined) patch.owned_paths = j((body.ownedPaths as any[]).map(String).filter(Boolean).slice(0, 40));
  if (body.dependsOn !== undefined) patch.depends_on = j((body.dependsOn as any[]).map(String));
  if (body.agentName !== undefined) patch.agent_name = str(body.agentName, 'agent name', { min: 1, max: 60 });
  setTask(taskId, patch);
  emitRun(t.runId);
  return getTask(taskId);
}

export function addTask(runId: string, body: any): AgentRun {
  const run = getRun(runId);
  const key = `t${run.tasks.reduce((m, t) => Math.max(m, Number(t.key.replace(/\D/g, '')) || 0), 0) + 1}`;
  insertTask(runId, key, body, parseAssignment(body?.assignment ?? run.coordinator, run.coordinator.provider));
  emitRun(runId);
  if (run.status === 'running') schedule(runId);
  return getRun(runId);
}

export function removeTask(taskId: string) {
  const t = getTask(taskId);
  if (t.status === 'working') throw new HttpError(409, 'Stop the task first');
  db().run('DELETE FROM tasks WHERE id = ?', taskId);
  emitRun(t.runId);
}

export function stopTask(taskId: string) {
  const a = activeTasks.get(taskId);
  if (!a) throw new HttpError(409, 'Task is not running');
  a.abort.abort();
}

export function retryTask(taskId: string) {
  const t = getTask(taskId);
  if (!['failed', 'cancelled', 'blocked', 'completed'].includes(t.status)) throw new HttpError(409, `Task is ${t.status}`);
  setTask(taskId, { status: 'pending', finished_at: null, review: null });
  // unblock dependents that were blocked by this task
  const run = getRun(t.runId);
  for (const other of run.tasks) if (other.status === 'blocked' && other.dependsOn.includes(t.key)) setTask(other.id, { status: 'pending' });
  if (run.status !== 'running') setRun(run.id, { status: 'running', finished_at: null });
  schedule(t.runId);
}

export function acceptTask(taskId: string) {
  const t = getTask(taskId);
  if (t.status !== 'reviewing') throw new HttpError(409, 'Task is not waiting for review');
  setTask(taskId, { status: 'completed', review: null });
  activity('agents', `Accepted changes from ${t.agentName}`, t.title, t.runId);
  schedule(t.runId);
}

export function revertTask(taskId: string) {
  const t = getTask(taskId);
  if (t.status === 'working') throw new HttpError(409, 'Stop the task first');
  const changes = changesBySource(taskId).filter((c) => !c.reverted).reverse();
  for (const c of changes) revertChange(c.id);
  setTask(taskId, { status: 'cancelled', error: `Changes reverted by user (${changes.length} file${changes.length === 1 ? '' : 's'})`, review: null, finished_at: now() });
  activity('agents', `Reverted ${changes.length} change(s) from ${t.agentName}`, t.title, t.runId);
  schedule(t.runId);
}

// ---------- scheduling ----------

function overlaps(a: string[], b: string[]): boolean {
  if (!a.length || !b.length) return false;
  return a.some((pa) => b.some((pb) => matchOwned([pa], pb.replace(/\*.*$/, '')) || matchOwned([pb], pa.replace(/\*.*$/, ''))));
}

function schedule(runId: string) {
  if (scheduling.has(runId)) return;
  scheduling.add(runId);
  try {
    const run = getRun(runId);
    const profile = EFFICIENCY_PROFILES[run.efficiency];
    const byKey = new Map(run.tasks.map((t) => [t.key, t]));
    // propagate failures to dependents
    for (const t of run.tasks) {
      if (t.status !== 'pending') continue;
      const bad = t.dependsOn.map((k) => byKey.get(k)).find((d) => d && ['failed', 'cancelled', 'blocked'].includes(d.status));
      if (bad) setTask(t.id, { status: 'blocked', error: `Waiting on ${bad.key} (${bad.title}), which ${bad.status === 'blocked' ? 'is blocked' : bad.status}` });
    }
    const fresh = getRun(runId);
    const working = fresh.tasks.filter((t) => t.status === 'working');
    const pending = fresh.tasks.filter((t) => t.status === 'pending');
    const reviewing = fresh.tasks.filter((t) => t.status === 'reviewing');
    if (fresh.status === 'running') {
      const limit = getSettings().agents.maxConcurrent ?? profile.maxConcurrentAgents;
      let slots = limit - working.length;
      const runningPaths = working.map((t) => t.ownedPaths);
      for (const t of pending) {
        if (slots <= 0) break;
        const depsDone = t.dependsOn.every((k) => byKey.get(k)?.status === 'completed' || !byKey.has(k));
        if (!depsDone) continue;
        if (runningPaths.some((p) => overlaps(p, t.ownedPaths))) continue; // never run two tasks on the same files at once
        runningPaths.push(t.ownedPaths);
        slots--;
        void runTask(t.id);
      }
    }
    const after = getRun(runId);
    const stillActive = after.tasks.some((t) => t.status === 'working' || t.status === 'pending');
    if (!stillActive && !reviewing.length && after.status === 'running') void finalize(runId);
  } finally {
    scheduling.delete(runId);
  }
}

function taskPrompt(run: AgentRun, task: AgentTask, brief: string): string {
  const deps = task.dependsOn
    .map((k) => run.tasks.find((t) => t.key === k))
    .filter(Boolean)
    .map((d) => `### ${d!.key} — ${d!.title} (${d!.agentName})\nFiles changed: ${d!.filesTouched.join(', ') || 'none'}\n${truncate(d!.summary ?? '', 2500)}`);
  const siblings = run.tasks.filter((t) => t.id !== task.id).map((t) => `- ${t.key} ${t.title} — ${t.agentName} — owns: ${t.ownedPaths.join(', ') || '(unspecified)'}`);
  return [
    `You are ${task.agentName}, one of ${run.tasks.length} BLOXADE agent${run.tasks.length === 1 ? '' : 's'} working on this request:`,
    `<overall_goal>\n${run.prompt}\n</overall_goal>`,
    `<your_task key="${task.key}">\n${task.title}\n\n${task.description}\n</your_task>`,
    task.ownedPaths.length ? `You own these paths — change files only inside them:\n${task.ownedPaths.map((p) => `- ${p}`).join('\n')}` : 'Keep your changes as small and focused as possible.',
    siblings.length ? `Other agents (do not edit their paths):\n${siblings.join('\n')}` : '',
    deps.length ? `<completed_dependencies note="Results you can build on — do not redo this work">\n${deps.join('\n\n')}\n</completed_dependencies>` : '',
    task.attempts > 0 && task.error ? `Previous attempt failed with: ${truncate(task.error, 800)}\nAvoid repeating the same mistake.` : '',
    brief,
    'When finished, reply with:\n## Summary\n(what you did, files/scripts changed)\n## Notes for other agents\n(changes you need outside your paths, or "None")',
  ]
    .filter(Boolean)
    .join('\n\n');
}

async function runTask(taskId: string) {
  let task = getTask(taskId);
  const run = getRun(task.runId);
  const project = getProject(run.projectId);
  const s = getSettings();
  const account = resolveAccount(task.assignment.provider, task.assignment.accountId);
  if (!account) {
    setTask(taskId, { status: 'failed', error: `No ${PROVIDER_LABEL[task.assignment.provider]} account available`, finished_at: now() });
    schedule(run.id);
    return;
  }
  const abort = new AbortController();
  activeTasks.set(taskId, { abort, accountId: account.id, runId: run.id });
  setTask(taskId, { status: 'working', started_at: now(), finished_at: null, attempts: task.attempts + 1, blocks: '[]', review: null });
  task = getTask(taskId);
  activity('agents', `${task.agentName} started “${task.title}”`, `${PROVIDER_LABEL[account.provider]} · ${account.name}`, run.id);

  const cwd = runCwd(run.id, project?.folderPath);
  const label = `${task.agentName} (${task.key})`;
  const robloxOn = !!project?.robloxEnabled && robloxAvailableFor();
  const bridgeToken = robloxOn ? createBridgeSession({ kind: 'task', id: taskId, label, runId: run.id }) : null;
  if (robloxOn && run.autoApprove.studioWrites) roblox.setAutoApprove(taskId, true);
  let before: Snapshot | null = null;
  if (project?.folderPath && cwd === project.folderPath) {
    try {
      before = snapshot(project.folderPath).snap;
    } catch (e) {
      log.warn('snapshot failed', (e as Error).message);
    }
  }
  const brief = projectBrief(run.id, project, run.prompt, run.efficiency);
  const prompt = taskPrompt(run, task, brief);

  const blocks: Block[] = [];
  const pushMeta = debounce(() => {
    db().update('tasks', taskId, { blocks: j(blocks), tool_ops: stream.toolOps, files_touched: j([...touchedRel()]) });
    liveActivity.set(taskId, stream.currentActivity);
    events.emit('task.updated', { ...getTask(taskId), blocks: undefined });
  }, 800);
  const stream = new BlockStream(blocks, {
    block: (index, block) => {
      events.emit('task.block', { taskId, index, block });
      pushMeta();
    },
    delta: (index, kind, text) => {
      events.emit('task.delta', { taskId, index, kind, text });
      pushMeta();
    },
  });
  const touchedAbs = new Set<string>();
  const touchedRel = () => {
    const out = new Set<string>();
    for (const p of [...touchedAbs, ...stream.filesTouched]) out.add(project?.folderPath ? path.relative(project.folderPath, path.resolve(cwd, p)).split(path.sep).join('/') : p);
    return out;
  };

  const result = await runTurn(task.assignment.provider, {
    account,
    model: task.assignment.model,
    effort: task.assignment.effort,
    mode: 'cowork',
    cwd,
    systemAppend: systemPrompt({ mode: 'cowork', project, roblox: robloxOn, cwd, role: `You are ${task.agentName}, a BLOXADE agent. Work only on your assigned task and paths.` }),
    prompt,
    resume: null,
    forkFrom: null,
    bridgeToken,
    permissionMode: 'ask',
    onPermission: makePermissionHandler({
      kind: 'task',
      id: taskId,
      label,
      cwd,
      projectRoot: project?.folderPath ?? null,
      extraRoots: [cwd],
      task: { runId: run.id, ownedPaths: task.ownedPaths.filter((p) => !p.startsWith('studio:')), autoApprove: run.autoApprove },
      onEditAllowed: (abs) => abs.forEach((a) => touchedAbs.add(a)),
    }),
    onEvent: (e) => stream.apply(e),
    signal: abort.signal,
    timeoutMs: s.advanced.turnTimeoutMin * 60_000,
    label,
  }).catch((e): TurnResult => ({ ok: false, cancelled: false, text: '', ref: {}, usage: null, error: (e as Error).message, durationMs: 0 }));

  pushMeta.flush();
  activeTasks.delete(taskId);
  liveActivity.delete(taskId);
  revokeBridgeSession(bridgeToken);
  fileLocks.release(taskId);
  roblox.releaseCaller(taskId);
  forgetRequester(taskId);

  // Attribute file changes to this task
  let changedRel: string[] = [];
  let conflicts: string[] = [];
  if (before && project?.folderPath) {
    try {
      const after = snapshot(project.folderPath).snap;
      const all = diffSnapshots(before, after);
      const touched = touchedRel();
      const ownedFs = task.ownedPaths.filter((p) => !p.startsWith('studio:'));
      const otherWorking = getRun(run.id).tasks.filter((t) => t.status === 'working' && t.id !== taskId);
      const mine = all.filter((c) => touched.has(c.path) || (ownedFs.length && matchOwned(ownedFs, c.path) && !otherWorking.some((o) => matchOwned(o.ownedPaths, c.path))));
      if (mine.length) recordChanges(project.id, mine, 'task', taskId);
      changedRel = mine.map((c) => c.path);
      if (ownedFs.length) conflicts = changedRel.filter((p) => !matchOwned(ownedFs, p));
      const others = getRun(run.id).tasks.filter((t) => t.id !== taskId);
      for (const p of changedRel) if (others.some((o) => o.filesTouched.includes(p)) && !conflicts.includes(p)) conflicts.push(p);
    } catch (e) {
      log.warn('change attribution failed', (e as Error).message);
    }
  }

  const text = result.text || stream.text;
  const summaryMatch = text.match(/##\s*Summary\s*([\s\S]*)/i);
  const summary = truncate((summaryMatch ? summaryMatch[1] : text).trim(), 6000);
  const profile = EFFICIENCY_PROFILES[run.efficiency];
  let status: TaskStatus;
  let error: string | null = null;
  let review: AgentTask['review'] = null;
  if (result.cancelled) {
    status = 'cancelled';
    error = 'Stopped by user';
  } else if (!result.ok) {
    error = result.error ?? 'Agent failed';
    status = task.attempts <= profile.retries ? 'pending' : 'failed';
    if (status === 'pending') stream.notice('warning', `Attempt ${task.attempts} failed — retrying (${profile.label} mode allows ${profile.retries} retr${profile.retries === 1 ? 'y' : 'ies'}).`);
  } else if (conflicts.length || (s.agents.requireReview && changedRel.length)) {
    status = 'reviewing';
    review = { reason: conflicts.length ? 'Changed files outside its assignment or files another agent also changed' : 'Review required by your settings', conflicts };
  } else status = 'completed';

  db().update('tasks', taskId, {
    status, error, summary, review: j(review), files_touched: j(changedRel.length ? changedRel : [...touchedRel()]), blocks: j(blocks), tool_ops: stream.toolOps,
    usage: j(result.usage), provider_ref: j(result.ref), finished_at: status === 'pending' ? null : now(),
  });
  events.emit('task.updated', { ...getTask(taskId), blocks: undefined });
  emitRun(run.id);
  recordUsage({
    provider: task.assignment.provider, accountId: account.id, model: result.model ?? task.assignment.model, kind: 'task', refId: taskId, usage: result.usage,
    estimatedTokens: estimateTokens(prompt) + estimateTokens(text), contextSaved: 0, durationMs: result.durationMs, ok: result.ok,
  });
  activity('agents', `${task.agentName} ${status === 'completed' ? 'completed' : status === 'reviewing' ? 'needs review for' : status === 'pending' ? 'will retry' : status} “${task.title}”`, error ?? `${changedRel.length} file(s) changed`, run.id);
  schedule(run.id);
}

async function finalize(runId: string) {
  const run = getRun(runId);
  if (run.status !== 'running') return;
  const profile = EFFICIENCY_PROFILES[run.efficiency];
  const done = run.tasks.filter((t) => t.status === 'completed');
  const failed = run.tasks.filter((t) => t.status !== 'completed');
  const fmtDur = (t: AgentTask) => (t.startedAt && t.finishedAt ? `${Math.max(1, Math.round((t.finishedAt - t.startedAt) / 1000))}s` : '');
  const deterministic = [
    `## Result`,
    `${done.length} of ${run.tasks.length} task${run.tasks.length === 1 ? '' : 's'} completed.`,
    `## Tasks`,
    ...run.tasks.map((t) => `- ${t.status === 'completed' ? '✅' : t.status === 'failed' ? '❌' : t.status === 'cancelled' ? '⏹️' : '⚠️'} **${t.key} · ${t.title}** — ${t.agentName} (${PROVIDER_LABEL[t.assignment.provider]}) ${fmtDur(t)}${t.error ? `\n  - ${t.error}` : ''}${t.summary ? `\n  - ${truncate(t.summary.split('\n').filter(Boolean)[0] ?? '', 220)}` : ''}`),
    `## Files changed`,
    [...new Set(run.tasks.flatMap((t) => t.filesTouched))].map((f) => `- \`${f}\``).join('\n') || '- None in the project folder',
  ].join('\n');
  let report = deterministic;
  if (profile.verification !== 'none' && done.length) {
    const acc = resolveAccount(run.coordinator.provider, run.coordinator.accountId);
    if (acc) {
      const material = run.tasks
        .map((t) => `### ${t.key} ${t.title} — ${t.agentName} — ${t.status}\nFiles: ${t.filesTouched.join(', ') || 'none'}\n${truncate(t.summary ?? t.error ?? '', profile.verification === 'review' ? 3500 : 1500)}`)
        .join('\n\n');
      const reviewAsk =
        profile.verification === 'review'
          ? 'Check the summaries for integration problems between the tasks (mismatched names, missing wiring, unhandled requests in "Notes for other agents") and list concrete follow-ups.'
          : 'Keep it short.';
      const p = `You are the BLOXADE coordinator. Write ONE unified final report (Markdown) for the user about this multi-agent run. Start with "## Result" (2–4 sentences), then "## What changed", then "## Follow-ups" if any. ${reviewAsk} Do not invent work that is not in the summaries.\n\n<user_request>\n${run.prompt}\n</user_request>\n\n<task_results>\n${material}\n</task_results>`;
      const t0 = now();
      const res = await complete(run.coordinator.provider, { account: acc, model: run.coordinator.model, effort: run.coordinator.effort || 'low', cwd: runCwd(runId, null), prompt: p, signal: new AbortController().signal, timeoutMs: 6 * 60_000, label: 'Coordinator (report)' });
      recordUsage({ provider: run.coordinator.provider, accountId: acc.id, model: res.model ?? run.coordinator.model, kind: 'coordinator', refId: runId, usage: res.usage, estimatedTokens: estimateTokens(p) + estimateTokens(res.text), contextSaved: 0, durationMs: now() - t0, ok: res.ok });
      if (res.ok && res.text.trim()) report = `${res.text.trim()}\n\n---\n\n<details><summary>Task details</summary>\n\n${deterministic}\n\n</details>`;
    }
  }
  const status: RunStatus = failed.length ? 'failed' : 'completed';
  setRun(runId, { status, report, finished_at: now() });
  roblox.releaseCaller(runId);
  briefs.delete(runId);
  activity('agents', `Run ${status}`, `${done.length}/${run.tasks.length} tasks completed`, runId);
  if (getSettings().context.autoMemory && run.projectId && done.length) void updateMemoryFromRun(runId).catch((e) => log.warn('memory update failed', e.message));
}

async function updateMemoryFromRun(runId: string) {
  const run = getRun(runId);
  const project = getProject(run.projectId);
  if (!project || !run.report) return;
  const acc = resolveAccount(run.coordinator.provider, run.coordinator.accountId);
  if (!acc) return;
  const p = `Update this project memory with durable facts from the run report (architecture, names, conventions, decisions). Keep it under 350 words, bullet points, no fluff. Return ONLY the new memory text.\n\n<current_memory>\n${project.memory || '(empty)'}\n</current_memory>\n\n<run_report>\n${truncate(run.report, 6000)}\n</run_report>`;
  const res = await complete(run.coordinator.provider, { account: acc, model: run.coordinator.model, effort: 'low', cwd: runCwd(runId, null), prompt: p, signal: new AbortController().signal, timeoutMs: 4 * 60_000, label: 'Memory update' });
  recordUsage({ provider: run.coordinator.provider, accountId: acc.id, model: res.model ?? null, kind: 'memory', refId: runId, usage: res.usage, estimatedTokens: estimateTokens(p), contextSaved: 0, durationMs: res.durationMs, ok: res.ok });
  if (res.ok && res.text.trim()) updateProject(project.id, { memory: res.text.trim().slice(0, 20000) });
}

export function recoverRuns() {
  db().run("UPDATE tasks SET status = 'failed', error = 'Interrupted — BLOXADE was closed while this task was running', finished_at = ? WHERE status = 'working'", now());
  db().run("UPDATE runs SET status = 'paused' WHERE status = 'running'");
  db().run("UPDATE runs SET status = 'failed', error = 'Interrupted during planning' WHERE status = 'planning'");
}

export function stopAllTasks() {
  for (const t of activeTasks.values()) t.abort.abort();
}
