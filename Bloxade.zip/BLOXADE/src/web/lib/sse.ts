import { useApp } from '../store/app';

/** One EventSource for the whole app; reconnects automatically and re-bootstraps after a gap. */
export function connectEvents() {
  let es: EventSource | null = null;
  let wasOffline = false;
  const open = () => {
    es = new EventSource('/api/events');
    es.onopen = () => {
      useApp.setState({ connection: 'online' });
      if (wasOffline) {
        wasOffline = false;
        void useApp.getState().bootstrap();
        for (const id of Object.keys(useApp.getState().messages)) void useApp.getState().loadChat(id).catch(() => undefined);
      }
    };
    es.onmessage = (ev) => {
      try {
        const { type, data } = JSON.parse(ev.data);
        useApp.getState().apply(type, data);
      } catch {
        /* ignore malformed */
      }
    };
    es.onerror = () => {
      useApp.setState({ connection: 'offline' });
      wasOffline = true;
    };
  };
  open();
  return () => es?.close();
}
