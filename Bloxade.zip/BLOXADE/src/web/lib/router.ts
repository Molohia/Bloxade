import { useSyncExternalStore } from 'react';

/** Tiny hash router: #/chat/abc → { page: 'chat', parts: ['abc'] } */
export interface Route {
  page: string;
  parts: string[];
  query: URLSearchParams;
}

function parse(): Route {
  const raw = window.location.hash.replace(/^#\/?/, '');
  const [p, q] = raw.split('?');
  const parts = p.split('/').filter(Boolean).map(decodeURIComponent);
  return { page: parts[0] ?? 'chat', parts: parts.slice(1), query: new URLSearchParams(q ?? '') };
}

let current = parse();
const listeners = new Set<() => void>();
window.addEventListener('hashchange', () => {
  current = parse();
  listeners.forEach((l) => l());
});

export function useRoute(): Route {
  return useSyncExternalStore(
    (cb) => {
      listeners.add(cb);
      return () => listeners.delete(cb);
    },
    () => current,
  );
}

export function navigate(path: string) {
  const target = '#/' + path.replace(/^[#/]+/, '');
  if (window.location.hash === target) return;
  window.location.hash = target;
}

export const routes = {
  newChat: (projectId?: string) => (projectId ? `chat?project=${projectId}` : 'chat'),
  chat: (id: string) => `chat/${id}`,
  projects: () => 'projects',
  project: (id: string, tab = 'overview') => `projects/${id}/${tab}`,
  agents: () => 'agents',
  tasks: (runId?: string) => (runId ? `tasks/${runId}` : 'tasks'),
  activity: () => 'activity',
  accounts: (provider?: string) => (provider ? `accounts?provider=${provider}` : 'accounts'),
  roblox: () => 'roblox',
  usage: () => 'usage',
  settings: (tab = 'general') => `settings/${tab}`,
};
