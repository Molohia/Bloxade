import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function timeAgo(ts: number | null | undefined): string {
  if (!ts) return 'never';
  const s = Math.round((Date.now() - ts) / 1000);
  if (s < 45) return 'just now';
  if (s < 3600) return `${Math.round(s / 60)}m ago`;
  if (s < 86400) return `${Math.round(s / 3600)}h ago`;
  if (s < 7 * 86400) return `${Math.round(s / 86400)}d ago`;
  return new Date(ts).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}

export function duration(ms: number | null | undefined): string {
  if (ms == null || !isFinite(ms)) return '—';
  const s = Math.max(0, Math.round(ms / 1000));
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ${String(s % 60).padStart(2, '0')}s`;
  return `${Math.floor(m / 60)}h ${String(m % 60).padStart(2, '0')}m`;
}

export function fmtNum(n: number | null | undefined): string {
  if (n == null) return '—';
  if (n >= 1e9) return (n / 1e9).toFixed(1) + 'B';
  if (n >= 1e6) return (n / 1e6).toFixed(n >= 1e7 ? 0 : 1) + 'M';
  if (n >= 1e4) return (n / 1e3).toFixed(0) + 'k';
  if (n >= 1e3) return (n / 1e3).toFixed(1) + 'k';
  return String(Math.round(n));
}

export function fmtBytes(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 ** 2) return `${(n / 1024).toFixed(1)} KB`;
  if (n < 1024 ** 3) return `${(n / 1024 ** 2).toFixed(1)} MB`;
  return `${(n / 1024 ** 3).toFixed(2)} GB`;
}

export function resetIn(unixSeconds: number | null | undefined): string {
  if (!unixSeconds) return '';
  const ms = unixSeconds * 1000 - Date.now();
  if (ms <= 0) return 'resets now';
  const h = Math.floor(ms / 3600e3);
  const m = Math.round((ms % 3600e3) / 60e3);
  if (h >= 24) return `resets ${new Date(unixSeconds * 1000).toLocaleDateString(undefined, { weekday: 'short', hour: 'numeric', minute: '2-digit' })}`;
  return `resets in ${h ? `${h}h ` : ''}${m}m`;
}

/** Picks black or white text for an accent background. */
export function contrastText(hex: string): string {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex);
  if (!m) return '#ffffff';
  const v = parseInt(m[1], 16);
  const r = (v >> 16) & 255;
  const g = (v >> 8) & 255;
  const b = v & 255;
  const lum = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
  return lum > 0.62 ? '#111113' : '#ffffff';
}

export function groupByDate<T extends { updatedAt: number }>(items: T[]): [string, T[]][] {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const t = today.getTime();
  const groups: Record<string, T[]> = {};
  const order = ['Today', 'Yesterday', 'Previous 7 days', 'Previous 30 days', 'Older'];
  for (const it of items) {
    const d = it.updatedAt;
    const key = d >= t ? 'Today' : d >= t - 86400e3 ? 'Yesterday' : d >= t - 7 * 86400e3 ? 'Previous 7 days' : d >= t - 30 * 86400e3 ? 'Previous 30 days' : 'Older';
    (groups[key] ??= []).push(it);
  }
  return order.filter((k) => groups[k]?.length).map((k) => [k, groups[k]]);
}

export const isMac = typeof navigator !== 'undefined' && /Mac/i.test(navigator.platform);
export const modKey = isMac ? '⌘' : 'Ctrl';
