import type { Settings, ThemeName } from '@shared/types';
import { contrastText } from './utils';

export const THEMES: { id: ThemeName; label: string; swatch: [string, string, string] }[] = [
  { id: 'dark', label: 'Dark', swatch: ['#111113', '#1d1d21', '#ececee'] },
  { id: 'light', label: 'Light', swatch: ['#ffffff', '#f2f2f4', '#18181b'] },
  { id: 'midnight', label: 'Midnight', swatch: ['#0b1020', '#162040', '#e6e9f6'] },
  { id: 'oled', label: 'OLED Black', swatch: ['#000000', '#121212', '#f2f2f2'] },
  { id: 'slate', label: 'Slate', swatch: ['#1b1f27', '#292f3a', '#e6e9ef'] },
];

export const ACCENTS = ['#7C7FFF', '#4FA8E8', '#3FB98A', '#E0B341', '#E58A5B', '#EF6461', '#D9608C', '#A678E8'];

/** Applies appearance settings instantly (CSS variables + data attributes). */
export function applyAppearance(a: Settings['appearance']) {
  const root = document.documentElement;
  root.dataset.theme = a.theme;
  root.dataset.mode = a.theme === 'light' ? 'light' : 'dark';
  root.dataset.density = a.density;
  root.dataset.reduceMotion = String(a.reduceMotion);
  root.style.setProperty('--accent', a.accent);
  root.style.setProperty('--accent-fg', contrastText(a.accent));
  root.style.setProperty('--chat-font', `${a.fontSize}px`);
  try {
    localStorage.setItem('bx-theme', JSON.stringify({ theme: a.theme, accent: a.accent }));
  } catch {
    /* storage unavailable */
  }
}
