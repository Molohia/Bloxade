import { toast } from 'sonner';

export class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

async function request<T>(method: string, url: string, body?: unknown, opts: { silent?: boolean } = {}): Promise<T> {
  let res: Response;
  try {
    res = await fetch(url, {
      method,
      headers: body !== undefined || method !== 'GET' ? { 'Content-Type': 'application/json', 'X-Bloxade': '1' } : { 'X-Bloxade': '1' },
      body: body !== undefined ? JSON.stringify(body) : method !== 'GET' ? '{}' : undefined,
    });
  } catch {
    const err = new ApiError(0, 'Cannot reach the BLOXADE server. Is START_BLOXADE still running?');
    if (!opts.silent) toast.error(err.message);
    throw err;
  }
  const text = await res.text();
  let data: any = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = text;
  }
  if (!res.ok) {
    const err = new ApiError(res.status, (data && data.error) || `Request failed (${res.status})`);
    if (!opts.silent) toast.error(err.message);
    throw err;
  }
  return data as T;
}

export const api = {
  get: <T>(url: string, opts?: { silent?: boolean }) => request<T>('GET', url, undefined, opts),
  post: <T>(url: string, body?: unknown, opts?: { silent?: boolean }) => request<T>('POST', url, body ?? {}, opts),
  put: <T>(url: string, body?: unknown, opts?: { silent?: boolean }) => request<T>('PUT', url, body ?? {}, opts),
  patch: <T>(url: string, body?: unknown, opts?: { silent?: boolean }) => request<T>('PATCH', url, body ?? {}, opts),
  del: <T>(url: string, opts?: { silent?: boolean }) => request<T>('DELETE', url, undefined, opts),
};

export function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => {
      const s = String(r.result);
      resolve(s.slice(s.indexOf(',') + 1));
    };
    r.onerror = () => reject(r.error);
    r.readAsDataURL(file);
  });
}
