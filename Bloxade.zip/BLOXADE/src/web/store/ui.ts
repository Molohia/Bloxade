import { create } from 'zustand';

interface UiState {
  paletteOpen: boolean;
  newProjectOpen: boolean;
  shortcutsOpen: boolean;
  inspectTaskId: string | null;
  draft: Record<string, string>;
  openPalette(): void;
  closePalette(): void;
  openNewProject(): void;
  closeNewProject(): void;
  setShortcuts(v: boolean): void;
  inspect(taskId: string | null): void;
  setDraft(key: string, text: string): void;
}

export const useUi = create<UiState>((set) => ({
  paletteOpen: false,
  newProjectOpen: false,
  shortcutsOpen: false,
  inspectTaskId: null,
  draft: {},
  openPalette: () => set({ paletteOpen: true }),
  closePalette: () => set({ paletteOpen: false }),
  openNewProject: () => set({ newProjectOpen: true }),
  closeNewProject: () => set({ newProjectOpen: false }),
  setShortcuts: (v) => set({ shortcutsOpen: v }),
  inspect: (taskId) => set({ inspectTaskId: taskId }),
  setDraft: (key, text) => set((s) => ({ draft: { ...s.draft, [key]: text } })),
}));
