import { create } from 'zustand';
import type {
  Account, AgentRun, AgentTask, Approval, Block, Bootstrap, Chat, CliInfo, Message, ModelCatalog, Project, Provider, RobloxActivity, RobloxStatus, Settings,
} from '@shared/types';
import { api } from '../lib/api';

export interface ActivityItem {
  id: string;
  ts: number;
  kind: string;
  label: string;
  detail: string;
  refId: string | null;
}

interface AppState {
  ready: boolean;
  connection: 'connecting' | 'online' | 'offline';
  bootError: string | null;
  version: string;
  platform: string;
  dataDir: string;
  settings: Settings | null;
  accounts: Account[];
  projects: Project[];
  chats: Chat[];
  clis: Record<Provider, CliInfo> | null;
  roblox: RobloxStatus | null;
  robloxActivity: RobloxActivity[];
  approvals: Approval[];
  running: Set<string>;
  models: Partial<Record<Provider, ModelCatalog>>;
  messages: Record<string, Message[]>;
  runs: Record<string, AgentRun>;
  taskBlocks: Record<string, Block[]>;
  activity: ActivityItem[];
  usageTick: number;
  changesTick: number;

  bootstrap(): Promise<void>;
  loadModels(provider: Provider, refresh?: boolean): Promise<ModelCatalog | null>;
  loadChat(id: string): Promise<void>;
  saveSettings(patch: unknown): Promise<void>;
  upsertChat(c: Chat): void;
  upsertRun(r: AgentRun): void;
  apply(type: string, data: any): void;
}

function upsert<T extends { id: string }>(list: T[], item: T, prepend = true): T[] {
  const i = list.findIndex((x) => x.id === item.id);
  if (i < 0) return prepend ? [item, ...list] : [...list, item];
  const next = list.slice();
  next[i] = { ...list[i], ...item };
  return next;
}

function sortChats(list: Chat[]) {
  return list.slice().sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.updatedAt - a.updatedAt);
}

export const useApp = create<AppState>((set, get) => ({
  ready: false,
  connection: 'connecting',
  bootError: null,
  version: '',
  platform: '',
  dataDir: '',
  settings: null,
  accounts: [],
  projects: [],
  chats: [],
  clis: null,
  roblox: null,
  robloxActivity: [],
  approvals: [],
  running: new Set(),
  models: {},
  messages: {},
  runs: {},
  taskBlocks: {},
  activity: [],
  usageTick: 0,
  changesTick: 0,

  async bootstrap() {
    try {
      const b = await api.get<Bootstrap>('/api/bootstrap', { silent: true });
      set({
        ready: true,
        bootError: null,
        version: b.version,
        platform: b.platform,
        dataDir: b.dataDir,
        settings: b.settings,
        accounts: b.accounts,
        projects: b.projects,
        chats: sortChats(b.chats),
        clis: b.clis,
        roblox: b.roblox,
        approvals: b.approvals,
        running: new Set(b.runningChats),
      });
      void get().loadModels('claude');
      void get().loadModels('codex');
    } catch (e) {
      set({ bootError: (e as Error).message });
    }
  },

  async loadModels(provider, refresh = false) {
    try {
      const cat = refresh
        ? await api.post<ModelCatalog>('/api/models/refresh', { provider })
        : await api.get<ModelCatalog>(`/api/models?provider=${provider}`, { silent: true });
      set((s) => ({ models: { ...s.models, [provider]: cat } }));
      return cat;
    } catch {
      return null;
    }
  },

  async loadChat(id) {
    const r = await api.get<{ chat: Chat; messages: Message[] }>(`/api/chats/${id}`, { silent: true });
    set((s) => ({ messages: { ...s.messages, [id]: r.messages }, chats: sortChats(upsert(s.chats, r.chat)) }));
  },

  async saveSettings(patch) {
    const next = await api.put<Settings>('/api/settings', patch);
    set({ settings: next });
  },

  upsertChat(c) {
    set((s) => ({ chats: sortChats(upsert(s.chats, c)) }));
  },

  upsertRun(r) {
    set((s) => ({ runs: { ...s.runs, [r.id]: r } }));
  },

  apply(type, data) {
    const s = get();
    switch (type) {
      case 'settings.updated':
        set({ settings: data });
        return;
      case 'account.updated':
        set({ accounts: upsert(s.accounts, data, false) });
        return;
      case 'account.deleted':
        set({ accounts: s.accounts.filter((a) => a.id !== data.id) });
        return;
      case 'project.updated':
        set({ projects: upsert(s.projects, data) });
        return;
      case 'project.deleted':
        set({ projects: s.projects.filter((p) => p.id !== data.id), chats: s.chats.map((c) => (c.projectId === data.id ? { ...c, projectId: null } : c)) });
        return;
      case 'project.changes':
        set({ changesTick: s.changesTick + 1 });
        return;
      case 'chat.updated': {
        const running = new Set(s.running);
        if (data.running) running.add(data.id);
        else running.delete(data.id);
        set({ chats: sortChats(upsert(s.chats, data)), running });
        return;
      }
      case 'chat.deleted': {
        const { [data.id]: _, ...rest } = s.messages;
        set({ chats: s.chats.filter((c) => c.id !== data.id), messages: rest });
        return;
      }
      case 'chat.message':
      case 'chat.done': {
        const list = s.messages[data.chatId];
        if (!list) return;
        set({ messages: { ...s.messages, [data.chatId]: upsert(list, data, false) } });
        return;
      }
      case 'chat.block': {
        const list = s.messages[data.chatId];
        if (!list) return;
        set({
          messages: {
            ...s.messages,
            [data.chatId]: list.map((m) => {
              if (m.id !== data.messageId) return m;
              const blocks = m.blocks.slice();
              blocks[data.index] = data.block;
              return { ...m, blocks };
            }),
          },
        });
        return;
      }
      case 'chat.delta': {
        const list = s.messages[data.chatId];
        if (!list) return;
        set({
          messages: {
            ...s.messages,
            [data.chatId]: list.map((m) => {
              if (m.id !== data.messageId) return m;
              const blocks = m.blocks.slice();
              const b = blocks[data.index];
              if (b && (b.type === 'text' || b.type === 'thinking')) blocks[data.index] = { ...b, text: b.text + data.text };
              else blocks[data.index] = { type: data.kind, text: data.text } as Block;
              return { ...m, blocks };
            }),
          },
        });
        return;
      }
      case 'chat.reload':
        if (s.messages[data.chatId]) void s.loadChat(data.chatId);
        return;
      case 'approval.created':
        set({ approvals: upsert(s.approvals, data, false) });
        return;
      case 'approval.resolved':
        set({ approvals: s.approvals.filter((a) => a.id !== data.id) });
        return;
      case 'roblox.status':
        set({ roblox: data });
        return;
      case 'roblox.activity':
        set({ robloxActivity: [data, ...s.robloxActivity].slice(0, 200) });
        return;
      case 'run.updated':
        set({ runs: { ...s.runs, [data.id]: data } });
        return;
      case 'run.deleted': {
        const { [data.id]: _, ...rest } = s.runs;
        set({ runs: rest });
        return;
      }
      case 'task.updated': {
        const run = s.runs[data.runId];
        if (!run) return;
        const tasks = run.tasks.map((t: AgentTask) => (t.id === data.id ? { ...t, ...data, blocks: t.blocks } : t));
        set({ runs: { ...s.runs, [run.id]: { ...run, tasks } } });
        return;
      }
      case 'task.block': {
        const blocks = (s.taskBlocks[data.taskId] ?? []).slice();
        blocks[data.index] = data.block;
        set({ taskBlocks: { ...s.taskBlocks, [data.taskId]: blocks } });
        return;
      }
      case 'task.delta': {
        const blocks = (s.taskBlocks[data.taskId] ?? []).slice();
        const b = blocks[data.index];
        blocks[data.index] = b && (b.type === 'text' || b.type === 'thinking') ? { ...b, text: b.text + data.text } : ({ type: data.kind, text: data.text } as Block);
        set({ taskBlocks: { ...s.taskBlocks, [data.taskId]: blocks } });
        return;
      }
      case 'activity':
        set({ activity: [data, ...s.activity].slice(0, 300) });
        return;
      case 'providers.updated':
        set({ clis: data });
        return;
      case 'models.updated':
        set({ models: { ...s.models, [data.provider]: data } });
        return;
      case 'usage.recorded':
        set({ usageTick: s.usageTick + 1 });
        return;
      case 'history.cleared':
        void s.bootstrap();
        return;
      default:
        return;
    }
  },
}));

export function useAccount(id: string | null | undefined) {
  return useApp((s) => s.accounts.find((a) => a.id === id) ?? null);
}

export function useProject(id: string | null | undefined) {
  return useApp((s) => s.projects.find((p) => p.id === id) ?? null);
}
