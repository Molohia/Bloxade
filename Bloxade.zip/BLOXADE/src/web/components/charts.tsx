import { useState } from 'react';
import { cn } from '../lib/utils';

/** Stacked bar chart (Claude vs Codex) — dependency-free SVG. */
export function StackedBars({ data, labels, height = 180 }: { data: { claude: number; codex: number }[]; labels: string[]; height?: number }) {
  const [hover, setHover] = useState<number | null>(null);
  const max = Math.max(1, ...data.map((d) => d.claude + d.codex));
  const w = 100 / Math.max(1, data.length);
  return (
    <div className="relative">
      <div className="flex items-end gap-[3px]" style={{ height }}>
        {data.map((d, i) => {
          const total = d.claude + d.codex;
          return (
            <div key={i} className="relative flex h-full flex-1 cursor-default flex-col justify-end" onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)} style={{ maxWidth: `${w}%` }}>
              <div className={cn('flex w-full flex-col-reverse overflow-hidden rounded-[5px] transition-opacity', hover != null && hover !== i && 'opacity-50')} style={{ height: `${(total / max) * 100}%`, minHeight: total ? 3 : 0 }}>
                <div className="bg-claude" style={{ height: `${total ? (d.claude / total) * 100 : 0}%` }} />
                <div className="bg-codex" style={{ height: `${total ? (d.codex / total) * 100 : 0}%` }} />
              </div>
              {!total && <div className="h-[3px] w-full rounded-full bg-surface-3" />}
              {hover === i && (
                <div className="pointer-events-none absolute bottom-full left-1/2 z-10 mb-2 -translate-x-1/2 whitespace-nowrap rounded-lg border border-line-strong bg-surface px-2.5 py-1.5 text-[11.5px] shadow-pop">
                  <div className="font-medium text-fg">{labels[i]}</div>
                  <div className="text-fg-3">
                    Claude {d.claude} · Codex {d.codex}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
      <div className="mt-2 flex justify-between text-[10.5px] text-fg-3">
        <span>{labels[0]}</span>
        <span>{labels[Math.floor(labels.length / 2)]}</span>
        <span>{labels[labels.length - 1]}</span>
      </div>
    </div>
  );
}

export function HBar({ items }: { items: { label: React.ReactNode; value: number; color: string; detail?: string }[] }) {
  const max = Math.max(1, ...items.map((i) => i.value));
  return (
    <div className="space-y-3">
      {items.map((it, i) => (
        <div key={i}>
          <div className="mb-1 flex items-center justify-between text-[12.5px]">
            <span className="text-fg-2">{it.label}</span>
            <span className="tabular-nums text-fg-3">{it.detail ?? it.value}</span>
          </div>
          <div className="h-2 overflow-hidden rounded-full bg-surface-3">
            <div className="h-full rounded-full transition-[width] duration-500" style={{ width: `${(it.value / max) * 100}%`, background: it.color }} />
          </div>
        </div>
      ))}
    </div>
  );
}

export function Donut({ parts, size = 120 }: { parts: { value: number; color: string }[]; size?: number }) {
  const total = parts.reduce((n, p) => n + p.value, 0);
  const r = size / 2 - 10;
  const c = 2 * Math.PI * r;
  let offset = 0;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--surface-3)" strokeWidth={12} />
      {total > 0 &&
        parts.map((p, i) => {
          const len = (p.value / total) * c;
          const el = <circle key={i} cx={size / 2} cy={size / 2} r={r} fill="none" stroke={p.color} strokeWidth={12} strokeDasharray={`${len} ${c - len}`} strokeDashoffset={-offset} transform={`rotate(-90 ${size / 2} ${size / 2})`} strokeLinecap="butt" />;
          offset += len;
          return el;
        })}
    </svg>
  );
}
