import { Blocks, Box, Code, Cuboid, Flame, Gamepad2, Heart, Layers, Rocket, Sparkles, Star, Zap, type LucideIcon } from 'lucide-react';

export const PROJECT_ICONS: Record<string, LucideIcon> = {
  cuboid: Cuboid,
  gamepad: Gamepad2,
  rocket: Rocket,
  sparkles: Sparkles,
  box: Box,
  layers: Layers,
  zap: Zap,
  star: Star,
  blocks: Blocks,
  code: Code,
  flame: Flame,
  heart: Heart,
};

export const PROJECT_COLORS = ['#7C7FFF', '#4FA8E8', '#3FB98A', '#E0B341', '#E58A5B', '#EF6461', '#D9608C', '#A678E8', '#8DB34A', '#9AA3B5'];

export function ProjectIcon({ icon, color, size = 'md' }: { icon: string; color: string; size?: 'xs' | 'sm' | 'md' | 'lg' }) {
  const Icon = PROJECT_ICONS[icon] ?? Cuboid;
  const box = { xs: 'size-5 rounded-md', sm: 'size-6 rounded-md', md: 'size-9 rounded-xl', lg: 'size-12 rounded-2xl' }[size];
  const ic = { xs: 'size-3', sm: 'size-3.5', md: 'size-[18px]', lg: 'size-6' }[size];
  return (
    <span className={`inline-flex shrink-0 items-center justify-center ${box}`} style={{ background: `color-mix(in oklab, ${color} 18%, transparent)`, color }}>
      <Icon className={ic} strokeWidth={2.1} />
    </span>
  );
}
