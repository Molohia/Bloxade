import { forwardRef, type ButtonHTMLAttributes, type InputHTMLAttributes, type ReactNode, type TextareaHTMLAttributes } from 'react';
import { Switch as RSwitch, Tooltip as RTooltip } from 'radix-ui';
import { LoaderCircle } from 'lucide-react';
import { cn } from '../../lib/utils';

type Variant = 'primary' | 'secondary' | 'ghost' | 'outline' | 'danger' | 'subtle';
type Size = 'xs' | 'sm' | 'md' | 'lg';

const variants: Record<Variant, string> = {
  primary: 'bg-accent text-accent-fg hover:brightness-110 active:brightness-95 shadow-sm',
  secondary: 'bg-surface-2 text-fg hover:bg-surface-3 border border-line',
  ghost: 'text-fg-2 hover:text-fg hover:bg-surface-2',
  outline: 'border border-line-strong text-fg hover:bg-surface-2',
  danger: 'bg-danger/90 text-white hover:bg-danger',
  subtle: 'bg-accent-soft text-accent-text hover:bg-accent-soft/80',
};
const sizes: Record<Size, string> = {
  xs: 'h-7 px-2.5 text-xs gap-1.5 rounded-lg',
  sm: 'h-8 px-3 text-[13px] gap-1.5 rounded-lg',
  md: 'h-9 px-3.5 text-[13.5px] gap-2 rounded-[10px]',
  lg: 'h-11 px-5 text-sm gap-2 rounded-xl',
};

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  loading?: boolean;
  icon?: ReactNode;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button({ variant = 'secondary', size = 'md', loading, icon, className, children, disabled, ...rest }, ref) {
  return (
    <button
      ref={ref}
      disabled={disabled || loading}
      className={cn(
        'inline-flex items-center justify-center whitespace-nowrap font-medium transition-[background,color,filter,border] duration-150 select-none disabled:opacity-45 disabled:pointer-events-none cursor-pointer',
        variants[variant],
        sizes[size],
        className,
      )}
      {...rest}
    >
      {loading ? <LoaderCircle className="size-4 animate-spin" /> : icon}
      {children}
    </button>
  );
});

export const IconButton = forwardRef<HTMLButtonElement, ButtonHTMLAttributes<HTMLButtonElement> & { label: string; size?: 'xs' | 'sm' | 'md'; active?: boolean; tooltip?: boolean }>(
  function IconButton({ label, size = 'sm', active, className, children, tooltip = true, ...rest }, ref) {
    const btn = (
      <button
        ref={ref}
        aria-label={label}
        className={cn(
          'inline-flex items-center justify-center rounded-lg text-fg-2 hover:text-fg hover:bg-surface-2 transition-colors cursor-pointer disabled:opacity-40 disabled:pointer-events-none',
          size === 'xs' ? 'size-6' : size === 'sm' ? 'size-8' : 'size-9',
          active && 'bg-surface-2 text-fg',
          className,
        )}
        {...rest}
      >
        {children}
      </button>
    );
    return tooltip ? <Tooltip content={label}>{btn}</Tooltip> : btn;
  },
);

export function Tooltip({ content, children, side = 'top' }: { content: ReactNode; children: ReactNode; side?: 'top' | 'bottom' | 'left' | 'right' }) {
  if (!content) return <>{children}</>;
  return (
    <RTooltip.Root delayDuration={350}>
      <RTooltip.Trigger asChild>{children}</RTooltip.Trigger>
      <RTooltip.Portal>
        <RTooltip.Content side={side} sideOffset={6} className="z-[80] rounded-md bg-fg px-2 py-1 text-[11.5px] font-medium text-bg shadow-pop data-[state=delayed-open]:animate-in max-w-72">
          {content}
        </RTooltip.Content>
      </RTooltip.Portal>
    </RTooltip.Root>
  );
}

export const Input = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement> & { icon?: ReactNode }>(function Input({ className, icon, ...rest }, ref) {
  return (
    <div className={cn('relative flex items-center', className)}>
      {icon && <span className="pointer-events-none absolute left-3 text-fg-3">{icon}</span>}
      <input
        ref={ref}
        className={cn(
          'h-9 w-full rounded-[10px] border border-line bg-surface-2/60 px-3 text-[13.5px] text-fg placeholder:text-fg-3 outline-none transition-colors focus:border-accent/60 focus:bg-surface-2 focus:ring-3 focus:ring-accent-soft',
          icon && 'pl-9',
        )}
        {...rest}
      />
    </div>
  );
});

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaHTMLAttributes<HTMLTextAreaElement>>(function Textarea({ className, ...rest }, ref) {
  return (
    <textarea
      ref={ref}
      className={cn(
        'w-full rounded-[10px] border border-line bg-surface-2/60 px-3 py-2.5 text-[13.5px] leading-relaxed text-fg placeholder:text-fg-3 outline-none transition-colors focus:border-accent/60 focus:bg-surface-2 focus:ring-3 focus:ring-accent-soft resize-y',
        className,
      )}
      {...rest}
    />
  );
});

export function Badge({ children, tone = 'neutral', className, dot }: { children: ReactNode; tone?: 'neutral' | 'accent' | 'success' | 'warning' | 'danger' | 'info'; className?: string; dot?: boolean }) {
  const tones = {
    neutral: 'bg-surface-2 text-fg-2 border-line',
    accent: 'bg-accent-soft text-accent-text border-transparent',
    success: 'bg-success/12 text-success border-transparent',
    warning: 'bg-warning/12 text-warning border-transparent',
    danger: 'bg-danger/12 text-danger border-transparent',
    info: 'bg-info/12 text-info border-transparent',
  };
  return (
    <span className={cn('inline-flex h-[22px] items-center gap-1.5 rounded-md border px-2 text-[11.5px] font-medium whitespace-nowrap', tones[tone], className)}>
      {dot && <span className="size-1.5 rounded-full bg-current" />}
      {children}
    </span>
  );
}

export function Card({ className, children, ...rest }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={cn('rounded-2xl border border-line bg-surface', className)} {...rest}>
      {children}
    </div>
  );
}

export function Kbd({ children }: { children: ReactNode }) {
  return <kbd className="inline-flex h-5 min-w-5 items-center justify-center rounded-[5px] border border-line-strong bg-surface-2 px-1 font-sans text-[10.5px] font-medium text-fg-3">{children}</kbd>;
}

export function Spinner({ className }: { className?: string }) {
  return <LoaderCircle className={cn('size-4 animate-spin text-fg-3', className)} />;
}

export function Skeleton({ className }: { className?: string }) {
  return <div className={cn('skeleton rounded-lg', className)} />;
}

export function Switch({ checked, onChange, disabled, label }: { checked: boolean; onChange: (v: boolean) => void; disabled?: boolean; label?: string }) {
  return (
    <RSwitch.Root
      checked={checked}
      onCheckedChange={onChange}
      disabled={disabled}
      aria-label={label}
      className="relative h-[22px] w-[38px] shrink-0 cursor-pointer rounded-full bg-surface-3 transition-colors data-[state=checked]:bg-accent disabled:opacity-40"
    >
      <RSwitch.Thumb className="block size-[18px] translate-x-[2px] rounded-full bg-white shadow-sm transition-transform duration-200 data-[state=checked]:translate-x-[18px]" />
    </RSwitch.Root>
  );
}

export function Segmented<T extends string>({ value, options, onChange, size = 'md', className }: { value: T; options: { value: T; label: ReactNode; title?: string }[]; onChange: (v: T) => void; size?: 'sm' | 'md'; className?: string }) {
  return (
    <div className={cn('inline-flex rounded-[10px] border border-line bg-surface-2/70 p-0.5', className)}>
      {options.map((o) => (
        <button
          key={o.value}
          title={o.title}
          onClick={() => onChange(o.value)}
          className={cn(
            'inline-flex items-center gap-1.5 whitespace-nowrap rounded-lg font-medium transition-all cursor-pointer',
            size === 'sm' ? 'h-6 px-2 text-[11.5px]' : 'h-7 px-3 text-[12.5px]',
            value === o.value ? 'bg-surface text-fg shadow-sm ring-1 ring-line' : 'text-fg-3 hover:text-fg-2',
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Progress({ value, tone = 'accent', className }: { value: number; tone?: 'accent' | 'success' | 'warning' | 'danger'; className?: string }) {
  const v = Math.max(0, Math.min(100, value));
  const color = tone === 'accent' ? 'bg-accent' : tone === 'success' ? 'bg-success' : tone === 'warning' ? 'bg-warning' : 'bg-danger';
  return (
    <div className={cn('h-1.5 w-full overflow-hidden rounded-full bg-surface-3', className)}>
      <div className={cn('h-full rounded-full transition-[width] duration-500', color)} style={{ width: `${v}%` }} />
    </div>
  );
}

export function EmptyState({ icon, title, description, action, className }: { icon?: ReactNode; title: string; description?: ReactNode; action?: ReactNode; className?: string }) {
  return (
    <div className={cn('flex flex-col items-center justify-center px-6 py-14 text-center', className)}>
      {icon && <div className="mb-4 flex size-12 items-center justify-center rounded-2xl border border-line bg-surface-2 text-fg-2">{icon}</div>}
      <div className="text-[15px] font-semibold text-fg">{title}</div>
      {description && <div className="mt-1.5 max-w-md text-[13px] leading-relaxed text-fg-3">{description}</div>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function Field({ label, description, children, className, vertical }: { label: ReactNode; description?: ReactNode; children: ReactNode; className?: string; vertical?: boolean }) {
  return (
    <div className={cn('flex gap-6 py-4', vertical ? 'flex-col gap-2.5' : 'items-center justify-between', className)}>
      <div className="min-w-0">
        <div className="text-[13.5px] font-medium text-fg">{label}</div>
        {description && <div className="mt-0.5 text-[12.5px] leading-relaxed text-fg-3">{description}</div>}
      </div>
      <div className={cn(vertical ? 'w-full' : 'shrink-0')}>{children}</div>
    </div>
  );
}

export function StatusDot({ tone, pulse }: { tone: 'success' | 'warning' | 'danger' | 'neutral' | 'info' | 'accent'; pulse?: boolean }) {
  const c = { success: 'bg-success', warning: 'bg-warning', danger: 'bg-danger', neutral: 'bg-fg-3', info: 'bg-info', accent: 'bg-accent' }[tone];
  return (
    <span className="relative inline-flex size-2">
      {pulse && <span className={cn('absolute inset-0 rounded-full opacity-60 animate-ping', c)} />}
      <span className={cn('relative inline-flex size-2 rounded-full', c)} />
    </span>
  );
}

export function SectionTitle({ children, action, className }: { children: ReactNode; action?: ReactNode; className?: string }) {
  return (
    <div className={cn('mb-3 flex items-center justify-between', className)}>
      <h3 className="text-[12px] font-semibold uppercase tracking-[0.06em] text-fg-3">{children}</h3>
      {action}
    </div>
  );
}
