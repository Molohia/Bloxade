import { useState, type ReactNode } from 'react';
import { Dialog as RDialog, DropdownMenu as RMenu, ContextMenu as RContext, Popover as RPopover, Tabs as RTabs } from 'radix-ui';
import { Check, ChevronDown, X } from 'lucide-react';
import { create } from 'zustand';
import { cn } from '../../lib/utils';
import { Button } from './primitives';

// ---------- Dialog ----------
export function Dialog({
  open,
  onOpenChange,
  title,
  description,
  children,
  footer,
  className,
  wide,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  title?: ReactNode;
  description?: ReactNode;
  children: ReactNode;
  footer?: ReactNode;
  className?: string;
  wide?: boolean;
}) {
  return (
    <RDialog.Root open={open} onOpenChange={onOpenChange}>
      <RDialog.Portal>
        <RDialog.Overlay className="fixed inset-0 z-[60] bg-black/55 backdrop-blur-[2px] data-[state=open]:animate-[bx-fade_150ms_ease]" />
        <RDialog.Content
          className={cn(
            'fixed left-1/2 top-1/2 z-[61] flex max-h-[88vh] w-[calc(100vw-32px)] -translate-x-1/2 -translate-y-1/2 flex-col overflow-hidden rounded-2xl border border-line-strong bg-surface shadow-pop outline-none data-[state=open]:animate-[bx-pop_180ms_cubic-bezier(.2,.9,.3,1.1)]',
            wide ? 'max-w-3xl' : 'max-w-lg',
            className,
          )}
          onOpenAutoFocus={(e) => {
            const el = (e.currentTarget as HTMLElement).querySelector<HTMLElement>('[data-autofocus]');
            if (el) {
              e.preventDefault();
              el.focus();
            }
          }}
        >
          {(title || description) && (
            <div className="flex items-start justify-between gap-4 border-b border-line px-6 pb-4 pt-5">
              <div>
                {title && <RDialog.Title className="text-[16px] font-semibold tracking-[-0.01em] text-fg">{title}</RDialog.Title>}
                {description && <RDialog.Description className="mt-1 text-[13px] leading-relaxed text-fg-3">{description}</RDialog.Description>}
              </div>
              <RDialog.Close className="-mr-2 -mt-1 rounded-lg p-1.5 text-fg-3 hover:bg-surface-2 hover:text-fg cursor-pointer" aria-label="Close">
                <X className="size-4" />
              </RDialog.Close>
            </div>
          )}
          <div className="min-h-0 flex-1 overflow-y-auto px-6 py-5">{children}</div>
          {footer && <div className="flex items-center justify-end gap-2 border-t border-line bg-surface-2/40 px-6 py-3.5">{footer}</div>}
        </RDialog.Content>
      </RDialog.Portal>
    </RDialog.Root>
  );
}

// ---------- Confirm (imperative) ----------
interface ConfirmState {
  open: boolean;
  title: string;
  body: ReactNode;
  confirmLabel: string;
  danger: boolean;
  checkbox?: string;
  resolve?: (v: { ok: boolean; checked: boolean }) => void;
}
const useConfirm = create<ConfirmState>(() => ({ open: false, title: '', body: '', confirmLabel: 'Confirm', danger: false }));

export function confirmDialog(opts: { title: string; body?: ReactNode; confirmLabel?: string; danger?: boolean; checkbox?: string }): Promise<{ ok: boolean; checked: boolean }> {
  return new Promise((resolve) => useConfirm.setState({ open: true, title: opts.title, body: opts.body ?? '', confirmLabel: opts.confirmLabel ?? 'Confirm', danger: !!opts.danger, checkbox: opts.checkbox, resolve }));
}

export function ConfirmHost() {
  const s = useConfirm();
  const [checked, setChecked] = useState(false);
  const close = (ok: boolean) => {
    s.resolve?.({ ok, checked });
    setChecked(false);
    useConfirm.setState({ open: false, resolve: undefined });
  };
  return (
    <Dialog
      open={s.open}
      onOpenChange={(o) => !o && close(false)}
      title={s.title}
      footer={
        <>
          <Button variant="ghost" onClick={() => close(false)}>
            Cancel
          </Button>
          <Button variant={s.danger ? 'danger' : 'primary'} onClick={() => close(true)} data-autofocus>
            {s.confirmLabel}
          </Button>
        </>
      }
    >
      <div className="text-[13.5px] leading-relaxed text-fg-2">{s.body}</div>
      {s.checkbox && (
        <label className="mt-4 flex cursor-pointer items-center gap-2.5 text-[13px] text-fg-2">
          <input type="checkbox" checked={checked} onChange={(e) => setChecked(e.target.checked)} className="size-4 accent-[var(--accent)]" />
          {s.checkbox}
        </label>
      )}
    </Dialog>
  );
}

// ---------- Menus ----------
export interface MenuItem {
  label?: ReactNode;
  icon?: ReactNode;
  onSelect?: () => void;
  danger?: boolean;
  disabled?: boolean;
  separator?: boolean;
  shortcut?: string;
  checked?: boolean;
}

const itemCls =
  'flex h-8 cursor-pointer select-none items-center gap-2.5 rounded-lg px-2.5 text-[13px] text-fg-2 outline-none data-[highlighted]:bg-surface-2 data-[highlighted]:text-fg data-[disabled]:opacity-40 data-[disabled]:pointer-events-none';
const contentCls = 'z-[70] min-w-[200px] rounded-xl border border-line-strong bg-surface p-1 shadow-pop data-[state=open]:animate-[bx-pop_120ms_ease]';

export function Menu({ trigger, items, align = 'end', side = 'bottom' }: { trigger: ReactNode; items: MenuItem[]; align?: 'start' | 'end' | 'center'; side?: 'top' | 'bottom' | 'left' | 'right' }) {
  return (
    <RMenu.Root modal={false}>
      <RMenu.Trigger asChild>{trigger}</RMenu.Trigger>
      <RMenu.Portal>
        <RMenu.Content align={align} side={side} sideOffset={6} className={contentCls}>
          {items.map((it, i) =>
            it.separator ? (
              <RMenu.Separator key={i} className="my-1 h-px bg-line" />
            ) : (
              <RMenu.Item key={i} disabled={it.disabled} onSelect={it.onSelect} className={cn(itemCls, it.danger && 'text-danger data-[highlighted]:text-danger')}>
                <span className="flex size-4 items-center justify-center">{it.checked ? <Check className="size-3.5" /> : it.icon}</span>
                <span className="flex-1">{it.label}</span>
                {it.shortcut && <span className="text-[11px] text-fg-3">{it.shortcut}</span>}
              </RMenu.Item>
            ),
          )}
        </RMenu.Content>
      </RMenu.Portal>
    </RMenu.Root>
  );
}

export function ContextMenu({ children, items }: { children: ReactNode; items: MenuItem[] }) {
  return (
    <RContext.Root modal={false}>
      <RContext.Trigger asChild>{children}</RContext.Trigger>
      <RContext.Portal>
        <RContext.Content className={contentCls}>
          {items.map((it, i) =>
            it.separator ? (
              <RContext.Separator key={i} className="my-1 h-px bg-line" />
            ) : (
              <RContext.Item key={i} disabled={it.disabled} onSelect={it.onSelect} className={cn(itemCls, it.danger && 'text-danger data-[highlighted]:text-danger')}>
                <span className="flex size-4 items-center justify-center">{it.icon}</span>
                <span className="flex-1">{it.label}</span>
              </RContext.Item>
            ),
          )}
        </RContext.Content>
      </RContext.Portal>
    </RContext.Root>
  );
}

export function Popover({ trigger, children, open, onOpenChange, align = 'start', side = 'bottom', className }: { trigger: ReactNode; children: ReactNode; open?: boolean; onOpenChange?: (o: boolean) => void; align?: 'start' | 'end' | 'center'; side?: 'top' | 'bottom'; className?: string }) {
  return (
    <RPopover.Root open={open} onOpenChange={onOpenChange}>
      <RPopover.Trigger asChild>{trigger}</RPopover.Trigger>
      <RPopover.Portal>
        <RPopover.Content align={align} side={side} sideOffset={8} collisionPadding={12} className={cn('z-[70] rounded-2xl border border-line-strong bg-surface shadow-pop outline-none data-[state=open]:animate-[bx-pop_140ms_ease]', className)}>
          {children}
        </RPopover.Content>
      </RPopover.Portal>
    </RPopover.Root>
  );
}

// ---------- Select (simple, styled) ----------
export function Select<T extends string>({ value, onChange, options, placeholder, className, size = 'md' }: { value: T | ''; onChange: (v: T) => void; options: { value: T; label: ReactNode; hint?: ReactNode }[]; placeholder?: string; className?: string; size?: 'sm' | 'md' }) {
  const current = options.find((o) => o.value === value);
  return (
    <RMenu.Root modal={false}>
      <RMenu.Trigger asChild>
        <button className={cn('inline-flex w-full min-w-[150px] cursor-pointer items-center justify-between gap-2 rounded-[10px] border border-line bg-surface-2/60 px-3 text-left text-fg hover:bg-surface-2', size === 'sm' ? 'h-8 text-[12.5px]' : 'h-9 text-[13.5px]', className)}>
          <span className={cn('truncate', !current && 'text-fg-3')}>{current?.label ?? placeholder ?? 'Select…'}</span>
          <ChevronDown className="size-3.5 shrink-0 text-fg-3" />
        </button>
      </RMenu.Trigger>
      <RMenu.Portal>
        <RMenu.Content align="start" sideOffset={6} className={cn(contentCls, 'max-h-80 overflow-y-auto')} style={{ minWidth: 'var(--radix-dropdown-menu-trigger-width)' }}>
          {options.map((o) => (
            <RMenu.Item key={o.value} onSelect={() => onChange(o.value)} className={cn(itemCls, 'h-auto min-h-8 py-1.5')}>
              <span className="flex size-4 items-center justify-center">{o.value === value && <Check className="size-3.5 text-accent" />}</span>
              <span className="flex-1">
                <span className="block text-fg">{o.label}</span>
                {o.hint && <span className="block text-[11.5px] text-fg-3">{o.hint}</span>}
              </span>
            </RMenu.Item>
          ))}
        </RMenu.Content>
      </RMenu.Portal>
    </RMenu.Root>
  );
}

// ---------- Tabs ----------
export function Tabs({ value, onChange, tabs, className }: { value: string; onChange: (v: string) => void; tabs: { value: string; label: ReactNode; count?: number }[]; className?: string }) {
  return (
    <RTabs.Root value={value} onValueChange={onChange} className={className}>
      <RTabs.List className="flex items-center gap-1 border-b border-line">
        {tabs.map((t) => (
          <RTabs.Trigger
            key={t.value}
            value={t.value}
            className="relative -mb-px inline-flex h-10 cursor-pointer items-center gap-2 px-3 text-[13px] font-medium text-fg-3 transition-colors hover:text-fg-2 data-[state=active]:text-fg after:absolute after:inset-x-2 after:-bottom-px after:h-0.5 after:rounded-full after:bg-transparent data-[state=active]:after:bg-accent"
          >
            {t.label}
            {t.count != null && <span className="rounded-md bg-surface-2 px-1.5 text-[11px] text-fg-3">{t.count}</span>}
          </RTabs.Trigger>
        ))}
      </RTabs.List>
    </RTabs.Root>
  );
}
