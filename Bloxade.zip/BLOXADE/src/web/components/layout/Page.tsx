import type { ReactNode } from 'react';
import { cn } from '../../lib/utils';

export function Page({ children, className, wide }: { children: ReactNode; className?: string; wide?: boolean }) {
  return (
    <div className="h-full overflow-y-auto">
      <div className={cn('mx-auto w-full px-6 pb-16 pt-6 md:px-10', wide ? 'max-w-[1400px]' : 'max-w-[1120px]', className)}>{children}</div>
    </div>
  );
}

export function PageHeader({ title, description, actions, icon, eyebrow }: { title: ReactNode; description?: ReactNode; actions?: ReactNode; icon?: ReactNode; eyebrow?: ReactNode }) {
  return (
    <div className="mb-7 flex flex-wrap items-start justify-between gap-4">
      <div className="flex min-w-0 items-start gap-3.5">
        {icon}
        <div className="min-w-0">
          {eyebrow && <div className="mb-1 text-[12px] font-medium text-fg-3">{eyebrow}</div>}
          <h1 className="text-[22px] font-semibold tracking-[-0.02em] text-fg">{title}</h1>
          {description && <p className="mt-1 max-w-2xl text-[13.5px] leading-relaxed text-fg-3">{description}</p>}
        </div>
      </div>
      {actions && <div className="flex shrink-0 items-center gap-2">{actions}</div>}
    </div>
  );
}

export function Stat({ label, value, hint, icon, tone }: { label: ReactNode; value: ReactNode; hint?: ReactNode; icon?: ReactNode; tone?: 'verified' | 'estimate' }) {
  return (
    <div className="rounded-2xl border border-line bg-surface p-4">
      <div className="flex items-center justify-between">
        <span className="text-[12.5px] font-medium text-fg-3">{label}</span>
        {icon && <span className="text-fg-3">{icon}</span>}
      </div>
      <div className="mt-2 text-[24px] font-semibold tracking-[-0.02em] tabular-nums text-fg">{value}</div>
      {(hint || tone) && (
        <div className="mt-1.5 text-[11.5px] leading-snug text-fg-3">
          {tone === 'verified' && <span className="mr-1.5 inline-block rounded bg-success/12 px-1.5 py-px font-medium text-success">Verified</span>}
          {tone === 'estimate' && <span className="mr-1.5 inline-block rounded bg-warning/12 px-1.5 py-px font-medium text-warning">Estimate</span>}
          {hint}
        </div>
      )}
    </div>
  );
}
