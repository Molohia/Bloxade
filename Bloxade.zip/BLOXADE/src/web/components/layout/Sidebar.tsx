import { useMemo, useState, type ReactNode } from 'react';
import {
  Activity, BarChart3, ChevronRight, FolderPlus, Gamepad2, LayoutGrid, ListTodo, MessageSquarePlus, MoreHorizontal, PanelLeftClose, Pencil, Pin, PinOff, Plus, Search, Settings, Trash2, Users, Workflow, FolderInput,
} from 'lucide-react';
import type { Chat } from '@shared/types';
import { useApp } from '../../store/app';
import { navigate, routes, useRoute } from '../../lib/router';
import { cn, groupByDate, modKey } from '../../lib/utils';
import { api } from '../../lib/api';
import { LogoMark, ProviderMark } from '../brand';
import { ProjectIcon } from '../icons';
import { IconButton, Kbd, StatusDot, Tooltip } from '../ui/primitives';
import { ContextMenu, Menu, confirmDialog, type MenuItem } from '../ui/overlays';
import { useUi } from '../../store/ui';

function NavItem({ icon, label, active, onClick, badge, right }: { icon: ReactNode; label: ReactNode; active?: boolean; onClick: () => void; badge?: ReactNode; right?: ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'group flex h-8 w-full cursor-pointer items-center gap-2.5 rounded-lg px-2.5 text-[13px] transition-colors',
        active ? 'bg-surface-3/70 text-fg' : 'text-fg-2 hover:bg-surface-2 hover:text-fg',
      )}
    >
      <span className={cn('flex size-4 shrink-0 items-center justify-center', active ? 'text-fg' : 'text-fg-3 group-hover:text-fg-2')}>{icon}</span>
      <span className="min-w-0 flex-1 truncate text-left">{label}</span>
      {badge}
      {right}
    </button>
  );
}

function Section({ title, children, defaultOpen = true, action, storageKey }: { title: string; children: ReactNode; defaultOpen?: boolean; action?: ReactNode; storageKey: string }) {
  const [open, setOpen] = useState(() => {
    try {
      const v = localStorage.getItem('bx-sec-' + storageKey);
      return v == null ? defaultOpen : v === '1';
    } catch {
      return defaultOpen;
    }
  });
  const toggle = () => {
    setOpen(!open);
    try {
      localStorage.setItem('bx-sec-' + storageKey, open ? '0' : '1');
    } catch {
      /* ignore */
    }
  };
  return (
    <div className="mt-3.5">
      <div className="group/sec flex h-6 items-center justify-between px-2.5">
        <button onClick={toggle} className="group/t flex cursor-pointer items-center gap-1 text-[12px] font-medium text-fg-3 hover:text-fg-2">
          {title}
          <ChevronRight className={cn('size-3 opacity-0 transition-all group-hover/t:opacity-100', open && 'rotate-90')} />
        </button>
        <div className="opacity-0 transition-opacity group-hover/sec:opacity-100">{action}</div>
      </div>
      {open && <div className="mt-0.5 space-y-px">{children}</div>}
    </div>
  );
}

function ChatRow({ chat, active }: { chat: Chat; active: boolean }) {
  const running = useApp((s) => s.running.has(chat.id));
  const projects = useApp((s) => s.projects);
  const [renaming, setRenaming] = useState(false);
  const [title, setTitle] = useState(chat.title);
  const save = async () => {
    setRenaming(false);
    if (title.trim() && title !== chat.title) await api.patch(`/api/chats/${chat.id}`, { title: title.trim() });
  };
  const items: MenuItem[] = [
    { label: 'Rename', icon: <Pencil className="size-3.5" />, onSelect: () => (setTitle(chat.title), setRenaming(true)) },
    { label: chat.pinned ? 'Unpin' : 'Pin', icon: chat.pinned ? <PinOff className="size-3.5" /> : <Pin className="size-3.5" />, onSelect: () => api.patch(`/api/chats/${chat.id}`, { pinned: !chat.pinned }) },
    ...(projects.length
      ? [
          { separator: true },
          ...projects.slice(0, 8).map((p) => ({
            label: `Move to ${p.name}`,
            icon: <FolderInput className="size-3.5" />,
            checked: chat.projectId === p.id,
            onSelect: () => api.patch(`/api/chats/${chat.id}`, { projectId: chat.projectId === p.id ? null : p.id }),
          })),
        ]
      : []),
    { separator: true },
    {
      label: 'Delete',
      icon: <Trash2 className="size-3.5" />,
      danger: true,
      onSelect: async () => {
        const r = await confirmDialog({ title: 'Delete chat?', body: `“${chat.title}” and its messages will be permanently deleted from this computer.`, confirmLabel: 'Delete', danger: true });
        if (r.ok) {
          await api.del(`/api/chats/${chat.id}`);
          if (active) navigate(routes.newChat());
        }
      },
    },
  ];
  if (renaming)
    return (
      <input
        autoFocus
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        onBlur={save}
        onKeyDown={(e) => {
          if (e.key === 'Enter') void save();
          if (e.key === 'Escape') setRenaming(false);
        }}
        className="h-8 w-full rounded-lg border border-accent/50 bg-surface-2 px-2.5 text-[13px] outline-none"
      />
    );
  return (
    <ContextMenu items={items}>
      <div
        role="button"
        tabIndex={0}
        onClick={() => navigate(routes.chat(chat.id))}
        onKeyDown={(e) => e.key === 'Enter' && navigate(routes.chat(chat.id))}
        className={cn('group relative flex h-8 cursor-pointer items-center gap-2 rounded-lg px-2.5 text-[13px]', active ? 'bg-surface-3/70 text-fg' : 'text-fg-2 hover:bg-surface-2 hover:text-fg')}
      >
        {running ? <span className="flex size-4 items-center justify-center"><StatusDot tone="accent" pulse /></span> : chat.pinned ? <Pin className="size-3.5 shrink-0 text-fg-3" /> : null}
        <span className="min-w-0 flex-1 truncate">{chat.title}</span>
        <Menu
          trigger={
            <button onClick={(e) => e.stopPropagation()} className="hidden size-6 shrink-0 items-center justify-center rounded-md text-fg-3 hover:bg-surface-3 hover:text-fg group-hover:flex data-[state=open]:flex cursor-pointer" aria-label="Chat options">
              <MoreHorizontal className="size-4" />
            </button>
          }
          items={items}
        />
      </div>
    </ContextMenu>
  );
}

export function Sidebar() {
  const route = useRoute();
  const chats = useApp((s) => s.chats);
  const projects = useApp((s) => s.projects);
  const accounts = useApp((s) => s.accounts);
  const roblox = useApp((s) => s.roblox);
  const approvals = useApp((s) => s.approvals.length);
  const runs = useApp((s) => s.runs);
  const settings = useApp((s) => s.settings);
  const saveSettings = useApp((s) => s.saveSettings);
  const openPalette = useUi((s) => s.openPalette);
  const openNewProject = useUi((s) => s.openNewProject);
  const activeChatId = route.page === 'chat' ? route.parts[0] : null;
  const activeProjectId = route.page === 'projects' ? route.parts[0] : null;

  const pinned = chats.filter((c) => c.pinned);
  const recent = useMemo(() => groupByDate(chats.filter((c) => !c.pinned).slice(0, 120)), [chats]);
  const signedIn = (p: 'claude' | 'codex') => accounts.filter((a) => a.provider === p && a.status === 'signed_in').length;
  const total = (p: 'claude' | 'codex') => accounts.filter((a) => a.provider === p).length;
  const workingAgents = Object.values(runs).reduce((n, r) => n + r.tasks.filter((t) => t.status === 'working').length, 0);
  const rbTone = roblox?.state === 'connected' ? 'success' : roblox?.state === 'connecting' ? 'warning' : roblox?.state === 'error' ? 'danger' : 'neutral';

  return (
    <aside className="flex h-full w-[268px] shrink-0 flex-col border-r border-line bg-sidebar">
      <div className="flex h-[52px] items-center justify-between px-3.5">
        <button onClick={() => navigate(routes.newChat())} className="flex cursor-pointer items-center gap-2 rounded-lg px-1 py-1">
          <LogoMark />
          <span className="text-[13.5px] font-bold tracking-[0.16em]">BLOXADE</span>
        </button>
        <IconButton label={`Collapse sidebar (${modKey}+B)`} onClick={() => saveSettings({ appearance: { sidebarCollapsed: true } })}>
          <PanelLeftClose className="size-[17px]" />
        </IconButton>
      </div>

      <div className="space-y-px px-2">
        <NavItem icon={<MessageSquarePlus className="size-4" />} label="New chat" active={route.page === 'chat' && !activeChatId && !route.query.get('project')} onClick={() => navigate(routes.newChat())} right={<span className="hidden group-hover:inline"><Kbd>{modKey}⇧O</Kbd></span>} />
        <NavItem icon={<Search className="size-4" />} label="Search" onClick={openPalette} right={<Kbd>{modKey}K</Kbd>} />
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto px-2 pb-3">
        <Section
          title="Projects"
          storageKey="projects"
          action={
            <IconButton label="New project" size="xs" onClick={openNewProject}>
              <Plus className="size-3.5" />
            </IconButton>
          }
        >
          {projects.slice(0, 12).map((p) => (
            <NavItem key={p.id} icon={<ProjectIcon icon={p.icon} color={p.color} size="xs" />} label={p.name} active={activeProjectId === p.id} onClick={() => navigate(routes.project(p.id))} />
          ))}
          {projects.length > 12 && <NavItem icon={<LayoutGrid className="size-4" />} label={`All projects (${projects.length})`} onClick={() => navigate(routes.projects())} />}
          {projects.length === 0 ? (
            <NavItem icon={<FolderPlus className="size-4" />} label="Create project" onClick={openNewProject} />
          ) : (
            <NavItem icon={<LayoutGrid className="size-4" />} label="All projects" active={route.page === 'projects' && !activeProjectId} onClick={() => navigate(routes.projects())} />
          )}
        </Section>

        <Section title="AI Workspace" storageKey="workspace">
          <NavItem icon={<Workflow className="size-4" />} label="Agents" active={route.page === 'agents'} onClick={() => navigate(routes.agents())} badge={workingAgents ? <span className="rounded-md bg-accent-soft px-1.5 text-[11px] font-medium text-accent-text">{workingAgents}</span> : null} />
          <NavItem icon={<ListTodo className="size-4" />} label="Task Board" active={route.page === 'tasks'} onClick={() => navigate(routes.tasks())} badge={approvals ? <Tooltip content="Waiting for your approval"><span className="rounded-md bg-warning/15 px-1.5 text-[11px] font-medium text-warning">{approvals}</span></Tooltip> : null} />
          <NavItem icon={<Activity className="size-4" />} label="Activity" active={route.page === 'activity'} onClick={() => navigate(routes.activity())} />
        </Section>

        <Section title="Connections" storageKey="connections">
          <NavItem icon={<ProviderMark provider="claude" size="xs" />} label="Claude accounts" active={route.page === 'accounts' && route.query.get('provider') === 'claude'} onClick={() => navigate(routes.accounts('claude'))} badge={<span className="text-[11.5px] text-fg-3">{signedIn('claude')}/{total('claude')}</span>} />
          <NavItem icon={<ProviderMark provider="codex" size="xs" />} label="Codex accounts" active={route.page === 'accounts' && route.query.get('provider') === 'codex'} onClick={() => navigate(routes.accounts('codex'))} badge={<span className="text-[11.5px] text-fg-3">{signedIn('codex')}/{total('codex')}</span>} />
          <NavItem icon={<Gamepad2 className="size-4" />} label="Roblox Studio" active={route.page === 'roblox'} onClick={() => navigate(routes.roblox())} badge={<StatusDot tone={rbTone} pulse={roblox?.state === 'connecting'} />} />
        </Section>

        {pinned.length > 0 && (
          <Section title="Pinned" storageKey="pinned">
            {pinned.map((c) => (
              <ChatRow key={c.id} chat={c} active={c.id === activeChatId} />
            ))}
          </Section>
        )}

        {recent.map(([label, list]) => (
          <Section key={label} title={label} storageKey={'recent-' + label}>
            {list.map((c) => (
              <ChatRow key={c.id} chat={c} active={c.id === activeChatId} />
            ))}
          </Section>
        ))}
        {chats.length === 0 && <div className="mt-6 px-3 text-[12.5px] leading-relaxed text-fg-3">Your chats will appear here.</div>}
      </div>

      <div className="space-y-px border-t border-line p-2">
        <NavItem icon={<BarChart3 className="size-4" />} label="Usage" active={route.page === 'usage'} onClick={() => navigate(routes.usage())} />
        <NavItem icon={<Users className="size-4" />} label="Accounts" active={route.page === 'accounts' && !route.query.get('provider')} onClick={() => navigate(routes.accounts())} />
        <NavItem icon={<Settings className="size-4" />} label="Settings" active={route.page === 'settings'} onClick={() => navigate(routes.settings())} right={settings ? <span className="hidden text-[11px] text-fg-3 group-hover:inline">{modKey},</span> : null} />
      </div>
    </aside>
  );
}
