import { useEffect, useState } from 'react';
import { ArrowUp, Folder, FolderOpen, HardDrive, Home, MonitorUp } from 'lucide-react';
import { toast } from 'sonner';
import type { Project } from '@shared/types';
import { api } from '../lib/api';
import { cn } from '../lib/utils';
import { navigate, routes } from '../lib/router';
import { useApp } from '../store/app';
import { useUi } from '../store/ui';
import { Dialog } from './ui/overlays';
import { Button, Input, Switch, Textarea } from './ui/primitives';
import { PROJECT_COLORS, PROJECT_ICONS, ProjectIcon } from './icons';

interface BrowseResult {
  path: string;
  parent: string | null;
  dirs: string[];
  drives: string[];
  home: string;
}

export function FolderPicker({ open, onOpenChange, onPick, initial }: { open: boolean; onOpenChange: (o: boolean) => void; onPick: (path: string) => void; initial?: string | null }) {
  const [data, setData] = useState<BrowseResult | null>(null);
  const [path, setPath] = useState(initial ?? '');
  const platform = useApp((s) => s.platform);
  const load = async (p?: string) => {
    try {
      const r = await api.post<BrowseResult>('/api/fs/browse', { path: p ?? '' }, { silent: true });
      setData(r);
      setPath(r.path);
    } catch (e) {
      toast.error((e as Error).message);
    }
  };
  useEffect(() => {
    if (open) void load(initial || undefined);
  }, [open]); // eslint-disable-line react-hooks/exhaustive-deps
  const sep = platform === 'win32' ? '\\' : '/';
  const join = (a: string, b: string) => (a.endsWith(sep) ? a + b : a + sep + b);
  return (
    <Dialog
      open={open}
      onOpenChange={onOpenChange}
      title="Choose a project folder"
      description="BLOXADE agents can only read and edit files inside the folder you choose."
      wide
      footer={
        <>
          {platform === 'win32' && (
            <Button
              variant="ghost"
              icon={<MonitorUp className="size-4" />}
              onClick={async () => {
                const r = await api.post<{ path: string | null }>('/api/fs/native-pick');
                if (r.path) {
                  onPick(r.path);
                  onOpenChange(false);
                }
              }}
              className="mr-auto"
            >
              Use Windows dialog
            </Button>
          )}
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            variant="primary"
            disabled={!path}
            onClick={() => {
              onPick(path);
              onOpenChange(false);
            }}
          >
            Use this folder
          </Button>
        </>
      }
    >
      <div className="flex items-center gap-2">
        <Input value={path} onChange={(e) => setPath(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && load(path)} className="flex-1 font-mono" />
        <Button size="md" variant="secondary" onClick={() => load(path)}>
          Go
        </Button>
      </div>
      <div className="mt-3 flex flex-wrap items-center gap-1.5">
        <Button size="xs" variant="ghost" icon={<Home className="size-3.5" />} onClick={() => load(data?.home)}>
          Home
        </Button>
        {data?.parent && (
          <Button size="xs" variant="ghost" icon={<ArrowUp className="size-3.5" />} onClick={() => load(data.parent!)}>
            Up
          </Button>
        )}
        {data?.drives?.map((d) => (
          <Button key={d} size="xs" variant="ghost" icon={<HardDrive className="size-3.5" />} onClick={() => load(d)}>
            {d}
          </Button>
        ))}
      </div>
      <div className="mt-3 h-[320px] overflow-y-auto rounded-xl border border-line bg-surface-2/40 p-1.5">
        {data?.dirs.length === 0 && <div className="p-6 text-center text-[13px] text-fg-3">No sub-folders here.</div>}
        {data?.dirs.map((d) => (
          <button key={d} onDoubleClick={() => load(join(data.path, d))} onClick={() => setPath(join(data.path, d))} className={cn('flex w-full cursor-pointer items-center gap-2.5 rounded-lg px-2.5 py-1.5 text-left text-[13px] hover:bg-surface-3', path === join(data.path, d) ? 'bg-accent-soft text-fg' : 'text-fg-2')}>
            {path === join(data.path, d) ? <FolderOpen className="size-4 text-accent" /> : <Folder className="size-4 text-fg-3" />}
            {d}
          </button>
        ))}
      </div>
      <div className="mt-2 text-[12px] text-fg-3">Click to select · double-click to open</div>
    </Dialog>
  );
}

export function ProjectForm({ value, onChange }: { value: Partial<Project> & { createFolder?: boolean }; onChange: (v: Partial<Project> & { createFolder?: boolean }) => void }) {
  const [picker, setPicker] = useState(false);
  return (
    <div className="space-y-4">
      <div className="flex items-start gap-3">
        <ProjectIcon icon={value.icon ?? 'cuboid'} color={value.color ?? PROJECT_COLORS[0]} size="lg" />
        <div className="flex-1 space-y-1.5">
          <label className="text-[12.5px] font-medium text-fg-2">Name</label>
          <Input data-autofocus value={value.name ?? ''} onChange={(e) => onChange({ ...value, name: e.target.value })} placeholder="Roblox — Milk the Cow" />
        </div>
      </div>
      <div className="flex flex-wrap items-center gap-1.5">
        {Object.entries(PROJECT_ICONS).map(([k, Icon]) => (
          <button key={k} onClick={() => onChange({ ...value, icon: k })} className={cn('flex size-8 cursor-pointer items-center justify-center rounded-lg border', value.icon === k ? 'border-accent bg-accent-soft text-fg' : 'border-line text-fg-3 hover:bg-surface-2')}>
            <Icon className="size-4" />
          </button>
        ))}
        <span className="mx-1 h-6 w-px bg-line" />
        {PROJECT_COLORS.map((c) => (
          <button key={c} onClick={() => onChange({ ...value, color: c })} className={cn('size-6 cursor-pointer rounded-full ring-offset-2 ring-offset-surface', value.color === c && 'ring-2 ring-fg/60')} style={{ background: c }} aria-label={`Color ${c}`} />
        ))}
      </div>
      <div className="space-y-1.5">
        <label className="text-[12.5px] font-medium text-fg-2">Description</label>
        <Input value={value.description ?? ''} onChange={(e) => onChange({ ...value, description: e.target.value })} placeholder="Tycoon game where players milk cows and upgrade their farm" />
      </div>
      <div className="space-y-1.5">
        <label className="text-[12.5px] font-medium text-fg-2">Project folder <span className="font-normal text-fg-3">(optional — needed for file editing)</span></label>
        <div className="flex gap-2">
          <Input value={value.folderPath ?? ''} onChange={(e) => onChange({ ...value, folderPath: e.target.value })} placeholder="C:\Users\you\Documents\Roblox\MilkTheCow" className="flex-1 font-mono" />
          <Button variant="secondary" icon={<FolderOpen className="size-4" />} onClick={() => setPicker(true)}>
            Browse
          </Button>
        </div>
        {value.folderPath && (
          <label className="flex cursor-pointer items-center gap-2 text-[12px] text-fg-3">
            <input type="checkbox" checked={!!value.createFolder} onChange={(e) => onChange({ ...value, createFolder: e.target.checked })} className="accent-[var(--accent)]" />
            Create the folder if it does not exist
          </label>
        )}
      </div>
      <div className="flex items-center justify-between rounded-xl border border-line bg-surface-2/40 px-3.5 py-3">
        <div>
          <div className="text-[13px] font-medium text-fg">Roblox Studio project</div>
          <div className="text-[12px] text-fg-3">Cowork chats and agents in this project get the Roblox Studio tools.</div>
        </div>
        <Switch checked={!!value.robloxEnabled} onChange={(v) => onChange({ ...value, robloxEnabled: v })} />
      </div>
      <div className="space-y-1.5">
        <label className="text-[12.5px] font-medium text-fg-2">Instructions for every AI in this project</label>
        <Textarea rows={4} value={value.instructions ?? ''} onChange={(e) => onChange({ ...value, instructions: e.target.value })} placeholder="e.g. Use strict Luau types. Server code lives in ServerScriptService/Services. Never trust the client for purchases." />
      </div>
      <FolderPicker open={picker} onOpenChange={setPicker} initial={value.folderPath} onPick={(p) => onChange({ ...value, folderPath: p })} />
    </div>
  );
}

export function NewProjectDialog() {
  const open = useUi((s) => s.newProjectOpen);
  const close = useUi((s) => s.closeNewProject);
  const [v, setV] = useState<Partial<Project> & { createFolder?: boolean }>({ icon: 'cuboid', color: PROJECT_COLORS[0], robloxEnabled: true });
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    if (open) setV({ icon: 'cuboid', color: PROJECT_COLORS[Math.floor(Math.random() * 6)], robloxEnabled: true });
  }, [open]);
  const create = async () => {
    setBusy(true);
    try {
      const p = await api.post<Project>('/api/projects', v);
      useApp.setState((s) => ({ projects: [p, ...s.projects.filter((x) => x.id !== p.id)] }));
      close();
      navigate(routes.project(p.id));
      toast.success(`Project “${p.name}” created`);
    } finally {
      setBusy(false);
    }
  };
  return (
    <Dialog
      open={open}
      onOpenChange={(o) => !o && close()}
      title="New project"
      description="Projects keep chats, files, agents, instructions and memory together."
      footer={
        <>
          <Button variant="ghost" onClick={close}>
            Cancel
          </Button>
          <Button variant="primary" loading={busy} disabled={!v.name?.trim()} onClick={create}>
            Create project
          </Button>
        </>
      }
    >
      <ProjectForm value={v} onChange={setV} />
    </Dialog>
  );
}
