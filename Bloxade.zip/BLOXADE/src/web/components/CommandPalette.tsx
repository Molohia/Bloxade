import { useEffect, useMemo, useRef, useState } from 'react';
import { Dialog as RDialog } from 'radix-ui';
import { BarChart3, FolderPlus, Gamepad2, ListTodo, MessageSquare, MessageSquarePlus, Moon, Search, Settings, Users, Workflow, Activity, CornerDownLeft } from 'lucide-react';
import type { Chat } from '@shared/types';
import { useApp } from '../store/app';
import { useUi } from '../store/ui';
import { api } from '../lib/api';
import { navigate, routes } from '../lib/router';
import { cn, timeAgo } from '../lib/utils';
import { ProjectIcon } from './icons';
import { THEMES } from '../lib/theme';

interface Item {
  id: string;
  group: string;
  icon: React.ReactNode;
  label: string;
  hint?: string;
  run: () => void;
}

export function CommandPalette() {
  const open = useUi((s) => s.paletteOpen);
  const close = useUi((s) => s.closePalette);
  const openNewProject = useUi((s) => s.openNewProject);
  const chats = useApp((s) => s.chats);
  const projects = useApp((s) => s.projects);
  const settings = useApp((s) => s.settings);
  const saveSettings = useApp((s) => s.saveSettings);
  const [q, setQ] = useState('');
  const [remote, setRemote] = useState<{ chat: Chat; messageId: string | null; snippet: string }[]>([]);
  const [idx, setIdx] = useState(0);
  const listRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!open) {
      setQ('');
      setRemote([]);
    }
  }, [open]);

  useEffect(() => {
    if (q.trim().length < 2) {
      setRemote([]);
      return;
    }
    const t = setTimeout(() => {
      api.get<typeof remote>(`/api/search?q=${encodeURIComponent(q.trim())}`, { silent: true }).then(setRemote, () => undefined);
    }, 140);
    return () => clearTimeout(t);
  }, [q]);

  const items = useMemo<Item[]>(() => {
    const go = (path: string) => () => {
      navigate(path);
      close();
    };
    const actions: Item[] = [
      { id: 'a-new', group: 'Actions', icon: <MessageSquarePlus className="size-4" />, label: 'New chat', run: go(routes.newChat()) },
      { id: 'a-proj', group: 'Actions', icon: <FolderPlus className="size-4" />, label: 'New project', run: () => (close(), openNewProject()) },
      { id: 'a-agents', group: 'Go to', icon: <Workflow className="size-4" />, label: 'Agents', run: go(routes.agents()) },
      { id: 'a-tasks', group: 'Go to', icon: <ListTodo className="size-4" />, label: 'Task Board', run: go(routes.tasks()) },
      { id: 'a-act', group: 'Go to', icon: <Activity className="size-4" />, label: 'Activity', run: go(routes.activity()) },
      { id: 'a-acc', group: 'Go to', icon: <Users className="size-4" />, label: 'Accounts', run: go(routes.accounts()) },
      { id: 'a-rbx', group: 'Go to', icon: <Gamepad2 className="size-4" />, label: 'Roblox Studio', run: go(routes.roblox()) },
      { id: 'a-use', group: 'Go to', icon: <BarChart3 className="size-4" />, label: 'Usage', run: go(routes.usage()) },
      { id: 'a-set', group: 'Go to', icon: <Settings className="size-4" />, label: 'Settings', run: go(routes.settings()) },
      ...THEMES.map((t) => ({ id: 'theme-' + t.id, group: 'Theme', icon: <Moon className="size-4" />, label: `Theme: ${t.label}`, hint: settings?.appearance.theme === t.id ? 'current' : undefined, run: () => (saveSettings({ appearance: { theme: t.id } }), close()) })),
    ];
    const ql = q.toLowerCase().trim();
    const match = (s: string) => !ql || s.toLowerCase().includes(ql);
    const projItems: Item[] = projects.filter((p) => match(p.name)).slice(0, 6).map((p) => ({ id: 'p-' + p.id, group: 'Projects', icon: <ProjectIcon icon={p.icon} color={p.color} size="xs" />, label: p.name, hint: p.folderPath ?? undefined, run: go(routes.project(p.id)) }));
    const localChats: Item[] = chats.filter((c) => match(c.title)).slice(0, ql ? 8 : 6).map((c) => ({ id: 'c-' + c.id, group: ql ? 'Chats' : 'Recent chats', icon: <MessageSquare className="size-4" />, label: c.title, hint: timeAgo(c.updatedAt), run: go(routes.chat(c.id)) }));
    const seen = new Set(localChats.map((i) => i.id));
    const msgItems: Item[] = remote
      .filter((r) => !seen.has('c-' + r.chat.id))
      .slice(0, 8)
      .map((r) => ({ id: 'm-' + r.chat.id, group: 'In messages', icon: <Search className="size-4" />, label: r.chat.title, hint: r.snippet, run: go(routes.chat(r.chat.id)) }));
    return [...localChats, ...msgItems, ...projItems, ...actions.filter((a) => match(a.label))];
  }, [q, chats, projects, remote, settings, close, openNewProject, saveSettings]);

  useEffect(() => setIdx(0), [q]);
  useEffect(() => {
    listRef.current?.querySelector(`[data-idx="${idx}"]`)?.scrollIntoView({ block: 'nearest' });
  }, [idx]);

  let lastGroup = '';
  return (
    <RDialog.Root open={open} onOpenChange={(o) => !o && close()}>
      <RDialog.Portal>
        <RDialog.Overlay className="fixed inset-0 z-[60] bg-black/50 backdrop-blur-[2px]" />
        <RDialog.Content
          onOpenAutoFocus={(e) => {
            e.preventDefault();
            inputRef.current?.focus();
          }}
          className="fixed left-1/2 top-[14vh] z-[61] w-[calc(100vw-32px)] max-w-[620px] -translate-x-1/2 overflow-hidden rounded-2xl border border-line-strong bg-surface shadow-pop outline-none data-[state=open]:animate-[bx-pop_140ms_ease]">
          <RDialog.Title className="sr-only">Search</RDialog.Title>
          <div className="flex items-center gap-3 border-b border-line px-4">
            <Search className="size-4 text-fg-3" />
            <input
              ref={inputRef}
              autoFocus
              value={q}
              onChange={(e) => setQ(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'ArrowDown') {
                  e.preventDefault();
                  setIdx((i) => Math.min(items.length - 1, i + 1));
                } else if (e.key === 'ArrowUp') {
                  e.preventDefault();
                  setIdx((i) => Math.max(0, i - 1));
                } else if (e.key === 'Enter') {
                  e.preventDefault();
                  items[idx]?.run();
                }
              }}
              placeholder="Search chats, messages, projects and actions…"
              className="h-14 flex-1 bg-transparent text-[15px] outline-none placeholder:text-fg-3"
            />
          </div>
          <div ref={listRef} className="max-h-[56vh] overflow-y-auto p-2">
            {items.length === 0 && <div className="px-3 py-10 text-center text-[13px] text-fg-3">No results for “{q}”</div>}
            {items.map((it, i) => {
              const header = it.group !== lastGroup ? it.group : null;
              lastGroup = it.group;
              return (
                <div key={it.id}>
                  {header && <div className="px-2.5 pb-1 pt-2.5 text-[10.5px] font-semibold uppercase tracking-[0.07em] text-fg-3">{header}</div>}
                  <button
                    data-idx={i}
                    onMouseMove={() => setIdx(i)}
                    onClick={it.run}
                    className={cn('flex w-full cursor-pointer items-center gap-3 rounded-xl px-2.5 py-2 text-left', i === idx ? 'bg-surface-2 text-fg' : 'text-fg-2')}
                  >
                    <span className="flex size-5 shrink-0 items-center justify-center text-fg-3">{it.icon}</span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[13.5px]">{it.label}</span>
                      {it.hint && it.group === 'In messages' && <span className="block truncate text-[12px] text-fg-3">{it.hint}</span>}
                    </span>
                    {it.hint && it.group !== 'In messages' && <span className="max-w-[40%] shrink-0 truncate text-[11.5px] text-fg-3">{it.hint}</span>}
                    {i === idx && <CornerDownLeft className="size-3.5 shrink-0 text-fg-3" />}
                  </button>
                </div>
              );
            })}
          </div>
        </RDialog.Content>
      </RDialog.Portal>
    </RDialog.Root>
  );
}
