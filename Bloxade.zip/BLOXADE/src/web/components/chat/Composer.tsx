import { useEffect, useRef, useState } from 'react';
import { ArrowUp, FileText, Image as ImageIcon, MessagesSquare, Paperclip, Square, Users2, X, FolderOpen, Gamepad2 } from 'lucide-react';
import type { AttachmentRef, ChatMode } from '@shared/types';
import { api, fileToBase64 } from '../../lib/api';
import { cn, fmtBytes } from '../../lib/utils';
import { toast } from 'sonner';
import { ModelPicker, type Selection } from './ModelPicker';
import { Segmented, Spinner, Tooltip } from '../ui/primitives';
import { useApp } from '../../store/app';
import { useUi } from '../../store/ui';

export interface ComposerProps {
  draftKey: string;
  selection: Selection & { mode: ChatMode };
  onSelectionChange: (v: Partial<Selection & { mode: ChatMode }>) => void;
  onSend: (text: string, attachments: AttachmentRef[]) => Promise<void> | void;
  running: boolean;
  onStop: () => void;
  projectId: string | null;
  autoFocus?: boolean;
  large?: boolean;
  chatId?: string | null;
}

export function Composer({ draftKey, selection, onSelectionChange, onSend, running, onStop, projectId, autoFocus, large, chatId }: ComposerProps) {
  const draft = useUi((s) => s.draft[draftKey] ?? '');
  const setDraft = useUi((s) => s.setDraft);
  const [atts, setAtts] = useState<(AttachmentRef & { uploading?: boolean; localUrl?: string })[]>([]);
  const [busy, setBusy] = useState(false);
  const [dragging, setDragging] = useState(false);
  const ta = useRef<HTMLTextAreaElement>(null);
  const fileInput = useRef<HTMLInputElement>(null);
  const project = useApp((s) => s.projects.find((p) => p.id === projectId) ?? null);
  const roblox = useApp((s) => s.roblox);

  useEffect(() => {
    const el = ta.current;
    if (!el) return;
    el.style.height = '0px';
    el.style.height = Math.min(el.scrollHeight, window.innerHeight * 0.4) + 'px';
  }, [draft]);

  useEffect(() => {
    if (autoFocus) ta.current?.focus();
  }, [autoFocus, draftKey]);

  const upload = async (files: FileList | File[]) => {
    for (const f of Array.from(files).slice(0, 10)) {
      if (f.size > 25 * 1024 * 1024) {
        toast.error(`${f.name} is larger than 25 MB`);
        continue;
      }
      const tmpId = 'tmp' + Math.random();
      const localUrl = f.type.startsWith('image/') ? URL.createObjectURL(f) : undefined;
      setAtts((a) => [...a, { id: tmpId, name: f.name, mime: f.type, size: f.size, kind: f.type.startsWith('image/') ? 'image' : 'file', uploading: true, localUrl }]);
      try {
        const data = await fileToBase64(f);
        const ref = await api.post<AttachmentRef>('/api/attachments', { name: f.name, mime: f.type || 'application/octet-stream', data, chatId });
        setAtts((a) => a.map((x) => (x.id === tmpId ? { ...ref, localUrl } : x)));
      } catch {
        setAtts((a) => a.filter((x) => x.id !== tmpId));
      }
    }
  };

  const canSend = !running && !busy && (draft.trim().length > 0 || atts.length > 0) && !atts.some((a) => a.uploading);
  const send = async () => {
    if (!canSend) return;
    setBusy(true);
    const text = draft;
    const list = atts;
    setDraft(draftKey, '');
    setAtts([]);
    try {
      await onSend(text, list);
    } catch {
      setDraft(draftKey, text);
      setAtts(list);
    } finally {
      setBusy(false);
      ta.current?.focus();
    }
  };

  const modeHint =
    selection.mode === 'chat'
      ? 'Chat mode — the AI answers here and cannot change files or Studio.'
      : project?.folderPath
        ? `Cowork mode — the AI can read & edit files in ${project.folderPath}${project.robloxEnabled && roblox?.enabled ? ' and use Roblox Studio tools' : ''}. Risky actions ask first.`
        : 'Cowork mode — the AI works in a private scratch folder. Link a project folder to let it edit your files.';

  return (
    <div className="w-full">
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragging(false);
          if (e.dataTransfer.files.length) void upload(e.dataTransfer.files);
        }}
        className={cn(
          'relative rounded-[22px] border bg-surface shadow-[0_8px_30px_-12px_rgb(0_0_0/0.35)] transition-[border,box-shadow] focus-within:border-line-strong',
          dragging ? 'border-accent ring-4 ring-accent-soft' : 'border-line',
        )}
      >
        {atts.length > 0 && (
          <div className="flex flex-wrap gap-2 px-3.5 pt-3">
            {atts.map((a) => (
              <div key={a.id} className="group relative flex h-12 max-w-[220px] items-center gap-2.5 rounded-xl border border-line bg-surface-2 pl-1.5 pr-3">
                {a.kind === 'image' && (a.localUrl || !a.uploading) ? (
                  <img src={a.localUrl ?? `/api/attachments/${a.id}`} className="size-9 rounded-lg object-cover" alt="" />
                ) : (
                  <span className="flex size-9 items-center justify-center rounded-lg bg-surface-3 text-fg-3">{a.kind === 'image' ? <ImageIcon className="size-4" /> : <FileText className="size-4" />}</span>
                )}
                <span className="min-w-0">
                  <span className="block truncate text-[12.5px] font-medium text-fg">{a.name}</span>
                  <span className="block text-[11px] text-fg-3">{a.uploading ? 'Uploading…' : fmtBytes(a.size)}</span>
                </span>
                {a.uploading ? (
                  <Spinner className="size-3.5" />
                ) : (
                  <button onClick={() => setAtts((l) => l.filter((x) => x.id !== a.id))} className="absolute -right-1.5 -top-1.5 hidden size-5 cursor-pointer items-center justify-center rounded-full border border-line bg-surface text-fg-2 shadow group-hover:flex" aria-label="Remove attachment">
                    <X className="size-3" />
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
        <textarea
          ref={ta}
          value={draft}
          onChange={(e) => setDraft(draftKey, e.target.value)}
          onPaste={(e) => {
            const files = Array.from(e.clipboardData.files);
            if (files.length) {
              e.preventDefault();
              void upload(files);
            }
          }}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {
              e.preventDefault();
              void send();
            } else if (e.key === 'Escape' && running) {
              e.preventDefault();
              onStop();
            }
          }}
          rows={1}
          placeholder={selection.mode === 'cowork' ? 'Describe what to build or change…' : 'Message BLOXADE…'}
          className={cn('block w-full resize-none bg-transparent px-5 text-[15px] leading-relaxed text-fg outline-none placeholder:text-fg-3', large ? 'min-h-[76px] pt-4' : 'min-h-[52px] pt-3.5')}
        />
        <div className="flex items-center gap-1.5 px-2.5 pb-2.5 pt-1">
          <input ref={fileInput} type="file" multiple hidden onChange={(e) => e.target.files && upload(e.target.files).finally(() => (e.target.value = ''))} />
          <Tooltip content="Attach files or images">
            <button onClick={() => fileInput.current?.click()} className="inline-flex size-8 cursor-pointer items-center justify-center rounded-full text-fg-2 hover:bg-surface-2 hover:text-fg" aria-label="Attach">
              <Paperclip className="size-[17px]" />
            </button>
          </Tooltip>
          <Segmented
            size="sm"
            value={selection.mode}
            onChange={(m) => onSelectionChange({ mode: m })}
            options={[
              { value: 'chat', label: <><MessagesSquare className="size-3.5" /> Chat</>, title: 'Conversation only — no file or tool access' },
              { value: 'cowork', label: <><Users2 className="size-3.5" /> Cowork</>, title: 'The AI works on your project files (and Roblox Studio) with approvals' },
            ]}
          />
          <ModelPicker value={selection} onChange={onSelectionChange} />
          <div className="flex-1" />
          {selection.mode === 'cowork' && project?.robloxEnabled && (
            <Tooltip content={roblox?.state === 'connected' ? 'Roblox Studio tools available' : 'Roblox Studio not connected yet — BLOXADE connects when the AI needs it'}>
              <span className={cn('mr-1 inline-flex items-center gap-1 rounded-md px-1.5 py-1 text-[11px]', roblox?.state === 'connected' ? 'text-success' : 'text-fg-3')}>
                <Gamepad2 className="size-3.5" /> Studio
              </span>
            </Tooltip>
          )}
          {selection.mode === 'cowork' && project?.folderPath && (
            <Tooltip content={project.folderPath}>
              <span className="mr-1 hidden items-center gap-1 rounded-md px-1.5 py-1 text-[11px] text-fg-3 md:inline-flex">
                <FolderOpen className="size-3.5" /> {project.folderPath.split(/[\\/]/).filter(Boolean).pop()}
              </span>
            </Tooltip>
          )}
          {running ? (
            <Tooltip content="Stop (Esc)">
              <button onClick={onStop} className="inline-flex size-9 cursor-pointer items-center justify-center rounded-full bg-fg text-bg transition-transform hover:scale-105" aria-label="Stop generating">
                <Square className="size-3.5 fill-current" />
              </button>
            </Tooltip>
          ) : (
            <button
              onClick={send}
              disabled={!canSend}
              className="inline-flex size-9 cursor-pointer items-center justify-center rounded-full bg-accent text-accent-fg transition-all hover:brightness-110 disabled:cursor-default disabled:bg-surface-3 disabled:text-fg-3"
              aria-label="Send message"
            >
              {busy ? <Spinner className="size-4 text-current" /> : <ArrowUp className="size-[18px]" strokeWidth={2.4} />}
            </button>
          )}
        </div>
      </div>
      <div className="mt-2 px-3 text-center text-[11.5px] text-fg-3">{modeHint}</div>
    </div>
  );
}
