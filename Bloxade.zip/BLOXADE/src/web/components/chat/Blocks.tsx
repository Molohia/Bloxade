import { memo, useState } from 'react';
import { Brain, ChevronRight, CircleAlert, CircleCheck, CircleX, FilePen, FileText, Gamepad2, Globe, Info, Search, ShieldAlert, Terminal, TriangleAlert, Wrench, Ban } from 'lucide-react';
import type { Block } from '@shared/types';
import { cn } from '../../lib/utils';
import { Markdown, CodeBlock } from './Markdown';
import { Spinner } from '../ui/primitives';

type ToolBlock = Extract<Block, { type: 'tool' }>;

function toolIcon(name: string, server?: string) {
  if (server === 'bloxade_roblox' || name.startsWith('mcp__bloxade_roblox') || name.startsWith('bloxade_roblox.')) return Gamepad2;
  if (/^(Write|Edit|MultiEdit|NotebookEdit|Edit files)$/.test(name)) return FilePen;
  if (/^(Read|NotebookRead)$/.test(name)) return FileText;
  if (/^(Bash|Shell|PowerShell|BashOutput)$/.test(name)) return Terminal;
  if (/^(Grep|Glob|LS|ToolSearch)$/.test(name)) return Search;
  if (/^(WebFetch|WebSearch|Web search)$/.test(name)) return Globe;
  return Wrench;
}

export function prettyToolName(name: string) {
  if (name.startsWith('mcp__')) {
    const [, server, ...rest] = name.split('__');
    const tool = rest.join('__');
    return server === 'bloxade_roblox' ? `Studio · ${tool}` : `${server} · ${tool}`;
  }
  if (name.startsWith('bloxade_roblox.')) return `Studio · ${name.slice('bloxade_roblox.'.length)}`;
  return name;
}

export const ToolCard = memo(function ToolCard({ block }: { block: ToolBlock }) {
  const [open, setOpen] = useState(false);
  const Icon = toolIcon(block.name, block.server);
  const input = block.input && typeof block.input === 'object' ? JSON.stringify(block.input, null, 2) : block.input != null ? String(block.input) : '';
  const isDiff = /^(Edit files)$/.test(block.name) && block.output?.includes('@@');
  return (
    <div className={cn('my-1.5 overflow-hidden rounded-xl border bg-surface/60 transition-colors', block.status === 'error' ? 'border-danger/30' : block.status === 'denied' ? 'border-warning/30' : 'border-line')}>
      <button onClick={() => setOpen(!open)} className="flex w-full cursor-pointer items-center gap-2.5 px-3 py-2 text-left hover:bg-surface-2/60">
        <Icon className="size-3.5 shrink-0 text-fg-3" />
        <span className="shrink-0 text-[12.5px] font-medium text-fg-2">{prettyToolName(block.name)}</span>
        {block.title && <span className="min-w-0 flex-1 truncate font-mono text-[11.75px] text-fg-3">{block.title}</span>}
        {!block.title && <span className="flex-1" />}
        {block.status === 'running' ? (
          <Spinner className="size-3.5" />
        ) : block.status === 'done' ? (
          <CircleCheck className="size-3.5 text-success" />
        ) : block.status === 'denied' ? (
          <Ban className="size-3.5 text-warning" />
        ) : (
          <CircleX className="size-3.5 text-danger" />
        )}
        <ChevronRight className={cn('size-3.5 text-fg-3 transition-transform', open && 'rotate-90')} />
      </button>
      {open && (
        <div className="space-y-2 border-t border-line px-3 py-2.5">
          {input && input !== '{}' && (
            <div>
              <div className="mb-1 text-[11px] font-semibold uppercase tracking-wide text-fg-3">Input</div>
              <pre className="max-h-64 overflow-auto rounded-lg bg-code p-2.5 font-mono text-[11.5px] leading-relaxed text-fg-2">{input}</pre>
            </div>
          )}
          {block.output != null && block.output !== '' && (
            <div>
              <div className="mb-1 text-[11px] font-semibold uppercase tracking-wide text-fg-3">{block.status === 'denied' ? 'Denied' : 'Output'}</div>
              {isDiff ? <CodeBlock code={block.output} lang="diff" /> : <pre className="max-h-80 overflow-auto whitespace-pre-wrap break-words rounded-lg bg-code p-2.5 font-mono text-[11.5px] leading-relaxed text-fg-2">{block.output}</pre>}
            </div>
          )}
        </div>
      )}
    </div>
  );
});

function ToolGroup({ blocks }: { blocks: ToolBlock[] }) {
  const [open, setOpen] = useState(false);
  const running = blocks.some((b) => b.status === 'running');
  if (blocks.length <= 3 || open) {
    return (
      <div>
        {blocks.map((b) => (
          <ToolCard key={b.id} block={b} />
        ))}
        {blocks.length > 3 && (
          <button onClick={() => setOpen(false)} className="ml-1 cursor-pointer text-[12px] text-fg-3 hover:text-fg-2">
            Collapse {blocks.length} steps
          </button>
        )}
      </div>
    );
  }
  const errors = blocks.filter((b) => b.status === 'error').length;
  return (
    <div>
      <button onClick={() => setOpen(true)} className="my-1.5 flex w-full cursor-pointer items-center gap-2.5 rounded-xl border border-line bg-surface/60 px-3 py-2 text-left hover:bg-surface-2/60">
        <Wrench className="size-3.5 text-fg-3" />
        <span className="text-[12.5px] font-medium text-fg-2">{blocks.length} tool steps</span>
        <span className="flex-1 truncate text-[12px] text-fg-3">{[...new Set(blocks.map((b) => prettyToolName(b.name)))].slice(0, 5).join(' · ')}</span>
        {running ? <Spinner className="size-3.5" /> : errors ? <span className="text-[11.5px] text-danger">{errors} failed</span> : <CircleCheck className="size-3.5 text-success" />}
        <ChevronRight className="size-3.5 text-fg-3" />
      </button>
      <ToolCard block={blocks[blocks.length - 1]} />
    </div>
  );
}

function Thinking({ text, live }: { text: string; live: boolean }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="my-1.5">
      <button onClick={() => setOpen(!open)} className="inline-flex cursor-pointer items-center gap-1.5 rounded-lg py-1 text-[12.5px] text-fg-3 hover:text-fg-2">
        <Brain className="size-3.5" />
        <span className={cn(live && 'shimmer')}>{live ? 'Thinking…' : 'Thought process'}</span>
        <ChevronRight className={cn('size-3.5 transition-transform', open && 'rotate-90')} />
      </button>
      {open && <div className="mt-1 border-l-2 border-line pl-3.5 text-[13px] leading-relaxed whitespace-pre-wrap text-fg-3">{text}</div>}
    </div>
  );
}

function Notice({ level, text }: { level: 'info' | 'warning' | 'error'; text: string }) {
  const Icon = level === 'error' ? CircleAlert : level === 'warning' ? TriangleAlert : Info;
  return (
    <div className={cn('my-2 flex items-start gap-2 rounded-lg px-3 py-2 text-[12.5px] leading-relaxed', level === 'error' ? 'bg-danger/10 text-danger' : level === 'warning' ? 'bg-warning/10 text-warning' : 'bg-surface-2 text-fg-2')}>
      <Icon className="mt-0.5 size-3.5 shrink-0" />
      <span>{text}</span>
    </div>
  );
}

/** Renders a message's ordered blocks; consecutive tool calls are grouped. */
export function Blocks({ blocks, streaming }: { blocks: Block[]; streaming: boolean }) {
  const out: React.ReactNode[] = [];
  let toolRun: ToolBlock[] = [];
  const flush = (key: string) => {
    if (toolRun.length) out.push(<ToolGroup key={key} blocks={toolRun} />);
    toolRun = [];
  };
  const lastTextIdx = blocks.map((b) => b.type).lastIndexOf('text');
  blocks.forEach((b, i) => {
    if (!b) return;
    if (b.type === 'tool') {
      toolRun.push(b);
      return;
    }
    flush('tg' + i);
    if (b.type === 'text') out.push(<Markdown key={i} text={b.text} streaming={streaming && i === lastTextIdx && i === blocks.length - 1} />);
    else if (b.type === 'thinking') out.push(<Thinking key={i} text={b.text} live={streaming && i === blocks.length - 1} />);
    else if (b.type === 'notice') out.push(<Notice key={i} level={b.level} text={b.text} />);
  });
  flush('tg-end');
  return <div className="space-y-1">{out}</div>;
}

export function ApprovalHint() {
  return (
    <div className="flex items-center gap-2 text-[12.5px] text-warning">
      <ShieldAlert className="size-3.5" />
      Waiting for your approval…
    </div>
  );
}
