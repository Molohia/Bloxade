import { useMemo, useState } from 'react';
import { Check, ChevronDown, Plus, RefreshCw, Search, UserPlus } from 'lucide-react';
import type { ModelInfo, Provider } from '@shared/types';
import { useApp } from '../../store/app';
import { useShallow } from 'zustand/react/shallow';
import { cn, timeAgo } from '../../lib/utils';
import { navigate, routes } from '../../lib/router';
import { Popover, Select } from '../ui/overlays';
import { Segmented, StatusDot, Tooltip } from '../ui/primitives';
import { ProviderMark, providerName } from '../brand';

export interface Selection {
  provider: Provider;
  accountId: string | null;
  model: string;
  effort: string;
}

export const EFFORT_LABEL: Record<string, string> = { minimal: 'Minimal', low: 'Low', medium: 'Medium', high: 'High', xhigh: 'X-High', max: 'Max', ultra: 'Ultra', none: 'None' };

export function useModelInfo(provider: Provider, model: string): ModelInfo | null {
  const cat = useApp((s) => s.models[provider]);
  return cat?.models.find((m) => m.id === model) ?? null;
}

export function defaultModelFor(provider: Provider): string {
  const s = useApp.getState();
  const fromSettings = s.settings?.providers.defaultModels[provider];
  if (fromSettings) return fromSettings;
  const cat = s.models[provider];
  return cat?.models.find((m) => m.isDefault)?.id ?? cat?.models[0]?.id ?? (provider === 'claude' ? 'default' : '');
}

export function defaultAccountFor(provider: Provider): string | null {
  const accs = useApp.getState().accounts.filter((a) => a.provider === provider && a.enabled);
  return (accs.find((a) => a.isDefault) ?? accs.find((a) => a.status === 'signed_in') ?? accs[0])?.id ?? null;
}

export function ModelPicker({ value, onChange, size = 'md', align = 'start', side = 'top', lockProvider }: { value: Selection; onChange: (v: Partial<Selection>) => void; size?: 'sm' | 'md'; align?: 'start' | 'end'; side?: 'top' | 'bottom'; lockProvider?: boolean }) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  const [custom, setCustom] = useState('');
  const accounts = useApp(useShallow((s) => s.accounts.filter((a) => a.provider === value.provider)));
  const catalog = useApp((s) => s.models[value.provider]);
  const settings = useApp((s) => s.settings);
  const clis = useApp((s) => s.clis);
  const loadModels = useApp((s) => s.loadModels);
  const saveSettings = useApp((s) => s.saveSettings);
  const [showHidden, setShowHidden] = useState(!!settings?.providers.showHiddenModels);
  const [refreshing, setRefreshing] = useState(false);
  const info = catalog?.models.find((m) => m.id === value.model) ?? null;
  const account = accounts.find((a) => a.id === value.accountId) ?? null;

  const groups = useMemo(() => {
    const list = (catalog?.models ?? []).filter((m) => !q || `${m.id} ${m.label} ${m.description ?? ''}`.toLowerCase().includes(q.toLowerCase()));
    return [
      { title: value.provider === 'claude' ? 'Recommended (from Claude Code)' : 'Models (from Codex)', items: list.filter((m) => m.group === 'recommended') },
      { title: 'Specific versions', items: list.filter((m) => m.group === 'versions') },
      { title: 'Hidden models', items: showHidden || q ? list.filter((m) => m.group === 'hidden') : [], hiddenCount: list.filter((m) => m.group === 'hidden').length },
    ];
  }, [catalog, q, showHidden, value.provider]);

  const setProvider = (p: Provider) => {
    if (p === value.provider) return;
    onChange({ provider: p, accountId: defaultAccountFor(p), model: defaultModelFor(p), effort: '' });
    void loadModels(p);
  };

  const label = info?.label ?? (value.model || (value.provider === 'claude' ? 'Default' : 'Default model'));
  const efforts = info?.efforts ?? [];

  return (
    <Popover
      open={open}
      onOpenChange={setOpen}
      align={align}
      side={side}
      className="w-[400px] p-0"
      trigger={
        <button className={cn('inline-flex max-w-[280px] cursor-pointer items-center gap-2 rounded-[10px] text-fg-2 transition-colors hover:bg-surface-2 hover:text-fg', size === 'sm' ? 'h-7 px-2 text-[12px]' : 'h-8 px-2.5 text-[12.5px]')}>
          <ProviderMark provider={value.provider} size="xs" />
          <span className="truncate font-medium">{label}</span>
          {value.effort && <span className="rounded-[5px] bg-surface-3 px-1.5 py-px text-[10.5px] font-semibold uppercase tracking-wide text-fg-3">{EFFORT_LABEL[value.effort] ?? value.effort}</span>}
          {account && accounts.length > 1 && <span className="hidden truncate text-fg-3 sm:inline">· {account.name}</span>}
          <ChevronDown className="size-3.5 shrink-0 text-fg-3" />
        </button>
      }
    >
      <div className="border-b border-line p-3">
        {!lockProvider && (
          <Segmented
            className="w-full [&>button]:flex-1 [&>button]:justify-center"
            value={value.provider}
            onChange={(v) => setProvider(v as Provider)}
            options={[
              { value: 'claude', label: <><ProviderMark provider="claude" size="xs" /> Claude Code</> },
              { value: 'codex', label: <><ProviderMark provider="codex" size="xs" /> Codex</> },
            ]}
          />
        )}
        {clis && !clis[value.provider]?.found && (
          <div className="mt-2.5 rounded-lg bg-warning/10 px-2.5 py-2 text-[12px] text-warning">
            {providerName(value.provider)} CLI was not found on this computer. Install it, then refresh in Settings → AI Providers.
          </div>
        )}
        <div className="mt-2.5 flex items-center gap-2">
          {accounts.length ? (
            <Select
              size="sm"
              value={value.accountId ?? ''}
              onChange={(id) => onChange({ accountId: id })}
              options={accounts.map((a) => ({
                value: a.id,
                label: (
                  <span className="flex items-center gap-2">
                    <StatusDot tone={a.status === 'signed_in' ? 'success' : a.status === 'signed_out' || a.status === 'error' ? 'danger' : 'neutral'} />
                    {a.name}
                    {!a.enabled && <span className="text-fg-3">(disabled)</span>}
                  </span>
                ),
                hint: a.email ?? (a.status === 'signed_in' ? 'Signed in' : 'Not signed in'),
              }))}
            />
          ) : (
            <button onClick={() => (setOpen(false), navigate(routes.accounts(value.provider)))} className="flex h-8 w-full cursor-pointer items-center justify-center gap-2 rounded-lg border border-dashed border-line-strong text-[12.5px] text-fg-2 hover:bg-surface-2">
              <UserPlus className="size-3.5" /> Add a {providerName(value.provider)} account
            </button>
          )}
        </div>
      </div>

      <div className="border-b border-line px-3 pt-2.5">
        <div className="relative">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-fg-3" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search models…" className="h-8 w-full rounded-lg bg-surface-2 pl-8 pr-2 text-[12.5px] outline-none placeholder:text-fg-3" />
        </div>
        <div className="-mx-1 max-h-[300px] overflow-y-auto py-2">
          {groups.map(
            (g) =>
              (g.items.length > 0 || (g.title === 'Hidden models' && (g as any).hiddenCount > 0)) && (
                <div key={g.title} className="mb-1.5">
                  <div className="flex items-center justify-between px-2 pb-1 pt-1.5">
                    <span className="text-[10.5px] font-semibold uppercase tracking-[0.07em] text-fg-3">{g.title}</span>
                    {g.title === 'Hidden models' && !q && (
                      <button onClick={() => setShowHidden(!showHidden)} className="cursor-pointer text-[11px] text-accent-text hover:underline">
                        {showHidden ? 'Hide' : `Show ${(g as any).hiddenCount}`}
                      </button>
                    )}
                  </div>
                  {g.items.map((m) => (
                    <button
                      key={m.id}
                      onClick={() => {
                        const eff = value.effort && m.efforts.includes(value.effort) ? value.effort : '';
                        onChange({ model: m.id, effort: eff });
                      }}
                      className={cn('flex w-full cursor-pointer items-start gap-2.5 rounded-lg px-2 py-1.5 text-left hover:bg-surface-2', m.id === value.model && 'bg-accent-softer')}
                    >
                      <span className="mt-0.5 flex size-4 shrink-0 items-center justify-center">{m.id === value.model && <Check className="size-3.5 text-accent" />}</span>
                      <span className="min-w-0 flex-1">
                        <span className="flex items-center gap-2">
                          <span className="truncate text-[13px] font-medium text-fg">{m.label}</span>
                          {m.isDefault && <span className="rounded bg-surface-3 px-1 text-[10px] text-fg-3">default</span>}
                          {m.note && <Tooltip content={m.note}><span className="size-1.5 rounded-full bg-warning" /></Tooltip>}
                        </span>
                        <span className="block truncate text-[11.5px] text-fg-3">
                          <span className="font-mono">{m.id}</span>
                          {m.resolvedModel && m.resolvedModel !== m.id ? ` → ${m.resolvedModel}` : ''}
                          {m.description ? ` · ${m.description}` : ''}
                        </span>
                      </span>
                    </button>
                  ))}
                </div>
              ),
          )}
          <div className="mt-1 flex items-center gap-1.5 px-1 pb-1">
            <input value={custom} onChange={(e) => setCustom(e.target.value)} placeholder="Custom model ID…" className="h-7 flex-1 rounded-md bg-surface-2 px-2 font-mono text-[11.5px] outline-none placeholder:font-sans placeholder:text-fg-3" />
            <button
              disabled={!/^[A-Za-z0-9._:\-[\]/@+]{1,120}$/.test(custom)}
              onClick={async () => {
                const list = [...new Set([...(settings?.providers.customModels[value.provider] ?? []), custom])];
                await saveSettings({ providers: { customModels: { [value.provider]: list } } });
                await loadModels(value.provider);
                onChange({ model: custom, effort: '' });
                setCustom('');
              }}
              className="inline-flex h-7 cursor-pointer items-center gap-1 rounded-md bg-surface-3 px-2 text-[11.5px] text-fg-2 hover:text-fg disabled:opacity-40"
            >
              <Plus className="size-3" /> Use
            </button>
          </div>
        </div>
      </div>

      <div className="p-3">
        <div className="mb-1.5 flex items-center justify-between">
          <span className="text-[11px] font-semibold uppercase tracking-[0.07em] text-fg-3">Effort</span>
          {info?.defaultEffort && <span className="text-[11px] text-fg-3">model default: {EFFORT_LABEL[info.defaultEffort] ?? info.defaultEffort}</span>}
        </div>
        {efforts.length ? (
          <div className="flex flex-wrap gap-1">
            {['', ...efforts].map((e) => (
              <button
                key={e || 'auto'}
                onClick={() => onChange({ effort: e })}
                className={cn('h-7 cursor-pointer rounded-lg border px-2.5 text-[12px] font-medium transition-colors', value.effort === e ? 'border-accent/60 bg-accent-soft text-accent-text' : 'border-line text-fg-2 hover:bg-surface-2')}
              >
                {e ? EFFORT_LABEL[e] ?? e : 'Auto'}
              </button>
            ))}
          </div>
        ) : (
          <div className="text-[12px] text-fg-3">This model does not report effort levels.</div>
        )}
        <div className="mt-3 flex items-center justify-between text-[11px] text-fg-3">
          <span>{catalog?.source === 'discovered' ? `Reported by your ${providerName(value.provider)} CLI · ${timeAgo(catalog.discoveredAt)}` : catalog?.error ? `Using built-in list (${catalog.error})` : 'Built-in list — refresh to ask your CLI'}</span>
          <button
            onClick={async () => {
              setRefreshing(true);
              await loadModels(value.provider, true);
              setRefreshing(false);
            }}
            className="inline-flex cursor-pointer items-center gap-1 rounded-md px-1.5 py-0.5 hover:bg-surface-2 hover:text-fg-2"
          >
            <RefreshCw className={cn('size-3', refreshing && 'animate-spin')} /> Refresh
          </button>
        </div>
      </div>
    </Popover>
  );
}
