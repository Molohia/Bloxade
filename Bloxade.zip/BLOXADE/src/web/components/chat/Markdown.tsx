import { memo, useMemo, useState } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import hljs from 'highlight.js/lib/core';
import lua from 'highlight.js/lib/languages/lua';
import typescript from 'highlight.js/lib/languages/typescript';
import javascript from 'highlight.js/lib/languages/javascript';
import python from 'highlight.js/lib/languages/python';
import json from 'highlight.js/lib/languages/json';
import bash from 'highlight.js/lib/languages/bash';
import shell from 'highlight.js/lib/languages/shell';
import powershell from 'highlight.js/lib/languages/powershell';
import css from 'highlight.js/lib/languages/css';
import xml from 'highlight.js/lib/languages/xml';
import rust from 'highlight.js/lib/languages/rust';
import go from 'highlight.js/lib/languages/go';
import cpp from 'highlight.js/lib/languages/cpp';
import csharp from 'highlight.js/lib/languages/csharp';
import java from 'highlight.js/lib/languages/java';
import diff from 'highlight.js/lib/languages/diff';
import yaml from 'highlight.js/lib/languages/yaml';
import markdown from 'highlight.js/lib/languages/markdown';
import sql from 'highlight.js/lib/languages/sql';
import ini from 'highlight.js/lib/languages/ini';
import { Check, Copy, WrapText } from 'lucide-react';
import { cn } from '../../lib/utils';

hljs.registerLanguage('lua', lua);
hljs.registerLanguage('luau', lua);
hljs.registerLanguage('typescript', typescript);
hljs.registerLanguage('ts', typescript);
hljs.registerLanguage('tsx', typescript);
hljs.registerLanguage('javascript', javascript);
hljs.registerLanguage('js', javascript);
hljs.registerLanguage('jsx', javascript);
hljs.registerLanguage('python', python);
hljs.registerLanguage('py', python);
hljs.registerLanguage('json', json);
hljs.registerLanguage('bash', bash);
hljs.registerLanguage('sh', bash);
hljs.registerLanguage('shell', shell);
hljs.registerLanguage('powershell', powershell);
hljs.registerLanguage('ps1', powershell);
hljs.registerLanguage('css', css);
hljs.registerLanguage('html', xml);
hljs.registerLanguage('xml', xml);
hljs.registerLanguage('rust', rust);
hljs.registerLanguage('go', go);
hljs.registerLanguage('cpp', cpp);
hljs.registerLanguage('c', cpp);
hljs.registerLanguage('csharp', csharp);
hljs.registerLanguage('cs', csharp);
hljs.registerLanguage('java', java);
hljs.registerLanguage('diff', diff);
hljs.registerLanguage('yaml', yaml);
hljs.registerLanguage('yml', yaml);
hljs.registerLanguage('markdown', markdown);
hljs.registerLanguage('md', markdown);
hljs.registerLanguage('sql', sql);
hljs.registerLanguage('toml', ini);
hljs.registerLanguage('ini', ini);

export function highlight(code: string, lang?: string): string {
  try {
    if (lang && hljs.getLanguage(lang)) return hljs.highlight(code, { language: lang, ignoreIllegals: true }).value;
    if (code.length < 20000) return hljs.highlightAuto(code, ['lua', 'typescript', 'javascript', 'python', 'json', 'bash']).value;
  } catch {
    /* fall through */
  }
  return code.replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' })[c]!);
}

export function CopyButton({ text, className, label = 'Copy' }: { text: string; className?: string; label?: string }) {
  const [done, setDone] = useState(false);
  return (
    <button
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(text);
        } catch {
          const ta = document.createElement('textarea');
          ta.value = text;
          document.body.appendChild(ta);
          ta.select();
          document.execCommand('copy');
          ta.remove();
        }
        setDone(true);
        setTimeout(() => setDone(false), 1400);
      }}
      className={cn('inline-flex cursor-pointer items-center gap-1.5 rounded-md px-2 py-1 text-[11.5px] font-medium text-fg-3 hover:bg-surface-3 hover:text-fg', className)}
    >
      {done ? <Check className="size-3.5 text-success" /> : <Copy className="size-3.5" />}
      {done ? 'Copied' : label}
    </button>
  );
}

export const CodeBlock = memo(function CodeBlock({ code, lang }: { code: string; lang?: string }) {
  const [wrap, setWrap] = useState(false);
  const html = useMemo(() => highlight(code, lang), [code, lang]);
  const lines = code.split('\n').length;
  return (
    <div className="group/code my-3.5 overflow-hidden rounded-xl border border-line bg-code">
      <div className="flex h-9 items-center justify-between border-b border-line bg-surface-2/50 pl-3.5 pr-1.5">
        <span className="font-mono text-[11.5px] text-fg-3">{lang || 'code'}{lines > 8 ? ` · ${lines} lines` : ''}</span>
        <div className="flex items-center gap-0.5">
          <button onClick={() => setWrap(!wrap)} className={cn('cursor-pointer rounded-md p-1.5 text-fg-3 hover:bg-surface-3 hover:text-fg', wrap && 'text-fg')} title="Toggle line wrap">
            <WrapText className="size-3.5" />
          </button>
          <CopyButton text={code} />
        </div>
      </div>
      <pre className={cn('overflow-x-auto px-4 py-3.5 font-mono text-[12.75px] leading-[1.65]', wrap && 'whitespace-pre-wrap break-words')}>
        <code className="hljs" dangerouslySetInnerHTML={{ __html: html }} />
      </pre>
    </div>
  );
});

const components = {
  code({ className, children, ...props }: any) {
    const text = String(children ?? '');
    const m = /language-([\w+-]+)/.exec(className || '');
    const isBlock = !!m || text.includes('\n');
    if (!isBlock) return <code {...props}>{children}</code>;
    return <CodeBlock code={text.replace(/\n$/, '')} lang={m?.[1]?.toLowerCase()} />;
  },
  pre({ children }: any) {
    return <>{children}</>;
  },
  a({ href, children }: any) {
    return (
      <a href={href} target="_blank" rel="noreferrer noopener">
        {children}
      </a>
    );
  },
};

export const Markdown = memo(function Markdown({ text, streaming }: { text: string; streaming?: boolean }) {
  return (
    <div className={cn('prose-bx', streaming && 'caret-last')}>
      <ReactMarkdown remarkPlugins={[remarkGfm]} components={components}>
        {text}
      </ReactMarkdown>
    </div>
  );
});
