import { memo, useState } from 'react';
import { CircleAlert, Copy, FileText, GitBranch, Pencil, RefreshCw, ShieldAlert, Check, UserCog } from 'lucide-react';
import type { Message } from '@shared/types';
import { api } from '../../lib/api';
import { cn, duration, fmtNum } from '../../lib/utils';
import { navigate, routes } from '../../lib/router';
import { useApp } from '../../store/app';
import { Blocks } from './Blocks';
import { ProviderMark, providerName } from '../brand';
import { Button, Textarea, Tooltip } from '../ui/primitives';
import { EFFORT_LABEL } from './ModelPicker';
import { confirmDialog } from '../ui/overlays';

function Action({ label, onClick, children }: { label: string; onClick: () => void; children: React.ReactNode }) {
  return (
    <Tooltip content={label}>
      <button onClick={onClick} aria-label={label} className="inline-flex size-7 cursor-pointer items-center justify-center rounded-lg text-fg-3 transition-colors hover:bg-surface-2 hover:text-fg">
        {children}
      </button>
    </Tooltip>
  );
}

function CopyAction({ text }: { text: string }) {
  const [done, setDone] = useState(false);
  return (
    <Action
      label={done ? 'Copied' : 'Copy'}
      onClick={() => {
        void navigator.clipboard.writeText(text).catch(() => undefined);
        setDone(true);
        setTimeout(() => setDone(false), 1300);
      }}
    >
      {done ? <Check className="size-3.5 text-success" /> : <Copy className="size-3.5" />}
    </Action>
  );
}

function UserMessage({ m, canEdit }: { m: Message; canEdit: boolean }) {
  const [editing, setEditing] = useState(false);
  const [text, setText] = useState(m.content);
  const submit = async () => {
    const r = await confirmDialog({ title: 'Edit and resend?', body: 'Messages after this one will be replaced by the new answer. Use “Branch” instead if you want to keep both versions.', confirmLabel: 'Resend' });
    if (!r.ok) return;
    setEditing(false);
    await api.post(`/api/chats/${m.chatId}/messages/${m.id}/edit`, { text });
  };
  return (
    <div className="group flex flex-col items-end">
      {m.attachments.length > 0 && (
        <div className="mb-2 flex max-w-[85%] flex-wrap justify-end gap-2">
          {m.attachments.map((a) =>
            a.kind === 'image' ? (
              <a key={a.id} href={`/api/attachments/${a.id}`} target="_blank" rel="noreferrer">
                <img src={`/api/attachments/${a.id}`} alt={a.name} className="max-h-48 max-w-[260px] rounded-2xl border border-line object-cover" />
              </a>
            ) : (
              <a key={a.id} href={`/api/attachments/${a.id}`} target="_blank" rel="noreferrer" className="flex items-center gap-2 rounded-xl border border-line bg-surface px-3 py-2 text-[12.5px] text-fg-2 hover:bg-surface-2">
                <FileText className="size-4 text-fg-3" /> {a.name}
              </a>
            ),
          )}
        </div>
      )}
      {editing ? (
        <div className="w-full max-w-[85%] rounded-2xl border border-line-strong bg-surface p-2">
          <Textarea value={text} onChange={(e) => setText(e.target.value)} rows={Math.min(12, text.split('\n').length + 1)} className="border-0 bg-transparent focus:ring-0" autoFocus />
          <div className="flex justify-end gap-2 px-1 pb-1">
            <Button size="sm" variant="ghost" onClick={() => setEditing(false)}>
              Cancel
            </Button>
            <Button size="sm" variant="primary" onClick={submit} disabled={!text.trim()}>
              Send
            </Button>
          </div>
        </div>
      ) : (
        m.content && <div className="max-w-[85%] whitespace-pre-wrap break-words rounded-[20px] rounded-br-md bg-surface-2 px-4 py-2.5 text-[length:var(--chat-font)] leading-relaxed text-fg">{m.content}</div>
      )}
      {!editing && (
        <div className="mt-1 flex items-center gap-0.5 opacity-0 transition-opacity group-hover:opacity-100">
          <CopyAction text={m.content} />
          {canEdit && (
            <Action label="Edit" onClick={() => (setText(m.content), setEditing(true))}>
              <Pencil className="size-3.5" />
            </Action>
          )}
        </div>
      )}
    </div>
  );
}

function AssistantMessage({ m, isLast }: { m: Message; isLast: boolean }) {
  const account = useApp((s) => s.accounts.find((a) => a.id === m.accountId));
  const waiting = useApp((s) => s.approvals.some((a) => a.requester.id === m.chatId));
  const streaming = m.status === 'streaming';
  const authError = m.error && /sign(ed)? in|not signed|login|account/i.test(m.error);
  const u = m.usage;
  const usageText = u
    ? [
        u.verified ? `Verified by ${m.provider === 'claude' ? 'Claude Code' : 'Codex'}` : 'Estimate',
        u.inputTokens != null ? `${fmtNum((u.inputTokens ?? 0) + (u.cacheReadTokens ?? 0) + (u.cacheWriteTokens ?? 0))} input (${fmtNum(u.cacheReadTokens ?? 0)} cached)` : null,
        u.outputTokens != null ? `${fmtNum(u.outputTokens)} output` : null,
        u.costUsd != null ? `$${u.costUsd.toFixed(4)} API-equivalent` : null,
        m.durationMs ? duration(m.durationMs) : null,
      ]
        .filter(Boolean)
        .join(' · ')
    : m.durationMs
      ? duration(m.durationMs)
      : '';
  return (
    <div className="group">
      <div className="mb-2 flex items-center gap-2 text-[12px] text-fg-3">
        {m.provider && <ProviderMark provider={m.provider} size="sm" />}
        <span className="font-medium text-fg-2">{m.provider ? providerName(m.provider) : 'Assistant'}</span>
        {m.model && <span className="font-mono text-[11px]">{m.model}</span>}
        {m.effort && <span className="rounded bg-surface-2 px-1 text-[10px] uppercase tracking-wide">{EFFORT_LABEL[m.effort] ?? m.effort}</span>}
        {account && <span className="hidden sm:inline">· {account.name}</span>}
        {m.mode === 'cowork' && <span className="rounded bg-accent-softer px-1.5 text-[10.5px] text-accent-text">Cowork</span>}
      </div>
      {m.blocks.length === 0 && streaming && (
        <div className="py-1 text-[14px]">
          <span className="shimmer font-medium">{m.provider === 'codex' ? 'Starting Codex…' : 'Starting Claude Code…'}</span>
        </div>
      )}
      <Blocks blocks={m.blocks} streaming={streaming} />
      {waiting && streaming && (
        <div className="mt-2 inline-flex items-center gap-2 rounded-lg bg-warning/10 px-3 py-1.5 text-[12.5px] text-warning">
          <ShieldAlert className="size-3.5" /> Waiting for your approval — see the request in the top-right corner
        </div>
      )}
      {m.status === 'error' && (
        <div className="mt-3 rounded-xl border border-danger/25 bg-danger/[0.07] px-4 py-3">
          <div className="flex items-start gap-2.5">
            <CircleAlert className="mt-0.5 size-4 shrink-0 text-danger" />
            <div className="min-w-0 flex-1">
              <div className="text-[13px] font-medium text-fg">Something went wrong</div>
              <div className="mt-0.5 whitespace-pre-wrap break-words text-[12.5px] leading-relaxed text-fg-2">{m.error}</div>
              <div className="mt-2.5 flex gap-2">
                {isLast && (
                  <Button size="xs" variant="secondary" icon={<RefreshCw className="size-3.5" />} onClick={() => api.post(`/api/chats/${m.chatId}/regenerate`)}>
                    Retry
                  </Button>
                )}
                {authError && (
                  <Button size="xs" variant="ghost" icon={<UserCog className="size-3.5" />} onClick={() => navigate(routes.accounts(m.provider ?? undefined))}>
                    Open accounts
                  </Button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
      {m.status === 'cancelled' && <div className="mt-2 text-[12px] text-fg-3">Stopped.</div>}
      {!streaming && (
        <div className={cn('mt-1.5 flex items-center gap-0.5 transition-opacity', isLast ? 'opacity-100' : 'opacity-0 group-hover:opacity-100')}>
          {m.content && <CopyAction text={m.content} />}
          {isLast && (
            <Action label="Regenerate" onClick={() => api.post(`/api/chats/${m.chatId}/regenerate`)}>
              <RefreshCw className="size-3.5" />
            </Action>
          )}
          <Action
            label="Branch into a new chat"
            onClick={async () => {
              const c = await api.post<{ id: string }>(`/api/chats/${m.chatId}/branch`, { messageId: m.id });
              navigate(routes.chat(c.id));
            }}
          >
            <GitBranch className="size-3.5" />
          </Action>
          {usageText && <span className="ml-1.5 text-[11.5px] text-fg-3">{usageText}</span>}
        </div>
      )}
    </div>
  );
}

export const MessageItem = memo(function MessageItem({ m, isLast, canEdit }: { m: Message; isLast: boolean; canEdit: boolean }) {
  return <div className="rise">{m.role === 'user' ? <UserMessage m={m} canEdit={canEdit} /> : <AssistantMessage m={m} isLast={isLast} />}</div>;
});
