import { useEffect, useState } from 'react';
import { ShieldAlert, Terminal, FilePen, Gamepad2, GitMerge, Wrench } from 'lucide-react';
import type { Approval } from '@shared/types';
import { useApp } from '../store/app';
import { api } from '../lib/api';
import { cn } from '../lib/utils';
import { Button } from './ui/primitives';

function Countdown({ until }: { until: number }) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);
  const s = Math.max(0, Math.round((until - now) / 1000));
  return <span>{s > 90 ? `${Math.round(s / 60)}m` : `${s}s`}</span>;
}

function ApprovalCard({ a }: { a: Approval }) {
  const [busy, setBusy] = useState(false);
  const decide = async (allow: boolean, remember: 'once' | 'session' = 'once') => {
    setBusy(true);
    try {
      await api.post(`/api/approvals/${a.id}`, { allow, remember });
    } finally {
      setBusy(false);
    }
  };
  const Icon = a.kind === 'command' ? Terminal : a.kind === 'file_edit' ? FilePen : a.kind === 'studio' ? Gamepad2 : a.kind === 'conflict' ? GitMerge : Wrench;
  return (
    <div className={cn('rise w-[400px] overflow-hidden rounded-2xl border bg-surface shadow-pop', a.kind === 'conflict' ? 'border-danger/40' : 'border-warning/35')}>
      <div className="flex items-start gap-3 px-4 pt-3.5">
        <span className={cn('mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-xl', a.kind === 'conflict' ? 'bg-danger/12 text-danger' : 'bg-warning/12 text-warning')}>
          <Icon className="size-4" />
        </span>
        <div className="min-w-0 flex-1">
          <div className="text-[13.5px] font-semibold text-fg">{a.title}</div>
          <div className="mt-0.5 text-[12px] text-fg-3">
            {a.requester.label} · auto-deny in <Countdown until={a.expiresAt} />
          </div>
        </div>
      </div>
      <pre className="mx-4 mt-2.5 max-h-44 overflow-auto whitespace-pre-wrap break-words rounded-lg bg-code p-2.5 font-mono text-[11.5px] leading-relaxed text-fg-2">{a.detail}</pre>
      <div className="flex items-center justify-end gap-2 px-4 py-3">
        <Button size="sm" variant="ghost" disabled={busy} onClick={() => decide(false)}>
          Deny
        </Button>
        {a.kind !== 'conflict' && (
          <Button size="sm" variant="secondary" disabled={busy} onClick={() => decide(true, 'session')} title="Allow similar requests from this chat/agent until it finishes">
            Allow for session
          </Button>
        )}
        <Button size="sm" variant="primary" disabled={busy} onClick={() => decide(true)}>
          Allow once
        </Button>
      </div>
    </div>
  );
}

export function ApprovalCenter() {
  const approvals = useApp((s) => s.approvals);
  if (!approvals.length) return null;
  return (
    <div className="pointer-events-none fixed right-5 top-14 z-[55] flex flex-col items-end gap-3">
      {approvals.length > 2 && (
        <div className="pointer-events-auto flex items-center gap-2 rounded-full border border-warning/30 bg-surface px-3 py-1.5 text-[12px] text-warning shadow-pop">
          <ShieldAlert className="size-3.5" /> {approvals.length} requests waiting
        </div>
      )}
      {approvals.slice(0, 2).map((a) => (
        <div key={a.id} className="pointer-events-auto">
          <ApprovalCard a={a} />
        </div>
      ))}
    </div>
  );
}
