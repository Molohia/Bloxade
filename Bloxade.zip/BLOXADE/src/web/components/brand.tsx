import { Braces, Sparkle } from 'lucide-react';
import type { Provider } from '@shared/types';
import { cn } from '../lib/utils';

export function LogoMark({ size = 22, className }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" className={className} aria-hidden>
      <rect x="2.5" y="2.5" width="8.5" height="8.5" rx="2.4" fill="var(--accent)" />
      <rect x="13" y="2.5" width="8.5" height="8.5" rx="2.4" fill="var(--accent)" opacity="0.45" />
      <rect x="2.5" y="13" width="8.5" height="8.5" rx="2.4" fill="var(--accent)" opacity="0.45" />
      <rect x="13" y="13" width="8.5" height="8.5" rx="2.4" fill="var(--accent)" opacity="0.85" />
    </svg>
  );
}

export function Wordmark({ className }: { className?: string }) {
  return (
    <span className={cn('inline-flex items-center gap-2', className)}>
      <LogoMark />
      <span className="text-[14px] font-bold tracking-[0.16em] text-fg">BLOXADE</span>
    </span>
  );
}

/** Original BLOXADE provider glyphs (not the providers' logos). */
export function ProviderMark({ provider, size = 'md', className }: { provider: Provider; size?: 'xs' | 'sm' | 'md' | 'lg'; className?: string }) {
  const box = { xs: 'size-4 rounded-[5px]', sm: 'size-5 rounded-md', md: 'size-7 rounded-lg', lg: 'size-10 rounded-xl' }[size];
  const icon = { xs: 'size-2.5', sm: 'size-3', md: 'size-4', lg: 'size-5' }[size];
  const Icon = provider === 'claude' ? Sparkle : Braces;
  return (
    <span className={cn('inline-flex shrink-0 items-center justify-center', box, provider === 'claude' ? 'bg-claude/15 text-claude' : 'bg-codex/15 text-codex', className)}>
      <Icon className={icon} strokeWidth={2.2} />
    </span>
  );
}

export const providerName = (p: Provider) => (p === 'claude' ? 'Claude Code' : 'Codex');
