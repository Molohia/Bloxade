import { useEffect, useState } from 'react';
import { ArrowLeft, ArrowRight, Check, CircleCheck, CircleX, FolderOpen, Gamepad2, Laptop, Plus, RefreshCw, Sparkles } from 'lucide-react';
import { toast } from 'sonner';
import type { Account, Project, Provider } from '@shared/types';
import { useApp } from '../store/app';
import { api } from '../lib/api';
import { cn } from '../lib/utils';
import { navigate, routes } from '../lib/router';
import { THEMES, ACCENTS } from '../lib/theme';
import { Badge, Button, Spinner, StatusDot } from '../components/ui/primitives';
import { LogoMark, ProviderMark, providerName } from '../components/brand';
import { AddAccountDialog, statusInfo } from './Accounts';
import { ProjectForm } from '../components/ProjectDialogs';
import { PROJECT_COLORS } from '../components/icons';

const STEPS = ['Welcome', 'Detect tools', 'Accounts', 'Roblox Studio', 'Theme', 'First project', 'Ready'];

export function Onboarding() {
  const [step, setStep] = useState(0);
  const clis = useApp((s) => s.clis);
  const accounts = useApp((s) => s.accounts);
  const roblox = useApp((s) => s.roblox);
  const settings = useApp((s) => s.settings);
  const saveSettings = useApp((s) => s.saveSettings);
  const [checking, setChecking] = useState(false);
  const [adding, setAdding] = useState<Provider | null>(null);
  const [testing, setTesting] = useState(false);
  const [proj, setProj] = useState<Partial<Project> & { createFolder?: boolean }>({ name: '', icon: 'cuboid', color: PROJECT_COLORS[0], robloxEnabled: true });
  const [created, setCreated] = useState<Project | null>(null);

  const detect = async () => {
    setChecking(true);
    try {
      const r = await api.get<NonNullable<typeof clis>>('/api/providers?refresh=1');
      useApp.setState({ clis: r });
    } finally {
      setChecking(false);
    }
  };
  useEffect(() => {
    if (step === 1) void detect();
  }, [step]);

  const addSystem = async (p: Provider) => {
    const a = await api.post<Account>('/api/accounts', { provider: p, useSystem: true });
    useApp.getState().apply('account.updated', a);
  };
  const finish = async (go: 'chat' | 'project') => {
    await saveSettings({ general: { onboardingComplete: true } });
    if (go === 'project' && created) navigate(routes.project(created.id));
    else navigate(routes.newChat());
  };

  const body = (() => {
    switch (step) {
      case 0:
        return (
          <div className="text-center">
            <LogoMark size={56} className="mx-auto" />
            <h1 className="mt-6 text-[30px] font-semibold tracking-[-0.03em]">Welcome to BLOXADE</h1>
            <p className="mx-auto mt-3 max-w-md text-[14.5px] leading-relaxed text-fg-3">Your local AI workspace for building Roblox games with Claude Code and Codex — chats, projects, coordinated agents and Roblox Studio in one place.</p>
            <div className="mx-auto mt-8 grid max-w-lg grid-cols-3 gap-3 text-left">
              {[
                ['Runs on your PC', 'Everything stays on 127.0.0.1'],
                ['Your subscriptions', 'Sign in with the official CLIs'],
                ['Studio built-in', 'Official Roblox MCP'],
              ].map(([t, d]) => (
                <div key={t} className="rounded-xl border border-line bg-surface-2/40 p-3">
                  <div className="text-[12.5px] font-medium">{t}</div>
                  <div className="mt-0.5 text-[11.5px] text-fg-3">{d}</div>
                </div>
              ))}
            </div>
          </div>
        );
      case 1:
        return (
          <div>
            <h2 className="text-[20px] font-semibold">Detecting Claude Code and Codex</h2>
            <p className="mt-1.5 text-[13.5px] text-fg-3">BLOXADE drives the official command-line tools installed on this computer.</p>
            <div className="mt-6 space-y-3">
              {(['claude', 'codex'] as Provider[]).map((p) => {
                const c = clis?.[p];
                return (
                  <div key={p} className="flex items-center gap-4 rounded-2xl border border-line bg-surface-2/30 p-4">
                    <ProviderMark provider={p} size="lg" />
                    <div className="min-w-0 flex-1">
                      <div className="text-[14px] font-medium">{providerName(p)}</div>
                      <div className="truncate text-[12px] text-fg-3">{checking ? 'Checking…' : c?.found ? `${c.version} · ${c.path}` : p === 'claude' ? 'Not found. Install in PowerShell: irm https://claude.ai/install.ps1 | iex' : 'Not found. Install Codex from developers.openai.com/codex'}</div>
                    </div>
                    {checking ? <Spinner /> : c?.found ? <CircleCheck className="size-5 text-success" /> : <CircleX className="size-5 text-danger" />}
                  </div>
                );
              })}
            </div>
            <div className="mt-4 flex items-center justify-between text-[12.5px] text-fg-3">
              <span>You only need one of them to get started.</span>
              <Button size="sm" variant="ghost" icon={<RefreshCw className={cn('size-3.5', checking && 'animate-spin')} />} onClick={detect}>
                Check again
              </Button>
            </div>
          </div>
        );
      case 2:
        return (
          <div>
            <h2 className="text-[20px] font-semibold">Connect your AI accounts</h2>
            <p className="mt-1.5 text-[13.5px] text-fg-3">Use the sign-in you already have on this PC, or add isolated accounts. You can add more later.</p>
            <div className="mt-6 grid grid-cols-1 gap-3 md:grid-cols-2">
              {(['claude', 'codex'] as Provider[]).map((p) => {
                const list = accounts.filter((a) => a.provider === p);
                const hasSystem = list.some((a) => a.isSystem);
                return (
                  <div key={p} className="rounded-2xl border border-line bg-surface-2/30 p-4">
                    <div className="flex items-center gap-2.5">
                      <ProviderMark provider={p} size="md" />
                      <span className="text-[14px] font-medium">{providerName(p)}</span>
                    </div>
                    <div className="mt-3 space-y-1.5">
                      {list.map((a) => (
                        <div key={a.id} className="flex items-center gap-2 text-[12.5px]">
                          <StatusDot tone={statusInfo(a).tone === 'neutral' ? 'neutral' : (statusInfo(a).tone as any)} pulse={a.status === 'checking'} />
                          <span className="flex-1 truncate">{a.name}</span>
                          <span className="text-fg-3">{statusInfo(a).label}</span>
                        </div>
                      ))}
                    </div>
                    <div className="mt-3 flex flex-wrap gap-2">
                      {!hasSystem && (
                        <Button size="xs" variant="secondary" icon={<Laptop className="size-3.5" />} disabled={!clis?.[p].found} onClick={() => addSystem(p)}>
                          Use this PC’s sign-in
                        </Button>
                      )}
                      <Button size="xs" variant="ghost" icon={<Plus className="size-3.5" />} disabled={!clis?.[p].found} onClick={() => setAdding(p)}>
                        Add account
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
            <AddAccountDialog open={!!adding} onOpenChange={(o) => !o && setAdding(null)} provider={adding ?? undefined} />
          </div>
        );
      case 3:
        return (
          <div>
            <h2 className="text-[20px] font-semibold">Connect Roblox Studio</h2>
            <ol className="mt-4 space-y-2 text-[13.5px] leading-relaxed text-fg-2">
              <li>1. Open Roblox Studio and open your place.</li>
              <li>2. Open <b>Assistant</b> → <b>⋯</b> → <b>Manage MCP Servers</b>.</li>
              <li>3. Turn on <b>Enable Studio as MCP server</b>.</li>
              <li>4. Press <b>Test connection</b> below.</li>
            </ol>
            <div className="mt-5 flex items-center gap-4 rounded-2xl border border-line bg-surface-2/30 p-4">
              <Gamepad2 className={cn('size-7', roblox?.state === 'connected' ? 'text-success' : 'text-fg-3')} />
              <div className="min-w-0 flex-1">
                <div className="text-[14px] font-medium">{roblox?.state === 'connected' ? 'Connected' : roblox?.state === 'error' ? 'Not connected yet' : 'Not tested'}</div>
                <div className="truncate text-[12px] text-fg-3">{roblox?.state === 'connected' ? roblox.studios.map((s) => s.name).join(', ') || 'No open place reported' : roblox?.error?.split('\n')[0] ?? 'You can also do this later from Connections → Roblox Studio.'}</div>
              </div>
              <Button
                variant="primary"
                size="sm"
                loading={testing}
                onClick={async () => {
                  setTesting(true);
                  try {
                    const r = await api.post<{ ok: boolean; message: string }>('/api/roblox/test');
                    r.ok ? toast.success(r.message) : toast.error(r.message);
                  } finally {
                    setTesting(false);
                  }
                }}
              >
                Test connection
              </Button>
            </div>
          </div>
        );
      case 4:
        return (
          <div>
            <h2 className="text-[20px] font-semibold">Pick a look</h2>
            <p className="mt-1.5 text-[13.5px] text-fg-3">Change it any time in Settings → Appearance.</p>
            <div className="mt-6 grid grid-cols-5 gap-2.5">
              {THEMES.map((t) => (
                <button key={t.id} onClick={() => saveSettings({ appearance: { theme: t.id } })} className={cn('cursor-pointer overflow-hidden rounded-xl border text-left', settings?.appearance.theme === t.id ? 'border-accent ring-2 ring-accent-soft' : 'border-line')}>
                  <div className="flex h-16 gap-1 p-1.5" style={{ background: t.swatch[0] }}>
                    <div className="w-1/4 rounded" style={{ background: t.swatch[1] }} />
                    <div className="flex-1 space-y-1 pt-1">
                      <div className="h-1 w-3/4 rounded-full" style={{ background: t.swatch[2] }} />
                      <div className="h-1 w-1/2 rounded-full opacity-50" style={{ background: t.swatch[2] }} />
                    </div>
                  </div>
                  <div className="px-2 py-1.5 text-[11.5px] font-medium">{t.label}</div>
                </button>
              ))}
            </div>
            <div className="mt-5 flex gap-2.5">
              {ACCENTS.map((c) => (
                <button key={c} onClick={() => saveSettings({ appearance: { accent: c } })} className={cn('flex size-8 cursor-pointer items-center justify-center rounded-full ring-offset-2 ring-offset-surface', settings?.appearance.accent.toLowerCase() === c.toLowerCase() && 'ring-2 ring-fg/50')} style={{ background: c }}>
                  {settings?.appearance.accent.toLowerCase() === c.toLowerCase() && <Check className="size-4 text-white" />}
                </button>
              ))}
            </div>
          </div>
        );
      case 5:
        return (
          <div>
            <h2 className="text-[20px] font-semibold">Create your first project</h2>
            <p className="mt-1.5 text-[13.5px] text-fg-3">A project groups chats, a folder, instructions and agents for one game. You can skip this.</p>
            <div className="mt-5">
              {created ? (
                <div className="flex items-center gap-3 rounded-2xl bg-success/10 p-4 text-[13.5px] text-success">
                  <CircleCheck className="size-5" /> Project “{created.name}” created.
                </div>
              ) : (
                <ProjectForm value={proj} onChange={setProj} />
              )}
            </div>
          </div>
        );
      default:
        return (
          <div className="text-center">
            <div className="mx-auto flex size-14 items-center justify-center rounded-2xl bg-accent-soft text-accent">
              <Sparkles className="size-7" />
            </div>
            <h2 className="mt-5 text-[24px] font-semibold">You’re all set</h2>
            <p className="mx-auto mt-2 max-w-md text-[13.5px] leading-relaxed text-fg-3">Start a chat, or open your project and launch agents. Press Ctrl+K anytime to search everything.</p>
            <div className="mx-auto mt-6 flex max-w-sm flex-col gap-2 text-left text-[12.5px]">
              <div className="flex items-center justify-between rounded-xl border border-line px-3.5 py-2.5">
                <span>AI accounts</span>
                <Badge tone={accounts.some((a) => a.status === 'signed_in') ? 'success' : 'warning'}>{accounts.filter((a) => a.status === 'signed_in').length} signed in</Badge>
              </div>
              <div className="flex items-center justify-between rounded-xl border border-line px-3.5 py-2.5">
                <span>Roblox Studio</span>
                <Badge tone={roblox?.state === 'connected' ? 'success' : 'neutral'}>{roblox?.state === 'connected' ? 'connected' : 'not connected'}</Badge>
              </div>
            </div>
          </div>
        );
    }
  })();

  const next = async () => {
    if (step === 5 && !created && proj.name?.trim()) {
      try {
        const p = await api.post<Project>('/api/projects', proj);
        useApp.setState((s) => ({ projects: [p, ...s.projects] }));
        setCreated(p);
      } catch {
        return;
      }
    }
    setStep(Math.min(STEPS.length - 1, step + 1));
  };

  return (
    <div className="fixed inset-0 z-[58] flex items-center justify-center bg-bg/95 p-4 backdrop-blur-sm">
      <div className="flex max-h-[92vh] w-full max-w-[680px] flex-col overflow-hidden rounded-3xl border border-line-strong bg-surface shadow-pop">
        <div className="flex items-center gap-1.5 px-8 pt-6">
          {STEPS.map((s, i) => (
            <div key={s} className="flex-1">
              <div className={cn('h-1 rounded-full transition-colors', i <= step ? 'bg-accent' : 'bg-surface-3')} />
              <div className={cn('mt-1.5 hidden text-[10.5px] md:block', i === step ? 'text-fg-2' : 'text-fg-3')}>{s}</div>
            </div>
          ))}
        </div>
        <div key={step} className="rise min-h-[380px] flex-1 overflow-y-auto px-8 py-8">
          {body}
        </div>
        <div className="flex items-center justify-between border-t border-line px-8 py-4">
          <div>
            {step > 0 && step < STEPS.length - 1 && (
              <Button variant="ghost" icon={<ArrowLeft className="size-4" />} onClick={() => setStep(step - 1)}>
                Back
              </Button>
            )}
            {step === 0 && (
              <Button variant="ghost" onClick={() => finish('chat')}>
                Skip setup
              </Button>
            )}
          </div>
          {step < STEPS.length - 1 ? (
            <Button variant="primary" onClick={next}>
              {step === 0 ? 'Get started' : step === 5 && !created && !proj.name?.trim() ? 'Skip' : 'Continue'} <ArrowRight className="size-4" />
            </Button>
          ) : (
            <div className="flex gap-2">
              {created && (
                <Button variant="secondary" icon={<FolderOpen className="size-4" />} onClick={() => finish('project')}>
                  Open project
                </Button>
              )}
              <Button variant="primary" onClick={() => finish('chat')}>
                Open workspace <ArrowRight className="size-4" />
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
