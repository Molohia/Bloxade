import { useEffect, useState } from 'react';
import { Bot, Brain, Check, CircleCheck, CircleX, Cog, Database, FolderOpen, Gamepad2, Palette, Power, RefreshCw, Shield, SlidersHorizontal, Trash2, Wrench, X } from 'lucide-react';
import { toast } from 'sonner';
import type { EfficiencyMode, PermissionPolicy, Provider, Settings, ThemeName } from '@shared/types';
import { EFFICIENCY_PROFILES } from '@shared/types';
import { useApp } from '../store/app';
import { api } from '../lib/api';
import { cn, fmtBytes, fmtNum } from '../lib/utils';
import { navigate, routes } from '../lib/router';
import { ACCENTS, THEMES } from '../lib/theme';
import { Page, PageHeader } from '../components/layout/Page';
import { Badge, Button, Card, Field, Input, Segmented, Spinner, Switch } from '../components/ui/primitives';
import { Select, confirmDialog } from '../components/ui/overlays';
import { ModelPicker } from '../components/chat/ModelPicker';
import { ProviderMark, providerName } from '../components/brand';

const TABS = [
  { id: 'general', label: 'General', icon: Cog },
  { id: 'appearance', label: 'Appearance', icon: Palette },
  { id: 'providers', label: 'AI Providers', icon: Bot },
  { id: 'agents', label: 'Agents', icon: SlidersHorizontal },
  { id: 'context', label: 'Context Optimization', icon: Brain },
  { id: 'roblox', label: 'Roblox Studio', icon: Gamepad2 },
  { id: 'privacy', label: 'Privacy & Security', icon: Shield },
  { id: 'advanced', label: 'Advanced', icon: Wrench },
];

function useSave() {
  const save = useApp((s) => s.saveSettings);
  return (patch: unknown) => save(patch).then(() => toast.success('Saved', { duration: 1200 }));
}

function PolicySelect({ value, onChange }: { value: PermissionPolicy; onChange: (v: PermissionPolicy) => void }) {
  return <Segmented size="sm" value={value} onChange={onChange} options={[{ value: 'allow', label: 'Allow' }, { value: 'ask', label: 'Ask' }, { value: 'deny', label: 'Block' }]} />;
}

function General({ s }: { s: Settings }) {
  const save = useSave();
  const projects = useApp((st) => st.projects);
  return (
    <Card className="divide-y divide-line px-6">
      <Field label="Open the browser when BLOXADE starts" description="START_BLOXADE.bat opens http://127.0.0.1:3000 automatically.">
        <Switch checked={s.general.openBrowserOnStart} onChange={(v) => save({ general: { openBrowserOnStart: v } })} />
      </Field>
      <Field label="Default project" description="Pre-selected when you start an agent run.">
        <div className="w-64">
          <Select value={s.general.defaultProjectId ?? ''} onChange={(v) => save({ general: { defaultProjectId: v || null } })} options={[{ value: '', label: 'None' }, ...projects.map((p) => ({ value: p.id, label: p.name }))]} />
        </div>
      </Field>
      <Field label="Automatic chat titles" description="Titles are made from your first message locally — no extra AI call.">
        <Switch checked={s.general.autoTitle} onChange={(v) => save({ general: { autoTitle: v } })} />
      </Field>
      <Field label="Notifications" description="Show toasts when agents finish or need approval.">
        <Switch checked={s.general.notifications} onChange={(v) => save({ general: { notifications: v } })} />
      </Field>
      <Field label="Confirm before deleting" description="Ask before deleting chats, projects and runs.">
        <Switch checked={s.general.confirmDeletes} onChange={(v) => save({ general: { confirmDeletes: v } })} />
      </Field>
      <Field label="Setup guide" description="Run the first-time setup again.">
        <Button size="sm" variant="secondary" onClick={() => save({ general: { onboardingComplete: false } })}>
          Open setup
        </Button>
      </Field>
    </Card>
  );
}

function Appearance({ s }: { s: Settings }) {
  const saveRaw = useApp((st) => st.saveSettings);
  const [custom, setCustom] = useState(s.appearance.accent);
  useEffect(() => setCustom(s.appearance.accent), [s.appearance.accent]);
  return (
    <div className="space-y-5">
      <Card className="p-6">
        <div className="mb-4 text-[13.5px] font-medium">Theme</div>
        <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
          {THEMES.map((t) => (
            <ThemeCard key={t.id} id={t.id} label={t.label} swatch={t.swatch} active={s.appearance.theme === t.id} onClick={() => saveRaw({ appearance: { theme: t.id } })} />
          ))}
        </div>
        <div className="mb-3 mt-7 text-[13.5px] font-medium">Accent color</div>
        <div className="flex flex-wrap items-center gap-2.5">
          {ACCENTS.map((c) => (
            <button key={c} onClick={() => saveRaw({ appearance: { accent: c } })} className={cn('flex size-8 cursor-pointer items-center justify-center rounded-full ring-offset-2 ring-offset-surface transition-transform hover:scale-110', s.appearance.accent.toLowerCase() === c.toLowerCase() && 'ring-2 ring-fg/50')} style={{ background: c }} aria-label={`Accent ${c}`}>
              {s.appearance.accent.toLowerCase() === c.toLowerCase() && <Check className="size-4 text-white" />}
            </button>
          ))}
          <span className="mx-2 h-6 w-px bg-line" />
          <label className="flex items-center gap-2 text-[12.5px] text-fg-3">
            Custom
            <input type="color" value={custom} onChange={(e) => setCustom(e.target.value)} onBlur={() => saveRaw({ appearance: { accent: custom } })} className="size-8 cursor-pointer rounded-lg border border-line bg-transparent" />
            <Input value={custom} onChange={(e) => setCustom(e.target.value)} onBlur={() => /^#[0-9a-f]{6}$/i.test(custom) && saveRaw({ appearance: { accent: custom } })} className="w-28 font-mono" />
          </label>
        </div>
      </Card>
      <Card className="divide-y divide-line px-6">
        <Field label="Chat font size" description="Size of message text.">
          <div className="flex items-center gap-3">
            <input type="range" min={13} max={19} value={s.appearance.fontSize} onChange={(e) => saveRaw({ appearance: { fontSize: Number(e.target.value) } })} className="w-40 accent-[var(--accent)]" />
            <span className="w-10 text-right text-[12.5px] tabular-nums text-fg-2">{s.appearance.fontSize}px</span>
          </div>
        </Field>
        <Field label="Chat density">
          <Segmented value={s.appearance.density} onChange={(v) => saveRaw({ appearance: { density: v } })} options={[{ value: 'comfortable', label: 'Comfortable' }, { value: 'compact', label: 'Compact' }]} />
        </Field>
        <Field label="Sidebar" description="Collapse with Ctrl+B at any time.">
          <Segmented value={s.appearance.sidebarCollapsed ? 'hidden' : 'shown'} onChange={(v) => saveRaw({ appearance: { sidebarCollapsed: v === 'hidden' } })} options={[{ value: 'shown', label: 'Expanded' }, { value: 'hidden', label: 'Collapsed' }]} />
        </Field>
        <Field label="Reduce motion" description="Turn off animations.">
          <Switch checked={s.appearance.reduceMotion} onChange={(v) => saveRaw({ appearance: { reduceMotion: v } })} />
        </Field>
      </Card>
    </div>
  );
}

function ThemeCard({ id, label, swatch, active, onClick }: { id: ThemeName; label: string; swatch: [string, string, string]; active: boolean; onClick: () => void }) {
  return (
    <button onClick={onClick} className={cn('cursor-pointer overflow-hidden rounded-xl border text-left transition-all', active ? 'border-accent ring-2 ring-accent-soft' : 'border-line hover:border-line-strong')}>
      <div className="flex h-20 gap-1.5 p-2" style={{ background: swatch[0] }}>
        <div className="w-1/4 rounded-md" style={{ background: swatch[1] }} />
        <div className="flex flex-1 flex-col gap-1.5 pt-1">
          <div className="h-1.5 w-3/4 rounded-full" style={{ background: swatch[2], opacity: 0.8 }} />
          <div className="h-1.5 w-1/2 rounded-full" style={{ background: swatch[2], opacity: 0.4 }} />
          <div className="mt-auto ml-auto h-4 w-2/3 rounded-md" style={{ background: swatch[1] }} />
        </div>
      </div>
      <div className="flex items-center justify-between px-3 py-2 text-[12.5px] font-medium">
        {label}
        {active && <Check className="size-3.5 text-accent" />}
      </div>
    </button>
  );
}

function Providers({ s }: { s: Settings }) {
  const save = useSave();
  const clis = useApp((st) => st.clis);
  const accounts = useApp((st) => st.accounts);
  const models = useApp((st) => st.models);
  const loadModels = useApp((st) => st.loadModels);
  const [checking, setChecking] = useState(false);
  const [paths, setPaths] = useState({ claude: s.providers.claudePath, codex: s.providers.codexPath });
  const refresh = async () => {
    setChecking(true);
    try {
      const r = await api.get<NonNullable<typeof clis>>('/api/providers?refresh=1');
      useApp.setState({ clis: r });
    } finally {
      setChecking(false);
    }
  };
  return (
    <div className="space-y-5">
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        {(['claude', 'codex'] as Provider[]).map((p) => {
          const c = clis?.[p];
          return (
            <Card key={p} className="p-5">
              <div className="flex items-center gap-3">
                <ProviderMark provider={p} size="lg" />
                <div className="min-w-0 flex-1">
                  <div className="text-[14.5px] font-semibold">{providerName(p)}</div>
                  <div className="truncate text-[12px] text-fg-3">{c?.found ? c.version : c?.error ?? 'Not checked'}</div>
                </div>
                {c?.found ? <Badge tone="success"><CircleCheck className="size-3" /> Installed</Badge> : <Badge tone="danger"><CircleX className="size-3" /> Missing</Badge>}
              </div>
              {c?.path && <div className="mt-3 truncate rounded-lg bg-surface-2 px-2.5 py-1.5 font-mono text-[11.5px] text-fg-3">{c.path}</div>}
              {!c?.found && (
                <div className="mt-3 text-[12.5px] leading-relaxed text-fg-3">
                  {p === 'claude' ? (
                    <>Install in PowerShell: <span className="font-mono">irm https://claude.ai/install.ps1 | iex</span> — or set a path below.</>
                  ) : (
                    <>Install Codex from developers.openai.com/codex (or the Codex IDE extension), or set the path to codex.exe below.</>
                  )}
                </div>
              )}
              <div className="mt-3 flex gap-2">
                <Input placeholder={`Custom path to ${p}.exe (optional)`} value={paths[p]} onChange={(e) => setPaths({ ...paths, [p]: e.target.value })} className="flex-1 font-mono" />
                <Button size="md" variant="secondary" onClick={async () => (await save({ providers: { [p === 'claude' ? 'claudePath' : 'codexPath']: paths[p] } }), refresh())}>
                  Save
                </Button>
              </div>
              <div className="mt-3 flex items-center justify-between text-[12px] text-fg-3">
                <span>
                  {accounts.filter((a) => a.provider === p).length} account(s) · {models[p]?.models.length ?? 0} models{models[p]?.source === 'discovered' ? ' (reported by CLI)' : ' (built-in list)'}
                </span>
                <Button size="xs" variant="ghost" icon={<RefreshCw className="size-3" />} onClick={() => loadModels(p, true).then(() => toast.success('Model list refreshed'))}>
                  Models
                </Button>
              </div>
            </Card>
          );
        })}
      </div>
      <div className="flex justify-end">
        <Button variant="secondary" icon={<RefreshCw className={cn('size-4', checking && 'animate-spin')} />} onClick={refresh}>
          Detect CLIs again
        </Button>
      </div>
      <Card className="divide-y divide-line px-6">
        <Field label="Default provider for new chats">
          <Segmented value={s.providers.defaultProvider} onChange={(v) => save({ providers: { defaultProvider: v } })} options={[{ value: 'claude', label: 'Claude Code' }, { value: 'codex', label: 'Codex' }]} />
        </Field>
        {(['claude', 'codex'] as Provider[]).map((p) => (
          <Field key={p} label={`Default ${providerName(p)} model & effort`}>
            <ModelPicker lockProvider side="bottom" align="end" value={{ provider: p, accountId: null, model: s.providers.defaultModels[p] ?? '', effort: s.providers.defaultEfforts[p] ?? '' }} onChange={(v) => save({ providers: { defaultModels: { [p]: v.model ?? s.providers.defaultModels[p] }, defaultEfforts: { [p]: v.effort ?? s.providers.defaultEfforts[p] } } })} />
          </Field>
        ))}
        <Field label="Default mode" description="Chat = conversation only. Cowork = the AI works on files / Studio with approvals.">
          <Segmented value={s.providers.defaultMode} onChange={(v) => save({ providers: { defaultMode: v } })} options={[{ value: 'chat', label: 'Chat' }, { value: 'cowork', label: 'Cowork' }]} />
        </Field>
        <Field label="Show hidden models" description="Codex reports some models as hidden from its default picker.">
          <Switch checked={s.providers.showHiddenModels} onChange={(v) => save({ providers: { showHiddenModels: v } })} />
        </Field>
        <Field label="Custom model IDs" description="Model IDs you added manually (any ID the CLI accepts).">
          <div className="flex max-w-md flex-wrap justify-end gap-1.5">
            {(['claude', 'codex'] as Provider[]).flatMap((p) =>
              (s.providers.customModels[p] ?? []).map((m) => (
                <span key={p + m} className="inline-flex items-center gap-1 rounded-md border border-line bg-surface-2 py-0.5 pl-2 pr-1 font-mono text-[11.5px]">
                  {m}
                  <button className="cursor-pointer rounded p-0.5 text-fg-3 hover:text-fg" onClick={() => save({ providers: { customModels: { [p]: s.providers.customModels[p].filter((x) => x !== m) } } }).then(() => loadModels(p))}>
                    <X className="size-3" />
                  </button>
                </span>
              )),
            )}
            {!s.providers.customModels.claude.length && !s.providers.customModels.codex.length && <span className="text-[12.5px] text-fg-3">None — add one from the model picker.</span>}
          </div>
        </Field>
      </Card>
    </div>
  );
}

function Agents({ s }: { s: Settings }) {
  const save = useSave();
  return (
    <Card className="divide-y divide-line px-6">
      <Field label="Maximum parallel agents" description="“Auto” follows the efficiency mode (1–4).">
        <Select value={String(s.agents.maxConcurrent ?? 'auto')} onChange={(v) => save({ agents: { maxConcurrent: v === 'auto' ? null : Number(v) } })} options={[{ value: 'auto', label: 'Auto (by efficiency mode)' }, ...[1, 2, 3, 4, 5, 6, 8].map((n) => ({ value: String(n), label: `${n} at a time` }))]} />
      </Field>
      <Field label="Routing strategy" description="How the coordinator spreads tasks between providers.">
        <Select value={s.agents.routing} onChange={(v) => save({ agents: { routing: v } })} options={[{ value: 'balanced', label: 'Balanced' }, { value: 'prefer-claude', label: 'Prefer Claude Code' }, { value: 'prefer-codex', label: 'Prefer Codex' }, { value: 'claude-only', label: 'Claude Code only' }, { value: 'codex-only', label: 'Codex only' }]} />
      </Field>
      <Field label="File edits inside the project" description="For Cowork chats, and for agents editing their assigned paths (unless the run auto-approves).">
        <PolicySelect value={s.agents.approvals.edits} onChange={(v) => save({ agents: { approvals: { edits: v } } })} />
      </Field>
      <Field label="Agent edits outside its assignment" description="When an agent touches files it doesn’t own.">
        <PolicySelect value={s.agents.approvals.unownedEdits} onChange={(v) => save({ agents: { approvals: { unownedEdits: v } } })} />
      </Field>
      <Field label="Shell commands & other tools" description="Read-only commands the CLIs consider safe may still run without asking.">
        <PolicySelect value={s.agents.approvals.commands} onChange={(v) => save({ agents: { approvals: { commands: v } } })} />
      </Field>
      <Field label="Require review of every agent change" description="Tasks with changes stop in “Reviewing” until you accept or revert. Conflicts are always reviewed.">
        <Switch checked={s.agents.requireReview} onChange={(v) => save({ agents: { requireReview: v } })} />
      </Field>
      <Field label="Approval timeout" description="Unanswered approval requests are denied after this time so agents never hang.">
        <Select value={String(s.agents.approvalTimeoutSec)} onChange={(v) => save({ agents: { approvalTimeoutSec: Number(v) } })} options={[60, 180, 300, 600, 1200, 1800].map((n) => ({ value: String(n), label: n < 120 ? `${n} seconds` : `${n / 60} minutes` }))} />
      </Field>
    </Card>
  );
}

function Context({ s }: { s: Settings }) {
  const save = useSave();
  const [stats, setStats] = useState<any>(null);
  useEffect(() => {
    api.get<any>('/api/system/diagnostics', { silent: true }).then((d) => setStats(d.context), () => undefined);
  }, []);
  return (
    <div className="space-y-5">
      <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-4">
        {(Object.keys(EFFICIENCY_PROFILES) as EfficiencyMode[]).map((m) => {
          const p = EFFICIENCY_PROFILES[m];
          const active = s.context.mode === m;
          return (
            <button key={m} onClick={() => save({ context: { mode: m } })} className={cn('cursor-pointer rounded-2xl border p-4 text-left transition-all', active ? 'border-accent bg-accent-softer ring-2 ring-accent-soft' : 'border-line bg-surface hover:border-line-strong')}>
              <div className="flex items-center justify-between">
                <span className="text-[14px] font-semibold">{p.label}</span>
                {active && <Check className="size-4 text-accent" />}
              </div>
              <div className="mt-1.5 text-[12px] leading-relaxed text-fg-3">{p.description}</div>
              <div className="mt-3 space-y-1 text-[11.5px] text-fg-2">
                <div>~{fmtNum(p.contextBudget)} token context budget</div>
                <div>{p.maxConcurrentAgents} parallel · ≤{p.maxTasks} tasks · {p.retries} retries</div>
                <div>Tool output cap {fmtNum(p.toolOutputCap)} chars</div>
              </div>
            </button>
          );
        })}
      </div>
      <Card className="divide-y divide-line px-6">
        <Field label="Context budget override" description="Tokens of project context (memory, tree, snippets) per new session. Empty = use the mode’s budget.">
          <Input type="number" className="w-36" placeholder={String(EFFICIENCY_PROFILES[s.context.mode].contextBudget)} defaultValue={s.context.budgetOverride ?? ''} onBlur={(e) => save({ context: { budgetOverride: e.target.value ? Math.max(500, Number(e.target.value)) : null } })} />
        </Field>
        <Field label="Prime project chats with relevant files" description="Adds small, ranked excerpts of the most relevant files to the first message — and never resends files already shared in the same session unless they changed.">
          <Switch checked={s.context.primeChats} onChange={(v) => save({ context: { primeChats: v } })} />
        </Field>
        <Field label="Cache project indexes & Studio reads" description="File metadata and read-only Studio results are cached and invalidated on changes.">
          <Switch checked={s.context.cache} onChange={(v) => save({ context: { cache: v } })} />
        </Field>
        <Field label="Tool output cap" description="Large Studio tool results are trimmed (head + tail kept) before they reach an agent.">
          <Input type="number" className="w-36" placeholder={String(EFFICIENCY_PROFILES[s.context.mode].toolOutputCap)} defaultValue={s.context.toolOutputCap ?? ''} onBlur={(e) => save({ context: { toolOutputCap: e.target.value ? Math.max(1000, Number(e.target.value)) : null } })} />
        </Field>
        <Field label="Automatic project memory" description="After an agent run, the coordinator updates the project memory (one small extra call).">
          <Switch checked={s.context.autoMemory} onChange={(v) => save({ context: { autoMemory: v } })} />
        </Field>
        {stats && (
          <Field label="Cache statistics" description="Since BLOXADE started.">
            <div className="text-right text-[12px] text-fg-3">
              {stats.indexBuilds} index builds · {stats.indexHits} index hits · {stats.contentHits} file cache hits · {fmtBytes(stats.cachedBytes)} cached
            </div>
          </Field>
        )}
      </Card>
    </div>
  );
}

function RobloxSettings({ s }: { s: Settings }) {
  const save = useSave();
  const [cmd, setCmd] = useState(s.roblox.command);
  return (
    <Card className="divide-y divide-line px-6">
      <Field label="Roblox Studio integration" description="Offer Studio tools to Cowork chats and agents in Roblox projects.">
        <Switch checked={s.roblox.enabled} onChange={(v) => save({ roblox: { enabled: v } })} />
      </Field>
      <Field label="Connect automatically on startup">
        <Switch checked={s.roblox.autoConnect} onChange={(v) => save({ roblox: { autoConnect: v } })} />
      </Field>
      <Field label="MCP server command" description="The official command from Roblox’s documentation. Change only if Roblox tells you to." vertical>
        <div className="flex gap-2">
          <Input value={cmd} onChange={(e) => setCmd(e.target.value)} className="flex-1 font-mono" />
          <Button variant="secondary" onClick={() => save({ roblox: { command: cmd } })}>
            Save
          </Button>
          <Button variant="ghost" onClick={() => (setCmd('cmd.exe /c %LOCALAPPDATA%\\Roblox\\mcp.bat'), save({ roblox: { command: 'cmd.exe /c %LOCALAPPDATA%\\Roblox\\mcp.bat' } }))}>
            Reset
          </Button>
        </div>
      </Field>
      <Field label="Share read-only results between agents" description="Identical reads (script_read, search_game_tree…) within 30 s are served from cache; any write clears it.">
        <Switch checked={s.roblox.cacheReads} onChange={(v) => save({ roblox: { cacheReads: v } })} />
      </Field>
      <Field label="Tool permissions" description="Per-tool Allow / Ask / Block lives on the Roblox Studio page.">
        <Button size="sm" variant="secondary" onClick={() => navigate(routes.roblox())}>
          Open tool permissions
        </Button>
      </Field>
    </Card>
  );
}

function Privacy() {
  const dataDir = useApp((s) => s.dataDir);
  const clear = async (what: string, label: string) => {
    const r = await confirmDialog({ title: `Clear ${label}?`, body: 'This cannot be undone. Files in your project folders are never touched.', confirmLabel: 'Clear', danger: true });
    if (r.ok) {
      await api.post('/api/system/clear-history', { what });
      toast.success(`${label} cleared`);
    }
  };
  return (
    <div className="space-y-5">
      <Card className="divide-y divide-line px-6">
        <Field label="Local data folder" description="Chats, settings, usage and account profile folders live only on this computer.">
          <div className="flex items-center gap-2">
            <span className="max-w-xs truncate font-mono text-[12px] text-fg-3">{dataDir}</span>
            <Button size="sm" variant="secondary" icon={<FolderOpen className="size-3.5" />} onClick={() => api.post('/api/system/open-data', { which: 'data' })}>
              Open
            </Button>
          </div>
        </Field>
        <Field label="Network exposure" description="BLOXADE only listens on 127.0.0.1 and rejects requests from other websites (host/origin checks).">
          <Badge tone="success">Localhost only</Badge>
        </Field>
        <Field label="Credentials" description="No passwords, API keys, OAuth tokens or cookies are collected or stored by BLOXADE. Sign-in happens in the official CLIs.">
          <Button size="sm" variant="secondary" onClick={() => navigate(routes.accounts())}>
            Manage accounts
          </Button>
        </Field>
        <Field label="Workspace permissions" description="Agents can edit only inside a project’s folder without asking; anything outside always asks you first.">
          <Button size="sm" variant="secondary" onClick={() => navigate(routes.settings('agents'))}>
            Approval rules
          </Button>
        </Field>
      </Card>
      <Card className="divide-y divide-line px-6">
        {[
          ['chats', 'chat history', 'All chats, messages and attachments.'],
          ['runs', 'agent runs', 'Plans, task transcripts and reports.'],
          ['usage', 'usage statistics', 'Token and activity statistics.'],
          ['activity', 'activity log', 'Activity timeline and Studio tool log.'],
          ['cache', 'caches', 'Model lists and other cached data.'],
        ].map(([w, l, d]) => (
          <Field key={w} label={`Clear ${l}`} description={d}>
            <Button size="sm" variant="ghost" className="text-danger" icon={<Trash2 className="size-3.5" />} onClick={() => clear(w, l)}>
              Clear
            </Button>
          </Field>
        ))}
      </Card>
    </div>
  );
}

function Advanced({ s }: { s: Settings }) {
  const save = useSave();
  const [diag, setDiag] = useState<any>(null);
  const [logs, setLogs] = useState<any[]>([]);
  const [level, setLevel] = useState<'info' | 'warn' | 'error' | 'debug'>('info');
  const load = () => api.get<any>('/api/system/diagnostics').then(setDiag);
  useEffect(() => {
    void load();
  }, []);
  useEffect(() => {
    api.get<any[]>(`/api/system/logs?limit=300&level=${level}`, { silent: true }).then(setLogs, () => undefined);
  }, [level]);
  return (
    <div className="space-y-5">
      <Card className="divide-y divide-line px-6">
        <Field label="Port" description="Applies after restarting BLOXADE. The server only binds to 127.0.0.1.">
          <Input type="number" className="w-28" defaultValue={s.advanced.port} onBlur={(e) => save({ advanced: { port: Number(e.target.value) } })} />
        </Field>
        <Field label="Log level">
          <Select value={s.advanced.logLevel} onChange={(v) => save({ advanced: { logLevel: v } })} options={['debug', 'info', 'warn', 'error'].map((x) => ({ value: x as any, label: x }))} />
        </Field>
        <Field label="Turn time limit" description="A single chat turn or agent task is stopped after this many minutes.">
          <Input type="number" className="w-28" defaultValue={s.advanced.turnTimeoutMin} onBlur={(e) => save({ advanced: { turnTimeoutMin: Number(e.target.value) } })} />
        </Field>
        <Field label="Stop BLOXADE" description="Stops the server and every running CLI session.">
          <Button
            size="sm"
            variant="danger"
            icon={<Power className="size-3.5" />}
            onClick={async () => {
              const r = await confirmDialog({ title: 'Stop BLOXADE?', body: 'Running chats and agents are stopped. Start it again with START_BLOXADE.bat.', confirmLabel: 'Stop', danger: true });
              if (r.ok) await api.post('/api/system/shutdown');
            }}
          >
            Shut down
          </Button>
        </Field>
      </Card>
      <Card className="p-5">
        <div className="mb-3 flex items-center justify-between">
          <span className="text-[13.5px] font-medium">Diagnostics & dependency checks</span>
          <Button size="xs" variant="ghost" icon={<RefreshCw className="size-3" />} onClick={load}>
            Refresh
          </Button>
        </div>
        {!diag ? (
          <Spinner />
        ) : (
          <div className="grid grid-cols-1 gap-x-8 gap-y-2 text-[12.5px] md:grid-cols-2">
            {[
              ['BLOXADE', diag.version],
              ['Node.js', diag.node],
              ['System', diag.platform],
              ['Port', diag.port],
              ['Git', diag.git],
              ['Claude Code', diag.clis.claude.found ? `${diag.clis.claude.version}` : 'not found'],
              ['Codex', diag.clis.codex.found ? `${diag.clis.codex.version}` : 'not found'],
              ['Roblox MCP', `${diag.roblox.state}${diag.roblox.launcherExists === false ? ' (mcp.bat not found)' : ''}${diag.roblox.studioProcessRunning === false ? ' · Studio not running' : diag.roblox.studioProcessRunning ? ' · Studio running' : ''}`],
              ['Database', fmtBytes(diag.dbBytes)],
              ['Live connections', diag.sseClients],
              ['Child processes', diag.processes.length],
              ['Memory', fmtBytes(diag.memory.rss)],
            ].map(([k, v]) => (
              <div key={k} className="flex justify-between gap-4 border-b border-line py-1.5">
                <span className="text-fg-3">{k}</span>
                <span className="truncate text-right font-mono text-[11.5px] text-fg-2">{String(v)}</span>
              </div>
            ))}
          </div>
        )}
      </Card>
      <Card className="p-5">
        <div className="mb-3 flex items-center justify-between">
          <span className="text-[13.5px] font-medium">Logs</span>
          <div className="flex items-center gap-2">
            <Segmented size="sm" value={level} onChange={setLevel} options={['debug', 'info', 'warn', 'error'].map((x) => ({ value: x as any, label: x }))} />
            <Button size="xs" variant="ghost" icon={<FolderOpen className="size-3" />} onClick={() => api.post('/api/system/open-data', { which: 'logs' })}>
              Folder
            </Button>
          </div>
        </div>
        <pre className="max-h-80 overflow-auto rounded-xl bg-code p-3 font-mono text-[11px] leading-relaxed">
          {logs
            .slice()
            .reverse()
            .map((l, i) => (
              <div key={i} className={l.level === 'error' ? 'text-danger' : l.level === 'warn' ? 'text-warning' : 'text-fg-3'}>
                {new Date(l.ts).toLocaleTimeString()} [{l.scope}] {l.msg} {l.data ? JSON.stringify(l.data).slice(0, 300) : ''}
              </div>
            ))}
        </pre>
      </Card>
    </div>
  );
}

export function SettingsPage({ tab }: { tab: string }) {
  const s = useApp((st) => st.settings);
  if (!s) return <Spinner className="m-10" />;
  const current = TABS.find((t) => t.id === tab) ?? TABS[0];
  return (
    <Page wide>
      <PageHeader title="Settings" description="Everything is stored locally on this computer." />
      <div className="grid grid-cols-1 gap-8 md:grid-cols-[220px_1fr]">
        <nav className="space-y-px md:sticky md:top-6 md:self-start">
          {TABS.map((t) => (
            <button key={t.id} onClick={() => navigate(routes.settings(t.id))} className={cn('flex h-9 w-full cursor-pointer items-center gap-2.5 rounded-lg px-3 text-[13px]', current.id === t.id ? 'bg-surface-2 font-medium text-fg' : 'text-fg-2 hover:bg-surface-2/60 hover:text-fg')}>
              <t.icon className="size-4 text-fg-3" /> {t.label}
            </button>
          ))}
          <div className="flex items-center gap-2 px-3 pt-4 text-[11.5px] text-fg-3">
            <Database className="size-3.5" /> Saved automatically
          </div>
        </nav>
        <div className="min-w-0">
          <h2 className="mb-4 text-[16px] font-semibold">{current.label}</h2>
          {current.id === 'general' && <General s={s} />}
          {current.id === 'appearance' && <Appearance s={s} />}
          {current.id === 'providers' && <Providers s={s} />}
          {current.id === 'agents' && <Agents s={s} />}
          {current.id === 'context' && <Context s={s} />}
          {current.id === 'roblox' && <RobloxSettings s={s} />}
          {current.id === 'privacy' && <Privacy />}
          {current.id === 'advanced' && <Advanced s={s} />}
        </div>
      </div>
    </Page>
  );
}
