import { useEffect, useMemo, useState } from 'react';
import { ChevronRight, File, FileCode, Folder, FolderOpen, FolderX, Gamepad2, GitCompare, MessageSquare, MessageSquarePlus, Plus, RotateCcw, Save, Search, Trash2, Workflow, Brain, Gauge } from 'lucide-react';
import { toast } from 'sonner';
import type { ChatMode, FileChange, FileEntry, Project, Provider } from '@shared/types';
import { useApp } from '../store/app';
import { useShallow } from 'zustand/react/shallow';
import { useUi } from '../store/ui';
import { api } from '../lib/api';
import { cn, fmtBytes, fmtNum, timeAgo } from '../lib/utils';
import { navigate, routes } from '../lib/router';
import { Page, PageHeader, Stat } from '../components/layout/Page';
import { Badge, Button, Card, EmptyState, Input, Segmented, SectionTitle, Spinner, StatusDot, Textarea } from '../components/ui/primitives';
import { Tabs, confirmDialog } from '../components/ui/overlays';
import { ProjectIcon } from '../components/icons';
import { ProjectForm } from '../components/ProjectDialogs';
import { CodeBlock } from '../components/chat/Markdown';
import { ModelPicker } from '../components/chat/ModelPicker';
import { ProviderMark } from '../components/brand';
import { RunLauncher, RunList } from './Agents';

export function ProjectsPage() {
  const projects = useApp((s) => s.projects);
  const openNew = useUi((s) => s.openNewProject);
  const [q, setQ] = useState('');
  const list = projects.filter((p) => !q || `${p.name} ${p.description}`.toLowerCase().includes(q.toLowerCase()));
  return (
    <Page wide>
      <PageHeader
        title="Projects"
        description="Each project keeps its own chats, folder, instructions, memory and agents — everyone working on it shares the same context automatically."
        actions={
          <Button variant="primary" icon={<Plus className="size-4" />} onClick={openNew}>
            New project
          </Button>
        }
      />
      {projects.length > 6 && <Input className="mb-5 max-w-sm" icon={<Search className="size-4" />} placeholder="Filter projects…" value={q} onChange={(e) => setQ(e.target.value)} />}
      {projects.length === 0 ? (
        <Card>
          <EmptyState
            icon={<FolderOpen className="size-5" />}
            title="No projects yet"
            description="Create a project for each game — e.g. “Roblox — Milk the Cow”. Link its folder so agents can edit files, and turn on Roblox Studio to let them work in your place."
            action={
              <Button variant="primary" icon={<Plus className="size-4" />} onClick={openNew}>
                Create your first project
              </Button>
            }
          />
        </Card>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {list.map((p) => (
            <button key={p.id} onClick={() => navigate(routes.project(p.id))} className="group flex cursor-pointer flex-col rounded-2xl border border-line bg-surface p-5 text-left transition-all hover:-translate-y-0.5 hover:border-line-strong hover:shadow-pop">
              <div className="flex items-start justify-between">
                <ProjectIcon icon={p.icon} color={p.color} size="md" />
                {p.robloxEnabled && (
                  <Badge tone="neutral">
                    <Gamepad2 className="size-3" /> Roblox
                  </Badge>
                )}
              </div>
              <div className="mt-4 truncate text-[15px] font-semibold text-fg">{p.name}</div>
              <div className="mt-1 line-clamp-2 min-h-[36px] text-[12.5px] leading-relaxed text-fg-3">{p.description || 'No description'}</div>
              <div className="mt-4 flex items-center gap-3 border-t border-line pt-3.5 text-[12px] text-fg-3">
                <span className="flex items-center gap-1">
                  <MessageSquare className="size-3.5" /> {p.stats?.chats ?? 0}
                </span>
                <span className="flex items-center gap-1">
                  <Workflow className="size-3.5" /> {p.stats?.runs ?? 0}
                </span>
                <span className="ml-auto truncate font-mono text-[11px]">{p.folderPath ? p.folderPath.split(/[\\/]/).filter(Boolean).slice(-2).join('/') : 'no folder'}</span>
              </div>
            </button>
          ))}
          <button onClick={openNew} className="flex min-h-[190px] cursor-pointer flex-col items-center justify-center gap-2 rounded-2xl border border-dashed border-line-strong text-fg-3 transition-colors hover:border-accent/50 hover:bg-accent-softer hover:text-fg-2">
            <Plus className="size-5" />
            <span className="text-[13px] font-medium">New project</span>
          </button>
        </div>
      )}
    </Page>
  );
}

function MemoryEditor({ project }: { project: Project }) {
  const [text, setText] = useState(project.memory);
  const [saving, setSaving] = useState(false);
  useEffect(() => setText(project.memory), [project.memory]);
  const dirty = text !== project.memory;
  return (
    <Card className="p-5">
      <SectionTitle
        action={
          dirty && (
            <Button
              size="xs"
              variant="primary"
              icon={<Save className="size-3.5" />}
              loading={saving}
              onClick={async () => {
                setSaving(true);
                await api.patch(`/api/projects/${project.id}`, { memory: text }).finally(() => setSaving(false));
                toast.success('Memory saved');
              }}
            >
              Save
            </Button>
          )
        }
      >
        <span className="flex items-center gap-1.5">
          <Brain className="size-3.5" /> Project memory
        </span>
      </SectionTitle>
      <Textarea rows={7} value={text} onChange={(e) => setText(e.target.value)} placeholder="Durable facts every AI should know: architecture, naming, decisions, TODOs. Use “Save insights to project memory” in a chat menu to fill this automatically." />
      <div className="mt-2 text-[11.5px] text-fg-3">Sent once at the start of each new session (not every message). {project.memoryUpdatedAt ? `Updated ${timeAgo(project.memoryUpdatedAt)}.` : ''}</div>
    </Card>
  );
}

function Overview({ project }: { project: Project }) {
  const chats = useApp(useShallow((s) => s.chats.filter((c) => c.projectId === project.id)));
  const roblox = useApp((s) => s.roblox);
  const changesTick = useApp((s) => s.changesTick);
  const [stats, setStats] = useState<{ files: number; textBytes: number; estTokensAll: number; truncated: boolean } | null>(null);
  const [changes, setChanges] = useState<FileChange[]>([]);
  const [preview, setPreview] = useState<{ estTokens: number; naiveTokens: number } | null>(null);
  useEffect(() => {
    if (project.folderPath) {
      api.get<typeof stats>(`/api/projects/${project.id}/stats`, { silent: true }).then(setStats, () => setStats(null));
      api.post<{ estTokens: number; naiveTokens: number } | null>(`/api/projects/${project.id}/context-preview`, { query: project.description || project.name }, { silent: true }).then(setPreview, () => undefined);
    }
    api.get<FileChange[]>(`/api/projects/${project.id}/changes`, { silent: true }).then(setChanges, () => undefined);
  }, [project.id, project.folderPath, changesTick]); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
      <div className="space-y-5 lg:col-span-2">
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          <Stat label="Chats" value={chats.length} />
          <Stat label="Agent runs" value={project.stats?.runs ?? 0} />
          <Stat label="Files" value={stats ? fmtNum(stats.files) : project.folderPath ? <Spinner /> : '—'} hint={stats ? fmtBytes(stats.textBytes) + ' of text' : 'no folder linked'} />
          <Stat label="Context pack" value={preview ? `~${fmtNum(preview.estTokens)}` : '—'} tone="estimate" hint={preview && stats ? `vs ~${fmtNum(stats.estTokensAll)} for the whole project` : 'tokens per new session'} />
        </div>
        <MemoryEditor project={project} />
        <Card className="p-5">
          <SectionTitle>Recent file changes</SectionTitle>
          {changes.length === 0 ? (
            <div className="text-[13px] text-fg-3">No changes recorded yet. Changes made by Cowork chats and agents appear here with diffs.</div>
          ) : (
            <div className="divide-y divide-line">
              {changes.slice(0, 8).map((c) => (
                <div key={c.id} className="flex items-center gap-3 py-2 text-[13px]">
                  <Badge tone={c.change === 'added' ? 'success' : c.change === 'deleted' ? 'danger' : 'info'}>{c.change}</Badge>
                  <span className="min-w-0 flex-1 truncate font-mono text-[12px] text-fg-2">{c.path}</span>
                  {c.reverted && <Badge>reverted</Badge>}
                  <span className="text-[11.5px] text-fg-3">{c.source} · {timeAgo(c.createdAt)}</span>
                </div>
              ))}
              <button onClick={() => navigate(routes.project(project.id, 'files') + '?view=changes')} className="cursor-pointer pt-2.5 text-[12.5px] text-accent-text hover:underline">
                View all changes →
              </button>
            </div>
          )}
        </Card>
      </div>
      <div className="space-y-5">
        <Card className="p-5">
          <SectionTitle>Instructions</SectionTitle>
          <div className="max-h-48 overflow-y-auto whitespace-pre-wrap text-[13px] leading-relaxed text-fg-2">{project.instructions || <span className="text-fg-3">No instructions yet. Add them in Settings — every chat and agent in this project receives them.</span>}</div>
        </Card>
        {project.robloxEnabled && (
          <Card className="p-5">
            <SectionTitle>Roblox Studio</SectionTitle>
            <div className="flex items-center gap-2 text-[13px]">
              <StatusDot tone={roblox?.state === 'connected' ? 'success' : roblox?.state === 'error' ? 'danger' : 'neutral'} />
              {roblox?.state === 'connected' ? 'Connected' : roblox?.state === 'connecting' ? 'Connecting…' : roblox?.state === 'error' ? 'Connection error' : 'Not connected'}
            </div>
            {roblox?.studios.length ? <div className="mt-1.5 text-[12.5px] text-fg-3">{roblox.studios.map((s) => s.name).join(', ')}</div> : null}
            <Button size="sm" variant="secondary" className="mt-3" onClick={() => navigate(routes.roblox())}>
              Open Studio connection
            </Button>
          </Card>
        )}
        <Card className="p-5">
          <SectionTitle>Recent chats</SectionTitle>
          {chats.length === 0 ? (
            <div className="text-[13px] text-fg-3">No chats yet.</div>
          ) : (
            <div className="-mx-2 space-y-px">
              {chats.slice(0, 6).map((c) => (
                <button key={c.id} onClick={() => navigate(routes.chat(c.id))} className="flex w-full cursor-pointer items-center gap-2 rounded-lg px-2 py-1.5 text-left text-[13px] text-fg-2 hover:bg-surface-2 hover:text-fg">
                  <ProviderMark provider={c.provider} size="xs" />
                  <span className="min-w-0 flex-1 truncate">{c.title}</span>
                  <span className="text-[11px] text-fg-3">{timeAgo(c.updatedAt)}</span>
                </button>
              ))}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}

function ChatsTab({ project }: { project: Project }) {
  const chats = useApp(useShallow((s) => s.chats.filter((c) => c.projectId === project.id)));
  if (!chats.length)
    return (
      <Card>
        <EmptyState icon={<MessageSquare className="size-5" />} title="No chats in this project" description="Chats started here automatically include the project instructions, memory and relevant files." action={<Button variant="primary" icon={<MessageSquarePlus className="size-4" />} onClick={() => navigate(routes.newChat(project.id))}>New chat in project</Button>} />
      </Card>
    );
  return (
    <Card className="divide-y divide-line">
      {chats.map((c) => (
        <button key={c.id} onClick={() => navigate(routes.chat(c.id))} className="flex w-full cursor-pointer items-center gap-3 px-5 py-3.5 text-left hover:bg-surface-2/50">
          <ProviderMark provider={c.provider} size="sm" />
          <div className="min-w-0 flex-1">
            <div className="truncate text-[13.5px] font-medium text-fg">{c.title}</div>
            <div className="truncate text-[12px] text-fg-3">{c.preview || '—'}</div>
          </div>
          <Badge>{c.mode === 'cowork' ? 'Cowork' : 'Chat'}</Badge>
          <span className="w-16 text-right text-[11.5px] text-fg-3">{timeAgo(c.updatedAt)}</span>
        </button>
      ))}
    </Card>
  );
}

function TreeNode({ project, entry, depth, onOpen, selected }: { project: Project; entry: FileEntry; depth: number; onOpen: (p: string) => void; selected: string | null }) {
  const [open, setOpen] = useState(false);
  const [children, setChildren] = useState<FileEntry[] | null>(null);
  const toggle = async () => {
    if (entry.type === 'file') return onOpen(entry.path);
    if (!open && !children) setChildren(await api.get<FileEntry[]>(`/api/projects/${project.id}/files?path=${encodeURIComponent(entry.path)}`, { silent: true }).catch(() => []));
    setOpen(!open);
  };
  const isCode = /\.(lua|luau|ts|tsx|js|jsx|json|py|toml|md|css|html)$/i.test(entry.name);
  return (
    <div>
      <button onClick={toggle} className={cn('flex w-full cursor-pointer items-center gap-1.5 rounded-md py-1 pr-2 text-left text-[12.75px] hover:bg-surface-2', selected === entry.path ? 'bg-accent-soft text-fg' : 'text-fg-2')} style={{ paddingLeft: 6 + depth * 14 }}>
        {entry.type === 'dir' ? (
          <>
            <ChevronRight className={cn('size-3 shrink-0 text-fg-3 transition-transform', open && 'rotate-90')} />
            {open ? <FolderOpen className="size-3.5 shrink-0 text-accent" /> : <Folder className="size-3.5 shrink-0 text-fg-3" />}
          </>
        ) : (
          <>
            <span className="w-3 shrink-0" />
            {isCode ? <FileCode className="size-3.5 shrink-0 text-fg-3" /> : <File className="size-3.5 shrink-0 text-fg-3" />}
          </>
        )}
        <span className="truncate">{entry.name}</span>
      </button>
      {open && children?.map((c) => <TreeNode key={c.path} project={project} entry={c} depth={depth + 1} onOpen={onOpen} selected={selected} />)}
    </div>
  );
}

function DiffView({ diff }: { diff: string }) {
  return (
    <pre className="overflow-x-auto rounded-xl border border-line bg-code py-2 font-mono text-[12px] leading-[1.6]">
      {diff.split('\n').map((l, i) => (
        <div key={i} className={cn('px-3.5', l.startsWith('+') && !l.startsWith('+++') ? 'diff-add' : l.startsWith('-') && !l.startsWith('---') ? 'diff-del' : l.startsWith('@@') ? 'diff-hunk' : 'text-fg-3')}>
          {l || ' '}
        </div>
      ))}
    </pre>
  );
}

function FilesTab({ project, initialView }: { project: Project; initialView: string }) {
  const [view, setView] = useState<'files' | 'changes'>(initialView === 'changes' ? 'changes' : 'files');
  const [root, setRoot] = useState<FileEntry[] | null>(null);
  const [file, setFile] = useState<string | null>(null);
  const [content, setContent] = useState<{ content: string; binary: boolean; truncated: boolean; size: number } | null>(null);
  const [changes, setChanges] = useState<FileChange[]>([]);
  const [openChange, setOpenChange] = useState<string | null>(null);
  const changesTick = useApp((s) => s.changesTick);
  useEffect(() => {
    if (project.folderPath) api.get<FileEntry[]>(`/api/projects/${project.id}/files`, { silent: true }).then(setRoot, (e) => (setRoot([]), toast.error(e.message)));
  }, [project.id, project.folderPath]);
  useEffect(() => {
    api.get<FileChange[]>(`/api/projects/${project.id}/changes`, { silent: true }).then(setChanges, () => undefined);
  }, [project.id, changesTick]);
  useEffect(() => {
    if (!file) return;
    setContent(null);
    api.get<typeof content>(`/api/projects/${project.id}/file?path=${encodeURIComponent(file)}`).then(setContent, () => setContent(null));
  }, [file, project.id]);
  if (!project.folderPath)
    return (
      <Card>
        <EmptyState icon={<FolderX className="size-5" />} title="No folder linked" description="Link the folder that contains this game’s code (for example a Rojo project) so agents can read and edit files safely inside it." action={<Button variant="primary" onClick={() => navigate(routes.project(project.id, 'settings'))}>Link a folder</Button>} />
      </Card>
    );
  const lang = file?.split('.').pop()?.toLowerCase();
  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <Segmented value={view} onChange={(v) => setView(v)} options={[{ value: 'files', label: 'Browse files' }, { value: 'changes', label: <>Changes {changes.length ? <span className="text-fg-3">({changes.length})</span> : null}</> }]} />
        <Button size="sm" variant="ghost" icon={<FolderOpen className="size-3.5" />} onClick={() => api.post(`/api/projects/${project.id}/open-folder`)}>
          Open in Explorer
        </Button>
      </div>
      {view === 'files' ? (
        <div className="grid min-h-[560px] grid-cols-1 overflow-hidden rounded-2xl border border-line md:grid-cols-[280px_1fr]">
          <div className="max-h-[70vh] overflow-y-auto border-r border-line bg-surface p-2">
            {root === null ? <Spinner className="m-3" /> : root.length === 0 ? <div className="p-3 text-[12.5px] text-fg-3">Folder is empty.</div> : root.map((e) => <TreeNode key={e.path} project={project} entry={e} depth={0} onOpen={setFile} selected={file} />)}
          </div>
          <div className="max-h-[70vh] min-w-0 overflow-auto bg-bg p-4">
            {!file ? (
              <div className="flex h-full items-center justify-center text-[13px] text-fg-3">Select a file to preview it (read-only).</div>
            ) : !content ? (
              <Spinner />
            ) : content.binary ? (
              <div className="text-[13px] text-fg-3">Binary file ({fmtBytes(content.size)}) — no preview.</div>
            ) : (
              <>
                <div className="mb-2 flex items-center justify-between text-[12px] text-fg-3">
                  <span className="font-mono">{file}</span>
                  <span>{fmtBytes(content.size)}{content.truncated ? ' · preview truncated' : ''}</span>
                </div>
                <CodeBlock code={content.content} lang={lang === 'luau' ? 'lua' : lang} />
              </>
            )}
          </div>
        </div>
      ) : changes.length === 0 ? (
        <Card>
          <EmptyState icon={<GitCompare className="size-5" />} title="No changes yet" description="Every file a Cowork chat or agent changes in this folder is recorded here with a diff, and can be reverted." />
        </Card>
      ) : (
        <Card className="divide-y divide-line">
          {changes.map((c) => (
            <div key={c.id}>
              <div className="flex cursor-pointer items-center gap-3 px-4 py-3 hover:bg-surface-2/50" onClick={() => setOpenChange(openChange === c.id ? null : c.id)}>
                <ChevronRight className={cn('size-3.5 text-fg-3 transition-transform', openChange === c.id && 'rotate-90')} />
                <Badge tone={c.change === 'added' ? 'success' : c.change === 'deleted' ? 'danger' : 'info'}>{c.change}</Badge>
                <span className="min-w-0 flex-1 truncate font-mono text-[12.5px] text-fg">{c.path}</span>
                <span className="text-[11.5px] text-fg-3">
                  {c.source === 'task' ? 'agent' : c.source} · {timeAgo(c.createdAt)}
                </span>
                {c.reverted ? (
                  <Badge>reverted</Badge>
                ) : (
                  <Button
                    size="xs"
                    variant="ghost"
                    icon={<RotateCcw className="size-3.5" />}
                    onClick={async (e) => {
                      e.stopPropagation();
                      const r = await confirmDialog({ title: `Revert ${c.path}?`, body: 'The file is restored to its content from before this change. Later edits to the same file are overwritten.', confirmLabel: 'Revert', danger: true });
                      if (r.ok) {
                        await api.post(`/api/changes/${c.id}/revert`);
                        toast.success('Change reverted');
                      }
                    }}
                  >
                    Revert
                  </Button>
                )}
              </div>
              {openChange === c.id && c.diff && (
                <div className="px-4 pb-4">
                  <DiffView diff={c.diff} />
                </div>
              )}
            </div>
          ))}
        </Card>
      )}
    </div>
  );
}

function SettingsTab({ project }: { project: Project }) {
  const [v, setV] = useState<Partial<Project> & { createFolder?: boolean }>(project);
  const [busy, setBusy] = useState(false);
  const [defaults, setDefaults] = useState(project.defaults);
  useEffect(() => {
    setV(project);
    setDefaults(project.defaults);
  }, [project.id]); // eslint-disable-line react-hooks/exhaustive-deps
  const save = async () => {
    setBusy(true);
    try {
      await api.patch(`/api/projects/${project.id}`, { name: v.name, icon: v.icon, color: v.color, description: v.description, folderPath: v.folderPath ?? '', createFolder: v.createFolder, instructions: v.instructions, robloxEnabled: v.robloxEnabled, defaults });
      toast.success('Project saved');
    } finally {
      setBusy(false);
    }
  };
  const provider: Provider = defaults.provider ?? 'claude';
  return (
    <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
      <Card className="p-6 lg:col-span-2">
        <ProjectForm value={v} onChange={setV} />
        <div className="mt-6 flex justify-end">
          <Button variant="primary" loading={busy} onClick={save} icon={<Save className="size-4" />}>
            Save changes
          </Button>
        </div>
      </Card>
      <div className="space-y-5">
        <Card className="p-5">
          <SectionTitle>Defaults for new chats</SectionTitle>
          <div className="space-y-3">
            <ModelPicker side="bottom" value={{ provider, accountId: defaults.accountId ?? null, model: defaults.model ?? '', effort: defaults.effort ?? '' }} onChange={(p) => setDefaults({ ...defaults, ...p })} />
            <Segmented value={(defaults.mode ?? 'cowork') as ChatMode} onChange={(m) => setDefaults({ ...defaults, mode: m })} options={[{ value: 'chat', label: 'Chat' }, { value: 'cowork', label: 'Cowork' }]} />
            <div className="text-[12px] text-fg-3">Saved with “Save changes”.</div>
          </div>
        </Card>
        <Card className="border-danger/25 p-5">
          <SectionTitle>Danger zone</SectionTitle>
          <p className="mb-3 text-[12.5px] leading-relaxed text-fg-3">Deleting a project keeps its chats (they move out of the project) and never deletes files in your folder.</p>
          <Button
            variant="danger"
            size="sm"
            icon={<Trash2 className="size-3.5" />}
            onClick={async () => {
              const r = await confirmDialog({ title: `Delete “${project.name}”?`, body: 'Chats are kept. Files in your folder are not touched.', confirmLabel: 'Delete project', danger: true });
              if (r.ok) {
                await api.del(`/api/projects/${project.id}`);
                navigate(routes.projects());
              }
            }}
          >
            Delete project
          </Button>
        </Card>
      </div>
    </div>
  );
}

export function ProjectWorkspace({ id, tab }: { id: string; tab: string }) {
  const project = useApp((s) => s.projects.find((p) => p.id === id));
  const chats = useApp((s) => s.chats.filter((c) => c.projectId === id).length);
  const query = useMemo(() => new URLSearchParams(window.location.hash.split('?')[1] ?? ''), [tab]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!project)
    return (
      <Page>
        <EmptyState title="Project not found" action={<Button onClick={() => navigate(routes.projects())}>All projects</Button>} />
      </Page>
    );
  return (
    <Page wide>
      <PageHeader
        icon={<ProjectIcon icon={project.icon} color={project.color} size="lg" />}
        eyebrow={
          <button onClick={() => navigate(routes.projects())} className="cursor-pointer hover:text-fg-2">
            Projects
          </button>
        }
        title={project.name}
        description={
          <span className="flex flex-wrap items-center gap-x-3 gap-y-1">
            {project.description && <span>{project.description}</span>}
            {project.folderPath ? (
              <button onClick={() => api.post(`/api/projects/${project.id}/open-folder`)} className="inline-flex cursor-pointer items-center gap-1 font-mono text-[12px] hover:text-fg-2">
                <FolderOpen className="size-3.5" /> {project.folderPath}
              </button>
            ) : (
              <span className="text-[12px] text-warning">No folder linked</span>
            )}
          </span>
        }
        actions={
          <>
            <Button variant="secondary" icon={<Workflow className="size-4" />} onClick={() => navigate(routes.project(project.id, 'agents'))}>
              Run agents
            </Button>
            <Button variant="primary" icon={<MessageSquarePlus className="size-4" />} onClick={() => navigate(routes.newChat(project.id))}>
              New chat
            </Button>
          </>
        }
      />
      <Tabs
        className="mb-6"
        value={tab}
        onChange={(t) => navigate(routes.project(project.id, t))}
        tabs={[
          { value: 'overview', label: 'Overview' },
          { value: 'chats', label: 'Chats', count: chats },
          { value: 'files', label: 'Files' },
          { value: 'agents', label: 'Agents' },
          { value: 'tasks', label: 'Tasks', count: project.stats?.runs },
          { value: 'settings', label: 'Settings' },
        ]}
      />
      {tab === 'overview' && <Overview project={project} />}
      {tab === 'chats' && <ChatsTab project={project} />}
      {tab === 'files' && <FilesTab project={project} initialView={query.get('view') ?? 'files'} />}
      {tab === 'agents' && (
        <div className="space-y-6">
          <RunLauncher projectId={project.id} />
          <div className="flex items-center gap-2 text-[12.5px] text-fg-3">
            <Gauge className="size-3.5" /> Agents get the project instructions, memory and a shared, token-budgeted project brief — so they don’t each re-read the whole project.
          </div>
        </div>
      )}
      {tab === 'tasks' && <RunList projectId={project.id} />}
      {tab === 'settings' && <SettingsTab project={project} />}
    </Page>
  );
}
