import { useEffect, useState } from 'react';
import { CircleCheck, Clock, ExternalLink, Info, KeyRound, LogIn, LogOut, MoreHorizontal, Pencil, Plus, Power, RefreshCw, ShieldCheck, Star, Terminal, Trash2, Laptop, FolderLock, Copy } from 'lucide-react';
import { toast } from 'sonner';
import type { Account, Provider } from '@shared/types';
import { useApp } from '../store/app';
import { api } from '../lib/api';
import { cn, resetIn, timeAgo } from '../lib/utils';
import { navigate, routes } from '../lib/router';
import { Page, PageHeader } from '../components/layout/Page';
import { Badge, Button, Card, IconButton, Input, Progress, Spinner, StatusDot, Tooltip } from '../components/ui/primitives';
import { Dialog, Menu, confirmDialog } from '../components/ui/overlays';
import { ProviderMark, providerName } from '../components/brand';

export function authLabel(m: string | null | undefined): string {
  if (!m) return 'Signed in';
  const map: Record<string, string> = { oauth_token: 'Claude subscription sign-in', 'claude.ai': 'Claude subscription sign-in', api_key: 'API key', apiKey: 'API key', chatgpt: 'ChatGPT sign-in', console: 'Anthropic Console' };
  return map[m] ?? m;
}

export function statusInfo(a: Account): { tone: 'success' | 'warning' | 'danger' | 'neutral' | 'info'; label: string } {
  switch (a.status) {
    case 'signed_in':
      return { tone: 'success', label: 'Signed in' };
    case 'signed_out':
      return { tone: 'danger', label: 'Not signed in' };
    case 'signing_in':
      return { tone: 'warning', label: 'Signing in…' };
    case 'checking':
      return { tone: 'info', label: 'Checking…' };
    case 'cli_missing':
      return { tone: 'danger', label: 'CLI not installed' };
    case 'error':
      return { tone: 'danger', label: 'Error' };
    default:
      return { tone: 'neutral', label: 'Unknown' };
  }
}

export function LimitBars({ account, compact }: { account: Account; compact?: boolean }) {
  const lim = account.limits;
  if (!lim || !lim.windows.length)
    return (
      <div className="text-[12px] leading-relaxed text-fg-3">
        {account.provider === 'claude' ? 'Usage windows appear after the first message (reported by Claude Code).' : account.status === 'signed_in' ? 'Codex did not report usage limits for this account.' : 'Sign in to see usage limits reported by Codex.'}
      </div>
    );
  return (
    <div className={cn('space-y-2.5', compact && 'space-y-2')}>
      {lim.windows.map((w) => (
        <div key={w.id}>
          <div className="mb-1 flex items-center justify-between text-[12px]">
            <span className="text-fg-2">{w.label}</span>
            <span className="tabular-nums text-fg-3">
              {isFinite(w.usedPercent) ? `${Math.round(w.usedPercent)}% used` : '—'} {w.resetsAt ? `· ${resetIn(w.resetsAt)}` : ''}
            </span>
          </div>
          <Progress value={w.usedPercent} tone={w.usedPercent > 90 ? 'danger' : w.usedPercent > 70 ? 'warning' : 'accent'} />
        </div>
      ))}
      <div className="flex flex-wrap items-center gap-x-1.5 gap-y-0.5 text-[11px] text-fg-3">
        <ShieldCheck className="size-3 text-success" /> Reported by {lim.source === 'claude-code' ? 'Claude Code' : 'Codex'} · {timeAgo(lim.updatedAt)}
        {lim.note && <span className="w-full pl-[18px]">{lim.note}</span>}
      </div>
    </div>
  );
}

function AccountCard({ a }: { a: Account }) {
  const st = statusInfo(a);
  const [renaming, setRenaming] = useState(false);
  const [name, setName] = useState(a.name);
  const [busy, setBusy] = useState(false);
  const run = async (fn: () => Promise<unknown>) => {
    setBusy(true);
    try {
      await fn();
    } finally {
      setBusy(false);
    }
  };
  const signIn = () =>
    run(async () => {
      const r = await api.post<{ kind: string; url?: string; code?: string; manualCommand?: string }>(`/api/accounts/${a.id}/login`, { method: 'browser' });
      if (r.manualCommand) toast.info('Run this in a terminal to sign in', { description: r.manualCommand, duration: 20000 });
      else if (a.provider === 'claude') toast.info('A sign-in window opened', { description: 'Finish signing in there (your browser will open). BLOXADE detects it automatically.' });
      else toast.info('Your browser opened the ChatGPT sign-in page', { description: 'BLOXADE updates automatically when you finish.' });
    });

  return (
    <Card className={cn('flex flex-col p-5 transition-colors', !a.enabled && 'opacity-60')}>
      <div className="flex items-start gap-3">
        <ProviderMark provider={a.provider} size="lg" />
        <div className="min-w-0 flex-1">
          {renaming ? (
            <Input
              autoFocus
              value={name}
              onChange={(e) => setName(e.target.value)}
              onBlur={async () => {
                setRenaming(false);
                if (name.trim() && name !== a.name) await api.patch(`/api/accounts/${a.id}`, { name: name.trim() });
              }}
              onKeyDown={(e) => e.key === 'Enter' && (e.target as HTMLInputElement).blur()}
            />
          ) : (
            <div className="flex items-center gap-2">
              <span className="truncate text-[15px] font-semibold text-fg">{a.name}</span>
              {a.isDefault && (
                <Tooltip content="Default account for new chats and agents">
                  <Star className="size-3.5 fill-warning text-warning" />
                </Tooltip>
              )}
            </div>
          )}
          <div className="mt-0.5 truncate text-[12.5px] text-fg-3">{a.email ?? (a.status === 'signed_in' ? authLabel(a.authMethod) : a.statusDetail ?? '—')}{a.plan ? ` · ${a.plan}` : ''}</div>
        </div>
        <Menu
          trigger={
            <IconButton label="Account options">
              <MoreHorizontal className="size-4" />
            </IconButton>
          }
          items={[
            { label: 'Rename', icon: <Pencil className="size-3.5" />, onSelect: () => (setName(a.name), setRenaming(true)) },
            { label: 'Set as default', icon: <Star className="size-3.5" />, disabled: a.isDefault, onSelect: () => api.post(`/api/accounts/${a.id}/default`) },
            { label: a.enabled ? 'Disable' : 'Enable', icon: <Power className="size-3.5" />, onSelect: () => api.patch(`/api/accounts/${a.id}`, { enabled: !a.enabled }) },
            { label: 'Open terminal with this profile', icon: <Terminal className="size-3.5" />, onSelect: () => api.post(`/api/accounts/${a.id}/terminal`) },
            { separator: true },
            ...(a.status === 'signed_in' ? [{ label: 'Sign out', icon: <LogOut className="size-3.5" />, onSelect: () => run(() => api.post(`/api/accounts/${a.id}/logout`)) }] : []),
            {
              label: 'Remove from BLOXADE',
              icon: <Trash2 className="size-3.5" />,
              danger: true,
              onSelect: async () => {
                const r = await confirmDialog({
                  title: `Remove “${a.name}”?`,
                  body: a.isSystem ? 'BLOXADE will stop using this computer’s default sign-in. Your CLI login itself is not changed.' : 'The account is removed from BLOXADE. You can also delete its isolated profile folder (this signs it out permanently).',
                  confirmLabel: 'Remove',
                  danger: true,
                  checkbox: a.isSystem ? undefined : 'Also delete the isolated profile folder',
                });
                if (r.ok) await api.del(`/api/accounts/${a.id}${r.checked ? '?removeProfile=1' : ''}`);
              },
            },
          ]}
        />
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-2">
        <Badge tone={st.tone === 'neutral' ? 'neutral' : st.tone} dot>
          {st.label}
        </Badge>
        {(a.activeSessions ?? 0) > 0 && (
          <Badge tone="accent">
            <StatusDot tone="accent" pulse /> {a.activeSessions} active session{a.activeSessions === 1 ? '' : 's'}
          </Badge>
        )}
        <Badge tone="neutral">
          {a.isSystem ? <Laptop className="size-3" /> : <FolderLock className="size-3" />}
          {a.isSystem ? 'This PC’s sign-in' : 'Isolated profile'}
        </Badge>
      </div>
      {a.status === 'error' && a.statusDetail && <div className="mt-3 rounded-lg bg-danger/10 px-3 py-2 text-[12px] leading-relaxed text-danger">{a.statusDetail}</div>}
      {a.login?.kind === 'device' && a.login.code && (
        <div className="mt-3 rounded-xl border border-accent/30 bg-accent-softer p-3 text-[12.5px]">
          <div className="text-fg-2">
            Open <a className="text-accent-text underline" href={a.login.url} target="_blank" rel="noreferrer">{a.login.url}</a> and enter:
          </div>
          <div className="mt-1.5 font-mono text-[20px] font-semibold tracking-[0.2em] text-fg">{a.login.code}</div>
        </div>
      )}

      <div className="mt-4 flex-1 border-t border-line pt-4">
        <LimitBars account={a} />
      </div>

      <div className="mt-4 flex items-center justify-between gap-2">
        <span className="flex items-center gap-1.5 text-[11.5px] text-fg-3">
          <Clock className="size-3" /> {a.lastUsedAt ? `Used ${timeAgo(a.lastUsedAt)}` : 'Not used yet'}
        </span>
        <div className="flex items-center gap-1.5">
          <IconButton label="Refresh status" onClick={() => run(() => api.post(`/api/accounts/${a.id}/refresh`))}>
            <RefreshCw className={cn('size-4', (busy || a.status === 'checking') && 'animate-spin')} />
          </IconButton>
          {a.status === 'signing_in' ? (
            <Button size="sm" variant="ghost" onClick={() => api.post(`/api/accounts/${a.id}/login/cancel`)}>
              <Spinner className="size-3.5" /> Cancel sign-in
            </Button>
          ) : a.status !== 'signed_in' ? (
            <Button size="sm" variant="primary" icon={<LogIn className="size-3.5" />} loading={busy} onClick={signIn} disabled={a.status === 'cli_missing'}>
              {a.provider === 'codex' ? 'Sign in with ChatGPT' : 'Sign in'}
            </Button>
          ) : (
            <Button size="sm" variant="secondary" onClick={() => navigate(routes.newChat())}>
              Launch session
            </Button>
          )}
        </div>
      </div>
    </Card>
  );
}

export function AddAccountDialog({ open, onOpenChange, provider: initial }: { open: boolean; onOpenChange: (o: boolean) => void; provider?: Provider }) {
  const [step, setStep] = useState(0);
  const [provider, setProvider] = useState<Provider>(initial ?? 'claude');
  const [mode, setMode] = useState<'isolated' | 'system'>('isolated');
  const [name, setName] = useState('');
  const [created, setCreated] = useState<string | null>(null);
  const [method, setMethod] = useState<'browser' | 'device'>('browser');
  const [busy, setBusy] = useState(false);
  const accounts = useApp((s) => s.accounts);
  const clis = useApp((s) => s.clis);
  const account = accounts.find((a) => a.id === created) ?? null;
  const hasSystem = accounts.some((a) => a.provider === provider && a.isSystem);

  useEffect(() => {
    if (open) {
      setStep(initial ? 1 : 0);
      setProvider(initial ?? 'claude');
      setMode('isolated');
      setName('');
      setCreated(null);
      setMethod('browser');
    }
  }, [open, initial]);

  const create = async () => {
    setBusy(true);
    try {
      const a = await api.post<Account>('/api/accounts', { provider, name: name.trim() || undefined, useSystem: mode === 'system' });
      useApp.getState().apply('account.updated', a);
      setCreated(a.id);
      setStep(2);
    } finally {
      setBusy(false);
    }
  };
  const signIn = async () => {
    if (!created) return;
    setBusy(true);
    try {
      const r = await api.post<{ manualCommand?: string }>(`/api/accounts/${created}/login`, { method });
      if (r.manualCommand) toast.info('Run this command in a terminal to sign in', { description: r.manualCommand, duration: 30000 });
    } finally {
      setBusy(false);
    }
  };
  const count = accounts.filter((a) => a.provider === provider).length;

  return (
    <Dialog
      open={open}
      onOpenChange={onOpenChange}
      title={step === 0 ? 'Add an AI account' : `Add a ${providerName(provider)} account`}
      description={step === 2 ? 'Sign in with the official CLI — BLOXADE never sees your password or tokens.' : 'Each account gets its own isolated profile so several can run side by side.'}
      footer={
        step === 1 ? (
          <>
            <Button variant="ghost" onClick={() => (initial ? onOpenChange(false) : setStep(0))}>
              {initial ? 'Cancel' : 'Back'}
            </Button>
            <Button variant="primary" loading={busy} onClick={create} disabled={mode === 'system' && hasSystem}>
              Continue
            </Button>
          </>
        ) : step === 2 ? (
          <Button variant={account?.status === 'signed_in' ? 'primary' : 'ghost'} onClick={() => onOpenChange(false)}>
            {account?.status === 'signed_in' ? 'Done' : 'Finish later'}
          </Button>
        ) : undefined
      }
    >
      {step === 0 && (
        <div className="grid grid-cols-2 gap-3">
          {(['claude', 'codex'] as Provider[]).map((p) => (
            <button key={p} onClick={() => (setProvider(p), setStep(1))} className="cursor-pointer rounded-2xl border border-line bg-surface-2/40 p-5 text-left transition-colors hover:border-line-strong hover:bg-surface-2">
              <ProviderMark provider={p} size="lg" />
              <div className="mt-3 text-[14px] font-semibold">{providerName(p)}</div>
              <div className="mt-1 text-[12.5px] leading-relaxed text-fg-3">{p === 'claude' ? 'Use your Claude subscription (Pro/Max/Team) or Console account.' : 'Use your ChatGPT subscription (Plus/Pro/Business) or an API key.'}</div>
              {clis && !clis[p].found && <div className="mt-2 text-[11.5px] text-warning">CLI not installed yet</div>}
            </button>
          ))}
        </div>
      )}
      {step === 1 && (
        <div className="space-y-4">
          {clis && !clis[provider].found && (
            <div className="rounded-xl bg-warning/10 px-3.5 py-3 text-[12.5px] leading-relaxed text-warning">
              {providerName(provider)} is not installed on this computer. Install it first ({provider === 'claude' ? 'claude.com/claude-code' : 'developers.openai.com/codex'}), then refresh in Settings → AI Providers.
            </div>
          )}
          <div className="grid gap-2.5">
            {[
              { v: 'isolated' as const, icon: FolderLock, title: 'New isolated account', desc: `A separate profile folder (${provider === 'claude' ? 'CLAUDE_CONFIG_DIR' : 'CODEX_HOME'}) so this account can be signed in alongside others.` },
              { v: 'system' as const, icon: Laptop, title: 'Use this computer’s existing sign-in', desc: hasSystem ? 'Already added.' : `Use the account you are already signed into with ${provider === 'claude' ? 'claude' : 'codex'} on this PC.` },
            ].map((o) => (
              <button
                key={o.v}
                disabled={o.v === 'system' && hasSystem}
                onClick={() => setMode(o.v)}
                className={cn('flex cursor-pointer items-start gap-3 rounded-xl border p-3.5 text-left transition-colors disabled:cursor-not-allowed disabled:opacity-50', mode === o.v ? 'border-accent/60 bg-accent-softer' : 'border-line hover:bg-surface-2')}
              >
                <o.icon className={cn('mt-0.5 size-4', mode === o.v ? 'text-accent' : 'text-fg-3')} />
                <span>
                  <span className="block text-[13.5px] font-medium">{o.title}</span>
                  <span className="mt-0.5 block text-[12.5px] leading-relaxed text-fg-3">{o.desc}</span>
                </span>
              </button>
            ))}
          </div>
          <div className="space-y-1.5">
            <label className="text-[12.5px] font-medium text-fg-2">Nickname</label>
            <Input data-autofocus value={name} onChange={(e) => setName(e.target.value)} placeholder={mode === 'system' ? `${provider === 'claude' ? 'Claude' : 'Codex'} (this PC)` : `${provider === 'claude' ? 'Claude' : 'Codex'} Account ${count + 1}`} />
          </div>
        </div>
      )}
      {step === 2 && account && (
        <div className="space-y-4">
          <div className="flex items-center gap-3 rounded-xl border border-line bg-surface-2/40 p-3.5">
            <ProviderMark provider={provider} size="md" />
            <div className="min-w-0 flex-1">
              <div className="text-[13.5px] font-medium">{account.name}</div>
              <div className="truncate font-mono text-[11.5px] text-fg-3">{account.profileDir ?? 'Default CLI profile on this computer'}</div>
            </div>
            <Badge tone={statusInfo(account).tone === 'neutral' ? 'neutral' : statusInfo(account).tone} dot>
              {statusInfo(account).label}
            </Badge>
          </div>
          {account.status === 'signed_in' ? (
            <div className="flex items-center gap-3 rounded-xl bg-success/10 p-4 text-[13px] text-success">
              <CircleCheck className="size-5" />
              <div>
                <div className="font-medium">Connected{account.email ? ` as ${account.email}` : ''}</div>
                <div className="text-[12px] opacity-80">You can now pick this account in any chat or agent.</div>
              </div>
            </div>
          ) : (
            <>
              <ol className="space-y-2.5 text-[13px] leading-relaxed text-fg-2">
                {provider === 'claude' ? (
                  <>
                    <li>1. Press <b>Sign in</b> — a small window opens running <code className="rounded bg-surface-2 px-1 font-mono text-[12px]">claude auth login</code> with this account’s profile.</li>
                    <li>2. Your browser opens the official Claude sign-in page. Approve access.</li>
                    <li>3. If the window asks for a code, paste it there (not into BLOXADE). BLOXADE detects the sign-in automatically.</li>
                  </>
                ) : (
                  <>
                    <li>1. Press <b>Sign in with ChatGPT</b> — your browser opens the official OpenAI sign-in page.</li>
                    <li>2. Sign in and approve. Codex receives the login on <span className="font-mono">localhost:1455</span>.</li>
                    <li>3. This dialog updates automatically. Only one Codex sign-in can run at a time.</li>
                  </>
                )}
              </ol>
              {provider === 'codex' && (
                <div className="flex gap-2 text-[12px]">
                  <button onClick={() => setMethod('browser')} className={cn('cursor-pointer rounded-lg border px-2.5 py-1', method === 'browser' ? 'border-accent/60 bg-accent-softer' : 'border-line')}>
                    Browser sign-in
                  </button>
                  <button onClick={() => setMethod('device')} className={cn('cursor-pointer rounded-lg border px-2.5 py-1', method === 'device' ? 'border-accent/60 bg-accent-softer' : 'border-line')}>
                    Device code (other device)
                  </button>
                </div>
              )}
              {account.login?.kind === 'device' && account.login.code && (
                <div className="rounded-xl border border-accent/30 bg-accent-softer p-4">
                  <div className="text-[12.5px] text-fg-2">Open the link and enter this code:</div>
                  <div className="mt-1 flex items-center gap-3">
                    <span className="font-mono text-[24px] font-semibold tracking-[0.25em]">{account.login.code}</span>
                    <IconButton label="Copy code" onClick={() => navigator.clipboard.writeText(account.login!.code!)}>
                      <Copy className="size-4" />
                    </IconButton>
                  </div>
                  <a href={account.login.url} target="_blank" rel="noreferrer" className="mt-1 inline-flex items-center gap-1 text-[12.5px] text-accent-text underline">
                    {account.login.url} <ExternalLink className="size-3" />
                  </a>
                </div>
              )}
              {account.status === 'signing_in' ? (
                <div className="flex items-center justify-between rounded-xl border border-line p-3.5">
                  <span className="flex items-center gap-2.5 text-[13px] text-fg-2">
                    <Spinner /> Waiting for you to finish signing in…
                  </span>
                  <div className="flex gap-2">
                    {account.login?.url && account.login.kind === 'browser' && (
                      <Button size="sm" variant="ghost" onClick={() => window.open(account.login!.url, '_blank')}>
                        Open page again
                      </Button>
                    )}
                    <Button size="sm" variant="ghost" onClick={() => api.post(`/api/accounts/${account.id}/login/cancel`)}>
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <Button variant="primary" size="lg" className="w-full" icon={<KeyRound className="size-4" />} loading={busy} onClick={signIn} disabled={account.status === 'cli_missing'}>
                  {provider === 'codex' ? 'Sign in with ChatGPT' : 'Sign in'}
                </Button>
              )}
            </>
          )}
        </div>
      )}
    </Dialog>
  );
}

export function AccountsPage({ provider }: { provider: Provider | null }) {
  const accounts = useApp((s) => s.accounts);
  const clis = useApp((s) => s.clis);
  const [adding, setAdding] = useState<Provider | null | 'any'>(null);
  const sections: Provider[] = provider ? [provider] : ['claude', 'codex'];
  return (
    <Page wide>
      <PageHeader
        title={provider ? `${providerName(provider)} accounts` : 'Accounts'}
        description="Connect as many Claude Code and Codex accounts as you like. Each one runs with its own isolated profile, so sessions on different accounts can run at the same time."
        actions={
          <>
            <Button variant="secondary" icon={<RefreshCw className="size-4" />} onClick={() => Promise.all(accounts.map((a) => api.post(`/api/accounts/${a.id}/refresh`, {}, { silent: true }))).then(() => toast.success('Account status refreshed'))}>
              Refresh all
            </Button>
            <Button variant="primary" icon={<Plus className="size-4" />} onClick={() => setAdding(provider ?? 'any')}>
              Add account
            </Button>
          </>
        }
      />
      {sections.map((p) => {
        const list = accounts.filter((a) => a.provider === p);
        const cli = clis?.[p];
        return (
          <section key={p} className="mb-10">
            <div className="mb-3.5 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <ProviderMark provider={p} size="sm" />
                <h2 className="text-[15px] font-semibold">{providerName(p)}</h2>
                <span className="text-[12.5px] text-fg-3">
                  {list.filter((a) => a.status === 'signed_in').length} of {list.length} signed in
                </span>
              </div>
              <span className="text-[12px] text-fg-3">{cli?.found ? `CLI ${cli.version ?? ''}` : <span className="text-warning">CLI not found</span>}</span>
            </div>
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
              {list.map((a) => (
                <AccountCard key={a.id} a={a} />
              ))}
              <button onClick={() => setAdding(p)} className="flex min-h-[220px] cursor-pointer flex-col items-center justify-center gap-2 rounded-2xl border border-dashed border-line-strong text-fg-3 transition-colors hover:border-accent/50 hover:bg-accent-softer hover:text-fg-2">
                <Plus className="size-5" />
                <span className="text-[13px] font-medium">Add {providerName(p)} account</span>
              </button>
            </div>
          </section>
        );
      })}
      <Card className="flex gap-3 p-5">
        <Info className="mt-0.5 size-4 shrink-0 text-info" />
        <div className="space-y-2 text-[12.5px] leading-relaxed text-fg-3">
          <p>
            <b className="text-fg-2">How isolation works.</b> Each isolated account uses its own configuration folder through the providers’ documented settings — <span className="font-mono">CLAUDE_CONFIG_DIR</span> for Claude Code and <span className="font-mono">CODEX_HOME</span> for Codex. Sign-in always happens in the official CLI or provider web page; BLOXADE never asks for, reads or copies passwords, tokens or cookies.
          </p>
          <p>
            <b className="text-fg-2">Usage numbers.</b> Limit bars show only what the CLIs report (Claude Code’s 5-hour/weekly windows, Codex rate limits). BLOXADE never estimates remaining messages and does not switch accounts automatically when a limit is reached — each account is subject to its provider’s terms.
          </p>
          <p>
            <b className="text-fg-2">Limitations.</b> Codex’s ChatGPT sign-in uses a fixed local callback port (1455), so sign in one Codex account at a time. Isolation relies on each CLI keeping a profile’s sign-in inside its profile folder (the default on Windows). If you configured a CLI to use a shared system keychain instead, profiles may share one login — each card shows the signed-in email so you can verify after pressing Refresh.
          </p>
        </div>
      </Card>
      <AddAccountDialog open={adding !== null} onOpenChange={(o) => !o && setAdding(null)} provider={adding && adding !== 'any' ? adding : undefined} />
    </Page>
  );
}
