import { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import { ArrowDown, Brain, Code2, FolderInput, GitBranch, Lightbulb, MoreHorizontal, Pencil, Pin, PinOff, ScrollText, Trash2, Wand2, Bug } from 'lucide-react';
import type { AttachmentRef, Chat, ChatMode, Message } from '@shared/types';
import { toast } from 'sonner';
import { useApp } from '../store/app';
import { useUi } from '../store/ui';
import { api } from '../lib/api';
import { navigate, routes, useRoute } from '../lib/router';
import { cn } from '../lib/utils';
import { Composer } from '../components/chat/Composer';
import { MessageItem } from '../components/chat/MessageItem';
import { defaultAccountFor, defaultModelFor, type Selection } from '../components/chat/ModelPicker';
import { IconButton, Skeleton, StatusDot } from '../components/ui/primitives';
import { Menu, confirmDialog } from '../components/ui/overlays';
import { LogoMark } from '../components/brand';
import { ProjectIcon } from '../components/icons';

type Sel = Selection & { mode: ChatMode };

function useNewChatSelection(projectId: string | null): [Sel, (p: Partial<Sel>) => void] {
  const settings = useApp((s) => s.settings);
  const project = useApp((s) => s.projects.find((p) => p.id === projectId));
  const accounts = useApp((s) => s.accounts);
  const make = useCallback((): Sel => {
    const provider = project?.defaults.provider ?? settings?.providers.defaultProvider ?? 'claude';
    return {
      provider,
      accountId: project?.defaults.accountId ?? defaultAccountFor(provider),
      model: project?.defaults.model ?? defaultModelFor(provider),
      effort: project?.defaults.effort ?? settings?.providers.defaultEfforts[provider] ?? '',
      mode: project?.defaults.mode ?? (project?.folderPath ? 'cowork' : settings?.providers.defaultMode ?? 'chat'),
    };
  }, [project, settings]);
  const [sel, setSel] = useState<Sel>(make);
  useEffect(() => setSel(make()), [projectId]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (!sel.accountId && accounts.length) setSel((s) => ({ ...s, accountId: defaultAccountFor(s.provider) }));
  }, [accounts.length]); // eslint-disable-line react-hooks/exhaustive-deps
  return [sel, (p) => setSel((s) => ({ ...s, ...p }))];
}

const SUGGESTIONS = [
  { icon: Lightbulb, title: 'Plan a game system', prompt: 'Help me design a pet-hatching system for my Roblox game: data model, remote events, and anti-exploit checks.' },
  { icon: Code2, title: 'Write Luau', prompt: 'Write a clean Luau ModuleScript for a coin leaderboard with DataStore saving and retry/backoff.' },
  { icon: Bug, title: 'Debug an error', prompt: 'I get "attempt to index nil with Humanoid" when a player respawns. What usually causes this and how do I fix it?' },
  { icon: Wand2, title: 'Polish my UI', prompt: 'Suggest a modern, clean layout for a Roblox shop ScreenGui with tabs, item cards and a purchase confirmation.' },
];

function Welcome({ projectId, onPick }: { projectId: string | null; onPick: (t: string) => void }) {
  const project = useApp((s) => s.projects.find((p) => p.id === projectId));
  const accounts = useApp((s) => s.accounts);
  const hour = new Date().getHours();
  const greet = hour < 5 ? 'Late night build?' : hour < 12 ? 'Good morning.' : hour < 18 ? 'Good afternoon.' : 'Good evening.';
  return (
    <div className="mb-8 flex flex-col items-center text-center">
      {project ? <ProjectIcon icon={project.icon} color={project.color} size="lg" /> : <LogoMark size={40} />}
      <h1 className="mt-5 text-[28px] font-semibold tracking-[-0.025em] text-fg">{project ? project.name : greet}</h1>
      <p className="mt-2 text-[14.5px] text-fg-3">{project ? project.description || 'Start a chat in this project — instructions and memory are shared automatically.' : 'What are we building today?'}</p>
      {accounts.length === 0 && (
        <button onClick={() => navigate(routes.accounts())} className="mt-4 cursor-pointer rounded-full border border-warning/30 bg-warning/10 px-4 py-1.5 text-[12.5px] text-warning hover:bg-warning/15">
          Connect a Claude or Codex account to start →
        </button>
      )}
      <div className="mt-8 grid w-full max-w-[720px] grid-cols-2 gap-2.5 md:grid-cols-4">
        {SUGGESTIONS.map((s) => (
          <button key={s.title} onClick={() => onPick(s.prompt)} className="group cursor-pointer rounded-2xl border border-line bg-surface/60 p-3.5 text-left transition-colors hover:border-line-strong hover:bg-surface">
            <s.icon className="size-4 text-fg-3 group-hover:text-accent" />
            <div className="mt-2.5 text-[13px] font-medium text-fg">{s.title}</div>
            <div className="mt-1 line-clamp-2 text-[12px] leading-snug text-fg-3">{s.prompt}</div>
          </button>
        ))}
      </div>
    </div>
  );
}

function ChatHeader({ chat }: { chat: Chat }) {
  const project = useApp((s) => s.projects.find((p) => p.id === chat.projectId));
  const projects = useApp((s) => s.projects);
  const running = useApp((s) => s.running.has(chat.id));
  const [renaming, setRenaming] = useState(false);
  const [title, setTitle] = useState(chat.title);
  useEffect(() => setTitle(chat.title), [chat.title]);
  const save = async () => {
    setRenaming(false);
    if (title.trim() && title !== chat.title) await api.patch(`/api/chats/${chat.id}`, { title: title.trim() });
  };
  return (
    <div className="flex h-[52px] shrink-0 items-center gap-3 border-b border-line/0 px-4">
      <div className="flex min-w-0 flex-1 items-center gap-2">
        {project && (
          <button onClick={() => navigate(routes.project(project.id))} className="flex shrink-0 cursor-pointer items-center gap-1.5 rounded-lg px-1.5 py-1 text-[12.5px] text-fg-3 hover:bg-surface-2 hover:text-fg-2">
            <ProjectIcon icon={project.icon} color={project.color} size="xs" /> {project.name}
            <span className="text-fg-3">/</span>
          </button>
        )}
        {renaming ? (
          <input
            autoFocus
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            onBlur={save}
            onKeyDown={(e) => {
              if (e.key === 'Enter') void save();
              if (e.key === 'Escape') setRenaming(false);
            }}
            className="h-8 min-w-0 flex-1 rounded-lg border border-accent/50 bg-surface-2 px-2 text-[14px] outline-none"
          />
        ) : (
          <button onClick={() => setRenaming(true)} className="min-w-0 cursor-text truncate rounded-lg px-1.5 py-1 text-[14px] font-medium text-fg hover:bg-surface-2" title="Rename">
            {chat.title}
          </button>
        )}
        {running && (
          <span className="flex items-center gap-1.5 text-[12px] text-fg-3">
            <StatusDot tone="accent" pulse /> working
          </span>
        )}
      </div>
      <Menu
        trigger={
          <IconButton label="Chat options">
            <MoreHorizontal className="size-[18px]" />
          </IconButton>
        }
        items={[
          { label: 'Rename', icon: <Pencil className="size-3.5" />, onSelect: () => setRenaming(true) },
          { label: chat.pinned ? 'Unpin' : 'Pin', icon: chat.pinned ? <PinOff className="size-3.5" /> : <Pin className="size-3.5" />, onSelect: () => api.patch(`/api/chats/${chat.id}`, { pinned: !chat.pinned }) },
          ...(chat.projectId
            ? [
                {
                  label: 'Save insights to project memory',
                  icon: <Brain className="size-3.5" />,
                  onSelect: async () => {
                    const t = toast.loading('Summarizing this chat into project memory…');
                    try {
                      await api.post(`/api/chats/${chat.id}/memory`, {}, { silent: true });
                      toast.success('Project memory updated', { id: t });
                    } catch (e) {
                      toast.error((e as Error).message, { id: t });
                    }
                  },
                },
              ]
            : []),
          { separator: true },
          ...projects.slice(0, 8).map((p) => ({ label: chat.projectId === p.id ? `Remove from ${p.name}` : `Move to ${p.name}`, icon: <FolderInput className="size-3.5" />, onSelect: () => api.patch(`/api/chats/${chat.id}`, { projectId: chat.projectId === p.id ? null : p.id }) })),
          { separator: true },
          {
            label: 'Delete chat',
            icon: <Trash2 className="size-3.5" />,
            danger: true,
            onSelect: async () => {
              const r = await confirmDialog({ title: 'Delete chat?', body: 'This permanently deletes the chat and its messages from this computer.', confirmLabel: 'Delete', danger: true });
              if (r.ok) {
                await api.del(`/api/chats/${chat.id}`);
                navigate(chat.projectId ? routes.project(chat.projectId) : routes.newChat());
              }
            },
          },
        ]}
      />
    </div>
  );
}

function MessageList({ messages, chatId }: { messages: Message[]; chatId: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const [atBottom, setAtBottom] = useState(true);
  const stick = useRef(true);
  const onScroll = () => {
    const el = ref.current;
    if (!el) return;
    const near = el.scrollHeight - el.scrollTop - el.clientHeight < 140;
    stick.current = near;
    setAtBottom(near);
  };
  const lastSig = messages.length ? `${messages.length}:${messages[messages.length - 1].blocks.length}:${JSON.stringify(messages[messages.length - 1].blocks.at(-1) ?? '').length}` : '0';
  useLayoutEffect(() => {
    const el = ref.current;
    if (el && stick.current) el.scrollTop = el.scrollHeight;
  }, [lastSig]);
  useLayoutEffect(() => {
    const el = ref.current;
    if (el) {
      el.scrollTop = el.scrollHeight;
      stick.current = true;
    }
  }, [chatId]);
  const lastUserIdx = messages.map((m) => m.role).lastIndexOf('user');
  const running = messages.some((m) => m.status === 'streaming');
  return (
    <div className="relative min-h-0 flex-1">
      <div ref={ref} onScroll={onScroll} className="h-full overflow-y-auto">
        <div className="mx-auto w-full max-w-[780px] space-y-7 px-5 pb-10 pt-4">
          {messages.map((m, i) => (
            <MessageItem key={m.id} m={m} isLast={i === messages.length - 1 && m.role === 'assistant'} canEdit={!running && i === lastUserIdx} />
          ))}
        </div>
      </div>
      {!atBottom && (
        <button
          onClick={() => {
            const el = ref.current;
            if (el) el.scrollTo({ top: el.scrollHeight, behavior: 'smooth' });
          }}
          className="absolute bottom-4 left-1/2 inline-flex -translate-x-1/2 cursor-pointer items-center gap-1.5 rounded-full border border-line-strong bg-surface px-3 py-1.5 text-[12px] font-medium text-fg-2 shadow-pop hover:text-fg"
        >
          <ArrowDown className="size-3.5" /> {running ? 'New output' : 'Jump to latest'}
        </button>
      )}
    </div>
  );
}

export function ChatPage() {
  const route = useRoute();
  const chatId = route.parts[0] ?? null;
  const projectParam = route.query.get('project');
  const chat = useApp((s) => (chatId ? s.chats.find((c) => c.id === chatId) : undefined));
  const messages = useApp((s) => (chatId ? s.messages[chatId] : undefined));
  const loadChat = useApp((s) => s.loadChat);
  const running = useApp((s) => (chatId ? s.running.has(chatId) : false));
  const [notFound, setNotFound] = useState(false);
  const [newSel, setNewSel] = useNewChatSelection(projectParam);

  useEffect(() => {
    setNotFound(false);
    if (chatId && !messages) loadChat(chatId).catch(() => setNotFound(true));
  }, [chatId]); // eslint-disable-line react-hooks/exhaustive-deps

  const sel: Sel = chat ? { provider: chat.provider, accountId: chat.accountId, model: chat.model, effort: chat.effort, mode: chat.mode } : newSel;
  const changeSel = async (p: Partial<Sel>) => {
    if (!chat) return setNewSel(p);
    useApp.getState().upsertChat({ ...chat, ...p } as Chat);
    await api.patch(`/api/chats/${chat.id}`, p);
  };

  const send = async (text: string, atts: AttachmentRef[]) => {
    let id = chatId;
    if (!id) {
      const c = await api.post<Chat>('/api/chats', { ...newSel, projectId: projectParam });
      useApp.getState().upsertChat(c);
      useApp.setState((s) => ({ messages: { ...s.messages, [c.id]: [] } }));
      id = c.id;
      navigate(routes.chat(c.id));
    }
    const r = await api.post<{ userMessage: Message; assistantMessage: Message }>(`/api/chats/${id}/messages`, { text, attachmentIds: atts.map((a) => a.id) });
    useApp.setState((s) => {
      const list = s.messages[id!] ?? [];
      const merged = [...list.filter((m) => m.id !== r.userMessage.id && m.id !== r.assistantMessage.id), r.userMessage, r.assistantMessage];
      return { messages: { ...s.messages, [id!]: merged } };
    });
  };
  const stop = () => chatId && api.post(`/api/chats/${chatId}/stop`);

  const draftKey = chatId ?? `new:${projectParam ?? ''}`;
  const composer = <Composer draftKey={draftKey} chatId={chatId} selection={sel} onSelectionChange={changeSel} onSend={send} running={running} onStop={stop} projectId={chat?.projectId ?? projectParam} autoFocus large={!chatId} />;

  if (notFound)
    return (
      <div className="flex h-full flex-col items-center justify-center gap-3 text-fg-3">
        <ScrollText className="size-6" />
        This chat no longer exists.
        <button onClick={() => navigate(routes.newChat())} className="cursor-pointer text-accent-text hover:underline">
          Start a new chat
        </button>
      </div>
    );

  if (!chatId) {
    return (
      <div className="flex h-full flex-col overflow-y-auto">
        <div className="m-auto w-full max-w-[780px] px-5 py-10">
          <Welcome projectId={projectParam} onPick={(t) => useUi.getState().setDraft(draftKey, t)} />
          {composer}
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-full min-w-0 flex-col">
      {chat ? <ChatHeader chat={chat} /> : <div className="h-[52px]" />}
      {messages ? (
        messages.length ? (
          <MessageList messages={messages} chatId={chatId} />
        ) : (
          <div className="flex flex-1 items-center justify-center text-[13px] text-fg-3">
            <GitBranch className="mr-2 size-4" /> Empty chat — send a message to begin.
          </div>
        )
      ) : (
        <div className="mx-auto w-full max-w-[780px] flex-1 space-y-6 px-5 pt-8">
          <Skeleton className="ml-auto h-10 w-2/5 rounded-2xl" />
          <Skeleton className="h-4 w-4/5" />
          <Skeleton className="h-4 w-3/5" />
          <Skeleton className="h-4 w-2/3" />
        </div>
      )}
      <div className={cn('mx-auto w-full max-w-[780px] px-5 pb-4')}>{composer}</div>
    </div>
  );
}
