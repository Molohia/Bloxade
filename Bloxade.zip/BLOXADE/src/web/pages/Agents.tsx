import { useEffect, useMemo, useState } from 'react';
import { Dialog as RDialog } from 'radix-ui';
import {
  Ban, Bot, Check, CircleCheck, CircleDashed, CircleX, Clock, Eye, FileCode, GitMerge, Hourglass, ListTodo, Pause, Play, Plus, RotateCcw, Rocket, Square, Trash2, Wrench, X, Zap, Workflow, Undo2, Sparkles,
} from 'lucide-react';
import { toast } from 'sonner';
import type { AgentRun, AgentTask, EfficiencyMode, FileChange, Provider, TaskStatus } from '@shared/types';
import { EFFICIENCY_PROFILES } from '@shared/types';
import { useApp } from '../store/app';
import { useUi } from '../store/ui';
import { api } from '../lib/api';
import { cn, duration, timeAgo, fmtNum } from '../lib/utils';
import { navigate, routes } from '../lib/router';
import { Page, PageHeader, Stat } from '../components/layout/Page';
import { Badge, Button, Card, EmptyState, IconButton, Input, Segmented, SectionTitle, Spinner, StatusDot, Switch, Textarea, Tooltip } from '../components/ui/primitives';
import { Select, confirmDialog } from '../components/ui/overlays';
import { ModelPicker, defaultAccountFor, defaultModelFor, EFFORT_LABEL } from '../components/chat/ModelPicker';
import { ProviderMark, providerName } from '../components/brand';
import { Blocks } from '../components/chat/Blocks';
import { Markdown } from '../components/chat/Markdown';
import { ProjectIcon } from '../components/icons';

export const TASK_STATUS: Record<TaskStatus, { label: string; tone: 'neutral' | 'accent' | 'warning' | 'success' | 'danger' | 'info'; icon: typeof Clock }> = {
  pending: { label: 'Pending', tone: 'neutral', icon: CircleDashed },
  working: { label: 'Working', tone: 'accent', icon: Zap },
  reviewing: { label: 'Reviewing', tone: 'warning', icon: GitMerge },
  completed: { label: 'Completed', tone: 'success', icon: CircleCheck },
  failed: { label: 'Failed', tone: 'danger', icon: CircleX },
  blocked: { label: 'Blocked', tone: 'warning', icon: Ban },
  cancelled: { label: 'Cancelled', tone: 'neutral', icon: Square },
};

function useTick(ms = 1000) {
  const [, set] = useState(0);
  useEffect(() => {
    const t = setInterval(() => set((x) => x + 1), ms);
    return () => clearInterval(t);
  }, [ms]);
}

function useRuns(projectId?: string | null) {
  const runs = useApp((s) => s.runs);
  useEffect(() => {
    api.get<AgentRun[]>(`/api/runs${projectId ? `?projectId=${projectId}` : ''}`, { silent: true }).then((list) => {
      useApp.setState((s) => {
        const next = { ...s.runs };
        for (const r of list) next[r.id] = r;
        return { runs: next };
      });
    }, () => undefined);
  }, [projectId]);
  return useMemo(() => Object.values(runs).filter((r) => !projectId || r.projectId === projectId).sort((a, b) => b.createdAt - a.createdAt), [runs, projectId]);
}

// ---------- launcher ----------

export function RunLauncher({ projectId: fixedProject, onCreated }: { projectId?: string; onCreated?: (r: AgentRun) => void }) {
  const projects = useApp((s) => s.projects);
  const settings = useApp((s) => s.settings);
  const [projectId, setProjectId] = useState<string>(fixedProject ?? settings?.general.defaultProjectId ?? projects[0]?.id ?? '');
  const [prompt, setPrompt] = useState('');
  const [strategy, setStrategy] = useState<'auto' | 'manual'>('auto');
  const [efficiency, setEfficiency] = useState<EfficiencyMode>(settings?.context.mode ?? 'balanced');
  const provider: Provider = settings?.providers.defaultProvider ?? 'claude';
  const [coord, setCoord] = useState({ provider, accountId: defaultAccountFor(provider), model: defaultModelFor(provider), effort: 'low' });
  const [auto, setAuto] = useState({ edits: true, commands: false, studioWrites: false });
  const [busy, setBusy] = useState(false);
  const project = projects.find((p) => p.id === projectId);
  const prof = EFFICIENCY_PROFILES[efficiency];

  const create = async (start: boolean) => {
    setBusy(true);
    try {
      const r = await api.post<AgentRun>('/api/runs', { projectId: projectId || null, prompt, strategy, efficiency, coordinator: coord, autoApprove: auto, autoStart: start });
      useApp.getState().upsertRun(r);
      setPrompt('');
      toast.success(strategy === 'auto' ? 'Coordinator is planning the work…' : 'Run created');
      onCreated?.(r);
      navigate(routes.tasks(r.id));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Card className="p-5">
      <div className="mb-4 flex items-center gap-2.5">
        <span className="flex size-8 items-center justify-center rounded-xl bg-accent-soft text-accent">
          <Sparkles className="size-4" />
        </span>
        <div>
          <div className="text-[14.5px] font-semibold">New multi-agent run</div>
          <div className="text-[12.5px] text-fg-3">The coordinator splits your request into the fewest sensible tasks and assigns Claude and Codex agents.</div>
        </div>
      </div>
      <Textarea rows={4} value={prompt} onChange={(e) => setPrompt(e.target.value)} placeholder="e.g. Create a complete shop system for my Roblox game: shop UI, server-side purchase validation, DataStore persistence and tests." />
      <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-2">
        {!fixedProject && (
          <div className="space-y-1.5">
            <div className="text-[12px] font-medium text-fg-3">Project</div>
            <Select value={projectId} onChange={setProjectId} placeholder="No project (scratch folder)" options={[{ value: '', label: 'No project (scratch folder)' }, ...projects.map((p) => ({ value: p.id, label: p.name, hint: p.folderPath ?? 'no folder' }))]} />
          </div>
        )}
        <div className="space-y-1.5">
          <div className="text-[12px] font-medium text-fg-3">Planning</div>
          <Segmented value={strategy} onChange={setStrategy} options={[{ value: 'auto', label: 'Automatic', title: 'The coordinator splits the work into tasks' }, { value: 'manual', label: 'Manual', title: 'One task that you assign yourself (add more on the Task Board)' }]} />
        </div>
        <div className="space-y-1.5 md:col-span-2">
          <div className="text-[12px] font-medium text-fg-3">Efficiency</div>
          <Segmented value={efficiency} onChange={setEfficiency} options={(['economy', 'balanced', 'performance', 'max'] as EfficiencyMode[]).map((m) => ({ value: m, label: EFFICIENCY_PROFILES[m].label }))} />
          <div className="text-[11.5px] text-fg-3">
            ≤{prof.maxTasks} tasks · {prof.maxConcurrentAgents} in parallel · ~{fmtNum(prof.contextBudget)} token brief · {prof.retries} retr{prof.retries === 1 ? 'y' : 'ies'} · {prof.verification === 'none' ? 'no' : prof.verification} final pass
          </div>
        </div>
        <div className="space-y-1.5">
          <div className="text-[12px] font-medium text-fg-3">{strategy === 'auto' ? 'Coordinator model' : 'Agent'}</div>
          <ModelPicker side="bottom" value={coord} onChange={(p) => setCoord((c) => ({ ...c, ...p }))} />
        </div>
      </div>
      <div className="mt-4 flex flex-wrap items-center gap-x-6 gap-y-2 rounded-xl border border-line bg-surface-2/40 px-4 py-3">
        <span className="text-[12px] font-medium text-fg-3">Auto-approve</span>
        <label className="flex items-center gap-2 text-[12.5px] text-fg-2">
          <Switch checked={auto.edits} onChange={(v) => setAuto({ ...auto, edits: v })} /> File edits in assigned paths
        </label>
        <label className="flex items-center gap-2 text-[12.5px] text-fg-2">
          <Switch checked={auto.commands} onChange={(v) => setAuto({ ...auto, commands: v })} /> Shell commands
        </label>
        {project?.robloxEnabled && (
          <label className="flex items-center gap-2 text-[12.5px] text-fg-2">
            <Switch checked={auto.studioWrites} onChange={(v) => setAuto({ ...auto, studioWrites: v })} /> Roblox Studio writes
          </label>
        )}
      </div>
      <div className="mt-4 flex items-center justify-end gap-2">
        <Button variant="ghost" disabled={!prompt.trim() || busy} onClick={() => create(false)}>
          {strategy === 'auto' ? 'Plan only' : 'Create'}
        </Button>
        <Button variant="primary" icon={<Rocket className="size-4" />} loading={busy} disabled={!prompt.trim()} onClick={() => create(true)}>
          {strategy === 'auto' ? 'Plan & start' : 'Start'}
        </Button>
      </div>
    </Card>
  );
}

// ---------- shared bits ----------

function TaskStatusBadge({ status }: { status: TaskStatus }) {
  const s = TASK_STATUS[status];
  return (
    <Badge tone={s.tone}>
      {status === 'working' ? <StatusDot tone="accent" pulse /> : <s.icon className="size-3" />}
      {s.label}
    </Badge>
  );
}

function runTone(r: AgentRun) {
  return r.status === 'completed' ? 'success' : r.status === 'failed' ? 'danger' : r.status === 'running' ? 'accent' : r.status === 'planning' ? 'info' : r.status === 'paused' ? 'warning' : 'neutral';
}

export function RunList({ projectId, selected }: { projectId?: string; selected?: string | null }) {
  const runs = useRuns(projectId);
  const projects = useApp((s) => s.projects);
  if (!runs.length)
    return (
      <Card>
        <EmptyState icon={<ListTodo className="size-5" />} title="No agent runs yet" description="Start a run from the Agents page or a project’s Agents tab." />
      </Card>
    );
  return (
    <div className="space-y-2">
      {runs.map((r) => {
        const done = r.tasks.filter((t) => t.status === 'completed').length;
        const p = projects.find((x) => x.id === r.projectId);
        return (
          <button key={r.id} onClick={() => navigate(routes.tasks(r.id))} className={cn('w-full cursor-pointer rounded-xl border p-3.5 text-left transition-colors', selected === r.id ? 'border-accent/50 bg-accent-softer' : 'border-line bg-surface hover:border-line-strong')}>
            <div className="flex items-center gap-2">
              <StatusDot tone={runTone(r) as any} pulse={r.status === 'running' || r.status === 'planning'} />
              <span className="text-[11.5px] font-medium capitalize text-fg-3">{r.status}</span>
              <span className="ml-auto text-[11px] text-fg-3">{timeAgo(r.createdAt)}</span>
            </div>
            <div className="mt-1.5 line-clamp-2 text-[13px] font-medium leading-snug text-fg">{r.prompt}</div>
            <div className="mt-2 flex min-w-0 items-center gap-1.5 whitespace-nowrap text-[11.5px] text-fg-3">
              {p && <><ProjectIcon icon={p.icon} color={p.color} size="xs" /> <span className="min-w-0 truncate">{p.name}</span><span>·</span></>}
              <span className="shrink-0">
                {done}/{r.tasks.length} tasks · {EFFICIENCY_PROFILES[r.efficiency].label}
              </span>
            </div>
          </button>
        );
      })}
    </div>
  );
}

// ---------- task graph ----------

function TaskGraph({ run, onSelect }: { run: AgentRun; onSelect: (t: AgentTask) => void }) {
  const layout = useMemo(() => {
    const byKey = new Map(run.tasks.map((t) => [t.key, t]));
    const level = new Map<string, number>();
    const depth = (k: string, seen = new Set<string>()): number => {
      if (level.has(k)) return level.get(k)!;
      if (seen.has(k)) return 0;
      seen.add(k);
      const t = byKey.get(k);
      const d = t && t.dependsOn.length ? 1 + Math.max(...t.dependsOn.filter((x) => byKey.has(x)).map((x) => depth(x, seen)), -1) : 0;
      level.set(k, Math.max(0, d));
      return Math.max(0, d);
    };
    run.tasks.forEach((t) => depth(t.key));
    const cols: AgentTask[][] = [];
    for (const t of run.tasks) (cols[level.get(t.key) ?? 0] ??= []).push(t);
    const W = 230;
    const H = 74;
    const GX = 64;
    const GY = 18;
    const pos = new Map<string, { x: number; y: number }>();
    const maxRows = Math.max(1, ...cols.map((c) => c?.length ?? 0));
    cols.forEach((col, ci) => col?.forEach((t, ri) => pos.set(t.key, { x: ci * (W + GX) + 8, y: ri * (H + GY) + 8 + ((maxRows - col.length) * (H + GY)) / 2 })));
    return { pos, W, H, width: cols.length * (W + GX) - GX + 16, height: maxRows * (H + GY) - GY + 16 };
  }, [run.tasks]);
  const colors: Record<TaskStatus, string> = { pending: 'var(--text-3)', working: 'var(--accent)', reviewing: 'var(--warning)', completed: 'var(--success)', failed: 'var(--danger)', blocked: 'var(--warning)', cancelled: 'var(--text-3)' };
  return (
    <div className="grid-dots overflow-x-auto rounded-2xl border border-line bg-surface/50 p-3">
      <div className="relative" style={{ width: layout.width, height: layout.height }}>
        <svg className="absolute inset-0" width={layout.width} height={layout.height}>
          {run.tasks.flatMap((t) =>
            t.dependsOn.map((d) => {
              const a = layout.pos.get(d);
              const b = layout.pos.get(t.key);
              if (!a || !b) return null;
              const x1 = a.x + layout.W;
              const y1 = a.y + layout.H / 2;
              const x2 = b.x;
              const y2 = b.y + layout.H / 2;
              const mx = (x1 + x2) / 2;
              return <path key={d + t.key} d={`M${x1},${y1} C${mx},${y1} ${mx},${y2} ${x2},${y2}`} fill="none" stroke="var(--border-strong)" strokeWidth={1.5} markerEnd="url(#arrow)" />;
            }),
          )}
          <defs>
            <marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
              <path d="M 0 0 L 10 5 L 0 10 z" fill="var(--border-strong)" />
            </marker>
          </defs>
        </svg>
        {run.tasks.map((t) => {
          const p = layout.pos.get(t.key)!;
          return (
            <button key={t.id} onClick={() => onSelect(t)} className="absolute flex cursor-pointer flex-col rounded-xl border border-line-strong bg-surface p-2.5 text-left shadow-sm transition-transform hover:-translate-y-0.5" style={{ left: p.x, top: p.y, width: layout.W, height: layout.H, boxShadow: `inset 3px 0 0 ${colors[t.status]}` }}>
              <div className="flex items-center gap-1.5">
                <span className="font-mono text-[10.5px] text-fg-3">{t.key}</span>
                <ProviderMark provider={t.assignment.provider} size="xs" />
                <span className="truncate text-[11px] text-fg-3">{t.agentName}</span>
                <span className="ml-auto">{t.status === 'working' ? <StatusDot tone="accent" pulse /> : <span className="text-[10.5px]" style={{ color: colors[t.status] }}>{TASK_STATUS[t.status].label}</span>}</span>
              </div>
              <div className="mt-1 line-clamp-2 text-[12.5px] font-medium leading-snug text-fg">{t.title}</div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ---------- task card ----------

function PathsEditor({ value, onChange }: { value: string[]; onChange: (v: string[]) => void }) {
  const [text, setText] = useState(value.join('\n'));
  useEffect(() => setText(value.join('\n')), [value.join('\n')]); // eslint-disable-line react-hooks/exhaustive-deps
  return <Textarea rows={2} value={text} onChange={(e) => setText(e.target.value)} onBlur={() => onChange(text.split('\n').map((s) => s.trim()).filter(Boolean))} placeholder="src/shop/  (one path, folder/ or glob per line; studio:ServerScriptService.Shop for Studio scripts)" className="font-mono text-[12px]" />;
}

function ReviewPanel({ task }: { task: AgentTask }) {
  const run = useApp((s) => s.runs[task.runId]);
  const projectId = run?.projectId;
  const [changes, setChanges] = useState<FileChange[]>([]);
  useEffect(() => {
    if (projectId) api.get<FileChange[]>(`/api/projects/${projectId}/changes?sourceId=${task.id}`, { silent: true }).then(setChanges, () => undefined);
  }, [projectId, task.id, task.status]);
  return (
    <div className="mt-3 rounded-xl border border-warning/30 bg-warning/[0.06] p-3.5">
      <div className="flex items-start gap-2.5">
        <GitMerge className="mt-0.5 size-4 text-warning" />
        <div className="min-w-0 flex-1">
          <div className="text-[13px] font-medium">Review needed</div>
          <div className="mt-0.5 text-[12.5px] text-fg-2">{task.review?.reason}</div>
          {task.review?.conflicts?.length ? <div className="mt-1 font-mono text-[11.5px] text-warning">{task.review.conflicts.join(', ')}</div> : null}
        </div>
      </div>
      {changes.length > 0 && (
        <div className="mt-3 max-h-72 space-y-2 overflow-y-auto">
          {changes.map((c) => (
            <details key={c.id} className="rounded-lg border border-line bg-surface">
              <summary className="flex cursor-pointer items-center gap-2 px-3 py-2 text-[12.5px]">
                <Badge tone={c.change === 'added' ? 'success' : c.change === 'deleted' ? 'danger' : 'info'}>{c.change}</Badge>
                <span className="truncate font-mono">{c.path}</span>
              </summary>
              <pre className="overflow-x-auto border-t border-line bg-code py-1.5 font-mono text-[11.5px] leading-[1.55]">
                {(c.diff ?? '').split('\n').map((l, i) => (
                  <div key={i} className={cn('px-3', l.startsWith('+') && !l.startsWith('+++') ? 'diff-add' : l.startsWith('-') && !l.startsWith('---') ? 'diff-del' : l.startsWith('@@') ? 'diff-hunk' : 'text-fg-3')}>
                    {l || ' '}
                  </div>
                ))}
              </pre>
            </details>
          ))}
        </div>
      )}
      <div className="mt-3 flex justify-end gap-2">
        <Button
          size="sm"
          variant="ghost"
          icon={<Undo2 className="size-3.5" />}
          onClick={async () => {
            const r = await confirmDialog({ title: 'Revert this agent’s changes?', body: 'All files changed by this task are restored to their previous content.', confirmLabel: 'Revert', danger: true });
            if (r.ok) await api.post(`/api/tasks/${task.id}/revert`);
          }}
        >
          Revert changes
        </Button>
        <Button size="sm" variant="primary" icon={<Check className="size-3.5" />} onClick={() => api.post(`/api/tasks/${task.id}/accept`)}>
          Accept & continue
        </Button>
      </div>
    </div>
  );
}

function TaskCard({ task, run }: { task: AgentTask; run: AgentRun }) {
  useTick(task.status === 'working' ? 1000 : 60000);
  const inspect = useUi((s) => s.inspect);
  const account = useApp((s) => s.accounts.find((a) => a.id === task.assignment.accountId));
  const editable = task.status === 'pending' || task.status === 'blocked' || task.status === 'failed' || task.status === 'cancelled';
  const [editing, setEditing] = useState(false);
  const [title, setTitle] = useState(task.title);
  const [desc, setDesc] = useState(task.description);
  const patch = (body: unknown) => api.patch(`/api/tasks/${task.id}`, body);
  const elapsed = task.startedAt ? (task.finishedAt ?? Date.now()) - task.startedAt : null;
  return (
    <Card className={cn('p-4', task.status === 'working' && 'border-accent/40')}>
      <div className="flex items-start gap-3">
        <ProviderMark provider={task.assignment.provider} size="md" />
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-mono text-[11px] text-fg-3">{task.key}</span>
            <span className="text-[13px] font-semibold text-fg">{task.agentName}</span>
            <TaskStatusBadge status={task.status} />
            {task.dependsOn.length > 0 && <span className="text-[11.5px] text-fg-3">after {task.dependsOn.join(', ')}</span>}
          </div>
          {editing ? (
            <div className="mt-2 space-y-2">
              <Input value={title} onChange={(e) => setTitle(e.target.value)} />
              <Textarea rows={5} value={desc} onChange={(e) => setDesc(e.target.value)} />
              <div className="flex justify-end gap-2">
                <Button size="xs" variant="ghost" onClick={() => setEditing(false)}>
                  Cancel
                </Button>
                <Button size="xs" variant="primary" onClick={() => patch({ title, description: desc }).then(() => setEditing(false))}>
                  Save
                </Button>
              </div>
            </div>
          ) : (
            <>
              <div className="mt-1 text-[13.5px] font-medium text-fg">{task.title}</div>
              <div className="mt-1 line-clamp-3 whitespace-pre-wrap text-[12.5px] leading-relaxed text-fg-3">{task.description}</div>
            </>
          )}
        </div>
        <div className="flex shrink-0 items-center gap-0.5">
          <IconButton label="Inspect transcript" onClick={() => inspect(task.id)}>
            <Eye className="size-4" />
          </IconButton>
          {task.status === 'working' && (
            <IconButton label="Stop task" onClick={() => api.post(`/api/tasks/${task.id}/stop`)}>
              <Square className="size-3.5" />
            </IconButton>
          )}
          {['failed', 'cancelled', 'blocked', 'completed'].includes(task.status) && run.status !== 'planning' && (
            <IconButton label="Retry task" onClick={() => api.post(`/api/tasks/${task.id}/retry`)}>
              <RotateCcw className="size-4" />
            </IconButton>
          )}
          {editable && !editing && (
            <IconButton label="Edit task" onClick={() => (setTitle(task.title), setDesc(task.description), setEditing(true))}>
              <Wrench className="size-4" />
            </IconButton>
          )}
          {editable && run.status !== 'running' && (
            <IconButton label="Remove task" onClick={() => api.del(`/api/tasks/${task.id}`)}>
              <Trash2 className="size-4" />
            </IconButton>
          )}
        </div>
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-2 border-t border-line pt-3 text-[12px] text-fg-3">
        {editable ? (
          <ModelPicker size="sm" side="bottom" value={task.assignment} onChange={(p) => patch({ assignment: p })} />
        ) : (
          <span className="flex items-center gap-1.5">
            {providerName(task.assignment.provider)} · {account?.name ?? 'default account'} · <span className="font-mono">{task.assignment.model || 'default'}</span>
            {task.assignment.effort && ` · ${EFFORT_LABEL[task.assignment.effort] ?? task.assignment.effort}`}
          </span>
        )}
        <span className="flex items-center gap-1">
          <Clock className="size-3.5" /> {duration(elapsed)}
        </span>
        <span className="flex items-center gap-1">
          <Wrench className="size-3.5" /> {task.toolOps} tool ops
        </span>
        {task.attempts > 1 && <span>attempt {task.attempts}</span>}
        {task.usage?.verified && (
          <Tooltip content="Reported by the CLI">
            <span>{fmtNum((task.usage.inputTokens ?? 0) + (task.usage.cacheReadTokens ?? 0) + (task.usage.cacheWriteTokens ?? 0))} in · {fmtNum(task.usage.outputTokens ?? 0)} out</span>
          </Tooltip>
        )}
      </div>
      {task.status === 'working' && task.currentActivity && (
        <div className="mt-2 flex items-center gap-2 truncate text-[12px] text-fg-2">
          <Spinner className="size-3" /> <span className="truncate">{task.currentActivity}</span>
        </div>
      )}
      {editable ? (
        <div className="mt-3">
          <div className="mb-1 text-[11px] font-semibold uppercase tracking-wide text-fg-3">Owned paths</div>
          <PathsEditor value={task.ownedPaths} onChange={(v) => patch({ ownedPaths: v })} />
        </div>
      ) : (
        task.ownedPaths.length > 0 && (
          <div className="mt-2.5 flex flex-wrap gap-1">
            {task.ownedPaths.map((p) => (
              <span key={p} className="rounded-md bg-surface-2 px-1.5 py-0.5 font-mono text-[11px] text-fg-3">
                {p}
              </span>
            ))}
          </div>
        )
      )}
      {task.filesTouched.length > 0 && (
        <div className="mt-2.5 flex flex-wrap items-center gap-1">
          <FileCode className="size-3.5 text-fg-3" />
          {task.filesTouched.slice(0, 12).map((p) => (
            <span key={p} className="rounded-md border border-line px-1.5 py-0.5 font-mono text-[11px] text-fg-2">
              {p}
            </span>
          ))}
        </div>
      )}
      {task.error && task.status !== 'working' && <div className="mt-2.5 rounded-lg bg-danger/10 px-3 py-2 text-[12px] text-danger">{task.error}</div>}
      {task.status === 'reviewing' && <ReviewPanel task={task} />}
      {task.summary && task.status === 'completed' && (
        <details className="mt-2.5">
          <summary className="cursor-pointer text-[12px] text-fg-3 hover:text-fg-2">Summary</summary>
          <div className="mt-2 rounded-lg bg-surface-2/50 p-3">
            <Markdown text={task.summary} />
          </div>
        </details>
      )}
    </Card>
  );
}

function RunView({ runId }: { runId: string }) {
  const run = useApp((s) => s.runs[runId]);
  const inspect = useUi((s) => s.inspect);
  const projects = useApp((s) => s.projects);
  useEffect(() => {
    api.get<AgentRun>(`/api/runs/${runId}`, { silent: true }).then((r) => useApp.getState().upsertRun(r), () => undefined);
  }, [runId]);
  if (!run) return <Spinner className="m-10" />;
  const project = projects.find((p) => p.id === run.projectId);
  const act = (a: string) => api.post(`/api/runs/${run.id}/${a}`);
  const counts = run.tasks.reduce<Record<string, number>>((m, t) => ((m[t.status] = (m[t.status] ?? 0) + 1), m), {});
  return (
    <div className="space-y-5">
      <Card className="p-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 text-[12px] text-fg-3">
              <StatusDot tone={runTone(run) as any} pulse={run.status === 'running' || run.status === 'planning'} />
              <span className="font-medium capitalize">{run.status === 'planning' ? 'Coordinator is planning…' : run.status}</span>
              <span>· {EFFICIENCY_PROFILES[run.efficiency].label}</span>
              {project && <span>· {project.name}</span>}
              <span>· coordinator: {providerName(run.coordinator.provider)} {run.coordinator.model}</span>
            </div>
            <div className="mt-2 whitespace-pre-wrap text-[14.5px] font-medium leading-relaxed text-fg">{run.prompt}</div>
          </div>
          <div className="flex items-center gap-2">
            {(run.status === 'ready' || run.status === 'paused') && (
              <Button variant="primary" size="sm" icon={<Play className="size-3.5" />} onClick={() => act(run.status === 'paused' ? 'resume' : 'start')}>
                {run.status === 'paused' ? 'Resume' : 'Start'}
              </Button>
            )}
            {run.status === 'running' && (
              <Button variant="secondary" size="sm" icon={<Pause className="size-3.5" />} onClick={() => act('pause')}>
                Pause
              </Button>
            )}
            {['running', 'paused', 'ready', 'planning'].includes(run.status) && (
              <Button variant="ghost" size="sm" icon={<X className="size-3.5" />} onClick={() => act('cancel')}>
                Cancel
              </Button>
            )}
            {!['running', 'planning'].includes(run.status) && (
              <IconButton
                label="Delete run"
                onClick={async () => {
                  const r = await confirmDialog({ title: 'Delete this run?', body: 'The plan and transcripts are removed. File changes stay (revert them from the project’s Changes list).', confirmLabel: 'Delete', danger: true });
                  if (r.ok) {
                    await api.del(`/api/runs/${run.id}`);
                    navigate(routes.tasks());
                  }
                }}
              >
                <Trash2 className="size-4" />
              </IconButton>
            )}
          </div>
        </div>
        {run.rationale && <div className="mt-3 whitespace-pre-wrap rounded-xl bg-surface-2/50 px-3.5 py-2.5 text-[12.5px] leading-relaxed text-fg-2">{run.rationale}</div>}
        {run.status === 'paused' && <div className="mt-3 text-[12px] text-fg-3">Paused — working agents finish their current task; no new tasks start until you resume. (The CLIs themselves cannot be paused mid-task.)</div>}
        <div className="mt-3 flex flex-wrap gap-1.5">
          {Object.entries(counts).map(([k, n]) => (
            <span key={k} className="flex items-center gap-1">
              <TaskStatusBadge status={k as TaskStatus} />
              <span className="text-[11.5px] text-fg-3">×{n}</span>
            </span>
          ))}
        </div>
      </Card>

      {run.status === 'planning' ? (
        <Card className="flex items-center gap-3 p-6 text-[13px] text-fg-2">
          <Spinner /> The coordinator is reading the project brief and splitting the work into tasks…
        </Card>
      ) : (
        run.tasks.length > 1 && (
          <div>
            <SectionTitle>Task graph</SectionTitle>
            <TaskGraph run={run} onSelect={(t) => inspect(t.id)} />
          </div>
        )
      )}

      <div>
        <SectionTitle
          action={
            run.status !== 'planning' && (
              <Button size="xs" variant="ghost" icon={<Plus className="size-3.5" />} onClick={() => api.post(`/api/runs/${run.id}/tasks`, { title: 'New task', description: '' })}>
                Add task
              </Button>
            )
          }
        >
          Tasks
        </SectionTitle>
        <div className="space-y-3">
          {run.tasks.map((t) => (
            <TaskCard key={t.id} task={t} run={run} />
          ))}
        </div>
      </div>

      {run.report && (
        <Card className="p-6">
          <SectionTitle>Final report</SectionTitle>
          <Markdown text={run.report} />
        </Card>
      )}
    </div>
  );
}

export function TaskBoardPage({ runId }: { runId: string | null }) {
  const runs = useRuns(null);
  const sel = runId ?? runs[0]?.id ?? null;
  return (
    <Page wide>
      <PageHeader
        title="Task Board"
        description="Every multi-agent run with its plan, dependency graph, live status, reviews and final report."
        actions={
          <Button variant="primary" icon={<Plus className="size-4" />} onClick={() => navigate(routes.agents())}>
            New run
          </Button>
        }
      />
      {runs.length === 0 ? (
        <Card>
          <EmptyState icon={<Workflow className="size-5" />} title="No runs yet" description="Describe a feature and let the coordinator split it between Claude and Codex agents." action={<Button variant="primary" onClick={() => navigate(routes.agents())}>Start a run</Button>} />
        </Card>
      ) : (
        <div className="grid grid-cols-1 gap-5 lg:grid-cols-[320px_1fr]">
          <div className="lg:max-h-[calc(100vh-180px)] lg:overflow-y-auto lg:pr-1">
            <RunList selected={sel} />
          </div>
          <div className="min-w-0">{sel && <RunView runId={sel} />}</div>
        </div>
      )}
    </Page>
  );
}

function AgentRow({ task }: { task: AgentTask }) {
  useTick(1000);
  const inspect = useUi((s) => s.inspect);
  const account = useApp((s) => s.accounts.find((a) => a.id === task.assignment.accountId));
  const elapsed = task.startedAt ? (task.finishedAt ?? Date.now()) - task.startedAt : null;
  return (
    <Card className={cn('p-4', task.status === 'working' && 'border-accent/35')}>
      <div className="flex items-start gap-3">
        <div className="relative">
          <ProviderMark provider={task.assignment.provider} size="lg" />
          {task.status === 'working' && (
            <span className="absolute -bottom-0.5 -right-0.5 rounded-full bg-surface p-0.5">
              <StatusDot tone="accent" pulse />
            </span>
          )}
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <span className="text-[14px] font-semibold">{task.agentName}</span>
            <TaskStatusBadge status={task.status} />
          </div>
          <div className="mt-0.5 text-[12px] text-fg-3">
            {providerName(task.assignment.provider)} · {account?.name ?? 'default'} · <span className="font-mono">{task.assignment.model || 'default'}</span>
          </div>
          <div className="mt-2 truncate text-[13px] text-fg">{task.title}</div>
          {task.currentActivity && task.status === 'working' && <div className="mt-1 truncate text-[12px] text-fg-3">{task.currentActivity}</div>}
          {task.filesTouched.length > 0 && (
            <div className="mt-2 flex flex-wrap gap-1">
              {task.filesTouched.slice(0, 5).map((f) => (
                <span key={f} className="rounded bg-surface-2 px-1.5 py-0.5 font-mono text-[10.5px] text-fg-3">
                  {f}
                </span>
              ))}
            </div>
          )}
        </div>
        <div className="text-right text-[12px] tabular-nums text-fg-3">
          <div>{duration(elapsed)}</div>
          <div className="mt-0.5">{task.toolOps} ops</div>
        </div>
      </div>
      <div className="mt-3 flex justify-end gap-1.5 border-t border-line pt-3">
        <Button size="xs" variant="ghost" icon={<Eye className="size-3.5" />} onClick={() => inspect(task.id)}>
          Inspect
        </Button>
        <Button size="xs" variant="ghost" onClick={() => navigate(routes.tasks(task.runId))}>
          Open run
        </Button>
        {task.status === 'working' ? (
          <Button size="xs" variant="secondary" icon={<Square className="size-3" />} onClick={() => api.post(`/api/tasks/${task.id}/stop`)}>
            Stop
          </Button>
        ) : ['failed', 'cancelled', 'blocked'].includes(task.status) ? (
          <Button size="xs" variant="secondary" icon={<RotateCcw className="size-3" />} onClick={() => api.post(`/api/tasks/${task.id}/retry`)}>
            Retry
          </Button>
        ) : null}
      </div>
    </Card>
  );
}

export function AgentsPage() {
  const runs = useRuns(null);
  const approvals = useApp((s) => s.approvals.length);
  const tasks = runs.flatMap((r) => r.tasks);
  const working = tasks.filter((t) => t.status === 'working');
  const recent = tasks.filter((t) => t.status !== 'working' && t.status !== 'pending' && t.finishedAt).sort((a, b) => (b.finishedAt ?? 0) - (a.finishedAt ?? 0)).slice(0, 9);
  const today = new Date().setHours(0, 0, 0, 0);
  return (
    <Page wide>
      <PageHeader title="Agents" description="Launch coordinated Claude Code and Codex agents and watch them work in real time." />
      <div className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label="Active agents" value={working.length} icon={<Bot className="size-4" />} />
        <Stat label="Waiting for approval" value={approvals} icon={<Hourglass className="size-4" />} />
        <Stat label="Completed today" value={tasks.filter((t) => t.status === 'completed' && (t.finishedAt ?? 0) >= today).length} icon={<CircleCheck className="size-4" />} />
        <Stat label="Failed today" value={tasks.filter((t) => t.status === 'failed' && (t.finishedAt ?? 0) >= today).length} icon={<CircleX className="size-4" />} />
      </div>
      <div className="grid grid-cols-1 gap-6 xl:grid-cols-[1fr_420px]">
        <div className="space-y-6">
          <RunLauncher />
          <div>
            <SectionTitle>Working now</SectionTitle>
            {working.length === 0 ? (
              <Card className="px-5 py-8 text-center text-[13px] text-fg-3">No agents are running.</Card>
            ) : (
              <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
                {working.map((t) => (
                  <AgentRow key={t.id} task={t} />
                ))}
              </div>
            )}
          </div>
        </div>
        <div>
          <SectionTitle>Recently finished</SectionTitle>
          {recent.length === 0 ? <Card className="px-5 py-8 text-center text-[13px] text-fg-3">Nothing yet.</Card> : <div className="space-y-3">{recent.map((t) => <AgentRow key={t.id} task={t} />)}</div>}
        </div>
      </div>
    </Page>
  );
}

// ---------- inspect drawer ----------

export function InspectDrawer() {
  const taskId = useUi((s) => s.inspectTaskId);
  const close = () => useUi.getState().inspect(null);
  const live = useApp((s) => (taskId ? s.taskBlocks[taskId] : undefined));
  const [task, setTask] = useState<AgentTask | null>(null);
  const runTask = useApp((s) => (taskId ? Object.values(s.runs).flatMap((r) => r.tasks).find((t) => t.id === taskId) : undefined));
  useEffect(() => {
    if (!taskId) return setTask(null);
    api.get<AgentTask>(`/api/tasks/${taskId}`, { silent: true }).then((t) => {
      setTask(t);
      useApp.setState((s) => ({ taskBlocks: { ...s.taskBlocks, [t.id]: t.blocks } }));
    }, () => undefined);
  }, [taskId]);
  const t = runTask ? { ...task, ...runTask } : task;
  const blocks = live ?? task?.blocks ?? [];
  return (
    <RDialog.Root open={!!taskId} onOpenChange={(o) => !o && close()}>
      <RDialog.Portal>
        <RDialog.Overlay className="fixed inset-0 z-[60] bg-black/40" />
        <RDialog.Content className="fixed inset-y-0 right-0 z-[61] flex w-[min(720px,100vw)] flex-col border-l border-line-strong bg-bg shadow-pop outline-none data-[state=open]:animate-[bx-fade_150ms_ease]">
          <div className="flex items-center gap-3 border-b border-line px-5 py-3.5">
            {t?.assignment && <ProviderMark provider={t.assignment.provider} size="md" />}
            <div className="min-w-0 flex-1">
              <RDialog.Title className="truncate text-[14.5px] font-semibold">{t?.agentName ?? 'Agent'} · {t?.title}</RDialog.Title>
              <div className="text-[12px] text-fg-3">{t?.status ? TASK_STATUS[t.status as TaskStatus].label : ''} · {t?.toolOps ?? 0} tool ops</div>
            </div>
            {t?.status && <TaskStatusBadge status={t.status as TaskStatus} />}
            <IconButton label="Close" onClick={close}>
              <X className="size-4" />
            </IconButton>
          </div>
          <div className="min-h-0 flex-1 overflow-y-auto px-6 py-5">
            {!t ? <Spinner /> : blocks.length === 0 ? <div className="text-[13px] text-fg-3">{t.status === 'pending' ? 'This task has not started yet.' : 'No output yet.'}</div> : <Blocks blocks={blocks} streaming={t.status === 'working'} />}
          </div>
        </RDialog.Content>
      </RDialog.Portal>
    </RDialog.Root>
  );
}
