import { useEffect, useMemo, useState } from 'react';
import { Activity, CircleCheck, CircleX, Gamepad2, Info, Lock, Play, Plug, PlugZap, RefreshCw, Search, Server, Stethoscope, Terminal, Unplug, Bot, ListOrdered } from 'lucide-react';
import { toast } from 'sonner';
import type { PermissionPolicy, RobloxActivity, RobloxStatus } from '@shared/types';
import { useApp } from '../store/app';
import { api } from '../lib/api';
import { cn, timeAgo } from '../lib/utils';
import { navigate, routes } from '../lib/router';
import { Page, PageHeader } from '../components/layout/Page';
import { Badge, Button, Card, Input, SectionTitle, Spinner, StatusDot, Textarea } from '../components/ui/primitives';
import { Select } from '../components/ui/overlays';

function StatusHero({ st }: { st: RobloxStatus }) {
  const [busy, setBusy] = useState<string | null>(null);
  const run = async (what: string, fn: () => Promise<unknown>) => {
    setBusy(what);
    try {
      await fn();
    } finally {
      setBusy(null);
    }
  };
  const tone = st.state === 'connected' ? 'success' : st.state === 'connecting' ? 'warning' : st.state === 'error' ? 'danger' : 'neutral';
  const active = st.studios.find((s) => s.id === st.activeStudioId);
  return (
    <Card className="overflow-hidden">
      <div className="flex flex-wrap items-center gap-5 p-6">
        <div className={cn('flex size-14 items-center justify-center rounded-2xl', st.state === 'connected' ? 'bg-success/12 text-success' : st.state === 'error' ? 'bg-danger/12 text-danger' : 'bg-surface-2 text-fg-3')}>
          <Gamepad2 className="size-7" />
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2.5">
            <StatusDot tone={tone} pulse={st.state === 'connecting'} />
            <span className="text-[17px] font-semibold">{st.state === 'connected' ? 'Connected to Roblox Studio' : st.state === 'connecting' ? 'Connecting…' : st.state === 'error' ? 'Connection failed' : 'Not connected'}</span>
          </div>
          <div className="mt-1 text-[13px] text-fg-3">
            {st.state === 'connected'
              ? active
                ? `Current place: ${active.name}${st.studios.length > 1 ? ` · ${st.studios.length} Studio windows open` : ''}`
                : 'MCP server is running, but no open place was reported.'
              : 'Uses the official Roblox Studio MCP server. Studio must be open with “Enable Studio as MCP server” turned on.'}
          </div>
          {st.error && <div className="mt-2 whitespace-pre-wrap rounded-lg bg-danger/10 px-3 py-2 text-[12.5px] text-danger">{st.error}</div>}
        </div>
        <div className="flex flex-wrap gap-2">
          {st.state === 'connected' ? (
            <Button variant="ghost" icon={<Unplug className="size-4" />} onClick={() => run('d', () => api.post('/api/roblox/disconnect'))}>
              Disconnect
            </Button>
          ) : (
            <Button variant="primary" icon={<Plug className="size-4" />} loading={busy === 'c' || st.state === 'connecting'} onClick={() => run('c', () => api.post('/api/roblox/connect'))}>
              Connect Roblox Studio
            </Button>
          )}
          <Button
            variant="secondary"
            icon={<PlugZap className="size-4" />}
            loading={busy === 't'}
            onClick={() =>
              run('t', async () => {
                const r = await api.post<{ ok: boolean; message: string }>('/api/roblox/test');
                r.ok ? toast.success(r.message) : toast.error(r.message);
              })
            }
          >
            Test connection
          </Button>
          <Button variant="ghost" icon={<RefreshCw className="size-4" />} loading={busy === 'r'} disabled={st.state !== 'connected'} onClick={() => run('r', () => api.post('/api/roblox/refresh'))}>
            Refresh
          </Button>
        </div>
      </div>
      {st.lastTest && (
        <div className={cn('flex items-center gap-2 border-t border-line px-6 py-2.5 text-[12.5px]', st.lastTest.ok ? 'text-success' : 'text-danger')}>
          {st.lastTest.ok ? <CircleCheck className="size-3.5" /> : <CircleX className="size-3.5" />}
          Last test {timeAgo(st.lastTest.at)} · {st.lastTest.latencyMs} ms · <span className="text-fg-2">{st.lastTest.message}</span>
        </div>
      )}
    </Card>
  );
}

function ToolConsole({ st }: { st: RobloxStatus }) {
  const [tool, setTool] = useState('get_studio_state');
  const [args, setArgs] = useState('{}');
  const [out, setOut] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [isErr, setIsErr] = useState(false);
  const t = st.tools.find((x) => x.name === tool);
  const run = async () => {
    let parsed: unknown;
    try {
      parsed = JSON.parse(args || '{}');
    } catch {
      return toast.error('Arguments must be valid JSON');
    }
    setBusy(true);
    setOut(null);
    try {
      const r = await api.post<{ content: any[]; isError?: boolean }>('/api/roblox/call', { tool, args: parsed });
      setIsErr(!!r.isError);
      setOut((r.content ?? []).map((c) => (c.type === 'text' ? c.text : c.type === 'image' ? `[image ${c.mimeType ?? ''}]` : JSON.stringify(c))).join('\n\n'));
    } finally {
      setBusy(false);
    }
  };
  return (
    <Card className="p-5">
      <SectionTitle>
        <span className="flex items-center gap-1.5">
          <Terminal className="size-3.5" /> Studio console
        </span>
      </SectionTitle>
      <p className="mb-3 text-[12.5px] text-fg-3">Run any Studio MCP tool yourself to check that real tool calls work. <span className="font-mono">studio_id</span> is filled in automatically.</p>
      <div className="flex gap-2">
        <Select value={tool} onChange={(v) => (setTool(v), setArgs(v === 'search_game_tree' ? '{"datamodel_type":"Edit","max_depth":2}' : v === 'script_search' ? '{"keywords":"shop"}' : '{}'))} options={st.tools.map((x) => ({ value: x.name, label: x.name, hint: x.readOnly ? 'read-only' : 'can change your place' }))} className="flex-1" />
        <Button variant="primary" icon={<Play className="size-3.5" />} loading={busy} disabled={st.state !== 'connected'} onClick={run}>
          Run
        </Button>
      </div>
      {t && !t.readOnly && <div className="mt-2 text-[12px] text-warning">This tool can modify your open place.</div>}
      <Textarea rows={3} value={args} onChange={(e) => setArgs(e.target.value)} className="mt-2 font-mono text-[12px]" />
      {out != null && <pre className={cn('mt-3 max-h-80 overflow-auto whitespace-pre-wrap break-words rounded-xl border bg-code p-3 font-mono text-[11.5px] leading-relaxed', isErr ? 'border-danger/30 text-danger' : 'border-line text-fg-2')}>{out || '(empty result)'}</pre>}
    </Card>
  );
}

export function RobloxPage() {
  const st = useApp((s) => s.roblox);
  const live = useApp((s) => s.robloxActivity);
  const settings = useApp((s) => s.settings);
  const saveSettings = useApp((s) => s.saveSettings);
  const [hist, setHist] = useState<RobloxActivity[]>([]);
  const [diag, setDiag] = useState<Record<string, unknown> | null>(null);
  const [filter, setFilter] = useState('');
  useEffect(() => {
    api.get<RobloxActivity[]>('/api/roblox/activity?limit=100', { silent: true }).then(setHist, () => undefined);
  }, []);
  const activity = useMemo(() => {
    const m = new Map<string, RobloxActivity>();
    for (const a of [...live, ...hist]) m.set(a.id, a);
    return [...m.values()].sort((a, b) => b.ts - a.ts).slice(0, 60);
  }, [live, hist]);
  if (!st || !settings) return <Spinner className="m-10" />;
  const setPolicy = (name: string, p: PermissionPolicy) => saveSettings({ roblox: { toolPolicies: { ...settings.roblox.toolPolicies, [name]: p } } });
  const tools = st.tools.filter((t) => !filter || t.name.includes(filter.toLowerCase()) || t.description.toLowerCase().includes(filter.toLowerCase()));
  return (
    <Page wide>
      <PageHeader
        title="Roblox Studio"
        description="BLOXADE connects to the official Roblox Studio MCP server once and routes every agent’s Studio calls through one queue — with permissions, script locks, shared caching and output trimming."
        actions={
          <Button variant="ghost" onClick={() => navigate(routes.settings('roblox'))}>
            MCP settings
          </Button>
        }
      />
      {!settings.roblox.enabled && (
        <Card className="mb-5 flex items-center justify-between gap-3 border-warning/30 p-4 text-[13px]">
          <span className="text-warning">Roblox Studio integration is turned off.</span>
          <Button size="sm" variant="primary" onClick={() => saveSettings({ roblox: { enabled: true } })}>
            Turn on
          </Button>
        </Card>
      )}
      <StatusHero st={st} />

      <div className="mt-5 grid grid-cols-1 gap-5 xl:grid-cols-3">
        <div className="space-y-5 xl:col-span-2">
          {st.studios.length > 1 && (
            <Card className="p-5">
              <SectionTitle>Open Studio windows</SectionTitle>
              <div className="space-y-1.5">
                {st.studios.map((s) => (
                  <button key={s.id} onClick={() => api.post('/api/roblox/studio', { studioId: s.id })} className={cn('flex w-full cursor-pointer items-center gap-3 rounded-xl border px-3.5 py-2.5 text-left text-[13px]', s.id === st.activeStudioId ? 'border-accent/50 bg-accent-softer' : 'border-line hover:bg-surface-2')}>
                    <Gamepad2 className="size-4 text-fg-3" />
                    <span className="flex-1">{s.name}</span>
                    {s.id === st.activeStudioId && <Badge tone="accent">active</Badge>}
                  </button>
                ))}
              </div>
              <div className="mt-2 text-[12px] text-fg-3">Agents use the active window unless they pass a specific studio_id.</div>
            </Card>
          )}
          <Card className="p-5">
            <SectionTitle action={<Input className="w-48" icon={<Search className="size-3.5" />} placeholder="Filter tools" value={filter} onChange={(e) => setFilter(e.target.value)} />}>
              Capabilities ({st.tools.length} tools)
            </SectionTitle>
            {st.tools.length === 0 ? (
              <div className="py-6 text-center text-[13px] text-fg-3">Connect to see the tools your Studio version exposes.</div>
            ) : (
              <div className="divide-y divide-line">
                {tools.map((t) => (
                  <div key={t.name} className="flex items-center gap-3 py-2.5">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-[12.5px] text-fg">{t.name}</span>
                        {t.readOnly ? <Badge tone="info">read</Badge> : <Badge tone="warning">write</Badge>}
                      </div>
                      <div className="mt-0.5 truncate text-[12px] text-fg-3">{t.description}</div>
                    </div>
                    <div className="w-[130px] shrink-0">
                      <Select size="sm" className="min-w-0" value={t.policy} onChange={(p) => setPolicy(t.name, p)} options={[{ value: 'allow', label: 'Allow' }, { value: 'ask', label: 'Ask first' }, { value: 'deny', label: 'Block' }]} />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>
          <Card className="p-5">
            <SectionTitle>
              <span className="flex items-center gap-1.5">
                <Activity className="size-3.5" /> Tool activity
              </span>
            </SectionTitle>
            {activity.length === 0 ? (
              <div className="py-6 text-center text-[13px] text-fg-3">No Studio calls yet.</div>
            ) : (
              <div className="max-h-[420px] divide-y divide-line overflow-y-auto">
                {activity.map((a) => (
                  <div key={a.id} className="flex items-center gap-3 py-2 text-[12.5px]">
                    <Badge tone={a.status === 'ok' ? 'success' : a.status === 'cached' ? 'info' : a.status === 'denied' ? 'warning' : 'danger'}>{a.status}</Badge>
                    <span className="w-36 shrink-0 truncate font-mono text-fg">{a.tool}</span>
                    <span className="min-w-0 flex-1 truncate text-fg-3">{a.summary}</span>
                    <span className="hidden w-32 shrink-0 truncate text-right text-fg-3 md:block">{a.caller}</span>
                    <span className="w-14 shrink-0 text-right tabular-nums text-fg-3">{a.durationMs}ms</span>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>
        <div className="space-y-5">
          <ToolConsole st={st} />
          <Card className="p-5">
            <SectionTitle>
              <span className="flex items-center gap-1.5">
                <Bot className="size-3.5" /> Connected agents
              </span>
            </SectionTitle>
            {st.connectedAgents.length === 0 ? (
              <div className="text-[12.5px] text-fg-3">None right now. Cowork chats and agents in Roblox projects connect automatically.</div>
            ) : (
              <div className="space-y-1.5">
                {st.connectedAgents.map((a) => (
                  <div key={a.id} className="flex items-center gap-2 text-[13px]">
                    <StatusDot tone="success" /> <span className="truncate">{a.label}</span>
                  </div>
                ))}
              </div>
            )}
            <div className="mt-4 flex items-center gap-2 border-t border-line pt-3 text-[12.5px] text-fg-3">
              <ListOrdered className="size-3.5" /> Write queue: {st.queue.running ? <span className="text-fg-2">running {st.queue.running}</span> : 'idle'} {st.queue.pending ? `· ${st.queue.pending} waiting` : ''}
            </div>
          </Card>
          <Card className="p-5">
            <SectionTitle
              action={
                <Button size="xs" variant="ghost" icon={<Stethoscope className="size-3.5" />} onClick={() => api.get<Record<string, unknown>>('/api/roblox/diagnostics').then(setDiag)}>
                  Run
                </Button>
              }
            >
              <span className="flex items-center gap-1.5">
                <Server className="size-3.5" /> Diagnostics
              </span>
            </SectionTitle>
            <div className="space-y-1.5 text-[12.5px]">
              <div className="flex justify-between gap-3">
                <span className="text-fg-3">MCP command</span>
                <span className="truncate font-mono text-[11.5px] text-fg-2">{st.command}</span>
              </div>
              {st.serverInfo && (
                <div className="flex justify-between">
                  <span className="text-fg-3">Server</span>
                  <span className="text-fg-2">{st.serverInfo.name} {st.serverInfo.version}</span>
                </div>
              )}
              {st.studioState && (
                <div>
                  <span className="text-fg-3">Studio state</span>
                  <pre className="mt-1 max-h-28 overflow-auto whitespace-pre-wrap rounded-lg bg-code p-2 font-mono text-[11px] text-fg-2">{st.studioState}</pre>
                </div>
              )}
              {diag && <pre className="mt-2 max-h-48 overflow-auto rounded-lg bg-code p-2 font-mono text-[11px] text-fg-2">{JSON.stringify(diag, null, 2)}</pre>}
              {st.stderrTail.length > 0 && (
                <details>
                  <summary className="cursor-pointer text-fg-3">Server log</summary>
                  <pre className="mt-1 max-h-40 overflow-auto whitespace-pre-wrap rounded-lg bg-code p-2 font-mono text-[11px] text-fg-3">{st.stderrTail.join('\n')}</pre>
                </details>
              )}
            </div>
          </Card>
          <Card className="flex gap-3 p-5">
            <Info className="mt-0.5 size-4 shrink-0 text-info" />
            <div className="space-y-2 text-[12.5px] leading-relaxed text-fg-3">
              <p>
                <b className="text-fg-2">Setup:</b> open Roblox Studio → Assistant → ⋯ → Manage MCP Servers → turn on <b>Enable Studio as MCP server</b>. BLOXADE launches the official server with <span className="font-mono">cmd.exe /c %LOCALAPPDATA%\Roblox\mcp.bat</span>.
              </p>
              <p>
                <Lock className="mr-1 inline size-3" />
                Write tools ask before running unless you allow them. Two agents can’t edit the same script at once, and all Studio writes run one at a time.
              </p>
            </div>
          </Card>
        </div>
      </div>
    </Page>
  );
}
