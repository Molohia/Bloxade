import { useEffect, useState } from 'react';
import { Activity, Bot, CircleCheck, CircleX, Clock, Coins, Gauge, Info, Layers, PiggyBank, Radio } from 'lucide-react';
import type { UsageSummary } from '@shared/types';
import { useApp } from '../store/app';
import { api } from '../lib/api';
import { duration, fmtNum, timeAgo } from '../lib/utils';
import { Page, PageHeader, Stat } from '../components/layout/Page';
import { Card, Segmented, SectionTitle, Skeleton } from '../components/ui/primitives';
import { StackedBars, HBar, Donut } from '../components/charts';
import { ProviderMark } from '../components/brand';
import { LimitBars } from './Accounts';

export function UsagePage() {
  const [range, setRange] = useState<'24h' | '7d' | '30d' | 'all'>('7d');
  const [data, setData] = useState<UsageSummary | null>(null);
  const tick = useApp((s) => s.usageTick);
  const accounts = useApp((s) => s.accounts);
  useEffect(() => {
    api.get<UsageSummary>(`/api/usage?range=${range}`, { silent: true }).then(setData, () => undefined);
  }, [range, tick]);
  const labels = (data?.timeline ?? []).map((b) => (range === '24h' ? new Date(b.bucket).toLocaleTimeString(undefined, { hour: 'numeric' }) : new Date(b.bucket).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })));
  const t = data?.totals;
  const verifiedTotal = t ? t.verifiedInput + t.verifiedOutput + t.verifiedCacheRead + t.verifiedCacheWrite : 0;
  return (
    <Page wide>
      <PageHeader
        title="Usage"
        description="Real activity from your local sessions. Verified numbers come directly from Claude Code / Codex; anything BLOXADE calculates itself is labelled as an estimate."
        actions={<Segmented value={range} onChange={setRange} options={[{ value: '24h', label: '24h' }, { value: '7d', label: '7 days' }, { value: '30d', label: '30 days' }, { value: 'all', label: 'All' }]} />}
      />
      {!data ? (
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <Skeleton key={i} className="h-28 rounded-2xl" />
          ))}
        </div>
      ) : (
        <>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
            <Stat label="Active agents" value={data.active.agents} icon={<Bot className="size-4" />} hint="right now" />
            <Stat label="Active sessions" value={data.active.sessions} icon={<Radio className="size-4" />} hint={`${data.active.chats} chat${data.active.chats === 1 ? '' : 's'} generating`} />
            <Stat label="Tasks completed" value={data.tasks.completed} icon={<CircleCheck className="size-4" />} />
            <Stat label="Tasks failed" value={data.tasks.failed} icon={<CircleX className="size-4" />} />
            <Stat label="Avg task time" value={duration(data.tasks.avgDurationMs)} icon={<Clock className="size-4" />} />
            <Stat label="Turns" value={fmtNum(t!.turns)} icon={<Activity className="size-4" />} hint="chat + agent" />
          </div>

          <div className="mt-3 grid grid-cols-2 gap-3 md:grid-cols-4">
            <Stat label="Verified tokens" value={fmtNum(verifiedTotal)} tone="verified" hint={`${fmtNum(t!.verifiedInput)} in · ${fmtNum(t!.verifiedOutput)} out · ${fmtNum(t!.verifiedCacheRead)} cache read`} icon={<Layers className="size-4" />} />
            <Stat label="Reported cost" value={`$${t!.reportedCostUsd.toFixed(2)}`} tone="verified" hint="API-equivalent value from Claude Code — not a bill on subscriptions" icon={<Coins className="size-4" />} />
            <Stat label="Estimated tokens" value={`~${fmtNum(t!.estimatedTokens)}`} tone="estimate" hint="BLOXADE’s own ≈4 chars/token count of prompts + replies" icon={<Gauge className="size-4" />} />
            <Stat label="Context saved" value={`~${fmtNum(t!.contextSavedEstimate)}`} tone="estimate" hint="vs. sending whole project files" icon={<PiggyBank className="size-4" />} />
          </div>

          <div className="mt-5 grid grid-cols-1 gap-5 xl:grid-cols-3">
            <Card className="p-5 xl:col-span-2">
              <SectionTitle
                action={
                  <span className="flex items-center gap-3 text-[11.5px] text-fg-3">
                    <span className="flex items-center gap-1.5"><span className="size-2 rounded-sm bg-claude" /> Claude Code</span>
                    <span className="flex items-center gap-1.5"><span className="size-2 rounded-sm bg-codex" /> Codex</span>
                  </span>
                }
              >
                Activity timeline (turns)
              </SectionTitle>
              <StackedBars data={data.timeline} labels={labels} />
            </Card>
            <Card className="p-5">
              <SectionTitle>Provider comparison</SectionTitle>
              {data.byProvider.length === 0 ? (
                <div className="py-8 text-center text-[13px] text-fg-3">No turns in this range yet.</div>
              ) : (
                <div className="flex items-center gap-5">
                  <Donut parts={data.byProvider.map((p) => ({ value: p.turns, color: p.provider === 'claude' ? 'var(--claude)' : 'var(--codex)' }))} />
                  <div className="flex-1 space-y-3">
                    {data.byProvider.map((p) => (
                      <div key={p.provider}>
                        <div className="flex items-center gap-2 text-[13px] font-medium">
                          <ProviderMark provider={p.provider} size="xs" /> {p.provider === 'claude' ? 'Claude Code' : 'Codex'}
                        </div>
                        <div className="mt-0.5 text-[11.5px] text-fg-3">
                          {p.turns} turns · {fmtNum(p.input)} in · {fmtNum(p.output)} out{p.costUsd ? ` · $${p.costUsd.toFixed(2)}` : ''}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </Card>
          </div>

          <div className="mt-5 grid grid-cols-1 gap-5 xl:grid-cols-3">
            <Card className="p-5">
              <SectionTitle>Models</SectionTitle>
              {data.byModel.length === 0 ? (
                <div className="py-6 text-center text-[13px] text-fg-3">No data yet.</div>
              ) : (
                <HBar items={data.byModel.map((m) => ({ label: <span className="font-mono text-[12px]">{m.model}</span>, value: m.turns, color: m.provider === 'claude' ? 'var(--claude)' : 'var(--codex)', detail: `${m.turns} turns · ${fmtNum(m.input + m.output)} tok` }))} />
              )}
            </Card>
            <Card className="p-5">
              <SectionTitle>Account limits (reported)</SectionTitle>
              {accounts.length === 0 ? (
                <div className="py-6 text-center text-[13px] text-fg-3">No accounts connected.</div>
              ) : (
                <div className="space-y-5">
                  {accounts.map((a) => (
                    <div key={a.id}>
                      <div className="mb-2 flex items-center gap-2 text-[13px] font-medium">
                        <ProviderMark provider={a.provider} size="xs" /> {a.name}
                      </div>
                      <LimitBars account={a} compact />
                    </div>
                  ))}
                </div>
              )}
            </Card>
            <Card className="p-5">
              <SectionTitle>Recent activity</SectionTitle>
              <div className="max-h-[360px] space-y-3 overflow-y-auto">
                {data.recentActivity.length === 0 && <div className="py-6 text-center text-[13px] text-fg-3">Nothing yet.</div>}
                {data.recentActivity.map((a, i) => (
                  <div key={i} className="flex gap-3">
                    <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-accent" />
                    <div className="min-w-0">
                      <div className="text-[12.5px] text-fg">{a.label}</div>
                      <div className="truncate text-[11.5px] text-fg-3">
                        {timeAgo(a.ts)}
                        {a.detail ? ` · ${a.detail}` : ''}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>
          <div className="mt-5 flex items-start gap-2.5 text-[12px] leading-relaxed text-fg-3">
            <Info className="mt-0.5 size-3.5 shrink-0" />
            BLOXADE never shows invented quotas or “messages remaining”. Limit windows appear only when the CLI reports them; token counts come from the CLIs’ own usage reports for each turn.
          </div>
        </>
      )}
    </Page>
  );
}
