import { useEffect, useMemo, useState } from 'react';
import { Activity as ActivityIcon, Bot, Files, FolderKanban, Gamepad2, MessageSquare, ShieldCheck, UserCog } from 'lucide-react';
import type { RobloxActivity } from '@shared/types';
import { useApp, type ActivityItem } from '../store/app';
import { api } from '../lib/api';
import { cn, timeAgo } from '../lib/utils';
import { navigate, routes } from '../lib/router';
import { Page, PageHeader } from '../components/layout/Page';
import { Badge, Card, EmptyState, Segmented } from '../components/ui/primitives';

const KIND_ICON: Record<string, typeof Bot> = { agents: Bot, account: UserCog, project: FolderKanban, chat: MessageSquare, roblox: Gamepad2, approval: ShieldCheck, files: Files };

export function ActivityPage() {
  const live = useApp((s) => s.activity);
  const liveRbx = useApp((s) => s.robloxActivity);
  const [items, setItems] = useState<ActivityItem[]>([]);
  const [rbx, setRbx] = useState<RobloxActivity[]>([]);
  const [tab, setTab] = useState<'all' | 'studio'>('all');
  const [kind, setKind] = useState<string>('all');
  useEffect(() => {
    api.get<ActivityItem[]>('/api/activity?limit=300', { silent: true }).then(setItems, () => undefined);
    api.get<RobloxActivity[]>('/api/roblox/activity?limit=300', { silent: true }).then(setRbx, () => undefined);
  }, []);
  const all = useMemo(() => {
    const m = new Map<string, ActivityItem>();
    for (const i of [...live, ...items]) m.set(i.id, i);
    return [...m.values()].sort((a, b) => b.ts - a.ts);
  }, [live, items]);
  const studio = useMemo(() => {
    const m = new Map<string, RobloxActivity>();
    for (const i of [...liveRbx, ...rbx]) m.set(i.id, i);
    return [...m.values()].sort((a, b) => b.ts - a.ts);
  }, [liveRbx, rbx]);
  const kinds = ['all', ...new Set(all.map((a) => a.kind))];
  const filtered = kind === 'all' ? all : all.filter((a) => a.kind === kind);
  return (
    <Page>
      <PageHeader title="Activity" description="A live timeline of what your agents, chats, accounts and Roblox Studio tools have been doing." actions={<Segmented value={tab} onChange={setTab} options={[{ value: 'all', label: 'Workspace' }, { value: 'studio', label: 'Studio tool calls' }]} />} />
      {tab === 'all' ? (
        <>
          <div className="mb-4 flex flex-wrap gap-1.5">
            {kinds.map((k) => (
              <button key={k} onClick={() => setKind(k)} className={cn('h-7 cursor-pointer rounded-lg border px-2.5 text-[12px] capitalize', kind === k ? 'border-accent/50 bg-accent-softer text-fg' : 'border-line text-fg-3 hover:text-fg-2')}>
                {k}
              </button>
            ))}
          </div>
          {filtered.length === 0 ? (
            <Card>
              <EmptyState icon={<ActivityIcon className="size-5" />} title="No activity yet" />
            </Card>
          ) : (
            <Card className="p-2">
              {filtered.map((a, i) => {
                const Icon = KIND_ICON[a.kind] ?? ActivityIcon;
                const first = i === 0 || new Date(filtered[i - 1].ts).toDateString() !== new Date(a.ts).toDateString();
                return (
                  <div key={a.id}>
                    {first && <div className="px-3 pb-1 pt-3 text-[11px] font-semibold uppercase tracking-[0.07em] text-fg-3">{new Date(a.ts).toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' })}</div>}
                    <button
                      onClick={() => a.refId && (a.refId.startsWith('run_') ? navigate(routes.tasks(a.refId)) : a.refId.startsWith('chat_') ? navigate(routes.chat(a.refId)) : a.refId.startsWith('prj_') ? navigate(routes.project(a.refId)) : undefined)}
                      className={cn('flex w-full items-start gap-3 rounded-xl px-3 py-2.5 text-left', a.refId ? 'cursor-pointer hover:bg-surface-2/60' : 'cursor-default')}
                    >
                      <span className="mt-0.5 flex size-7 shrink-0 items-center justify-center rounded-lg bg-surface-2 text-fg-3">
                        <Icon className="size-3.5" />
                      </span>
                      <div className="min-w-0 flex-1">
                        <div className="text-[13px] text-fg">{a.label}</div>
                        {a.detail && <div className="mt-0.5 line-clamp-2 text-[12px] text-fg-3">{a.detail}</div>}
                      </div>
                      <span className="shrink-0 text-[11.5px] text-fg-3">{new Date(a.ts).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' })}</span>
                    </button>
                  </div>
                );
              })}
            </Card>
          )}
        </>
      ) : studio.length === 0 ? (
        <Card>
          <EmptyState icon={<Gamepad2 className="size-5" />} title="No Studio tool calls yet" description="Every Roblox Studio MCP call made by agents, chats or the Studio console is logged here." />
        </Card>
      ) : (
        <Card className="divide-y divide-line">
          {studio.map((r) => (
            <div key={r.id} className="flex items-center gap-3 px-4 py-2.5 text-[12.5px]">
              <Badge tone={r.status === 'ok' ? 'success' : r.status === 'cached' ? 'info' : r.status === 'denied' ? 'warning' : 'danger'}>{r.status}</Badge>
              <span className="w-40 shrink-0 truncate font-mono text-fg">{r.tool}</span>
              <span className="min-w-0 flex-1 truncate text-fg-3">{r.summary}</span>
              <span className="w-36 shrink-0 truncate text-right text-fg-3">{r.caller}</span>
              <span className="w-16 shrink-0 text-right tabular-nums text-fg-3">{r.durationMs} ms</span>
              <span className="w-16 shrink-0 text-right text-fg-3">{timeAgo(r.ts)}</span>
            </div>
          ))}
        </Card>
      )}
    </Page>
  );
}
