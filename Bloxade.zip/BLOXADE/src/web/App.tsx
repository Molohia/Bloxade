import { useEffect } from 'react';
import { Tooltip } from 'radix-ui';
import { Toaster } from 'sonner';
import { PanelLeftOpen, WifiOff, MessageSquarePlus } from 'lucide-react';
import { useApp } from './store/app';
import { useUi } from './store/ui';
import { useRoute, navigate, routes } from './lib/router';
import { applyAppearance } from './lib/theme';
import { connectEvents } from './lib/sse';
import { modKey } from './lib/utils';
import { Sidebar } from './components/layout/Sidebar';
import { ApprovalCenter } from './components/ApprovalCenter';
import { CommandPalette } from './components/CommandPalette';
import { NewProjectDialog } from './components/ProjectDialogs';
import { ConfirmHost, Dialog } from './components/ui/overlays';
import { IconButton, Kbd, Button } from './components/ui/primitives';
import { LogoMark } from './components/brand';
import { ChatPage } from './pages/ChatPage';
import { ProjectsPage, ProjectWorkspace } from './pages/Projects';
import { AgentsPage, TaskBoardPage, InspectDrawer } from './pages/Agents';
import { ActivityPage } from './pages/Activity';
import { AccountsPage } from './pages/Accounts';
import { RobloxPage } from './pages/Roblox';
import { UsagePage } from './pages/Usage';
import { SettingsPage } from './pages/Settings';
import { Onboarding } from './pages/Onboarding';

function Shortcuts() {
  const open = useUi((s) => s.shortcutsOpen);
  const set = useUi((s) => s.setShortcuts);
  const rows: [string, string][] = [
    [`${modKey} K`, 'Search chats, projects & actions'],
    [`${modKey} Shift O`, 'New chat'],
    [`${modKey} B`, 'Toggle sidebar'],
    [`${modKey} ,`, 'Settings'],
    ['Enter', 'Send message'],
    ['Shift Enter', 'New line'],
    ['Esc', 'Stop generating (in the message box)'],
    [`${modKey} /`, 'Show shortcuts'],
  ];
  return (
    <Dialog open={open} onOpenChange={set} title="Keyboard shortcuts">
      <div className="divide-y divide-line">
        {rows.map(([k, d]) => (
          <div key={k} className="flex items-center justify-between py-2.5 text-[13px]">
            <span className="text-fg-2">{d}</span>
            <span className="flex gap-1">
              {k.split(' ').map((p) => (
                <Kbd key={p}>{p}</Kbd>
              ))}
            </span>
          </div>
        ))}
      </div>
    </Dialog>
  );
}

function Main() {
  const route = useRoute();
  switch (route.page) {
    case 'projects':
      return route.parts[0] ? <ProjectWorkspace id={route.parts[0]} tab={route.parts[1] ?? 'overview'} /> : <ProjectsPage />;
    case 'agents':
      return <AgentsPage />;
    case 'tasks':
      return <TaskBoardPage runId={route.parts[0] ?? null} />;
    case 'activity':
      return <ActivityPage />;
    case 'accounts':
      return <AccountsPage provider={(route.query.get('provider') as 'claude' | 'codex' | null) ?? null} />;
    case 'roblox':
      return <RobloxPage />;
    case 'usage':
      return <UsagePage />;
    case 'settings':
      return <SettingsPage tab={route.parts[0] ?? 'general'} />;
    default:
      return <ChatPage />;
  }
}

export function App() {
  const ready = useApp((s) => s.ready);
  const bootError = useApp((s) => s.bootError);
  const settings = useApp((s) => s.settings);
  const connection = useApp((s) => s.connection);
  const bootstrap = useApp((s) => s.bootstrap);
  const saveSettings = useApp((s) => s.saveSettings);

  useEffect(() => {
    void bootstrap();
    return connectEvents();
  }, [bootstrap]);

  useEffect(() => {
    if (settings) applyAppearance(settings.appearance);
  }, [settings?.appearance]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const mod = e.ctrlKey || e.metaKey;
      if (!mod) return;
      const k = e.key.toLowerCase();
      if (k === 'k') {
        e.preventDefault();
        useUi.getState().openPalette();
      } else if (k === 'o' && e.shiftKey) {
        e.preventDefault();
        navigate(routes.newChat());
      } else if (k === 'b' && !e.shiftKey) {
        e.preventDefault();
        const s = useApp.getState().settings;
        if (s) void saveSettings({ appearance: { sidebarCollapsed: !s.appearance.sidebarCollapsed } });
      } else if (k === ',') {
        e.preventDefault();
        navigate(routes.settings());
      } else if (k === '/') {
        e.preventDefault();
        useUi.getState().setShortcuts(true);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [saveSettings]);

  if (!ready) {
    return (
      <div className="flex h-full flex-col items-center justify-center gap-4">
        <LogoMark size={36} className={bootError ? '' : 'pulse-dot'} />
        {bootError ? (
          <div className="max-w-md text-center">
            <div className="text-[15px] font-semibold">Can’t reach the BLOXADE server</div>
            <div className="mt-1.5 text-[13px] text-fg-3">{bootError}</div>
            <Button className="mt-4" variant="secondary" onClick={() => bootstrap()}>
              Try again
            </Button>
          </div>
        ) : (
          <div className="text-[13px] text-fg-3">Starting BLOXADE…</div>
        )}
      </div>
    );
  }

  const collapsed = settings?.appearance.sidebarCollapsed;
  return (
    <Tooltip.Provider delayDuration={350}>
      <div className="flex h-full w-full overflow-hidden bg-bg text-fg">
        {!collapsed && <Sidebar />}
        <main className="relative min-w-0 flex-1">
          {collapsed && (
            <div className="absolute left-3 top-2.5 z-20 flex items-center gap-1">
              <IconButton label={`Show sidebar (${modKey}+B)`} onClick={() => saveSettings({ appearance: { sidebarCollapsed: false } })}>
                <PanelLeftOpen className="size-[18px]" />
              </IconButton>
              <IconButton label="New chat" onClick={() => navigate(routes.newChat())}>
                <MessageSquarePlus className="size-[18px]" />
              </IconButton>
            </div>
          )}
          {connection === 'offline' && (
            <div className="absolute inset-x-0 top-0 z-30 flex items-center justify-center gap-2 bg-danger/90 py-1.5 text-[12.5px] font-medium text-white">
              <WifiOff className="size-3.5" /> Lost connection to the BLOXADE server — reconnecting… (is the START_BLOXADE window still open?)
            </div>
          )}
          <Main />
        </main>
      </div>
      <ApprovalCenter />
      <CommandPalette />
      <NewProjectDialog />
      <InspectDrawer />
      <Shortcuts />
      <ConfirmHost />
      {settings && !settings.general.onboardingComplete && <Onboarding />}
      <Toaster
        position="bottom-center"
        theme={settings?.appearance.theme === 'light' ? 'light' : 'dark'}
        toastOptions={{ classNames: { toast: '!bg-surface !border-line-strong !text-fg !rounded-xl !shadow-pop', description: '!text-fg-3' } }}
      />
    </Tooltip.Provider>
  );
}
