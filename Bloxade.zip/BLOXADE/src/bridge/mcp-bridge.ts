/**
 * BLOXADE MCP bridge — launched by Claude Code / Codex as a stdio MCP server.
 * It forwards each JSON-RPC message to the local BLOXADE backend, which routes Roblox Studio tool calls
 * through its central queue (permissions, locks, caching) to the official Roblox Studio MCP server.
 * Contains no credentials; the per-session token only identifies which chat/agent is calling.
 */
import http from 'node:http';

const base = process.env.BLOXADE_URL || 'http://127.0.0.1:3000';
const token = process.env.BLOXADE_BRIDGE_TOKEN || '';
const url = new URL('/api/bridge/rpc', base);

function post(body: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const req = http.request(
      { hostname: url.hostname, port: url.port, path: url.pathname, method: 'POST', headers: { 'content-type': 'application/json', 'x-bloxade-bridge-token': token, host: `${url.hostname}:${url.port}` }, timeout: 15 * 60_000 },
      (res) => {
        const chunks: Buffer[] = [];
        res.on('data', (c: Buffer) => chunks.push(c));
        res.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
      },
    );
    req.on('error', reject);
    req.on('timeout', () => req.destroy(new Error('BLOXADE did not answer in time')));
    req.end(body);
  });
}

function write(obj: unknown) {
  process.stdout.write(JSON.stringify(obj) + '\n');
}

let buf = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', (chunk: string) => {
  buf += chunk;
  let i: number;
  while ((i = buf.indexOf('\n')) >= 0) {
    const line = buf.slice(0, i).trim();
    buf = buf.slice(i + 1);
    if (line) void handle(line);
  }
});
process.stdin.on('end', () => process.exit(0));

async function handle(line: string) {
  let msg: any;
  try {
    msg = JSON.parse(line);
  } catch {
    return;
  }
  try {
    const text = await post(line);
    if (!text.trim()) return;
    const resp = JSON.parse(text);
    if (resp && resp.response !== undefined) {
      if (resp.response !== null) write(resp.response);
    } else if (resp?.error && msg?.id !== undefined) {
      write({ jsonrpc: '2.0', id: msg.id, error: { code: -32000, message: String(resp.error) } });
    }
  } catch (e) {
    if (msg?.id !== undefined) write({ jsonrpc: '2.0', id: msg.id, error: { code: -32000, message: `BLOXADE is not reachable: ${(e as Error).message}` } });
  }
}
