// Types shared by the BLOXADE backend and frontend.

export type Provider = 'claude' | 'codex';
export type ChatMode = 'chat' | 'cowork';
export type ThemeName = 'dark' | 'light' | 'midnight' | 'oled' | 'slate';
export type EfficiencyMode = 'economy' | 'balanced' | 'performance' | 'max';
export type Density = 'comfortable' | 'compact';
export type PermissionPolicy = 'allow' | 'ask' | 'deny';

export const PROVIDER_LABEL: Record<Provider, string> = { claude: 'Claude Code', codex: 'Codex' };

// ---------- Accounts ----------
export type AccountStatus = 'unknown' | 'checking' | 'signed_in' | 'signed_out' | 'signing_in' | 'error' | 'cli_missing';

export interface LimitWindow {
  id: string;
  label: string;
  usedPercent: number; // 0..100
  resetsAt?: number | null; // unix seconds
  windowMins?: number | null;
  status?: string | null;
}

export interface AccountLimits {
  source: 'claude-code' | 'codex';
  updatedAt: number;
  windows: LimitWindow[];
  note?: string;
}

export interface Account {
  id: string;
  provider: Provider;
  name: string;
  /** null = the provider CLI's default (system) sign-in location */
  profileDir: string | null;
  isSystem: boolean;
  enabled: boolean;
  isDefault: boolean;
  color: string;
  createdAt: number;
  lastUsedAt: number | null;
  status: AccountStatus;
  statusDetail?: string | null;
  email?: string | null;
  plan?: string | null;
  authMethod?: string | null;
  limits?: AccountLimits | null;
  activeSessions?: number;
  login?: { kind: 'browser' | 'terminal' | 'device'; url?: string; code?: string; startedAt: number } | null;
}

// ---------- Providers / models ----------
export interface CliInfo {
  provider: Provider;
  found: boolean;
  path?: string | null;
  version?: string | null;
  launch?: string | null;
  error?: string | null;
  checkedAt: number;
}

export interface ModelInfo {
  id: string; // value passed to the CLI
  label: string;
  description?: string;
  resolvedModel?: string | null;
  efforts: string[];
  defaultEffort?: string | null;
  group: 'recommended' | 'versions' | 'hidden';
  isDefault?: boolean;
  source: 'discovered' | 'catalog';
  note?: string;
}

export interface ModelCatalog {
  provider: Provider;
  models: ModelInfo[];
  discoveredAt: number | null;
  source: 'discovered' | 'catalog';
  error?: string | null;
}

// ---------- Chats ----------
export type Block =
  | { type: 'text'; text: string }
  | { type: 'thinking'; text: string }
  | {
      type: 'tool';
      id: string;
      name: string;
      title?: string;
      input?: unknown;
      status: 'running' | 'done' | 'error' | 'denied';
      output?: string;
      server?: string;
    }
  | { type: 'notice'; level: 'info' | 'warning' | 'error'; text: string };

export interface AttachmentRef {
  id: string;
  name: string;
  mime: string;
  size: number;
  kind: 'image' | 'text' | 'file';
}

export interface UsageInfo {
  inputTokens?: number;
  outputTokens?: number;
  cacheReadTokens?: number;
  cacheWriteTokens?: number;
  reasoningTokens?: number;
  costUsd?: number | null;
  verified: boolean;
  contextTokensSent?: number; // BLOXADE's own context pack estimate
  contextTokensSaved?: number;
}

export interface ProviderRef {
  sessionId?: string | null; // claude
  lastAssistantUuid?: string | null; // claude
  threadId?: string | null; // codex
  turnId?: string | null; // codex
}

export interface Message {
  id: string;
  chatId: string;
  role: 'user' | 'assistant';
  content: string;
  blocks: Block[];
  status: 'complete' | 'streaming' | 'error' | 'cancelled';
  attachments: AttachmentRef[];
  usage?: UsageInfo | null;
  error?: string | null;
  provider?: Provider | null;
  accountId?: string | null;
  model?: string | null;
  effort?: string | null;
  mode?: ChatMode | null;
  providerRef?: ProviderRef | null;
  createdAt: number;
  durationMs?: number | null;
}

export interface Chat {
  id: string;
  title: string;
  projectId: string | null;
  pinned: boolean;
  provider: Provider;
  accountId: string | null;
  model: string;
  effort: string;
  mode: ChatMode;
  createdAt: number;
  updatedAt: number;
  preview?: string;
  running?: boolean;
  messageCount?: number;
  branchedFrom?: { chatId: string; messageId: string } | null;
}

// ---------- Projects ----------
export interface Project {
  id: string;
  name: string;
  icon: string;
  color: string;
  description: string;
  folderPath: string | null;
  instructions: string;
  memory: string;
  memoryUpdatedAt: number | null;
  robloxEnabled: boolean;
  defaults: { provider?: Provider; accountId?: string | null; model?: string; effort?: string; mode?: ChatMode };
  createdAt: number;
  updatedAt: number;
  stats?: { chats: number; runs: number; files?: number };
}

export interface FileEntry {
  name: string;
  path: string; // relative, forward slashes
  type: 'file' | 'dir';
  size?: number;
  mtime?: number;
}

export interface FileChange {
  id: string;
  projectId: string;
  path: string;
  change: 'added' | 'modified' | 'deleted';
  source: 'chat' | 'task' | 'scan';
  sourceId: string | null;
  diff: string | null;
  createdAt: number;
  reverted: boolean;
}

// ---------- Agents ----------
export type TaskStatus = 'pending' | 'working' | 'reviewing' | 'completed' | 'failed' | 'blocked' | 'cancelled';
export type RunStatus = 'planning' | 'ready' | 'running' | 'paused' | 'completed' | 'failed' | 'cancelled';

export interface AgentAssignment {
  provider: Provider;
  accountId: string | null;
  model: string;
  effort: string;
}

export interface AgentTask {
  id: string;
  runId: string;
  key: string; // t1, t2 ...
  title: string;
  description: string;
  status: TaskStatus;
  agentName: string;
  assignment: AgentAssignment;
  dependsOn: string[]; // task keys
  ownedPaths: string[]; // file globs / studio script paths
  filesTouched: string[];
  toolOps: number;
  currentActivity?: string | null;
  summary?: string | null;
  error?: string | null;
  attempts: number;
  blocks: Block[];
  usage?: UsageInfo | null;
  createdAt: number;
  startedAt: number | null;
  finishedAt: number | null;
  review?: { reason: string; conflicts: string[] } | null;
}

export interface AgentRun {
  id: string;
  projectId: string | null;
  prompt: string;
  status: RunStatus;
  strategy: 'auto' | 'manual';
  efficiency: EfficiencyMode;
  coordinator: AgentAssignment;
  rationale?: string | null;
  report?: string | null;
  error?: string | null;
  createdAt: number;
  startedAt: number | null;
  finishedAt: number | null;
  tasks: AgentTask[];
  autoApprove: { edits: boolean; commands: boolean; studioWrites: boolean };
}

// ---------- Approvals ----------
export interface Approval {
  id: string;
  kind: 'command' | 'file_edit' | 'tool' | 'studio' | 'conflict';
  title: string;
  detail: string;
  toolName?: string;
  input?: unknown;
  requester: { kind: 'chat' | 'task' | 'user'; id: string; label: string };
  createdAt: number;
  expiresAt: number;
}

// ---------- Roblox ----------
export interface RobloxTool {
  name: string;
  description: string;
  readOnly: boolean;
  policy: PermissionPolicy;
}

export interface RobloxStatus {
  enabled: boolean;
  state: 'disconnected' | 'connecting' | 'connected' | 'error';
  command: string;
  error?: string | null;
  serverInfo?: { name?: string; version?: string } | null;
  tools: RobloxTool[];
  studios: { id: string; name: string }[];
  activeStudioId: string | null;
  studioState?: string | null;
  lastTest?: { ok: boolean; at: number; latencyMs: number; message: string } | null;
  connectedAgents: { id: string; label: string; since: number }[];
  queue: { pending: number; running: string | null };
  stderrTail: string[];
  connectedAt?: number | null;
}

export interface RobloxActivity {
  id: string;
  ts: number;
  caller: string;
  tool: string;
  summary: string;
  status: 'ok' | 'error' | 'denied' | 'cached';
  durationMs: number;
}

// ---------- Settings ----------
export interface Settings {
  general: {
    onboardingComplete: boolean;
    openBrowserOnStart: boolean;
    defaultProjectId: string | null;
    notifications: boolean;
    confirmDeletes: boolean;
    autoTitle: boolean;
  };
  appearance: {
    theme: ThemeName;
    accent: string;
    fontSize: number; // px
    density: Density;
    sidebarCollapsed: boolean;
    reduceMotion: boolean;
  };
  providers: {
    claudePath: string;
    codexPath: string;
    defaultProvider: Provider;
    defaultModels: Record<Provider, string>;
    defaultEfforts: Record<Provider, string>;
    defaultMode: ChatMode;
    showHiddenModels: boolean;
    customModels: Record<Provider, string[]>;
  };
  agents: {
    maxConcurrent: number | null; // null = from efficiency mode
    routing: 'balanced' | 'prefer-claude' | 'prefer-codex' | 'claude-only' | 'codex-only';
    approvals: { edits: PermissionPolicy; commands: PermissionPolicy; unownedEdits: PermissionPolicy };
    requireReview: boolean;
    approvalTimeoutSec: number;
    useGitWorktrees: boolean;
  };
  context: {
    mode: EfficiencyMode;
    budgetOverride: number | null;
    cache: boolean;
    primeChats: boolean;
    toolOutputCap: number | null;
    autoMemory: boolean;
  };
  roblox: {
    enabled: boolean;
    autoConnect: boolean;
    command: string;
    defaultStudioId: string | null;
    toolPolicies: Record<string, PermissionPolicy>;
    cacheReads: boolean;
  };
  privacy: { keepAttachments: boolean; logPrompts: boolean };
  advanced: { port: number; logLevel: 'debug' | 'info' | 'warn' | 'error'; turnTimeoutMin: number };
}

export interface EfficiencyProfile {
  label: string;
  description: string;
  contextBudget: number; // tokens
  maxConcurrentAgents: number;
  maxTasks: number;
  retries: number;
  toolOutputCap: number; // chars
  verification: 'none' | 'report' | 'review';
  primeSnippets: number; // max files with snippets
}

export const EFFICIENCY_PROFILES: Record<EfficiencyMode, EfficiencyProfile> = {
  economy: {
    label: 'Economy',
    description: 'Smallest context, one agent at a time, no extra verification pass.',
    contextBudget: 2500,
    maxConcurrentAgents: 1,
    maxTasks: 2,
    retries: 0,
    toolOutputCap: 4000,
    verification: 'none',
    primeSnippets: 3,
  },
  balanced: {
    label: 'Balanced',
    description: 'Targeted context, up to two agents in parallel, short final report.',
    contextBudget: 8000,
    maxConcurrentAgents: 2,
    maxTasks: 4,
    retries: 1,
    toolOutputCap: 8000,
    verification: 'report',
    primeSnippets: 6,
  },
  performance: {
    label: 'Performance',
    description: 'Richer context, three parallel agents, coordinator review of results.',
    contextBudget: 20000,
    maxConcurrentAgents: 3,
    maxTasks: 6,
    retries: 1,
    toolOutputCap: 16000,
    verification: 'review',
    primeSnippets: 10,
  },
  max: {
    label: 'Maximum Quality',
    description: 'Large context budgets, four parallel agents, full review and two retries.',
    contextBudget: 50000,
    maxConcurrentAgents: 4,
    maxTasks: 8,
    retries: 2,
    toolOutputCap: 32000,
    verification: 'review',
    primeSnippets: 16,
  },
};

// ---------- Usage ----------
export interface UsageSummary {
  range: string;
  totals: {
    verifiedInput: number;
    verifiedOutput: number;
    verifiedCacheRead: number;
    verifiedCacheWrite: number;
    reportedCostUsd: number;
    estimatedTokens: number;
    contextSavedEstimate: number;
    turns: number;
  };
  byProvider: { provider: Provider; turns: number; input: number; output: number; costUsd: number }[];
  byModel: { model: string; provider: Provider; turns: number; input: number; output: number }[];
  timeline: { bucket: number; claude: number; codex: number }[];
  tasks: { completed: number; failed: number; avgDurationMs: number | null; running: number };
  active: { agents: number; chats: number; sessions: number };
  accounts: { id: string; name: string; provider: Provider; limits: AccountLimits | null }[];
  recentActivity: { ts: number; kind: string; label: string; detail: string }[];
}

export interface Bootstrap {
  version: string;
  settings: Settings;
  accounts: Account[];
  projects: Project[];
  chats: Chat[];
  clis: Record<Provider, CliInfo>;
  roblox: RobloxStatus;
  approvals: Approval[];
  platform: string;
  dataDir: string;
  runningChats: string[];
}
