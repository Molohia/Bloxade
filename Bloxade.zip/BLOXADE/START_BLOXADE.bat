@echo off
setlocal EnableExtensions EnableDelayedExpansion
title BLOXADE
cd /d "%~dp0"

rem ---------------------------------------------------------------
rem  BLOXADE one-click launcher
rem   1) finds Node.js 22.13+ (private copy in %LOCALAPPDATA%\BLOXADE\runtime, or system)
rem   2) downloads a private portable Node.js on first run if needed
rem   3) starts BLOXADE on http://127.0.0.1:3000 and opens the browser
rem ---------------------------------------------------------------

set "RUNTIME_DIR=%LOCALAPPDATA%\BLOXADE\runtime"
set "NODE_EXE="
if exist "%RUNTIME_DIR%\node\node.exe" set "NODE_EXE=%RUNTIME_DIR%\node\node.exe"

if not defined NODE_EXE (
  for /f "delims=" %%i in ('where node 2^>nul') do (
    if not defined NODE_EXE set "NODE_EXE=%%i"
  )
  if defined NODE_EXE (
    "!NODE_EXE!" -e "const [a,b]=process.versions.node.split('.').map(Number);process.exit(a>22||(a===22&&b>=13)?0:1)" >nul 2>nul
    if errorlevel 1 (
      echo   Found Node.js at !NODE_EXE! but it is older than 22.13 - BLOXADE will use its own copy.
      set "NODE_EXE="
    )
  )
)

if not defined NODE_EXE (
  echo.
  echo   First run: downloading a private copy of Node.js for BLOXADE ^(about 30 MB^).
  echo   This only happens once and does not change your system.
  echo.
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0app\setup-node.ps1" -Dest "%RUNTIME_DIR%"
  if errorlevel 1 (
    echo.
    pause
    exit /b 1
  )
  set "NODE_EXE=%RUNTIME_DIR%\node\node.exe"
)

"%NODE_EXE%" --disable-warning=ExperimentalWarning "%~dp0app\launcher.mjs" %*
if errorlevel 1 (
  echo.
  echo   BLOXADE stopped with an error. See the message above.
  pause
)
endlocal
