import { createRequire as __bxCreateRequire } from 'node:module'; const require = __bxCreateRequire(import.meta.url);

// src/server/main.ts
import { pathToFileURL } from "node:url";

// src/server/core/paths.ts
import path from "node:path";
import os from "node:os";
import fs from "node:fs";
import { fileURLToPath } from "node:url";

// src/server/core/util.ts
import { randomBytes, createHash } from "node:crypto";
var ALPHABET = "0123456789abcdefghijklmnopqrstuvwxyz";
function newId(prefix = "") {
  const t = Date.now().toString(36).padStart(9, "0");
  const bytes = randomBytes(8);
  let r = "";
  for (const b2 of bytes) r += ALPHABET[b2 % 36];
  return (prefix ? prefix + "_" : "") + t + r;
}
function uuid() {
  return globalThis.crypto.randomUUID();
}
var now = () => Date.now();
function sha1(data) {
  return createHash("sha1").update(data).digest("hex");
}
function estimateTokens(text) {
  const n = typeof text === "number" ? text : text.length;
  return Math.ceil(n / 4);
}
function truncate(text, max, suffix = "\u2026") {
  if (text.length <= max) return text;
  return text.slice(0, Math.max(0, max - suffix.length)) + suffix;
}
function safeJson(text, fallback) {
  if (text == null || text === "") return fallback;
  try {
    return JSON.parse(text);
  } catch {
    return fallback;
  }
}
function isPlainObject(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}
function deepMerge(base, patch) {
  if (!isPlainObject(base) || !isPlainObject(patch)) return patch === void 0 ? base : patch;
  const out = { ...base };
  for (const [k, v] of Object.entries(patch)) {
    if (v === void 0) continue;
    const cur = out[k];
    out[k] = isPlainObject(cur) && isPlainObject(v) ? deepMerge(cur, v) : v;
  }
  return out;
}
var HttpError = class extends Error {
  constructor(status, message, code) {
    super(message);
    this.status = status;
    this.code = code;
  }
  status;
  code;
};
function str(v, name, opts = {}) {
  if (v == null && opts.optional) return "";
  if (typeof v !== "string") throw new HttpError(400, `${name} must be text`);
  if (opts.min != null && v.trim().length < opts.min) throw new HttpError(400, `${name} is required`);
  if (opts.max != null && v.length > opts.max) throw new HttpError(400, `${name} is too long (max ${opts.max})`);
  return v;
}
function oneOf(v, values, name, fallback) {
  if (v == null && fallback !== void 0) return fallback;
  if (typeof v === "string" && values.includes(v)) return v;
  throw new HttpError(400, `${name} must be one of: ${values.join(", ")}`);
}
function safeToken(v, name, optional = false) {
  if ((v == null || v === "") && optional) return "";
  if (typeof v !== "string" || !/^[A-Za-z0-9._:\-[\]/@+]{1,120}$/.test(v)) {
    throw new HttpError(400, `${name} contains unsupported characters`);
  }
  return v;
}
function debounce(fn, ms) {
  let t = null;
  let lastArgs;
  const d = (...a) => {
    lastArgs = a;
    if (t) return;
    t = setTimeout(() => {
      t = null;
      fn(...lastArgs);
    }, ms);
  };
  d.flush = () => {
    if (t) {
      clearTimeout(t);
      t = null;
      fn(...lastArgs);
    }
  };
  return d;
}
function preview(text, max = 140) {
  return truncate(text.replace(/\s+/g, " ").trim(), max);
}
function titleFrom(text) {
  const firstLine = text.replace(/```[\s\S]*?```/g, " ").split("\n").map((l) => l.trim()).find(Boolean) ?? "New chat";
  const clean = firstLine.replace(/^[#>*\-\s]+/, "").replace(/\s+/g, " ");
  return truncate(clean || "New chat", 60);
}
var IS_WIN = process.platform === "win32";

// src/server/core/paths.ts
function detectAppDir() {
  try {
    const here = path.dirname(fileURLToPath(import.meta.url));
    return here;
  } catch {
    return process.cwd();
  }
}
var APP_DIR = process.env.BLOXADE_APP_DIR || detectAppDir();
function findPublicDir() {
  const candidates = [
    path.join(APP_DIR, "public"),
    path.join(APP_DIR, "..", "app", "public"),
    path.join(APP_DIR, "..", "..", "app", "public"),
    path.join(process.cwd(), "app", "public")
  ];
  return candidates.find((p) => fs.existsSync(path.join(p, "index.html"))) ?? candidates[0];
}
function findBridge() {
  const candidates = [
    path.join(APP_DIR, "mcp-bridge.mjs"),
    path.join(APP_DIR, "..", "app", "mcp-bridge.mjs"),
    path.join(APP_DIR, "..", "..", "app", "mcp-bridge.mjs"),
    path.join(process.cwd(), "app", "mcp-bridge.mjs")
  ];
  return candidates.find((p) => fs.existsSync(p)) ?? candidates[0];
}
var PUBLIC_DIR = findPublicDir();
var BRIDGE_SCRIPT = findBridge();
function defaultDataDir() {
  if (process.env.BLOXADE_DATA_DIR) return path.resolve(process.env.BLOXADE_DATA_DIR);
  if (IS_WIN) {
    const local = process.env.LOCALAPPDATA || path.join(os.homedir(), "AppData", "Local");
    return path.join(local, "BLOXADE");
  }
  return path.join(os.homedir(), ".bloxade");
}
var DATA_DIR = defaultDataDir();
var dirs = {
  data: DATA_DIR,
  db: path.join(DATA_DIR, "db"),
  logs: path.join(DATA_DIR, "logs"),
  profiles: path.join(DATA_DIR, "profiles"),
  attachments: path.join(DATA_DIR, "attachments"),
  blobs: path.join(DATA_DIR, "blobs"),
  workspaces: path.join(DATA_DIR, "workspaces"),
  runtime: path.join(DATA_DIR, "runtime")
};
function ensureDirs() {
  for (const d of Object.values(dirs)) fs.mkdirSync(d, { recursive: true });
}
function profileDir(provider, accountId) {
  return path.join(dirs.profiles, provider, accountId);
}
function expandUserPath(p) {
  let out = p.trim().replace(/^"(.*)"$/, "$1");
  if (out === "~" || out.startsWith("~/") || out.startsWith("~\\")) out = path.join(os.homedir(), out.slice(1));
  if (IS_WIN) out = out.replace(/%([^%]+)%/g, (m, name) => process.env[name] ?? m);
  return path.resolve(out);
}

// src/server/core/db.ts
import { DatabaseSync } from "node:sqlite";
import path3 from "node:path";
import fs3 from "node:fs";

// src/server/core/log.ts
import fs2 from "node:fs";
import path2 from "node:path";
var ORDER = { debug: 10, info: 20, warn: 30, error: 40 };
var ring = [];
var minLevel = process.env.BLOXADE_LOG_LEVEL || "info";
var stream = null;
var streamDay = "";
function fileStream() {
  const day = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
  if (stream && day === streamDay) return stream;
  try {
    stream?.end();
    fs2.mkdirSync(dirs.logs, { recursive: true });
    stream = fs2.createWriteStream(path2.join(dirs.logs, `bloxade-${day}.log`), { flags: "a" });
    streamDay = day;
  } catch {
    stream = null;
  }
  return stream;
}
function setLogLevel(level) {
  minLevel = level;
}
function scrub(data) {
  if (data instanceof Error) return { error: data.message, stack: data.stack?.split("\n").slice(0, 4).join("\n") };
  return data;
}
function write(level, scope, msg, data) {
  const entry = { ts: Date.now(), level, scope, msg, data: scrub(data) };
  ring.push(entry);
  if (ring.length > 800) ring.splice(0, ring.length - 800);
  if (ORDER[level] < ORDER[minLevel]) return;
  const line = JSON.stringify(entry);
  fileStream()?.write(line + "\n");
  if (process.env.BLOXADE_QUIET !== "1") {
    const t = new Date(entry.ts).toLocaleTimeString();
    const tag = level === "error" ? "\x1B[31mERR\x1B[0m" : level === "warn" ? "\x1B[33mWRN\x1B[0m" : level === "debug" ? "\x1B[90mDBG\x1B[0m" : "\x1B[36mINF\x1B[0m";
    const extra = data === void 0 ? "" : " " + (typeof entry.data === "string" ? entry.data : JSON.stringify(entry.data)).slice(0, 400);
    console.log(`${t} ${tag} [${scope}] ${msg}${extra}`);
  }
}
function logger(scope) {
  return {
    debug: (msg, data) => write("debug", scope, msg, data),
    info: (msg, data) => write("info", scope, msg, data),
    warn: (msg, data) => write("warn", scope, msg, data),
    error: (msg, data) => write("error", scope, msg, data)
  };
}
function recentLogs(limit = 300, level) {
  const list = level ? ring.filter((e) => ORDER[e.level] >= ORDER[level]) : ring;
  return list.slice(-limit);
}

// src/server/core/db.ts
var log = logger("db");
var MIGRATIONS = [
  // 1 — initial schema
  `
  CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS accounts (
    id TEXT PRIMARY KEY, provider TEXT NOT NULL, name TEXT NOT NULL, profile_dir TEXT, is_system INTEGER NOT NULL DEFAULT 0,
    enabled INTEGER NOT NULL DEFAULT 1, is_default INTEGER NOT NULL DEFAULT 0, color TEXT NOT NULL DEFAULT '#6E7BFF',
    created_at INTEGER NOT NULL, last_used_at INTEGER, status TEXT NOT NULL DEFAULT 'unknown', status_detail TEXT,
    email TEXT, plan TEXT, auth_method TEXT, limits TEXT
  );
  CREATE TABLE IF NOT EXISTS projects (
    id TEXT PRIMARY KEY, name TEXT NOT NULL, icon TEXT NOT NULL, color TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
    folder_path TEXT, instructions TEXT NOT NULL DEFAULT '', memory TEXT NOT NULL DEFAULT '', memory_updated_at INTEGER,
    roblox_enabled INTEGER NOT NULL DEFAULT 0, defaults TEXT NOT NULL DEFAULT '{}', created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS chats (
    id TEXT PRIMARY KEY, title TEXT NOT NULL, project_id TEXT, pinned INTEGER NOT NULL DEFAULT 0, provider TEXT NOT NULL,
    account_id TEXT, model TEXT NOT NULL, effort TEXT NOT NULL, mode TEXT NOT NULL, created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL, preview TEXT, branched_from TEXT, provider_ref TEXT, context_sent TEXT
  );
  CREATE INDEX IF NOT EXISTS idx_chats_updated ON chats(updated_at DESC);
  CREATE INDEX IF NOT EXISTS idx_chats_project ON chats(project_id);
  CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY, chat_id TEXT NOT NULL, seq INTEGER NOT NULL, role TEXT NOT NULL, content TEXT NOT NULL,
    blocks TEXT NOT NULL DEFAULT '[]', status TEXT NOT NULL, attachments TEXT NOT NULL DEFAULT '[]', usage TEXT, error TEXT,
    provider TEXT, account_id TEXT, model TEXT, effort TEXT, mode TEXT, provider_ref TEXT, created_at INTEGER NOT NULL, duration_ms INTEGER
  );
  CREATE INDEX IF NOT EXISTS idx_messages_chat ON messages(chat_id, seq);
  CREATE TABLE IF NOT EXISTS attachments (
    id TEXT PRIMARY KEY, chat_id TEXT, name TEXT NOT NULL, mime TEXT NOT NULL, size INTEGER NOT NULL, kind TEXT NOT NULL,
    path TEXT NOT NULL, created_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS runs (
    id TEXT PRIMARY KEY, project_id TEXT, prompt TEXT NOT NULL, status TEXT NOT NULL, strategy TEXT NOT NULL,
    efficiency TEXT NOT NULL, coordinator TEXT NOT NULL, rationale TEXT, report TEXT, error TEXT, auto_approve TEXT NOT NULL,
    created_at INTEGER NOT NULL, started_at INTEGER, finished_at INTEGER
  );
  CREATE TABLE IF NOT EXISTS tasks (
    id TEXT PRIMARY KEY, run_id TEXT NOT NULL, key TEXT NOT NULL, title TEXT NOT NULL, description TEXT NOT NULL,
    status TEXT NOT NULL, agent_name TEXT NOT NULL, assignment TEXT NOT NULL, depends_on TEXT NOT NULL DEFAULT '[]',
    owned_paths TEXT NOT NULL DEFAULT '[]', files_touched TEXT NOT NULL DEFAULT '[]', tool_ops INTEGER NOT NULL DEFAULT 0,
    summary TEXT, error TEXT, attempts INTEGER NOT NULL DEFAULT 0, blocks TEXT NOT NULL DEFAULT '[]', usage TEXT,
    review TEXT, provider_ref TEXT, created_at INTEGER NOT NULL, started_at INTEGER, finished_at INTEGER
  );
  CREATE INDEX IF NOT EXISTS idx_tasks_run ON tasks(run_id);
  CREATE TABLE IF NOT EXISTS usage_events (
    id TEXT PRIMARY KEY, ts INTEGER NOT NULL, provider TEXT NOT NULL, account_id TEXT, model TEXT, kind TEXT NOT NULL,
    ref_id TEXT, input_tokens INTEGER NOT NULL DEFAULT 0, output_tokens INTEGER NOT NULL DEFAULT 0,
    cache_read INTEGER NOT NULL DEFAULT 0, cache_write INTEGER NOT NULL DEFAULT 0, reasoning INTEGER NOT NULL DEFAULT 0,
    cost_usd REAL, verified INTEGER NOT NULL DEFAULT 0, estimated_tokens INTEGER NOT NULL DEFAULT 0,
    context_saved INTEGER NOT NULL DEFAULT 0, duration_ms INTEGER, ok INTEGER NOT NULL DEFAULT 1
  );
  CREATE INDEX IF NOT EXISTS idx_usage_ts ON usage_events(ts);
  CREATE TABLE IF NOT EXISTS file_changes (
    id TEXT PRIMARY KEY, project_id TEXT NOT NULL, path TEXT NOT NULL, change TEXT NOT NULL, source TEXT NOT NULL,
    source_id TEXT, before_hash TEXT, after_hash TEXT, diff TEXT, created_at INTEGER NOT NULL, reverted INTEGER NOT NULL DEFAULT 0
  );
  CREATE INDEX IF NOT EXISTS idx_changes_project ON file_changes(project_id, created_at DESC);
  CREATE TABLE IF NOT EXISTS roblox_activity (
    id TEXT PRIMARY KEY, ts INTEGER NOT NULL, caller TEXT NOT NULL, tool TEXT NOT NULL, summary TEXT NOT NULL,
    status TEXT NOT NULL, duration_ms INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_roblox_ts ON roblox_activity(ts DESC);
  CREATE TABLE IF NOT EXISTS activity (
    id TEXT PRIMARY KEY, ts INTEGER NOT NULL, kind TEXT NOT NULL, label TEXT NOT NULL, detail TEXT NOT NULL DEFAULT '', ref_id TEXT
  );
  CREATE INDEX IF NOT EXISTS idx_activity_ts ON activity(ts DESC);
  CREATE TABLE IF NOT EXISTS kv_cache (key TEXT PRIMARY KEY, value TEXT NOT NULL, created_at INTEGER NOT NULL, expires_at INTEGER);
  `
];
var Db = class {
  raw;
  file;
  constructor(file = path3.join(dirs.db, "bloxade.sqlite")) {
    fs3.mkdirSync(path3.dirname(file), { recursive: true });
    this.file = file;
    this.raw = new DatabaseSync(file);
    this.raw.exec("PRAGMA journal_mode = WAL; PRAGMA synchronous = NORMAL; PRAGMA foreign_keys = OFF; PRAGMA busy_timeout = 4000;");
    this.migrate();
  }
  migrate() {
    this.raw.exec("CREATE TABLE IF NOT EXISTS _migrations (version INTEGER PRIMARY KEY, applied_at INTEGER NOT NULL)");
    const row = this.raw.prepare("SELECT MAX(version) AS v FROM _migrations").get();
    const current = row?.v ?? 0;
    for (let i = current; i < MIGRATIONS.length; i++) {
      this.raw.exec("BEGIN");
      try {
        this.raw.exec(MIGRATIONS[i]);
        this.raw.prepare("INSERT INTO _migrations (version, applied_at) VALUES (?, ?)").run(i + 1, Date.now());
        this.raw.exec("COMMIT");
        log.info(`applied migration ${i + 1}`);
      } catch (e) {
        this.raw.exec("ROLLBACK");
        throw e;
      }
    }
  }
  all(sql, ...params) {
    return this.raw.prepare(sql).all(...params);
  }
  get(sql, ...params) {
    return this.raw.prepare(sql).get(...params);
  }
  run(sql, ...params) {
    return this.raw.prepare(sql).run(...params);
  }
  tx(fn) {
    this.raw.exec("BEGIN");
    try {
      const r = fn();
      this.raw.exec("COMMIT");
      return r;
    } catch (e) {
      this.raw.exec("ROLLBACK");
      throw e;
    }
  }
  /** Insert or replace a row from a plain object (keys = columns). */
  upsert(table, row) {
    const keys = Object.keys(row);
    const sql = `INSERT OR REPLACE INTO ${table} (${keys.join(",")}) VALUES (${keys.map(() => "?").join(",")})`;
    this.raw.prepare(sql).run(...keys.map((k) => row[k]));
  }
  update(table, id, patch) {
    const keys = Object.keys(patch);
    if (!keys.length) return;
    const sql = `UPDATE ${table} SET ${keys.map((k) => `${k} = ?`).join(", ")} WHERE id = ?`;
    this.raw.prepare(sql).run(...keys.map((k) => patch[k]), id);
  }
  sizeBytes() {
    try {
      return fs3.statSync(this.file).size;
    } catch {
      return 0;
    }
  }
  close() {
    try {
      this.raw.close();
    } catch {
    }
  }
};
var instance = null;
function db() {
  if (!instance) instance = new Db();
  return instance;
}
var j = (v) => JSON.stringify(v ?? null);
var b = (v) => v ? 1 : 0;

// src/server/core/events.ts
import { EventEmitter } from "node:events";
var EventHub = class {
  clients = /* @__PURE__ */ new Set();
  seq = 0;
  local = new EventEmitter();
  heartbeat = null;
  constructor() {
    this.local.setMaxListeners(200);
  }
  attach(res) {
    res.writeHead(200, {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no"
    });
    res.write(`retry: 1500

`);
    this.clients.add(res);
    res.on("close", () => this.clients.delete(res));
    if (!this.heartbeat) {
      this.heartbeat = setInterval(() => {
        for (const c of this.clients) c.write(`: ping ${Date.now()}

`);
      }, 15e3);
      this.heartbeat.unref();
    }
  }
  emit(type, data) {
    const id = ++this.seq;
    const payload = `id: ${id}
event: message
data: ${JSON.stringify({ type, data })}

`;
    for (const c of this.clients) {
      try {
        c.write(payload);
      } catch {
        this.clients.delete(c);
      }
    }
    this.local.emit(type, data);
  }
  get clientCount() {
    return this.clients.size;
  }
  closeAll() {
    for (const c of this.clients) {
      try {
        c.end();
      } catch {
      }
    }
    this.clients.clear();
    if (this.heartbeat) clearInterval(this.heartbeat);
    this.heartbeat = null;
  }
};
var events = new EventHub();

// src/server/core/settings.ts
var DEFAULT_ROBLOX_COMMAND = process.platform === "win32" ? "cmd.exe /c %LOCALAPPDATA%\\Roblox\\mcp.bat" : process.platform === "darwin" ? "/Applications/RobloxStudio.app/Contents/MacOS/StudioMCP" : "";
var DEFAULT_SETTINGS = {
  general: {
    onboardingComplete: false,
    openBrowserOnStart: true,
    defaultProjectId: null,
    notifications: true,
    confirmDeletes: true,
    autoTitle: true
  },
  appearance: {
    theme: "dark",
    accent: "#7C7FFF",
    fontSize: 15,
    density: "comfortable",
    sidebarCollapsed: false,
    reduceMotion: false
  },
  providers: {
    claudePath: "",
    codexPath: "",
    defaultProvider: "claude",
    defaultModels: { claude: "default", codex: "" },
    defaultEfforts: { claude: "", codex: "" },
    defaultMode: "chat",
    showHiddenModels: false,
    customModels: { claude: [], codex: [] }
  },
  agents: {
    maxConcurrent: null,
    routing: "balanced",
    approvals: { edits: "allow", commands: "ask", unownedEdits: "ask" },
    requireReview: false,
    approvalTimeoutSec: 600,
    useGitWorktrees: false
  },
  context: {
    mode: "balanced",
    budgetOverride: null,
    cache: true,
    primeChats: true,
    toolOutputCap: null,
    autoMemory: false
  },
  roblox: {
    enabled: true,
    autoConnect: false,
    command: DEFAULT_ROBLOX_COMMAND,
    defaultStudioId: null,
    toolPolicies: {},
    cacheReads: true
  },
  privacy: { keepAttachments: true, logPrompts: false },
  advanced: { port: 3e3, logLevel: "info", turnTimeoutMin: 45 }
};
var cache = null;
function getSettings() {
  if (cache) return cache;
  const row = db().get("SELECT value FROM settings WHERE key = ?", "app");
  cache = deepMerge(DEFAULT_SETTINGS, safeJson(row?.value, {}));
  setLogLevel(cache.advanced.logLevel);
  return cache;
}
function updateSettings(patch) {
  const next = deepMerge(getSettings(), patch);
  next.appearance.fontSize = Math.min(20, Math.max(12, Number(next.appearance.fontSize) || 15));
  next.advanced.port = Math.min(65535, Math.max(1024, Number(next.advanced.port) || 3e3));
  next.advanced.turnTimeoutMin = Math.min(240, Math.max(2, Number(next.advanced.turnTimeoutMin) || 45));
  next.agents.approvalTimeoutSec = Math.min(3600, Math.max(30, Number(next.agents.approvalTimeoutSec) || 600));
  if (next.agents.maxConcurrent != null) next.agents.maxConcurrent = Math.min(8, Math.max(1, Number(next.agents.maxConcurrent)));
  if (!/^#[0-9a-fA-F]{6}$/.test(next.appearance.accent)) next.appearance.accent = DEFAULT_SETTINGS.appearance.accent;
  db().run("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", "app", JSON.stringify(next));
  cache = next;
  setLogLevel(next.advanced.logLevel);
  events.emit("settings.updated", next);
  return next;
}
function kvGet(key, fallback) {
  const row = db().get("SELECT value, expires_at FROM kv_cache WHERE key = ?", key);
  if (!row) return fallback;
  if (row.expires_at && row.expires_at < Date.now()) return fallback;
  return safeJson(row.value, fallback);
}
function kvSet(key, value, ttlMs) {
  db().run(
    "INSERT OR REPLACE INTO kv_cache (key, value, created_at, expires_at) VALUES (?, ?, ?, ?)",
    key,
    JSON.stringify(value),
    Date.now(),
    ttlMs ? Date.now() + ttlMs : null
  );
}
function kvDelete(prefix) {
  db().run("DELETE FROM kv_cache WHERE key LIKE ? || '%'", prefix);
}

// src/server/core/http.ts
import http from "node:http";
import fs4 from "node:fs";
import path4 from "node:path";
var log2 = logger("http");
var MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".gif": "image/gif",
  ".webp": "image/webp",
  ".ico": "image/x-icon",
  ".woff2": "font/woff2",
  ".woff": "font/woff",
  ".txt": "text/plain; charset=utf-8",
  ".map": "application/json"
};
function mimeFor(file) {
  return MIME[path4.extname(file).toLowerCase()] ?? "application/octet-stream";
}
var Router = class {
  routes = [];
  allowedHosts = /* @__PURE__ */ new Set();
  add(method, pattern, handler, opts = {}) {
    const keys = [];
    const re = new RegExp(
      "^" + pattern.replace(/\/:([a-zA-Z_]+)/g, (_m, k) => {
        keys.push(k);
        return "/([^/]+)";
      }) + "/?$"
    );
    this.routes.push({ method, re, keys, handler, raw: opts.raw });
  }
  get(p, h, o) {
    this.add("GET", p, h, o);
  }
  post(p, h, o) {
    this.add("POST", p, h, o);
  }
  patch(p, h) {
    this.add("PATCH", p, h);
  }
  put(p, h) {
    this.add("PUT", p, h);
  }
  delete(p, h) {
    this.add("DELETE", p, h);
  }
  /** Rejects requests that don't come from this app (DNS rebinding / cross-site requests). */
  checkOrigin(req, isMutation, pathname) {
    const host = (req.headers.host || "").toLowerCase();
    if (!this.allowedHosts.has(host)) return `Host '${host}' is not allowed`;
    const origin = req.headers.origin;
    if (origin) {
      try {
        const o = new URL(origin);
        if (!this.allowedHosts.has(o.host.toLowerCase())) return "Cross-origin request blocked";
      } catch {
        return "Invalid origin";
      }
    }
    if (isMutation && pathname.startsWith("/api/") && !pathname.startsWith("/api/bridge/")) {
      if (req.headers["x-bloxade"] !== "1") return "Missing X-Bloxade header";
    }
    return null;
  }
  async handle(req, res, publicDir) {
    const url = new URL(req.url || "/", "http://localhost");
    const method = req.method || "GET";
    const isMutation = !["GET", "HEAD", "OPTIONS"].includes(method);
    const blocked = this.checkOrigin(req, isMutation, url.pathname);
    if (blocked) {
      log2.warn("blocked request", { path: url.pathname, reason: blocked });
      return sendJson(res, 403, { error: blocked });
    }
    if (method === "OPTIONS") {
      res.writeHead(204);
      return res.end();
    }
    if (url.pathname.startsWith("/api/")) {
      for (const r of this.routes) {
        if (r.method !== method) continue;
        const m = r.re.exec(url.pathname);
        if (!m) continue;
        const params = {};
        r.keys.forEach((k, i) => params[k] = decodeURIComponent(m[i + 1]));
        try {
          const body = isMutation && !r.raw ? await readJson(req) : void 0;
          const out = await r.handler({ req, res, params, query: url.searchParams, body });
          if (r.raw || res.headersSent) return;
          return sendJson(res, 200, out === void 0 ? { ok: true } : out);
        } catch (e) {
          const err = e;
          const status = err instanceof HttpError ? err.status : 500;
          if (status >= 500) log2.error(`${method} ${url.pathname} failed`, e);
          if (!res.headersSent) sendJson(res, status, { error: err.message || "Internal error", code: err.code });
          return;
        }
      }
      return sendJson(res, 404, { error: "Not found" });
    }
    return serveStatic(res, publicDir, url.pathname);
  }
};
function sendJson(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff"
  });
  res.end(body);
}
var MAX_BODY = 40 * 1024 * 1024;
function readJson(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on("data", (c) => {
      size += c.length;
      if (size > MAX_BODY) {
        reject(new HttpError(413, "Request body too large"));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on("end", () => {
      if (!chunks.length) return resolve({});
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString("utf8")));
      } catch {
        reject(new HttpError(400, "Invalid JSON body"));
      }
    });
    req.on("error", reject);
  });
}
function serveStatic(res, publicDir, pathname) {
  const rel = decodeURIComponent(pathname).replace(/^\/+/, "");
  const target = path4.resolve(publicDir, rel || "index.html");
  const inside = target === publicDir || target.startsWith(publicDir + path4.sep);
  let file = inside && fs4.existsSync(target) && fs4.statSync(target).isFile() ? target : path4.join(publicDir, "index.html");
  if (!fs4.existsSync(file)) {
    res.writeHead(503, { "Content-Type": "text/plain; charset=utf-8" });
    return res.end("BLOXADE frontend build not found. Run `npm run build` in the BLOXADE folder.");
  }
  const isAsset = file.includes(`${path4.sep}assets${path4.sep}`);
  res.writeHead(200, {
    "Content-Type": mimeFor(file),
    "Cache-Control": isAsset ? "public, max-age=31536000, immutable" : "no-cache",
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "no-referrer"
  });
  fs4.createReadStream(file).pipe(res);
}
function createServer(router, publicDir) {
  return http.createServer((req, res) => {
    router.handle(req, res, publicDir).catch((e) => {
      log2.error("unhandled request error", e);
      if (!res.headersSent) sendJson(res, 500, { error: "Internal error" });
    });
  });
}

// src/server/core/proc.ts
import { spawn, spawnSync } from "node:child_process";
var log3 = logger("proc");
var registry = /* @__PURE__ */ new Map();
function spawnTracked(command, args, opts) {
  const { kind, label, ...spawnOpts } = opts;
  const child = spawn(command, args, {
    windowsHide: true,
    ...spawnOpts,
    shell: false
  });
  const tp = { id: newId("p"), pid: child.pid, kind, label, startedAt: Date.now(), child };
  registry.set(tp.id, tp);
  const cleanup = () => registry.delete(tp.id);
  child.once("exit", cleanup);
  child.once("error", (e) => {
    log3.warn(`process error (${label})`, e.message);
    cleanup();
  });
  log3.debug(`spawned ${kind}`, { label, pid: child.pid });
  return tp;
}
function killTree(child, force = true) {
  if (child.exitCode !== null || child.killed) return;
  const pid = child.pid;
  if (!pid) return;
  try {
    if (IS_WIN) {
      spawnSync("taskkill", ["/pid", String(pid), "/T", ...force ? ["/F"] : []], { windowsHide: true, timeout: 8e3 });
    } else {
      try {
        process.kill(-pid, force ? "SIGKILL" : "SIGTERM");
      } catch {
        child.kill(force ? "SIGKILL" : "SIGTERM");
      }
    }
  } catch (e) {
    log3.warn("killTree failed", e.message);
    try {
      child.kill("SIGKILL");
    } catch {
    }
  }
}
function listProcesses() {
  return [...registry.values()].map((p) => ({ id: p.id, pid: p.pid, kind: p.kind, label: p.label, startedAt: p.startedAt }));
}
function killAll() {
  for (const p of registry.values()) killTree(p.child, true);
  registry.clear();
}
function onLines(stream2, cb) {
  if (!stream2) return;
  let buf = "";
  stream2.setEncoding?.("utf8");
  stream2.on("data", (chunk) => {
    buf += chunk.toString();
    let idx;
    while ((idx = buf.indexOf("\n")) >= 0) {
      const line = buf.slice(0, idx).replace(/\r$/, "");
      buf = buf.slice(idx + 1);
      if (line.trim()) cb(line);
    }
    if (buf.length > 64 * 1024 * 1024) buf = "";
  });
  stream2.on("end", () => {
    if (buf.trim()) cb(buf);
    buf = "";
  });
}
function runCapture(command, args, opts = {}) {
  return new Promise((resolve) => {
    let child;
    try {
      child = spawn(command, args, { env: opts.env, cwd: opts.cwd, windowsHide: true, shell: false });
    } catch (e) {
      resolve({ code: null, stdout: "", stderr: "", error: e.message });
      return;
    }
    let stdout = "";
    let stderr = "";
    const timer = setTimeout(() => {
      killTree(child);
      resolve({ code: null, stdout, stderr, error: "timed out" });
    }, opts.timeoutMs ?? 2e4);
    child.stdout?.on("data", (d) => stdout += d.toString());
    child.stderr?.on("data", (d) => stderr += d.toString());
    child.on("error", (e) => {
      clearTimeout(timer);
      resolve({ code: null, stdout, stderr, error: e.message });
    });
    child.on("close", (code) => {
      clearTimeout(timer);
      resolve({ code, stdout, stderr });
    });
    if (opts.input != null) child.stdin?.end(opts.input);
    else child.stdin?.end();
  });
}
function openUrl(url) {
  if (!/^https?:\/\//i.test(url)) throw new Error("Only http(s) URLs can be opened");
  try {
    if (IS_WIN) spawn("rundll32", ["url.dll,FileProtocolHandler", url], { detached: true, stdio: "ignore", windowsHide: true }).unref();
    else if (process.platform === "darwin") spawn("open", [url], { detached: true, stdio: "ignore" }).unref();
    else spawn("xdg-open", [url], { detached: true, stdio: "ignore" }).unref();
  } catch (e) {
    log3.warn("could not open browser", e.message);
  }
}
function openFolder(dir) {
  try {
    if (IS_WIN) spawn("explorer.exe", [dir], { detached: true, stdio: "ignore" }).unref();
    else if (process.platform === "darwin") spawn("open", [dir], { detached: true, stdio: "ignore" }).unref();
    else spawn("xdg-open", [dir], { detached: true, stdio: "ignore" }).unref();
  } catch (e) {
    log3.warn("could not open folder", e.message);
  }
}

// src/server/core/runtime.ts
import fs5 from "node:fs";
import path5 from "node:path";
var VERSION = "1.0.0";
var runtime = {
  port: 3e3,
  startedAt: Date.now(),
  get baseUrl() {
    return `http://127.0.0.1:${this.port}`;
  }
};
function writeBridgeMcpConfig(token) {
  const file = path5.join(dirs.runtime, `mcp-${token.slice(0, 12)}.json`);
  const cfg = {
    mcpServers: {
      bloxade_roblox: {
        type: "stdio",
        command: process.execPath,
        args: [BRIDGE_SCRIPT],
        env: { BLOXADE_URL: runtime.baseUrl, BLOXADE_BRIDGE_TOKEN: token }
      }
    }
  };
  fs5.mkdirSync(dirs.runtime, { recursive: true });
  fs5.writeFileSync(file, JSON.stringify(cfg, null, 2));
  return file;
}
function bridgeServerSpec(token) {
  return {
    command: process.execPath,
    args: [BRIDGE_SCRIPT],
    env: { BLOXADE_URL: runtime.baseUrl, BLOXADE_BRIDGE_TOKEN: token }
  };
}
function removeQuiet(file) {
  if (!file) return;
  try {
    fs5.rmSync(file, { force: true });
  } catch {
  }
}

// src/server/api.ts
import fs16 from "node:fs";
import path14 from "node:path";
import os4 from "node:os";

// src/server/providers/resolve.ts
import fs6 from "node:fs";
import path6 from "node:path";
import os2 from "node:os";
var log4 = logger("cli");
var BIN = { claude: "claude", codex: "codex" };
function pathDirs() {
  return (process.env.PATH || process.env.Path || "").split(path6.delimiter).filter(Boolean);
}
function isFile(p) {
  try {
    return fs6.statSync(p).isFile();
  } catch {
    return false;
  }
}
function knownLocations(provider) {
  const home = os2.homedir();
  const local = process.env.LOCALAPPDATA || path6.join(home, "AppData", "Local");
  const roaming = process.env.APPDATA || path6.join(home, "AppData", "Roaming");
  if (IS_WIN) {
    if (provider === "claude") {
      return [
        path6.join(home, ".local", "bin", "claude.exe"),
        path6.join(roaming, "npm", "claude.cmd"),
        path6.join(local, "Programs", "claude", "claude.exe"),
        path6.join(local, "AnthropicClaude", "claude.exe")
      ];
    }
    const list = [
      path6.join(local, "Programs", "OpenAI", "Codex", "codex.exe"),
      path6.join(local, "Programs", "OpenAI", "Codex", "bin", "codex.exe"),
      path6.join(home, ".local", "bin", "codex.exe"),
      path6.join(roaming, "npm", "codex.cmd"),
      path6.join(home, ".codex", "bin", "codex.exe")
    ];
    for (const extRoot of [path6.join(home, ".vscode", "extensions"), path6.join(home, ".cursor", "extensions")]) {
      try {
        const exts = fs6.readdirSync(extRoot).filter((n) => n.startsWith("openai.chatgpt-")).sort().reverse();
        for (const e of exts) list.push(path6.join(extRoot, e, "bin", "windows-x86_64", "codex.exe"));
      } catch {
      }
    }
    return list;
  }
  return [path6.join(home, ".local", "bin", BIN[provider]), path6.join(home, ".npm-global", "bin", BIN[provider]), `/usr/local/bin/${BIN[provider]}`, `/opt/homebrew/bin/${BIN[provider]}`];
}
function fromCmdShim(cmdPath, provider) {
  try {
    const text = fs6.readFileSync(cmdPath, "utf8");
    const m = text.match(/"%(?:~dp0|dp0%)\\?([^"]+?\.(?:js|cjs|mjs|exe))"/i) || text.match(/%~dp0\\([^\s"]+?\.(?:js|cjs|mjs|exe))/i);
    if (!m) return null;
    const target = path6.resolve(path6.dirname(cmdPath), m[1]);
    if (!isFile(target)) return null;
    if (/\.exe$/i.test(target)) return { provider, command: target, prefixArgs: [], display: target };
    return { provider, command: process.execPath, prefixArgs: [target], display: `node ${target}` };
  } catch {
    return null;
  }
}
function asResolved(file, provider) {
  if (!isFile(file)) return null;
  const ext = path6.extname(file).toLowerCase();
  if (IS_WIN && (ext === ".cmd" || ext === ".bat")) return fromCmdShim(file, provider);
  if ([".js", ".mjs", ".cjs"].includes(ext)) return { provider, command: process.execPath, prefixArgs: [file], display: `node ${file}` };
  return { provider, command: file, prefixArgs: [], display: file };
}
function findCli(provider) {
  const s = getSettings();
  const override = (provider === "claude" ? s.providers.claudePath : s.providers.codexPath) || process.env[`BLOXADE_${provider.toUpperCase()}_PATH`] || "";
  if (override.trim()) {
    const r = asResolved(expandUserPath(override), provider);
    if (r) return r;
    log4.warn(`configured ${provider} path not usable`, override);
  }
  const exts = IS_WIN ? [".exe", ".cmd", ".bat", ""] : [""];
  for (const dir of pathDirs()) {
    for (const ext of exts) {
      const r = asResolved(path6.join(dir, BIN[provider] + ext), provider);
      if (r) return r;
    }
  }
  for (const loc of knownLocations(provider)) {
    const r = asResolved(loc, provider);
    if (r) return r;
  }
  return null;
}
var cache2 = /* @__PURE__ */ new Map();
async function detectCli(provider, force = false) {
  const cached = cache2.get(provider);
  if (cached && !force && Date.now() - cached.checkedAt < 5 * 6e4) return cached;
  const r = findCli(provider);
  let info;
  if (!r) {
    info = { provider, found: false, checkedAt: Date.now(), error: `${provider === "claude" ? "Claude Code" : "Codex"} CLI not found on this computer` };
  } else {
    const out = await runCapture(r.command, [...r.prefixArgs, "--version"], { timeoutMs: 2e4 });
    const version = (out.stdout || out.stderr).trim().split("\n")[0]?.trim() || null;
    info = {
      provider,
      found: out.code === 0,
      path: r.display,
      launch: r.command,
      version,
      error: out.code === 0 ? null : out.error || out.stderr.trim().slice(0, 300) || "CLI did not start",
      checkedAt: Date.now()
    };
  }
  cache2.set(provider, info);
  return info;
}
function cachedCli(provider) {
  return cache2.get(provider) ?? { provider, found: false, checkedAt: 0, error: "Not checked yet" };
}
function requireCli(provider) {
  const r = findCli(provider);
  if (!r) {
    throw new Error(
      provider === "claude" ? "Claude Code is not installed (or not on PATH). Install it from https://claude.com/claude-code, then press Refresh in Settings \u2192 AI Providers." : "Codex CLI is not installed (or not on PATH). Install it from https://developers.openai.com/codex, then press Refresh in Settings \u2192 AI Providers."
    );
  }
  return r;
}

// src/server/providers/claude.ts
import fs8 from "node:fs";

// src/server/providers/env.ts
import fs7 from "node:fs";
function providerEnv(account, extra = {}) {
  const env = { ...process.env };
  for (const k of ["CLAUDECODE", "CLAUDE_CODE_SESSION_ID", "CLAUDE_CODE_SSE_PORT", "CLAUDE_CODE_CHILD_SESSION"]) delete env[k];
  if (process.env.BLOXADE_KEEP_ENV !== "1") delete env.CLAUDE_CODE_ENTRYPOINT;
  if (account?.profileDir) {
    fs7.mkdirSync(account.profileDir, { recursive: true });
    if (account.provider === "claude") env.CLAUDE_CONFIG_DIR = account.profileDir;
    else env.CODEX_HOME = account.profileDir;
  }
  env.BLOXADE = "1";
  return { ...env, ...extra };
}

// src/server/providers/claude.ts
var log5 = logger("claude");
var EDIT_TOOLS = /* @__PURE__ */ new Set(["Write", "Edit", "MultiEdit", "NotebookEdit"]);
var COMMAND_TOOLS = /* @__PURE__ */ new Set(["Bash", "PowerShell", "BashOutput", "KillShell", "KillBash"]);
function classifyClaudeTool(toolName, input, description) {
  if (EDIT_TOOLS.has(toolName)) {
    const p = input?.file_path || input?.notebook_path || input?.path;
    return { kind: "file_edit", toolName, input, paths: p ? [String(p)] : [], description: description || `${toolName} ${p ?? ""}` };
  }
  if (COMMAND_TOOLS.has(toolName)) {
    return { kind: "command", toolName, input, paths: [], command: String(input?.command ?? ""), description: description || String(input?.command ?? toolName) };
  }
  return { kind: "tool", toolName, input, paths: [], description: description || toolName };
}
function stringifyToolResult(content) {
  if (typeof content === "string") return content;
  if (Array.isArray(content)) {
    return content.map((c) => c?.type === "text" ? c.text : c?.type === "image" ? "[image]" : JSON.stringify(c)).join("\n");
  }
  return content == null ? "" : JSON.stringify(content);
}
function toLimits(info) {
  if (!info) return null;
  const windows = [];
  const uw = info.unifiedWindows || {};
  const labels = { five_hour: "5-hour window", seven_day: "Weekly", seven_day_opus: "Weekly (Opus)", seven_day_sonnet: "Weekly (Sonnet)" };
  for (const [k, v] of Object.entries(uw)) {
    if (typeof v?.utilization !== "number") continue;
    windows.push({ id: k, label: labels[k] ?? k.replace(/_/g, " "), usedPercent: Math.round(v.utilization * 1e3) / 10, resetsAt: v.resetsAt ?? null, status: v.status ?? null });
  }
  if (!windows.length && info.rateLimitType) {
    windows.push({ id: info.rateLimitType, label: labels[info.rateLimitType] ?? info.rateLimitType, usedPercent: typeof info.utilization === "number" ? info.utilization * 100 : NaN, resetsAt: info.resetsAt ?? null, status: info.status ?? null });
  }
  const statusText = { allowed_warning: "Approaching the usage limit", rejected: "Usage limit reached" };
  return { source: "claude-code", updatedAt: Date.now(), windows, note: info.status && info.status !== "allowed" ? statusText[info.status] ?? `Status: ${info.status}` : void 0 };
}
function usageFromResult(d) {
  const u = d?.usage ?? {};
  return {
    inputTokens: u.input_tokens ?? 0,
    outputTokens: u.output_tokens ?? 0,
    cacheReadTokens: u.cache_read_input_tokens ?? 0,
    cacheWriteTokens: u.cache_creation_input_tokens ?? 0,
    reasoningTokens: u.output_tokens_details?.thinking_tokens ?? void 0,
    costUsd: typeof d?.total_cost_usd === "number" ? d.total_cost_usd : null,
    verified: true
  };
}
function friendlyError(raw) {
  const t = raw.toLowerCase();
  if (t.includes("please run /login") || t.includes("invalid api key") || t.includes("not logged in") || t.includes("oauth token has expired") || t.includes("authentication_error"))
    return 'This Claude account is not signed in (or its sign-in expired). Open Accounts and press "Sign in".';
  if (t.includes("rate_limit") || t.includes("usage limit") || t.includes("limit reached")) return "Claude usage limit reached for this account. " + truncate(raw, 300);
  return truncate(raw, 1200);
}
async function runClaudeTurn(req) {
  const cli = requireCli("claude");
  const started = Date.now();
  const args = [...cli.prefixArgs, "-p", "--input-format", "stream-json", "--output-format", "stream-json", "--verbose", "--include-partial-messages", "--permission-prompt-tool", "stdio"];
  if (req.model && req.model !== "default") args.push("--model", req.model);
  if (req.effort) args.push("--effort", req.effort);
  let sessionId = null;
  if (req.forkFrom) {
    if (req.forkFrom.sessionId) {
      args.push("--resume", req.forkFrom.sessionId, "--fork-session");
      if (req.forkFrom.lastAssistantUuid) args.push("--resume-session-at", req.forkFrom.lastAssistantUuid);
    } else {
      sessionId = uuid();
      args.push("--session-id", sessionId);
    }
  } else if (req.resume?.sessionId) {
    sessionId = req.resume.sessionId;
    args.push("--resume", sessionId);
  } else {
    sessionId = uuid();
    args.push("--session-id", sessionId);
  }
  let mcpFile = null;
  if (req.mode === "chat") {
    args.push("--tools", "", "--strict-mcp-config", "--permission-mode", "default");
  } else {
    const pm = req.permissionMode === "full" ? "bypassPermissions" : req.permissionMode === "acceptEdits" ? "acceptEdits" : "default";
    args.push("--permission-mode", pm);
    if (req.bridgeToken) {
      mcpFile = writeBridgeMcpConfig(req.bridgeToken);
      args.push("--mcp-config", mcpFile, "--allowedTools", "mcp__bloxade_roblox");
    }
    for (const d of req.addDirs ?? []) args.push("--add-dir", d);
  }
  if (req.systemAppend?.trim()) args.push("--append-system-prompt", req.systemAppend.slice(0, 24e3));
  const proc = spawnTracked(cli.command, args, {
    cwd: req.cwd,
    env: providerEnv(req.account),
    stdio: ["pipe", "pipe", "pipe"],
    kind: "claude",
    label: req.label
  });
  const child = proc.child;
  const content = [{ type: "text", text: req.prompt }];
  for (const img of req.images ?? []) {
    try {
      const data = fs8.readFileSync(img.path).toString("base64");
      content.push({ type: "image", source: { type: "base64", media_type: img.mime, data } });
    } catch (e) {
      log5.warn("could not attach image", e.message);
    }
  }
  const send = (obj) => {
    if (child.stdin && !child.stdin.destroyed && child.stdin.writable) child.stdin.write(JSON.stringify(obj) + "\n");
  };
  return await new Promise((resolve) => {
    let finalText = "";
    const streamedForMessage = /* @__PURE__ */ new Set();
    let currentMsgId = null;
    let textSinceMessageStart = false;
    let anyText = false;
    let lastAssistantUuid = req.resume?.lastAssistantUuid ?? null;
    let model = null;
    let usage = null;
    let resultSeen = false;
    let resultError = null;
    let cancelled = false;
    const stderrTail = [];
    const openTools = /* @__PURE__ */ new Set();
    const toolMeta = /* @__PURE__ */ new Map();
    let settled = false;
    const finish = (r) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      req.signal.removeEventListener("abort", onAbort);
      removeQuiet(mcpFile);
      for (const id of openTools) req.onEvent({ type: "tool_end", id, output: cancelled ? "Cancelled" : "", isError: cancelled });
      resolve({
        ok: false,
        cancelled,
        text: finalText,
        ref: { sessionId, lastAssistantUuid },
        usage,
        durationMs: Date.now() - started,
        model,
        ...r
      });
    };
    const onAbort = () => {
      cancelled = true;
      send({ type: "control_request", request_id: uuid(), request: { subtype: "interrupt" } });
      setTimeout(() => {
        if (!settled) killTree(child);
      }, 4e3);
    };
    req.signal.addEventListener("abort", onAbort);
    const timer = setTimeout(() => {
      req.onEvent({ type: "notice", level: "error", text: `Turn exceeded the ${Math.round(req.timeoutMs / 6e4)} minute limit and was stopped.` });
      resultError = "Timed out";
      killTree(child);
    }, req.timeoutMs);
    onLines(child.stderr, (line) => {
      stderrTail.push(line);
      if (stderrTail.length > 40) stderrTail.shift();
    });
    onLines(child.stdout, (line) => {
      const d = safeJson(line, null);
      if (!d || typeof d !== "object") return;
      try {
        handle(d);
      } catch (e) {
        log5.warn("event handling failed", e.message);
      }
    });
    const handle = (d) => {
      const topLevel = d.parent_tool_use_id == null;
      switch (d.type) {
        case "system":
          if (d.subtype === "init") {
            if (d.session_id) sessionId = d.session_id;
            model = d.model ?? model;
            req.onEvent({ type: "session", ref: { sessionId, lastAssistantUuid }, model });
          } else if (d.subtype === "compact_boundary") {
            req.onEvent({ type: "notice", level: "info", text: "Claude Code compacted the conversation context." });
          }
          return;
        case "stream_event": {
          if (!topLevel) return;
          const ev = d.event;
          if (ev?.type === "message_start") {
            currentMsgId = ev.message?.id ?? null;
            textSinceMessageStart = false;
          } else if (ev?.type === "content_block_delta") {
            if (ev.delta?.type === "text_delta" && ev.delta.text) {
              if (currentMsgId) streamedForMessage.add(currentMsgId);
              req.onEvent({ type: "text", text: ev.delta.text, newBlock: anyText && !textSinceMessageStart });
              textSinceMessageStart = true;
              anyText = true;
              finalText += ev.delta.text;
            } else if (ev.delta?.type === "thinking_delta" && ev.delta.thinking) {
              req.onEvent({ type: "thinking", text: ev.delta.thinking });
            }
          }
          return;
        }
        case "assistant": {
          if (!topLevel) return;
          if (d.uuid) lastAssistantUuid = d.uuid;
          const msg = d.message ?? {};
          model = msg.model ?? model;
          for (const block of msg.content ?? []) {
            if (block.type === "text" && block.text && !streamedForMessage.has(msg.id)) {
              req.onEvent({ type: "text", text: block.text, newBlock: anyText });
              anyText = true;
              finalText += block.text;
            } else if (block.type === "tool_use") {
              openTools.add(block.id);
              toolMeta.set(block.id, { name: block.name, input: block.input });
              const server2 = String(block.name).startsWith("mcp__") ? String(block.name).split("__")[1] : void 0;
              req.onEvent({ type: "tool_start", id: block.id, name: block.name, input: block.input, server: server2 });
            }
          }
          return;
        }
        case "user": {
          if (!topLevel) return;
          for (const block of d.message?.content ?? []) {
            if (block?.type === "tool_result") {
              openTools.delete(block.tool_use_id);
              const output = stringifyToolResult(block.content);
              req.onEvent({ type: "tool_end", id: block.tool_use_id, output, isError: !!block.is_error });
              const meta = toolMeta.get(block.tool_use_id);
              if (meta && !block.is_error && EDIT_TOOLS.has(meta.name)) {
                const p = meta.input?.file_path || meta.input?.notebook_path;
                if (p) req.onEvent({ type: "file_change", paths: [String(p)] });
              }
            }
          }
          return;
        }
        case "rate_limit_event": {
          const lim = toLimits(d.rate_limit_info);
          if (lim) req.onEvent({ type: "limits", limits: lim });
          return;
        }
        case "control_request": {
          const r = d.request ?? {};
          if (r.subtype === "can_use_tool") {
            const pr = classifyClaudeTool(r.tool_name, r.input, r.description);
            req.onPermission(pr).then((dec) => {
              send({
                type: "control_response",
                response: {
                  subtype: "success",
                  request_id: d.request_id,
                  response: dec.allow ? { behavior: "allow", updatedInput: r.input ?? {} } : { behavior: "deny", message: dec.message || "Denied in BLOXADE" }
                }
              });
              if (!dec.allow && r.tool_use_id) req.onEvent({ type: "tool_end", id: r.tool_use_id, output: dec.message || "Denied", isError: true, denied: true });
            }).catch((e) => {
              send({ type: "control_response", response: { subtype: "success", request_id: d.request_id, response: { behavior: "deny", message: String(e?.message ?? e) } } });
            });
          } else {
            send({ type: "control_response", response: { subtype: "error", request_id: d.request_id, error: `BLOXADE does not handle '${r.subtype}' requests` } });
          }
          return;
        }
        case "result": {
          resultSeen = true;
          usage = usageFromResult(d);
          req.onEvent({ type: "usage", usage });
          if (d.is_error || d.subtype && d.subtype !== "success") {
            const raw = typeof d.result === "string" && d.result ? d.result : Array.isArray(d.errors) ? d.errors.join("\n") : d.subtype;
            if (!cancelled) resultError = friendlyError(String(raw));
          }
          if (!finalText && typeof d.result === "string" && !d.is_error) {
            finalText = d.result;
            req.onEvent({ type: "text", text: d.result });
          }
          if (d.session_id) sessionId = d.session_id;
          try {
            child.stdin?.end();
          } catch {
          }
          return;
        }
        default:
          return;
      }
    };
    try {
      send({ type: "user", message: { role: "user", content }, parent_tool_use_id: null, session_id: "" });
    } catch (e) {
      finish({ ok: false, error: `Could not start Claude Code: ${e.message}` });
      return;
    }
    child.on("error", (e) => finish({ ok: false, error: `Could not start Claude Code: ${e.message}` }));
    child.on("exit", (code) => {
      setTimeout(() => {
        if (cancelled) return finish({ ok: false, cancelled: true, error: "Stopped" });
        if (resultError) return finish({ ok: false, error: resultError });
        if (!resultSeen) {
          const tail = stderrTail.join("\n").trim();
          return finish({ ok: false, error: friendlyError(tail || `Claude Code exited (code ${code}) before finishing the turn.`) });
        }
        finish({ ok: true });
      }, 50);
    });
  });
}
async function discoverClaude(account) {
  const cli = requireCli("claude");
  const args = [...cli.prefixArgs, "-p", "--input-format", "stream-json", "--output-format", "stream-json", "--verbose", "--tools", "", "--strict-mcp-config", "--no-session-persistence"];
  const proc = spawnTracked(cli.command, args, { env: providerEnv(account), stdio: ["pipe", "pipe", "pipe"], kind: "claude-discovery", label: "model discovery", cwd: process.cwd() });
  const child = proc.child;
  return await new Promise((resolve, reject) => {
    const reqId = "bx_init_" + Date.now();
    const timer = setTimeout(() => {
      killTree(child);
      reject(new Error("Claude Code did not answer the initialize request in time"));
    }, 3e4);
    let stderr = "";
    child.stderr?.on("data", (d) => stderr += d.toString());
    child.on("error", (e) => {
      clearTimeout(timer);
      reject(e);
    });
    child.on("exit", (code) => {
      clearTimeout(timer);
      reject(new Error(`Claude Code exited (${code}) during discovery. ${stderr.trim().slice(0, 300)}`));
    });
    onLines(child.stdout, (line) => {
      const d = safeJson(line, null);
      if (d?.type !== "control_response") return;
      const r = d.response ?? {};
      if (r.request_id && r.request_id !== reqId) return;
      clearTimeout(timer);
      const resp = r.response ?? {};
      const models = (resp.models ?? []).map((m) => ({
        id: String(m.value),
        label: String(m.displayName ?? m.value),
        description: m.description ?? "",
        resolvedModel: m.resolvedModel ?? null,
        efforts: Array.isArray(m.supportedEffortLevels) ? m.supportedEffortLevels : m.supportsEffort ? ["low", "medium", "high"] : [],
        defaultEffort: null,
        group: "recommended",
        isDefault: m.value === "default",
        source: "discovered"
      }));
      const a = resp.account ?? null;
      killTree(child);
      child.removeAllListeners("exit");
      resolve({
        models,
        account: a ? { email: a.email ?? a.emailAddress ?? null, plan: a.subscriptionType ?? null, apiProvider: a.apiProvider ?? null, organization: a.organization ?? a.organizationName ?? null } : null,
        version: resp.claude_code_version ?? null
      });
    });
    child.stdin?.write(JSON.stringify({ type: "control_request", request_id: reqId, request: { subtype: "initialize" } }) + "\n");
  });
}
async function claudeAuthStatus(account) {
  const cli = requireCli("claude");
  const out = await runCapture(cli.command, [...cli.prefixArgs, "auth", "status", "--json"], { env: providerEnv(account), timeoutMs: 25e3 });
  const data = safeJson(out.stdout.trim(), null);
  if (!data) return { loggedIn: false, error: out.error || out.stderr.trim().slice(0, 300) || "Could not read auth status" };
  return {
    loggedIn: !!data.loggedIn,
    authMethod: data.authMethod,
    email: data.email ?? data.emailAddress ?? data.account?.email ?? null,
    raw: { authMethod: data.authMethod, apiProvider: data.apiProvider, subscriptionType: data.subscriptionType ?? null, orgName: data.orgName ?? data.organizationName ?? null }
  };
}
async function claudeLogout(account) {
  const cli = requireCli("claude");
  return runCapture(cli.command, [...cli.prefixArgs, "auth", "logout"], { env: providerEnv(account), timeoutMs: 2e4 });
}

// src/server/providers/codex.ts
var log6 = logger("codex");
var CodexAppServer = class {
  constructor(account) {
    this.account = account;
  }
  account;
  proc = null;
  nextId = 1;
  pending = /* @__PURE__ */ new Map();
  threadListeners = /* @__PURE__ */ new Map();
  threadRequestHandlers = /* @__PURE__ */ new Map();
  globalListeners = /* @__PURE__ */ new Set();
  starting = null;
  idleTimer = null;
  loadedThreads = /* @__PURE__ */ new Set();
  threadTotals = /* @__PURE__ */ new Map();
  activeTurns = 0;
  stderrTail = [];
  lastLimits = null;
  get running() {
    return !!this.proc && this.proc.child.exitCode === null;
  }
  async ensure() {
    if (this.running && !this.starting) return;
    if (this.starting) return this.starting;
    this.starting = this.start().finally(() => this.starting = null);
    return this.starting;
  }
  async start() {
    const cli = requireCli("codex");
    const proc = spawnTracked(cli.command, [...cli.prefixArgs, "app-server"], {
      env: providerEnv(this.account),
      stdio: ["pipe", "pipe", "pipe"],
      kind: "codex-app-server",
      label: `Codex app-server (${this.account.name})`
    });
    this.proc = proc;
    this.loadedThreads.clear();
    onLines(proc.child.stdout, (line) => this.onLine(line));
    onLines(proc.child.stderr, (line) => {
      this.stderrTail.push(line);
      if (this.stderrTail.length > 50) this.stderrTail.shift();
    });
    proc.child.on("exit", (code) => {
      log6.info(`app-server exited (${this.account.name})`, { code });
      for (const [, p] of this.pending) {
        clearTimeout(p.timer);
        p.reject(new Error(`Codex app-server stopped (code ${code}). ${this.stderrTail.slice(-3).join(" ")}`));
      }
      this.pending.clear();
      for (const [threadId, l] of this.threadListeners) l("bloxade/serverExited", { threadId, code });
      this.proc = null;
    });
    proc.child.on("error", (e) => log6.warn("app-server spawn error", e.message));
    await this.rawRequest("initialize", { clientInfo: { name: "bloxade", title: "BLOXADE", version: VERSION }, capabilities: null }, 3e4);
    this.write({ method: "initialized" });
    this.touch();
  }
  write(obj) {
    const stdin = this.proc?.child.stdin;
    if (!stdin || stdin.destroyed) throw new Error("Codex app-server is not running");
    stdin.write(JSON.stringify(obj) + "\n");
  }
  rawRequest(method, params, timeoutMs = 6e4) {
    const id = this.nextId++;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`Codex did not answer '${method}' within ${Math.round(timeoutMs / 1e3)}s`));
      }, timeoutMs);
      this.pending.set(id, { resolve, reject, timer, method });
      try {
        this.write({ id, method, params });
      } catch (e) {
        clearTimeout(timer);
        this.pending.delete(id);
        reject(e);
      }
    });
  }
  async request(method, params, timeoutMs = 6e4) {
    await this.ensure();
    this.touch();
    return this.rawRequest(method, params, timeoutMs);
  }
  onLine(line) {
    const msg = safeJson(line, null);
    if (!msg || typeof msg !== "object") return;
    if (msg.id !== void 0 && (msg.result !== void 0 || msg.error !== void 0) && !msg.method) {
      const p = this.pending.get(msg.id);
      if (!p) return;
      clearTimeout(p.timer);
      this.pending.delete(msg.id);
      if (msg.error) p.reject(new Error(msg.error.message || JSON.stringify(msg.error)));
      else p.resolve(msg.result);
      return;
    }
    if (msg.method && msg.id !== void 0) {
      void this.onServerRequest(msg.id, msg.method, msg.params ?? {});
      return;
    }
    if (msg.method) {
      const params = msg.params ?? {};
      if (msg.method === "account/rateLimits/updated" && params.rateLimits) {
        this.lastLimits = mergeLimits(this.lastLimits, codexLimits(params.rateLimits));
      }
      const tid = params.threadId ?? params.thread?.id;
      if (tid && this.threadListeners.has(tid)) this.threadListeners.get(tid)(msg.method, params);
      for (const g of this.globalListeners) g(msg.method, params);
    }
  }
  async onServerRequest(id, method, params) {
    const tid = params.threadId;
    const handler = tid ? this.threadRequestHandlers.get(tid) : void 0;
    try {
      if (!handler) throw new Error(`No active BLOXADE turn for ${method}`);
      const result = await handler(method, params);
      this.write({ id, result });
    } catch (e) {
      try {
        this.write({ id, error: { code: -32e3, message: e.message } });
      } catch {
      }
    }
  }
  onThread(threadId, listener, handler) {
    this.threadListeners.set(threadId, listener);
    this.threadRequestHandlers.set(threadId, handler);
    return () => {
      this.threadListeners.delete(threadId);
      this.threadRequestHandlers.delete(threadId);
    };
  }
  onGlobal(listener) {
    this.globalListeners.add(listener);
    return () => this.globalListeners.delete(listener);
  }
  touch() {
    if (this.idleTimer) clearTimeout(this.idleTimer);
    this.idleTimer = setTimeout(() => {
      if (this.activeTurns === 0 && this.globalListeners.size === 0) this.stop();
      else this.touch();
    }, 10 * 6e4);
    this.idleTimer.unref();
  }
  stop() {
    if (this.proc) killTree(this.proc.child);
    this.proc = null;
  }
};
var servers = /* @__PURE__ */ new Map();
function codexServer(account) {
  let s = servers.get(account.id);
  if (!s) {
    s = new CodexAppServer(account);
    servers.set(account.id, s);
  } else {
    s.account = account;
  }
  return s;
}
function stopCodexServer(accountId) {
  servers.get(accountId)?.stop();
  servers.delete(accountId);
}
function stopAllCodex() {
  for (const s of servers.values()) s.stop();
  servers.clear();
}
function codexLimits(rl) {
  const windows = [];
  const label = (mins, fallback) => {
    if (!mins) return fallback;
    if (mins === 300) return "5-hour window";
    if (mins === 10080) return "Weekly";
    if (mins % 1440 === 0) return `${mins / 1440}-day window`;
    if (mins % 60 === 0) return `${mins / 60}-hour window`;
    return `${mins}-minute window`;
  };
  if (rl?.primary) windows.push({ id: "primary", label: label(rl.primary.windowDurationMins, "Primary"), usedPercent: rl.primary.usedPercent, resetsAt: rl.primary.resetsAt, windowMins: rl.primary.windowDurationMins });
  if (rl?.secondary) windows.push({ id: "secondary", label: label(rl.secondary.windowDurationMins, "Secondary"), usedPercent: rl.secondary.usedPercent, resetsAt: rl.secondary.resetsAt, windowMins: rl.secondary.windowDurationMins });
  const credits = rl?.credits;
  return {
    source: "codex",
    updatedAt: Date.now(),
    windows,
    note: credits && typeof credits === "object" && "balance" in credits ? `Credits: ${credits.balance}` : rl?.planType ? `Plan: ${rl.planType}` : void 0
  };
}
function mergeLimits(prev, next) {
  if (!prev) return next;
  const byId = new Map(prev.windows.map((w) => [w.id, w]));
  for (const w of next.windows) byId.set(w.id, w);
  return { ...prev, ...next, windows: [...byId.values()], note: next.note ?? prev.note };
}
function itemOutputText(item) {
  if (item?.type === "commandExecution") return item.aggregatedOutput ?? "";
  if (item?.type === "fileChange") return (item.changes ?? []).map((c) => `${c.kind?.type ?? "update"} ${c.path}
${c.diff ?? ""}`).join("\n");
  if (item?.type === "mcpToolCall") {
    if (item.error) return item.error.message ?? "MCP tool failed";
    return (item.result?.content ?? []).map((c) => c?.type === "text" ? c.text : c?.type === "image" ? "[image]" : JSON.stringify(c)).join("\n");
  }
  if (item?.type === "dynamicToolCall") return (item.contentItems ?? []).map((c) => c.text ?? JSON.stringify(c)).join("\n");
  if (item?.type === "webSearch") return item.query ? `Searched: ${item.query}` : "Web search finished";
  return "";
}
function itemTool(item) {
  switch (item?.type) {
    case "commandExecution":
      return { name: "Shell", input: { command: item.command, cwd: item.cwd }, title: truncate(String(item.command ?? ""), 120) };
    case "fileChange":
      return { name: "Edit files", input: { files: (item.changes ?? []).map((c) => c.path) }, title: (item.changes ?? []).map((c) => c.path).join(", ") };
    case "mcpToolCall":
      return { name: `${item.server}.${item.tool}`, input: item.arguments, server: item.server };
    case "webSearch":
      return { name: "Web search", input: { query: item.query }, title: item.query };
    case "dynamicToolCall":
      return { name: item.tool, input: item.arguments };
    case "collabAgentToolCall":
      return { name: "Sub-agent", input: { prompt: item.prompt }, title: truncate(String(item.prompt ?? ""), 100) };
    case "imageView":
      return { name: "View image", input: { path: item.path } };
    case "imageGeneration":
      return { name: "Generate image", input: {} };
    default:
      return null;
  }
}
function friendlyCodexError(msg) {
  const t = msg.toLowerCase();
  if (t.includes("401") || t.includes("unauthorized") || t.includes("not logged in") || t.includes("login") && t.includes("required") || t.includes("requiresopenaiauth"))
    return 'This Codex account is not signed in. Open Accounts and press "Sign in with ChatGPT".';
  if (t.includes("usage limit") || t.includes("rate limit")) return "Codex usage limit reached for this account. " + truncate(msg, 300);
  return truncate(msg, 1200);
}
async function runCodexTurn(req) {
  const server2 = codexServer(req.account);
  const started = Date.now();
  await server2.ensure();
  const sandbox = req.mode === "chat" ? "read-only" : req.permissionMode === "full" ? "danger-full-access" : "workspace-write";
  const approvalPolicy = req.mode === "chat" ? "never" : req.permissionMode === "full" ? "never" : "on-request";
  const config = {};
  if (req.bridgeToken && req.mode === "cowork") {
    const spec = bridgeServerSpec(req.bridgeToken);
    config["mcp_servers.bloxade_roblox.command"] = spec.command;
    config["mcp_servers.bloxade_roblox.args"] = spec.args;
    config["mcp_servers.bloxade_roblox.env"] = spec.env;
  }
  const threadParams = {
    model: req.model || null,
    cwd: req.cwd,
    approvalPolicy,
    sandbox,
    developerInstructions: req.systemAppend?.trim() ? req.systemAppend.slice(0, 24e3) : null,
    config: Object.keys(config).length ? config : null
  };
  let threadId = null;
  try {
    if (req.forkFrom) {
      if (req.forkFrom.threadId) {
        const r = await server2.request("thread/fork", { threadId: req.forkFrom.threadId, lastTurnId: req.forkFrom.turnId ?? null, ...threadParams, excludeTurns: true });
        threadId = r.thread.id;
      } else {
        const r = await server2.request("thread/start", threadParams);
        threadId = r.thread.id;
      }
    } else if (req.resume?.threadId) {
      threadId = req.resume.threadId;
      if (!server2.loadedThreads.has(threadId)) {
        try {
          await server2.request("thread/resume", { threadId, ...threadParams, excludeTurns: true });
        } catch (e) {
          req.onEvent({ type: "notice", level: "warning", text: `Could not resume the previous Codex thread (${e.message}). Started a new thread.` });
          const r = await server2.request("thread/start", threadParams);
          threadId = r.thread.id;
        }
      }
    } else {
      const r = await server2.request("thread/start", threadParams);
      threadId = r.thread.id;
    }
  } catch (e) {
    return { ok: false, cancelled: false, text: "", ref: { threadId: req.resume?.threadId ?? null }, usage: null, error: friendlyCodexError(e.message), durationMs: Date.now() - started };
  }
  const tid = threadId;
  server2.loadedThreads.add(tid);
  req.onEvent({ type: "session", ref: { threadId: tid }, model: req.model || null });
  return await new Promise((resolve) => {
    let turnId = null;
    let finalText = "";
    let lastTextItem = null;
    const deltaItems = /* @__PURE__ */ new Set();
    const fileChangeItems = /* @__PURE__ */ new Map();
    const openTools = /* @__PURE__ */ new Set();
    let usage = null;
    let errorMsg = null;
    let cancelled = false;
    let settled = false;
    const baseline = server2.threadTotals.get(tid) ?? null;
    const finish = (r) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      req.signal.removeEventListener("abort", onAbort);
      server2.activeTurns = Math.max(0, server2.activeTurns - 1);
      unsubscribe();
      for (const id of openTools) req.onEvent({ type: "tool_end", id, output: cancelled ? "Cancelled" : "", isError: cancelled });
      if (server2.lastLimits) req.onEvent({ type: "limits", limits: server2.lastLimits });
      resolve({ ok: false, cancelled, text: finalText, ref: { threadId: tid, turnId }, usage, durationMs: Date.now() - started, model: req.model, ...r });
    };
    const interrupt = () => {
      if (turnId) server2.request("turn/interrupt", { threadId: tid, turnId }, 15e3).catch(() => void 0);
    };
    const onAbort = () => {
      cancelled = true;
      interrupt();
      setTimeout(() => finish({ ok: false, cancelled: true, error: "Stopped" }), 8e3);
    };
    req.signal.addEventListener("abort", onAbort);
    const timer = setTimeout(() => {
      errorMsg = "Timed out";
      req.onEvent({ type: "notice", level: "error", text: `Turn exceeded the ${Math.round(req.timeoutMs / 6e4)} minute limit and was stopped.` });
      interrupt();
      setTimeout(() => finish({ ok: false, error: "Timed out" }), 8e3);
    }, req.timeoutMs);
    const listener = (method, p) => {
      if (p.turnId && turnId && p.turnId !== turnId && method !== "thread/tokenUsage/updated") return;
      switch (method) {
        case "turn/started":
          if (!turnId && p.turn?.id) turnId = p.turn.id;
          return;
        case "item/agentMessage/delta": {
          if (!p.delta) return;
          deltaItems.add(p.itemId);
          const newBlock = finalText.length > 0 && lastTextItem !== p.itemId;
          lastTextItem = p.itemId;
          finalText += (newBlock ? "\n\n" : "") + p.delta;
          req.onEvent({ type: "text", text: p.delta, newBlock });
          return;
        }
        case "item/reasoning/summaryTextDelta":
        case "item/reasoning/textDelta":
          if (p.delta) req.onEvent({ type: "thinking", text: p.delta });
          return;
        case "item/started": {
          const item = p.item;
          if (item?.type === "fileChange") fileChangeItems.set(item.id, (item.changes ?? []).map((c) => c.path));
          const t = itemTool(item);
          if (t) {
            openTools.add(item.id);
            req.onEvent({ type: "tool_start", id: item.id, name: t.name, input: t.input, server: t.server, title: t.title });
          }
          return;
        }
        case "item/completed": {
          const item = p.item;
          if (item?.type === "agentMessage") {
            if (!deltaItems.has(item.id) && item.text) {
              const newBlock = finalText.length > 0;
              finalText += (newBlock ? "\n\n" : "") + item.text;
              req.onEvent({ type: "text", text: item.text, newBlock });
            }
            return;
          }
          if (item?.type === "fileChange" && item.status !== "failed" && item.status !== "declined") {
            req.onEvent({ type: "file_change", paths: (item.changes ?? []).map((c) => c.path) });
          }
          if (openTools.has(item?.id)) {
            openTools.delete(item.id);
            const isError = item.status === "failed" || item.status === "declined" || item.type === "commandExecution" && item.exitCode != null && item.exitCode !== 0 || !!item.error;
            req.onEvent({ type: "tool_end", id: item.id, output: itemOutputText(item), isError, denied: item.status === "declined" });
          }
          return;
        }
        case "thread/tokenUsage/updated": {
          const t = p.tokenUsage?.total;
          const l = p.tokenUsage?.last;
          if (!t) return;
          const base = baseline ?? (l ? { input: t.inputTokens - l.inputTokens, cached: t.cachedInputTokens - l.cachedInputTokens, output: t.outputTokens - l.outputTokens, reasoning: t.reasoningOutputTokens - l.reasoningOutputTokens } : { input: 0, cached: 0, output: 0, reasoning: 0 });
          server2.threadTotals.set(tid, { input: t.inputTokens, cached: t.cachedInputTokens, output: t.outputTokens, reasoning: t.reasoningOutputTokens });
          usage = {
            inputTokens: Math.max(0, t.inputTokens - base.input),
            cacheReadTokens: Math.max(0, t.cachedInputTokens - base.cached),
            outputTokens: Math.max(0, t.outputTokens - base.output),
            reasoningTokens: Math.max(0, t.reasoningOutputTokens - base.reasoning),
            costUsd: null,
            verified: true
          };
          req.onEvent({ type: "usage", usage });
          return;
        }
        case "error":
          if (p.willRetry) req.onEvent({ type: "notice", level: "warning", text: `Codex: ${p.error?.message ?? "temporary error"} \u2014 retrying\u2026` });
          else errorMsg = friendlyCodexError(p.error?.message ?? "Codex reported an error");
          return;
        case "turn/completed": {
          const turn = p.turn ?? {};
          if (turnId && turn.id && turn.id !== turnId) return;
          if (turn.status === "completed") return finish({ ok: true });
          if (turn.status === "interrupted") return finish({ ok: false, cancelled: true, error: cancelled ? "Stopped" : errorMsg ?? "Interrupted" });
          return finish({ ok: false, error: friendlyCodexError(turn.error?.message ?? errorMsg ?? "Codex turn failed") });
        }
        case "bloxade/serverExited":
          return finish({ ok: false, error: `Codex app-server stopped unexpectedly. ${server2.stderrTail.slice(-3).join(" ")}` });
        default:
          return;
      }
    };
    const handler = async (method, p) => {
      if (method === "item/commandExecution/requestApproval") {
        const cmd = String(p.command ?? "");
        const dec = await req.onPermission({ kind: "command", toolName: "Shell", input: { command: cmd, cwd: p.cwd, reason: p.reason }, paths: [], command: cmd, description: p.reason ? `${cmd}

Reason: ${p.reason}` : cmd });
        return { decision: dec.allow ? "accept" : "decline" };
      }
      if (method === "item/fileChange/requestApproval") {
        const paths = fileChangeItems.get(p.itemId) ?? (p.grantRoot ? [p.grantRoot] : []);
        const dec = await req.onPermission({ kind: "file_edit", toolName: "Edit files", input: { paths, reason: p.reason }, paths, description: p.reason || `Edit ${paths.join(", ")}` });
        return { decision: dec.allow ? "accept" : "decline" };
      }
      if (method === "mcpServer/elicitation/request") {
        if (p.serverName === "bloxade_roblox") return { action: "accept", content: {}, _meta: null };
        return { action: "decline", content: null, _meta: null };
      }
      throw new Error(`BLOXADE does not support '${method}' yet`);
    };
    const unsubscribe = server2.onThread(tid, listener, handler);
    server2.activeTurns++;
    const input = [{ type: "text", text: req.prompt, text_elements: [] }];
    for (const img of req.images ?? []) input.push({ type: "localImage", path: img.path });
    server2.request("turn/start", { threadId: tid, input, model: req.model || null, effort: req.effort || null, cwd: req.cwd, approvalPolicy }, 6e4).then((r) => {
      if (r?.turn?.id) turnId = r.turn.id;
      if (cancelled) interrupt();
    }).catch((e) => finish({ ok: false, error: friendlyCodexError(e.message) }));
  });
}
async function codexAccountRead(account) {
  const s = codexServer(account);
  const r = await s.request("account/read", { refreshToken: false }, 3e4);
  return r;
}
async function codexRateLimits(account) {
  const s = codexServer(account);
  try {
    const r = await s.request("account/rateLimits/read", {}, 3e4);
    const lim = codexLimits(r.rateLimits);
    s.lastLimits = lim;
    return lim;
  } catch (e) {
    log6.debug("rate limits unavailable", e.message);
    return s.lastLimits;
  }
}
async function codexModels(account) {
  const s = codexServer(account);
  const out = [];
  let cursor = null;
  for (let page = 0; page < 10; page++) {
    const r = await s.request("model/list", { includeHidden: true, cursor, limit: 100 }, 45e3);
    for (const m of r.data ?? []) {
      out.push({
        id: m.model || m.id,
        label: m.displayName || m.model || m.id,
        description: m.description ?? "",
        efforts: (m.supportedReasoningEfforts ?? []).map((e) => e.reasoningEffort),
        defaultEffort: m.defaultReasoningEffort ?? null,
        group: m.hidden ? "hidden" : "recommended",
        isDefault: !!m.isDefault,
        source: "discovered"
      });
    }
    cursor = r.nextCursor ?? null;
    if (!cursor) break;
  }
  return out;
}
async function codexLoginStart(account, kind) {
  const s = codexServer(account);
  const r = await s.request("account/login/start", kind === "device" ? { type: "chatgptDeviceCode" } : { type: "chatgpt" }, 3e4);
  return r;
}
async function codexLoginCancel(account, loginId) {
  return codexServer(account).request("account/login/cancel", { loginId }, 15e3).catch(() => void 0);
}
async function codexLogout(account) {
  return codexServer(account).request("account/logout", {}, 2e4);
}

// src/server/providers/models.ts
var log7 = logger("models");
var CLAUDE_EFFORTS = ["low", "medium", "high", "xhigh", "max"];
var CLAUDE_VERSIONS = [
  ["claude-fable-5-1", "Claude Fable 5.1"],
  ["claude-fable-5", "Claude Fable 5"],
  ["claude-mythos-5-1", "Claude Mythos 5.1", "Availability depends on your plan"],
  ["claude-mythos-5", "Claude Mythos 5", "Availability depends on your plan"],
  ["claude-opus-5-5", "Claude Opus 5.5"],
  ["claude-opus-5", "Claude Opus 5"],
  ["claude-opus-4-8", "Claude Opus 4.8"],
  ["claude-opus-4-7", "Claude Opus 4.7"],
  ["claude-opus-4-6", "Claude Opus 4.6"],
  ["claude-opus-4-5-20251101", "Claude Opus 4.5"],
  ["claude-sonnet-5-5", "Claude Sonnet 5.5"],
  ["claude-sonnet-5", "Claude Sonnet 5"],
  ["claude-sonnet-4-6", "Claude Sonnet 4.6"],
  ["claude-sonnet-4-5-20250929", "Claude Sonnet 4.5", "Deprecated \u2014 retires Nov 30, 2026"],
  ["claude-haiku-5-5", "Claude Haiku 5.5"],
  ["claude-haiku-4-5-20251001", "Claude Haiku 4.5"]
];
var CLAUDE_FALLBACK_ALIASES = [
  { id: "default", label: "Default (recommended)", description: "Claude Code picks the recommended model for your plan", efforts: CLAUDE_EFFORTS, group: "recommended", isDefault: true, source: "catalog" },
  { id: "opus", label: "Opus", description: "Latest Opus", efforts: CLAUDE_EFFORTS, group: "recommended", source: "catalog" },
  { id: "sonnet", label: "Sonnet", description: "Latest Sonnet", efforts: CLAUDE_EFFORTS, group: "recommended", source: "catalog" },
  { id: "haiku", label: "Haiku", description: "Latest Haiku", efforts: CLAUDE_EFFORTS, group: "recommended", source: "catalog" },
  { id: "fable", label: "Fable", description: "Latest Fable", efforts: CLAUDE_EFFORTS, group: "recommended", source: "catalog" }
];
var CODEX_FALLBACK = [
  ["gpt-6.1-sol", "GPT-6.1-Sol"],
  ["gpt-6.1-terra", "GPT-6.1 Terra"],
  ["gpt-6-astra", "GPT-6-Astra"],
  ["gpt-6-sol", "GPT-6-Sol"],
  ["gpt-6-luna", "GPT-6-Luna"],
  ["gpt-5.6-sol", "GPT-5.6-Sol"],
  ["gpt-5.6-terra", "GPT-5.6-Terra"],
  ["gpt-5.6-luna", "GPT-5.6-Luna"],
  ["gpt-5.5", "GPT-5.5"]
].map(([id, label], i) => ({ id, label, efforts: ["low", "medium", "high", "xhigh"], group: "recommended", isDefault: i === 0, source: "catalog", note: "Not yet verified with your Codex CLI" }));
function claudeCatalog(discovered) {
  const base = discovered && discovered.length ? discovered : CLAUDE_FALLBACK_ALIASES;
  const effortsFor = (id) => base.find((m) => m.resolvedModel === id)?.efforts ?? CLAUDE_EFFORTS;
  const versions = CLAUDE_VERSIONS.map(([id, label, note]) => ({
    id,
    label,
    description: base.find((m) => m.resolvedModel === id) ? `Current target of \u201C${base.find((m) => m.resolvedModel === id).label}\u201D` : "Pinned version",
    efforts: effortsFor(id),
    group: "versions",
    source: "catalog",
    note
  }));
  return [...base, ...versions];
}
function withCustom(provider, list) {
  const custom = getSettings().providers.customModels[provider] ?? [];
  const ids = new Set(list.map((m) => m.id));
  const extra = custom.filter((id) => !ids.has(id)).map((id) => ({ id, label: id, description: "Custom model ID", efforts: provider === "claude" ? CLAUDE_EFFORTS : ["low", "medium", "high"], group: "versions", source: "catalog", note: "Added by you" }));
  return [...list, ...extra];
}
function cachedCatalog(provider) {
  const c = kvGet(`models:${provider}`, null);
  if (c) return { ...c, models: withCustom(provider, c.models) };
  const models = provider === "claude" ? claudeCatalog(null) : CODEX_FALLBACK;
  return { provider, models: withCustom(provider, models), discoveredAt: null, source: "catalog" };
}
var inflight = /* @__PURE__ */ new Map();
function refreshCatalog(provider, account) {
  const existing = inflight.get(provider);
  if (existing) return existing;
  const p = Promise.resolve().then(async () => {
    try {
      let models;
      if (provider === "claude") {
        const d = await discoverClaude(account);
        models = claudeCatalog(d.models);
      } else {
        if (!account) throw new Error("Add a Codex account first");
        models = await codexModels(account);
        if (!models.length) throw new Error("Codex returned no models");
      }
      const cat = { provider, models, discoveredAt: Date.now(), source: "discovered" };
      kvSet(`models:${provider}`, cat);
      return { ...cat, models: withCustom(provider, cat.models) };
    } catch (e) {
      log7.warn(`model discovery failed for ${provider}`, e.message);
      const prev = cachedCatalog(provider);
      return { ...prev, error: e.message };
    } finally {
      inflight.delete(provider);
    }
  });
  inflight.set(provider, p);
  return p;
}

// src/server/services/accounts.ts
import fs9 from "node:fs";
import path7 from "node:path";
import { spawn as spawn2 } from "node:child_process";

// src/server/services/activity.ts
function activity(kind, label, detail = "", refId = null) {
  const e = { id: newId("ev"), ts: now(), kind, label, detail: detail.slice(0, 500), refId };
  try {
    db().run("INSERT INTO activity (id, ts, kind, label, detail, ref_id) VALUES (?, ?, ?, ?, ?, ?)", e.id, e.ts, e.kind, e.label, e.detail, e.refId);
  } catch {
  }
  events.emit("activity", e);
  return e;
}
function listActivity(limit = 200, before) {
  const rows = before ? db().all("SELECT * FROM activity WHERE ts < ? ORDER BY ts DESC LIMIT ?", before, limit) : db().all("SELECT * FROM activity ORDER BY ts DESC LIMIT ?", limit);
  return rows.map((r) => ({ id: r.id, ts: r.ts, kind: r.kind, label: r.label, detail: r.detail, refId: r.ref_id }));
}

// src/server/services/accounts.ts
var log8 = logger("accounts");
var COLORS = ["#E58A5B", "#7C7FFF", "#3FB98A", "#E0B341", "#D9608C", "#4FA8E8", "#A678E8", "#8DB34A"];
var loginState = /* @__PURE__ */ new Map();
var sessionCounters = [];
function registerSessionCounter(fn) {
  sessionCounters.push(fn);
}
function activeSessions(id) {
  let n = 0;
  for (const f of sessionCounters) n += f().get(id) ?? 0;
  return n;
}
function toAccount(r) {
  return {
    id: r.id,
    provider: r.provider,
    name: r.name,
    profileDir: r.profile_dir,
    isSystem: !!r.is_system,
    enabled: !!r.enabled,
    isDefault: !!r.is_default,
    color: r.color,
    createdAt: r.created_at,
    lastUsedAt: r.last_used_at,
    status: loginState.get(r.id) ? "signing_in" : r.status,
    statusDetail: r.status_detail,
    email: r.email,
    plan: r.plan,
    authMethod: r.auth_method,
    limits: safeJson(r.limits, null),
    activeSessions: activeSessions(r.id),
    login: loginState.get(r.id) ?? null
  };
}
function listAccounts() {
  return db().all("SELECT * FROM accounts ORDER BY provider, created_at").map(toAccount);
}
function getAccount(id) {
  if (!id) return null;
  const r = db().get("SELECT * FROM accounts WHERE id = ?", id);
  return r ? toAccount(r) : null;
}
function mustAccount(id) {
  const a = getAccount(id);
  if (!a) throw new HttpError(404, "Account not found");
  return a;
}
function resolveAccount(provider, id) {
  const a = id ? getAccount(id) : null;
  if (a && a.provider === provider) return a;
  const all = listAccounts().filter((x) => x.provider === provider && x.enabled);
  return all.find((x) => x.isDefault) ?? all.find((x) => x.status === "signed_in") ?? all[0] ?? null;
}
function emit(id) {
  const a = getAccount(id);
  if (a) events.emit("account.updated", a);
}
function createAccount(body) {
  const provider = oneOf(body?.provider, ["claude", "codex"], "provider");
  const useSystem = !!body?.useSystem;
  const existing = listAccounts().filter((a) => a.provider === provider);
  if (useSystem && existing.some((a) => a.isSystem)) throw new HttpError(409, "The system sign-in is already added as an account");
  const id = newId("acc");
  const name = str(body?.name || (useSystem ? `${provider === "claude" ? "Claude" : "Codex"} (this PC)` : `${provider === "claude" ? "Claude" : "Codex"} Account ${existing.length + 1}`), "name", { max: 60, min: 1 }).trim();
  const dir = useSystem ? null : profileDir(provider, id);
  if (dir) fs9.mkdirSync(dir, { recursive: true });
  db().upsert("accounts", {
    id,
    provider,
    name,
    profile_dir: dir,
    is_system: b(useSystem),
    enabled: 1,
    is_default: b(existing.length === 0),
    color: COLORS[(existing.length + (provider === "codex" ? 3 : 0)) % COLORS.length],
    created_at: now(),
    last_used_at: null,
    status: "unknown",
    status_detail: null,
    email: null,
    plan: null,
    auth_method: null,
    limits: null
  });
  activity("account", `Added ${provider === "claude" ? "Claude" : "Codex"} account \u201C${name}\u201D`, useSystem ? "Uses this computer\u2019s existing sign-in" : "Isolated profile");
  emit(id);
  void refreshStatus(id);
  return getAccount(id);
}
function updateAccount(id, body) {
  const a = mustAccount(id);
  const patch = {};
  if (body.name !== void 0) patch.name = str(body.name, "name", { max: 60, min: 1 }).trim();
  if (body.enabled !== void 0) patch.enabled = b(!!body.enabled);
  if (body.color !== void 0 && /^#[0-9a-fA-F]{6}$/.test(body.color)) patch.color = body.color;
  db().update("accounts", a.id, patch);
  if (body.isDefault) setDefault(id);
  emit(id);
  return getAccount(id);
}
function setDefault(id) {
  const a = mustAccount(id);
  db().tx(() => {
    db().run("UPDATE accounts SET is_default = 0 WHERE provider = ?", a.provider);
    db().run("UPDATE accounts SET is_default = 1 WHERE id = ?", id);
  });
  for (const x of listAccounts()) events.emit("account.updated", x);
}
function deleteAccount(id, removeProfile) {
  const a = mustAccount(id);
  if (a.activeSessions) throw new HttpError(409, "This account has running sessions. Stop them first.");
  if (a.provider === "codex") stopCodexServer(a.id);
  db().run("DELETE FROM accounts WHERE id = ?", id);
  if (removeProfile && a.profileDir && a.profileDir.startsWith(dirs.profiles)) {
    try {
      fs9.rmSync(a.profileDir, { recursive: true, force: true });
    } catch (e) {
      log8.warn("could not remove profile folder", e.message);
    }
  }
  if (a.isDefault) {
    const next = listAccounts().find((x) => x.provider === a.provider);
    if (next) setDefault(next.id);
  }
  activity("account", `Removed account \u201C${a.name}\u201D`, removeProfile ? "Profile folder deleted" : "Profile folder kept");
  events.emit("account.deleted", { id });
}
function touchAccount(id) {
  db().run("UPDATE accounts SET last_used_at = ? WHERE id = ?", now(), id);
}
function recordLimits(id, limits) {
  const a = getAccount(id);
  if (!a) return;
  const prev = a.limits;
  const merged = prev && prev.source === limits.source ? { ...limits, windows: mergeWindows(prev.windows, limits.windows) } : limits;
  db().update("accounts", id, { limits: j(merged) });
  emit(id);
}
function mergeWindows(a, bList) {
  const m = new Map(a.map((w) => [w.id, w]));
  for (const w of bList) m.set(w.id, w);
  return [...m.values()];
}
function setStatus(id, status, patch = {}) {
  db().update("accounts", id, { status, ...patch });
  emit(id);
}
var refreshing = /* @__PURE__ */ new Map();
function refreshStatus(id) {
  const inflight2 = refreshing.get(id);
  if (inflight2) return inflight2;
  const p = doRefresh(id).finally(() => refreshing.delete(id));
  refreshing.set(id, p);
  return p;
}
async function doRefresh(id) {
  const a = mustAccount(id);
  if (!findCli(a.provider)) {
    setStatus(id, "cli_missing", { status_detail: `${a.provider === "claude" ? "Claude Code" : "Codex"} CLI not found` });
    return getAccount(id);
  }
  db().update("accounts", id, { status: "checking" });
  emit(id);
  try {
    if (a.provider === "claude") {
      const s = await claudeAuthStatus(a);
      if (s.error && !s.loggedIn) {
        setStatus(id, "error", { status_detail: s.error });
      } else {
        setStatus(id, s.loggedIn ? "signed_in" : "signed_out", {
          status_detail: s.loggedIn ? null : "Not signed in",
          auth_method: s.authMethod ?? null,
          email: s.email ?? a.email ?? null,
          plan: s.raw?.subscriptionType ?? a.plan ?? null
        });
      }
    } else {
      const r = await codexAccountRead(a);
      const acct = r.account;
      if (acct) {
        setStatus(id, "signed_in", { status_detail: null, auth_method: acct.type, email: acct.email ?? null, plan: acct.planType ?? null });
        const lim = await codexRateLimits(a);
        if (lim) recordLimits(id, lim);
      } else {
        setStatus(id, "signed_out", { status_detail: r.requiresOpenaiAuth ? "Sign in with ChatGPT to use this account" : "Not signed in", email: null, plan: null });
      }
    }
  } catch (e) {
    setStatus(id, "error", { status_detail: e.message.slice(0, 400) });
  }
  return getAccount(id);
}
function writeTerminalScript(a, title, commandLine, footer) {
  const file = path7.join(dirs.runtime, `terminal-${a.id}.cmd`);
  const envLine = a.profileDir ? a.provider === "claude" ? `set "CLAUDE_CONFIG_DIR=${a.profileDir}"` : `set "CODEX_HOME=${a.profileDir}"` : "rem using this computer's default sign-in location";
  const body = [
    "@echo off",
    `title ${title.replace(/[&|<>^%]/g, "")}`,
    envLine,
    "echo.",
    `echo   BLOXADE  -  ${title.replace(/[&|<>^%]/g, "")}`,
    "echo   This window runs the official CLI. BLOXADE never sees your password or tokens.",
    "echo.",
    commandLine,
    "echo.",
    `echo   ${footer}`,
    "echo."
  ].join("\r\n");
  fs9.mkdirSync(dirs.runtime, { recursive: true });
  fs9.writeFileSync(file, body + "\r\n");
  return file;
}
function quoteCmd(s) {
  return `"${s.replace(/"/g, "")}"`;
}
function openConsole(a, title, cliArgs, footer, keepOpen) {
  const cli = findCli(a.provider);
  if (!cli) throw new HttpError(400, `${a.provider === "claude" ? "Claude Code" : "Codex"} CLI not found`);
  if (!IS_WIN) {
    const envStr = a.profileDir ? `${a.provider === "claude" ? "CLAUDE_CONFIG_DIR" : "CODEX_HOME"}="${a.profileDir}" ` : "";
    return { manual: `${envStr}${[cli.command, ...cli.prefixArgs, ...cliArgs ?? []].map((x) => /\s/.test(x) ? `"${x}"` : x).join(" ")}` };
  }
  const exe = [cli.command, ...cli.prefixArgs].map(quoteCmd).join(" ");
  const line = cliArgs ? exe + (cliArgs.length ? " " + cliArgs.join(" ") : "") : `doskey ${a.provider}=${exe} $*\r
echo   Type ${a.provider} to start the CLI with this account's profile.`;
  const script = writeTerminalScript(a, title, line, footer);
  spawn2(`start "BLOXADE" cmd.exe ${keepOpen ? "/k" : "/c"} ${quoteCmd(script)}${keepOpen ? "" : " ^& pause"}`, {
    shell: true,
    detached: true,
    stdio: "ignore",
    windowsHide: false,
    env: providerEnv(a)
  }).unref();
  return { manual: null };
}
var loginTimers = {};
var loginIds = {};
async function startLogin(id, method = "browser") {
  const a = mustAccount(id);
  if (a.provider === "claude") {
    const r2 = openConsole(a, `Sign in to Claude - ${a.name}`, ["auth", "login"], "When it says you are signed in, close this window and return to BLOXADE.", true);
    loginState.set(id, { kind: "terminal", startedAt: now() });
    emit(id);
    pollClaudeLogin(id);
    activity("account", `Sign-in started for \u201C${a.name}\u201D`, "Claude Code sign-in window opened");
    return { kind: "terminal", manualCommand: r2.manual };
  }
  for (const [otherId, st] of loginState) {
    if (otherId !== id && st && getAccount(otherId)?.provider === "codex") throw new HttpError(409, "Another Codex sign-in is in progress. Finish or cancel it first.");
  }
  const r = await codexLoginStart(a, method);
  const url = r.authUrl ?? r.verificationUrl;
  loginState.set(id, { kind: method === "device" ? "device" : "browser", url, code: r.userCode, startedAt: now() });
  emit(id);
  const server2 = codexServer(a);
  const off = server2.onGlobal((m, p) => {
    if (m === "account/login/completed" && (!p.loginId || p.loginId === r.loginId)) {
      off();
      loginState.delete(id);
      if (!p.success) {
        clearTimeout(loginTimers[id]);
        setStatus(id, "error", { status_detail: p.error || "Sign-in was not completed" });
      } else {
        clearTimeout(loginTimers[id]);
        activity("account", `Signed in \u201C${a.name}\u201D`, "ChatGPT sign-in completed");
        void refreshStatus(id);
      }
      emit(id);
    }
  });
  clearTimeout(loginTimers[id]);
  loginTimers[id] = setTimeout(() => {
    off();
    if (loginState.has(id)) {
      loginState.delete(id);
      void codexLoginCancel(a, r.loginId);
      setStatus(id, "signed_out", { status_detail: "Sign-in timed out" });
    }
  }, 10 * 6e4);
  loginIds[id] = r.loginId;
  if (url && method === "browser") openUrl(url);
  return { kind: method, url, code: r.userCode ?? null };
}
function pollClaudeLogin(id) {
  const started = now();
  const tick = async () => {
    if (!loginState.has(id)) return;
    const a = getAccount(id);
    if (!a) return;
    try {
      const s = await claudeAuthStatus(a);
      if (s.loggedIn) {
        loginState.delete(id);
        activity("account", `Signed in \u201C${a.name}\u201D`, "Claude Code sign-in completed");
        await refreshStatus(id);
        return;
      }
    } catch {
    }
    if (now() - started > 8 * 6e4) {
      loginState.delete(id);
      emit(id);
      return;
    }
    setTimeout(tick, 3e3);
  };
  setTimeout(tick, 4e3);
}
async function cancelLogin(id) {
  const a = mustAccount(id);
  loginState.delete(id);
  clearTimeout(loginTimers[id]);
  if (a.provider === "codex" && loginIds[id]) await codexLoginCancel(a, loginIds[id]);
  await refreshStatus(id);
}
async function logout(id) {
  const a = mustAccount(id);
  if (a.provider === "claude") await claudeLogout(a);
  else await codexLogout(a);
  db().update("accounts", id, { limits: null, email: null, plan: null });
  activity("account", `Signed out \u201C${a.name}\u201D`, "");
  return refreshStatus(id);
}
function openTerminal(id) {
  const a = mustAccount(id);
  return openConsole(a, `${a.provider === "claude" ? "Claude Code" : "Codex"} - ${a.name}`, null, "Type exit to close this window.", true);
}
async function refreshAllAccounts() {
  for (const a of listAccounts()) {
    if (a.enabled) await refreshStatus(a.id).catch(() => void 0);
  }
}

// src/server/services/chats.ts
import fs14 from "node:fs";
import path12 from "node:path";

// src/server/services/projects.ts
import fs12 from "node:fs";
import path10 from "node:path";
import os3 from "node:os";

// src/server/services/context.ts
import fs11 from "node:fs";
import path9 from "node:path";

// src/shared/types.ts
var PROVIDER_LABEL = { claude: "Claude Code", codex: "Codex" };
var EFFICIENCY_PROFILES = {
  economy: {
    label: "Economy",
    description: "Smallest context, one agent at a time, no extra verification pass.",
    contextBudget: 2500,
    maxConcurrentAgents: 1,
    maxTasks: 2,
    retries: 0,
    toolOutputCap: 4e3,
    verification: "none",
    primeSnippets: 3
  },
  balanced: {
    label: "Balanced",
    description: "Targeted context, up to two agents in parallel, short final report.",
    contextBudget: 8e3,
    maxConcurrentAgents: 2,
    maxTasks: 4,
    retries: 1,
    toolOutputCap: 8e3,
    verification: "report",
    primeSnippets: 6
  },
  performance: {
    label: "Performance",
    description: "Richer context, three parallel agents, coordinator review of results.",
    contextBudget: 2e4,
    maxConcurrentAgents: 3,
    maxTasks: 6,
    retries: 1,
    toolOutputCap: 16e3,
    verification: "review",
    primeSnippets: 10
  },
  max: {
    label: "Maximum Quality",
    description: "Large context budgets, four parallel agents, full review and two retries.",
    contextBudget: 5e4,
    maxConcurrentAgents: 4,
    maxTasks: 8,
    retries: 2,
    toolOutputCap: 32e3,
    verification: "review",
    primeSnippets: 16
  }
};

// src/server/services/files.ts
import fs10 from "node:fs";
import path8 from "node:path";

// node_modules/diff/libesm/diff/base.js
var Diff = class {
  diff(oldStr, newStr, options = {}) {
    let callback;
    if (typeof options === "function") {
      callback = options;
      options = {};
    } else if ("callback" in options) {
      callback = options.callback;
    }
    const oldString = this.castInput(oldStr, options);
    const newString = this.castInput(newStr, options);
    const oldTokens = this.removeEmpty(this.tokenize(oldString, options));
    const newTokens = this.removeEmpty(this.tokenize(newString, options));
    return this.diffWithOptionsObj(oldTokens, newTokens, options, callback);
  }
  diffWithOptionsObj(oldTokens, newTokens, options, callback) {
    var _a;
    const done = (value) => {
      value = this.postProcess(value, options);
      if (callback) {
        setTimeout(function() {
          callback(value);
        }, 0);
        return void 0;
      } else {
        return value;
      }
    };
    const newLen = newTokens.length, oldLen = oldTokens.length;
    let editLength = 1;
    let maxEditLength = newLen + oldLen;
    if (options.maxEditLength != null) {
      maxEditLength = Math.min(maxEditLength, options.maxEditLength);
    }
    const maxExecutionTime = (_a = options.timeout) !== null && _a !== void 0 ? _a : Infinity;
    const abortAfterTimestamp = Date.now() + maxExecutionTime;
    const bestPath = [{ oldPos: -1, lastComponent: void 0 }];
    let newPos = this.extractCommon(bestPath[0], newTokens, oldTokens, 0, options);
    if (bestPath[0].oldPos + 1 >= oldLen && newPos + 1 >= newLen) {
      return done(this.buildValues(bestPath[0].lastComponent, newTokens, oldTokens));
    }
    let minDiagonalToConsider = -Infinity, maxDiagonalToConsider = Infinity;
    const execEditLength = () => {
      for (let diagonalPath = Math.max(minDiagonalToConsider, -editLength); diagonalPath <= Math.min(maxDiagonalToConsider, editLength); diagonalPath += 2) {
        let basePath;
        const removePath = bestPath[diagonalPath - 1], addPath = bestPath[diagonalPath + 1];
        if (removePath) {
          bestPath[diagonalPath - 1] = void 0;
        }
        let canAdd = false;
        if (addPath) {
          const addPathNewPos = addPath.oldPos - diagonalPath;
          canAdd = addPath && 0 <= addPathNewPos && addPathNewPos < newLen;
        }
        const canRemove = removePath && removePath.oldPos + 1 < oldLen;
        if (!canAdd && !canRemove) {
          bestPath[diagonalPath] = void 0;
          continue;
        }
        if (!canRemove || canAdd && removePath.oldPos < addPath.oldPos) {
          basePath = this.addToPath(addPath, true, false, 0, options);
        } else {
          basePath = this.addToPath(removePath, false, true, 1, options);
        }
        newPos = this.extractCommon(basePath, newTokens, oldTokens, diagonalPath, options);
        if (basePath.oldPos + 1 >= oldLen && newPos + 1 >= newLen) {
          return done(this.buildValues(basePath.lastComponent, newTokens, oldTokens)) || true;
        } else {
          bestPath[diagonalPath] = basePath;
          if (basePath.oldPos + 1 >= oldLen) {
            maxDiagonalToConsider = Math.min(maxDiagonalToConsider, diagonalPath - 1);
          }
          if (newPos + 1 >= newLen) {
            minDiagonalToConsider = Math.max(minDiagonalToConsider, diagonalPath + 1);
          }
        }
      }
      editLength++;
    };
    if (callback) {
      (function exec() {
        setTimeout(function() {
          if (editLength > maxEditLength || Date.now() > abortAfterTimestamp) {
            return callback(void 0);
          }
          if (!execEditLength()) {
            exec();
          }
        }, 0);
      })();
    } else {
      while (editLength <= maxEditLength && Date.now() <= abortAfterTimestamp) {
        const ret = execEditLength();
        if (ret) {
          return ret;
        }
      }
    }
  }
  addToPath(path15, added, removed, oldPosInc, options) {
    const last = path15.lastComponent;
    if (last && !options.oneChangePerToken && last.added === added && last.removed === removed) {
      return {
        oldPos: path15.oldPos + oldPosInc,
        lastComponent: { count: last.count + 1, added, removed, previousComponent: last.previousComponent }
      };
    } else {
      return {
        oldPos: path15.oldPos + oldPosInc,
        lastComponent: { count: 1, added, removed, previousComponent: last }
      };
    }
  }
  extractCommon(basePath, newTokens, oldTokens, diagonalPath, options) {
    const newLen = newTokens.length, oldLen = oldTokens.length;
    let oldPos = basePath.oldPos, newPos = oldPos - diagonalPath, commonCount = 0;
    while (newPos + 1 < newLen && oldPos + 1 < oldLen && this.equals(oldTokens[oldPos + 1], newTokens[newPos + 1], options)) {
      newPos++;
      oldPos++;
      commonCount++;
      if (options.oneChangePerToken) {
        basePath.lastComponent = { count: 1, previousComponent: basePath.lastComponent, added: false, removed: false };
      }
    }
    if (commonCount && !options.oneChangePerToken) {
      basePath.lastComponent = { count: commonCount, previousComponent: basePath.lastComponent, added: false, removed: false };
    }
    basePath.oldPos = oldPos;
    return newPos;
  }
  equals(left, right, options) {
    if (options.comparator) {
      return options.comparator(left, right);
    } else {
      return left === right || !!options.ignoreCase && left.toLowerCase() === right.toLowerCase();
    }
  }
  removeEmpty(array) {
    const ret = [];
    for (let i = 0; i < array.length; i++) {
      if (array[i]) {
        ret.push(array[i]);
      }
    }
    return ret;
  }
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  castInput(value, options) {
    return value;
  }
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  tokenize(value, options) {
    return Array.from(value);
  }
  join(chars) {
    return chars.join("");
  }
  postProcess(changeObjects, options) {
    return changeObjects;
  }
  get useLongestToken() {
    return false;
  }
  buildValues(lastComponent, newTokens, oldTokens) {
    const components = [];
    let nextComponent;
    while (lastComponent) {
      components.push(lastComponent);
      nextComponent = lastComponent.previousComponent;
      delete lastComponent.previousComponent;
      lastComponent = nextComponent;
    }
    components.reverse();
    const componentLen = components.length;
    let componentPos = 0, newPos = 0, oldPos = 0;
    for (; componentPos < componentLen; componentPos++) {
      const component = components[componentPos];
      if (!component.removed) {
        if (!component.added && this.useLongestToken) {
          let value = newTokens.slice(newPos, newPos + component.count);
          value = value.map(function(value2, i) {
            const oldValue = oldTokens[oldPos + i];
            return oldValue.length > value2.length ? oldValue : value2;
          });
          component.value = this.join(value);
        } else {
          component.value = this.join(newTokens.slice(newPos, newPos + component.count));
        }
        newPos += component.count;
        if (!component.added) {
          oldPos += component.count;
        }
      } else {
        component.value = this.join(oldTokens.slice(oldPos, oldPos + component.count));
        oldPos += component.count;
      }
    }
    return components;
  }
};

// node_modules/diff/libesm/diff/line.js
var LineDiff = class extends Diff {
  constructor() {
    super(...arguments);
    this.tokenize = tokenize;
  }
  equals(left, right, options) {
    if (options.ignoreWhitespace) {
      if (!options.newlineIsToken || !left.includes("\n")) {
        left = left.trim();
      }
      if (!options.newlineIsToken || !right.includes("\n")) {
        right = right.trim();
      }
    } else if (options.ignoreNewlineAtEof && !options.newlineIsToken) {
      if (left.endsWith("\n")) {
        left = left.slice(0, -1);
      }
      if (right.endsWith("\n")) {
        right = right.slice(0, -1);
      }
    }
    return super.equals(left, right, options);
  }
};
var lineDiff = new LineDiff();
function diffLines(oldStr, newStr, options) {
  return lineDiff.diff(oldStr, newStr, options);
}
function tokenize(value, options) {
  if (options.stripTrailingCr) {
    value = value.replace(/\r\n/g, "\n");
  }
  const retLines = [], linesAndNewlines = value.split(/(\n|\r\n)/);
  if (!linesAndNewlines[linesAndNewlines.length - 1]) {
    linesAndNewlines.pop();
  }
  for (let i = 0; i < linesAndNewlines.length; i++) {
    const line = linesAndNewlines[i];
    if (i % 2 && !options.newlineIsToken) {
      retLines[retLines.length - 1] += line;
    } else {
      retLines.push(line);
    }
  }
  return retLines;
}

// node_modules/diff/libesm/patch/create.js
function needsQuoting(s) {
  for (let i = 0; i < s.length; i++) {
    if (s[i] < " " || s[i] > "~" || s[i] === '"' || s[i] === "\\") {
      return true;
    }
  }
  return false;
}
function quoteFileNameIfNeeded(s) {
  if (!needsQuoting(s)) {
    return s;
  }
  let result = '"';
  const bytes = new TextEncoder().encode(s);
  let i = 0;
  while (i < bytes.length) {
    const b2 = bytes[i];
    if (b2 === 7) {
      result += "\\a";
    } else if (b2 === 8) {
      result += "\\b";
    } else if (b2 === 9) {
      result += "\\t";
    } else if (b2 === 10) {
      result += "\\n";
    } else if (b2 === 11) {
      result += "\\v";
    } else if (b2 === 12) {
      result += "\\f";
    } else if (b2 === 13) {
      result += "\\r";
    } else if (b2 === 34) {
      result += '\\"';
    } else if (b2 === 92) {
      result += "\\\\";
    } else if (b2 >= 32 && b2 <= 126) {
      result += String.fromCharCode(b2);
    } else {
      result += "\\" + b2.toString(8).padStart(3, "0");
    }
    i++;
  }
  result += '"';
  return result;
}
var INCLUDE_HEADERS = {
  includeIndex: true,
  includeUnderline: true,
  includeFileHeaders: true
};
function structuredPatch(oldFileName, newFileName, oldStr, newStr, oldHeader, newHeader, options) {
  let optionsObj;
  if (!options) {
    optionsObj = {};
  } else if (typeof options === "function") {
    optionsObj = { callback: options };
  } else {
    optionsObj = options;
  }
  if (typeof optionsObj.context === "undefined") {
    optionsObj.context = 4;
  }
  const context = optionsObj.context;
  if (optionsObj.newlineIsToken) {
    throw new Error("newlineIsToken may not be used with patch-generation functions, only with diffing functions");
  }
  if (!optionsObj.callback) {
    return diffLinesResultToPatch(diffLines(oldStr, newStr, optionsObj));
  } else {
    const { callback } = optionsObj;
    diffLines(oldStr, newStr, Object.assign(Object.assign({}, optionsObj), { callback: (diff) => {
      const patch = diffLinesResultToPatch(diff);
      callback(patch);
    } }));
  }
  function diffLinesResultToPatch(diff) {
    if (!diff) {
      return;
    }
    diff.push({ value: "", lines: [] });
    function contextLines(lines) {
      return lines.map(function(entry) {
        return " " + entry;
      });
    }
    const hunks = [];
    let oldRangeStart = 0, newRangeStart = 0, curRange = [], oldLine = 1, newLine = 1;
    for (let i = 0; i < diff.length; i++) {
      const current = diff[i], lines = current.lines || splitLines(current.value);
      current.lines = lines;
      if (current.added || current.removed) {
        if (!oldRangeStart) {
          const prev = diff[i - 1];
          oldRangeStart = oldLine;
          newRangeStart = newLine;
          if (prev) {
            curRange = context > 0 ? contextLines(prev.lines.slice(-context)) : [];
            oldRangeStart -= curRange.length;
            newRangeStart -= curRange.length;
          }
        }
        for (const line of lines) {
          curRange.push((current.added ? "+" : "-") + line);
        }
        if (current.added) {
          newLine += lines.length;
        } else {
          oldLine += lines.length;
        }
      } else {
        if (oldRangeStart) {
          if (lines.length <= context * 2 && i < diff.length - 2) {
            for (const line of contextLines(lines)) {
              curRange.push(line);
            }
          } else {
            const contextSize = Math.min(lines.length, context);
            for (const line of contextLines(lines.slice(0, contextSize))) {
              curRange.push(line);
            }
            const hunk = {
              oldStart: oldRangeStart,
              oldLines: oldLine - oldRangeStart + contextSize,
              newStart: newRangeStart,
              newLines: newLine - newRangeStart + contextSize,
              lines: curRange
            };
            hunks.push(hunk);
            oldRangeStart = 0;
            newRangeStart = 0;
            curRange = [];
          }
        }
        oldLine += lines.length;
        newLine += lines.length;
      }
    }
    for (const hunk of hunks) {
      for (let i = 0; i < hunk.lines.length; i++) {
        if (hunk.lines[i].endsWith("\n")) {
          hunk.lines[i] = hunk.lines[i].slice(0, -1);
        } else {
          hunk.lines.splice(i + 1, 0, "\\ No newline at end of file");
          i++;
        }
      }
    }
    return {
      oldFileName,
      newFileName,
      oldHeader,
      newHeader,
      hunks
    };
  }
}
function formatPatch(patch, headerOptions) {
  var _a, _b, _c, _d, _e, _f;
  if (!headerOptions) {
    headerOptions = INCLUDE_HEADERS;
  }
  if (Array.isArray(patch)) {
    if (patch.length > 1 && !headerOptions.includeFileHeaders && !patch.every((p) => p.isGit)) {
      throw new Error("Cannot omit file headers on a multi-file patch. (The result would be unparseable; how would a tool trying to apply the patch know which changes are to which file?)");
    }
    return patch.map((p) => formatPatch(p, headerOptions)).join("\n");
  }
  const ret = [];
  if (patch.isGit) {
    headerOptions = INCLUDE_HEADERS;
    if (!patch.oldFileName) {
      throw new Error("oldFileName must be specified for Git patches");
    }
    if (!patch.newFileName) {
      throw new Error("newFileName must be specified for Git patches");
    }
    let gitOldName = patch.oldFileName;
    let gitNewName = patch.newFileName;
    if (patch.isCreate && gitOldName === "/dev/null") {
      gitOldName = gitNewName.replace(/^b\//, "a/");
    } else if (patch.isDelete && gitNewName === "/dev/null") {
      gitNewName = gitOldName.replace(/^a\//, "b/");
    }
    ret.push("diff --git " + quoteFileNameIfNeeded(gitOldName) + " " + quoteFileNameIfNeeded(gitNewName));
    if (patch.isDelete) {
      ret.push("deleted file mode " + ((_a = patch.oldMode) !== null && _a !== void 0 ? _a : "100644"));
    }
    if (patch.isCreate) {
      ret.push("new file mode " + ((_b = patch.newMode) !== null && _b !== void 0 ? _b : "100644"));
    }
    if (patch.oldMode && patch.newMode && !patch.isDelete && !patch.isCreate) {
      ret.push("old mode " + patch.oldMode);
      ret.push("new mode " + patch.newMode);
    }
    if (patch.isRename) {
      ret.push("rename from " + quoteFileNameIfNeeded(((_c = patch.oldFileName) !== null && _c !== void 0 ? _c : "").replace(/^a\//, "")));
      ret.push("rename to " + quoteFileNameIfNeeded(((_d = patch.newFileName) !== null && _d !== void 0 ? _d : "").replace(/^b\//, "")));
    }
    if (patch.isCopy) {
      ret.push("copy from " + quoteFileNameIfNeeded(((_e = patch.oldFileName) !== null && _e !== void 0 ? _e : "").replace(/^a\//, "")));
      ret.push("copy to " + quoteFileNameIfNeeded(((_f = patch.newFileName) !== null && _f !== void 0 ? _f : "").replace(/^b\//, "")));
    }
  } else {
    if (headerOptions.includeIndex && patch.oldFileName == patch.newFileName && patch.oldFileName !== void 0) {
      ret.push("Index: " + patch.oldFileName);
    }
    if (headerOptions.includeUnderline) {
      ret.push("===================================================================");
    }
  }
  const hasHunks = patch.hunks.length > 0;
  if (headerOptions.includeFileHeaders && patch.oldFileName !== void 0 && patch.newFileName !== void 0 && (!patch.isGit || hasHunks)) {
    ret.push("--- " + quoteFileNameIfNeeded(patch.oldFileName) + (patch.oldHeader ? "	" + patch.oldHeader : ""));
    ret.push("+++ " + quoteFileNameIfNeeded(patch.newFileName) + (patch.newHeader ? "	" + patch.newHeader : ""));
  }
  for (let i = 0; i < patch.hunks.length; i++) {
    const hunk = patch.hunks[i];
    const oldStart = hunk.oldLines === 0 ? hunk.oldStart - 1 : hunk.oldStart;
    const newStart = hunk.newLines === 0 ? hunk.newStart - 1 : hunk.newStart;
    ret.push("@@ -" + oldStart + "," + hunk.oldLines + " +" + newStart + "," + hunk.newLines + " @@");
    for (const line of hunk.lines) {
      ret.push(line);
    }
  }
  return ret.join("\n") + "\n";
}
function createTwoFilesPatch(oldFileName, newFileName, oldStr, newStr, oldHeader, newHeader, options) {
  if (typeof options === "function") {
    options = { callback: options };
  }
  if (!(options === null || options === void 0 ? void 0 : options.callback)) {
    const patchObj = structuredPatch(oldFileName, newFileName, oldStr, newStr, oldHeader, newHeader, options);
    if (!patchObj) {
      return;
    }
    return formatPatch(patchObj, options === null || options === void 0 ? void 0 : options.headerOptions);
  } else {
    const { callback } = options;
    structuredPatch(oldFileName, newFileName, oldStr, newStr, oldHeader, newHeader, Object.assign(Object.assign({}, options), { callback: (patchObj) => {
      if (!patchObj) {
        callback(void 0);
      } else {
        callback(formatPatch(patchObj, options.headerOptions));
      }
    } }));
  }
}
function splitLines(text) {
  const hasTrailingNl = text.endsWith("\n");
  const result = text.split("\n").map((line) => line + "\n");
  if (hasTrailingNl) {
    result.pop();
  } else {
    result.push(result.pop().slice(0, -1));
  }
  return result;
}

// src/server/services/files.ts
var IGNORE_DIRS = /* @__PURE__ */ new Set([
  "node_modules",
  ".git",
  ".svn",
  ".hg",
  "dist",
  "build",
  "out",
  ".next",
  ".nuxt",
  ".cache",
  "__pycache__",
  ".venv",
  "venv",
  "target",
  ".idea",
  ".bloxade",
  ".turbo",
  "coverage",
  ".pytest_cache",
  "DevPackages",
  ".gradle",
  "bin",
  "obj"
]);
var BINARY_EXT = /* @__PURE__ */ new Set([
  ".png",
  ".jpg",
  ".jpeg",
  ".gif",
  ".webp",
  ".bmp",
  ".ico",
  ".tga",
  ".psd",
  ".mp3",
  ".wav",
  ".ogg",
  ".mp4",
  ".mov",
  ".zip",
  ".rar",
  ".7z",
  ".gz",
  ".exe",
  ".dll",
  ".so",
  ".dylib",
  ".pdf",
  ".rbxl",
  ".rbxm",
  ".fbx",
  ".obj",
  ".blend",
  ".woff",
  ".woff2",
  ".ttf",
  ".otf",
  ".sqlite",
  ".db",
  ".bin",
  ".lockb",
  ".class",
  ".jar",
  ".pyc"
]);
function isProbablyText(file) {
  return !BINARY_EXT.has(path8.extname(file).toLowerCase());
}
function norm(p) {
  return IS_WIN ? p.toLowerCase() : p;
}
function isInside(root, target) {
  const r = norm(path8.resolve(root));
  const t = norm(path8.resolve(target));
  return t === r || t.startsWith(r.endsWith(path8.sep) ? r : r + path8.sep);
}
function safeResolve(root, rel) {
  if (!root) throw new HttpError(400, "This project has no folder");
  const cleaned = (rel || "").replace(/\\/g, "/").replace(/^\/+/, "");
  const abs = path8.resolve(root, cleaned);
  if (!isInside(root, abs)) throw new HttpError(403, "Path is outside the project folder");
  try {
    const real = fs10.realpathSync(abs);
    const realRoot = fs10.realpathSync(root);
    if (!isInside(realRoot, real)) throw new HttpError(403, "Path resolves outside the project folder");
  } catch (e) {
    if (e instanceof HttpError) throw e;
  }
  return abs;
}
function relPath(root, abs) {
  return path8.relative(root, abs).split(path8.sep).join("/");
}
function listDir(root, rel) {
  const abs = safeResolve(root, rel);
  let entries;
  try {
    entries = fs10.readdirSync(abs, { withFileTypes: true });
  } catch {
    throw new HttpError(404, "Folder not found");
  }
  const out = [];
  for (const e of entries) {
    if (e.name === ".DS_Store") continue;
    const full = path8.join(abs, e.name);
    const r = relPath(root, full);
    if (e.isDirectory()) out.push({ name: e.name, path: r, type: "dir" });
    else if (e.isFile()) {
      try {
        const st = fs10.statSync(full);
        out.push({ name: e.name, path: r, type: "file", size: st.size, mtime: st.mtimeMs });
      } catch {
      }
    }
  }
  return out.sort((a, b2) => a.type === b2.type ? a.name.localeCompare(b2.name) : a.type === "dir" ? -1 : 1);
}
function walk(root, opts = {}) {
  const max = opts.maxFiles ?? 2e4;
  const files = [];
  const stack = [root];
  let truncated = false;
  while (stack.length) {
    const dir = stack.pop();
    let entries;
    try {
      entries = fs10.readdirSync(dir, { withFileTypes: true });
    } catch {
      continue;
    }
    for (const e of entries) {
      const full = path8.join(dir, e.name);
      if (e.isDirectory()) {
        if (!opts.includeIgnored && (IGNORE_DIRS.has(e.name) || e.name.startsWith(".") && e.name !== ".github")) continue;
        stack.push(full);
      } else if (e.isFile()) {
        if (files.length >= max) {
          truncated = true;
          return { files, truncated };
        }
        try {
          const st = fs10.statSync(full);
          files.push({ rel: relPath(root, full), abs: full, size: st.size, mtime: st.mtimeMs });
        } catch {
        }
      }
    }
  }
  return { files, truncated };
}
function readText(abs, maxBytes = 512 * 1024) {
  const st = fs10.statSync(abs);
  const fd = fs10.openSync(abs, "r");
  try {
    const len = Math.min(st.size, maxBytes);
    const buf = Buffer.alloc(len);
    fs10.readSync(fd, buf, 0, len, 0);
    const sample = buf.subarray(0, Math.min(len, 8e3));
    const binary = !isProbablyText(abs) || sample.includes(0);
    return { content: binary ? "" : buf.toString("utf8"), truncated: st.size > maxBytes, binary, size: st.size };
  } finally {
    fs10.closeSync(fd);
  }
}
function blobPath(hash) {
  return path8.join(dirs.blobs, hash.slice(0, 2), hash);
}
function putBlob(data) {
  const hash = sha1(data);
  const p = blobPath(hash);
  if (!fs10.existsSync(p)) {
    fs10.mkdirSync(path8.dirname(p), { recursive: true });
    fs10.writeFileSync(p, data);
  }
  return hash;
}
function getBlob(hash) {
  try {
    return fs10.readFileSync(blobPath(hash));
  } catch {
    return null;
  }
}
var memo = /* @__PURE__ */ new Map();
function snapshot(root, maxFiles = 15e3) {
  const { files, truncated } = walk(root, { maxFiles });
  const snap = /* @__PURE__ */ new Map();
  for (const f of files) {
    if (f.size > 2 * 1024 * 1024 || !isProbablyText(f.abs)) continue;
    const key = `${f.abs}|${f.size}|${f.mtime}`;
    let e = memo.get(key);
    if (!e) {
      try {
        const data = fs10.readFileSync(f.abs);
        e = { hash: putBlob(data), size: f.size, mtime: f.mtime };
        memo.set(key, e);
        if (memo.size > 6e4) memo.clear();
      } catch {
        continue;
      }
    }
    snap.set(f.rel, e);
  }
  return { snap, truncated };
}
function diffSnapshots(before, after, only) {
  const out = [];
  for (const [p, a] of after) {
    if (only && !only.has(p)) continue;
    const bEntry = before.get(p);
    if (!bEntry) out.push({ path: p, change: "added", beforeHash: null, afterHash: a.hash });
    else if (bEntry.hash !== a.hash) out.push({ path: p, change: "modified", beforeHash: bEntry.hash, afterHash: a.hash });
  }
  for (const [p, bEntry] of before) {
    if (only && !only.has(p)) continue;
    if (!after.has(p)) out.push({ path: p, change: "deleted", beforeHash: bEntry.hash, afterHash: null });
  }
  return out.sort((x, y) => x.path.localeCompare(y.path));
}
function unifiedDiff(file, beforeHash, afterHash, maxChars = 12e4) {
  const a = beforeHash ? getBlob(beforeHash)?.toString("utf8") ?? "" : "";
  const b2 = afterHash ? getBlob(afterHash)?.toString("utf8") ?? "" : "";
  const patch = createTwoFilesPatch(beforeHash ? `a/${file}` : "/dev/null", afterHash ? `b/${file}` : "/dev/null", a, b2, "", "", { context: 3 });
  return patch.length > maxChars ? patch.slice(0, maxChars) + "\n\u2026 diff truncated \u2026" : patch;
}
function restoreFile(root, rel, beforeHash) {
  const abs = safeResolve(root, rel);
  if (beforeHash == null) {
    fs10.rmSync(abs, { force: true });
    return;
  }
  const data = getBlob(beforeHash);
  if (!data) throw new HttpError(410, `The original content of ${rel} is no longer available`);
  fs10.mkdirSync(path8.dirname(abs), { recursive: true });
  fs10.writeFileSync(abs, data);
}
var LockTable = class {
  locks = /* @__PURE__ */ new Map();
  key(k) {
    const n = k.replace(/\\/g, "/");
    return IS_WIN ? n.toLowerCase() : n;
  }
  claim(k, owner) {
    const key = this.key(k);
    const cur = this.locks.get(key);
    if (cur && cur.id !== owner.id) return { ok: false, holder: cur };
    if (!cur) this.locks.set(key, { ...owner, since: Date.now() });
    return { ok: true };
  }
  holder(k) {
    return this.locks.get(this.key(k)) ?? null;
  }
  release(ownerId) {
    for (const [k, v] of this.locks) if (v.id === ownerId) this.locks.delete(k);
  }
  list() {
    return [...this.locks.entries()].map(([key, v]) => ({ key, ...v }));
  }
};
var fileLocks = new LockTable();
var studioLocks = new LockTable();
function matchOwned(patterns, rel) {
  const target = rel.replace(/\\/g, "/").replace(/^\.\//, "");
  const t = IS_WIN ? target.toLowerCase() : target;
  return patterns.some((raw) => {
    let p = raw.trim().replace(/\\/g, "/").replace(/^\.\//, "");
    if (!p) return false;
    if (IS_WIN) p = p.toLowerCase();
    if (p.endsWith("/")) return t.startsWith(p);
    if (!p.includes("*")) return t === p || t.startsWith(p + "/");
    const re = new RegExp(
      "^" + p.split("**").map((seg) => seg.split("*").map((s) => s.replace(/[.+?^${}()|[\]\\]/g, "\\$&")).join("[^/]*")).join(".*") + "$"
    );
    return re.test(t);
  });
}

// src/server/services/context.ts
var indexes = /* @__PURE__ */ new Map();
var contentCache = /* @__PURE__ */ new Map();
var contentBytes = 0;
var stats = { indexHits: 0, indexBuilds: 0, contentHits: 0, contentReads: 0 };
function cacheStats() {
  return { ...stats, indexes: indexes.size, cachedFiles: contentCache.size, cachedBytes: contentBytes };
}
function invalidateProject(projectId) {
  indexes.delete(projectId);
}
function getIndex(projectId, root, force = false) {
  const cur = indexes.get(projectId);
  const useCache = getSettings().context.cache;
  if (cur && !force && useCache && cur.root === root && Date.now() - cur.builtAt < 15e3) {
    stats.indexHits++;
    return cur;
  }
  const { files, truncated } = walk(root, { maxFiles: 25e3 });
  const entries = files.map((f) => ({ ...f, ext: path9.extname(f.rel).toLowerCase() }));
  const totalTextBytes = entries.filter((f) => isProbablyText(f.rel) && f.size < 1e6).reduce((n, f) => n + f.size, 0);
  const idx = { root, files: entries, truncated, builtAt: Date.now(), totalTextBytes };
  indexes.set(projectId, idx);
  stats.indexBuilds++;
  return idx;
}
var STOP = new Set(
  "the a an and or but if then else for to of in on at by with from into this that these those is are was were be been it its as do does did make add create build fix update change use using please can could would should my our your their game script code file files new also just like want need get set via all any some more most".split(
    " "
  )
);
function terms(text) {
  const out = [];
  const raw = text.replace(/([a-z0-9])([A-Z])/g, "$1 $2").replace(/[_\-./\\:]+/g, " ").toLowerCase().split(/[^a-z0-9]+/);
  for (const t of raw) if (t.length >= 3 && !STOP.has(t) && !/^\d+$/.test(t)) out.push(t);
  return out;
}
function fileContent(f) {
  if (!isProbablyText(f.rel) || f.size > 4e5) return null;
  const key = `${f.size}|${f.mtime}`;
  const c = contentCache.get(f.abs);
  if (c && c.key === key) {
    stats.contentHits++;
    return c;
  }
  try {
    const r = readText(f.abs, 4e5);
    if (r.binary) return null;
    const tf = /* @__PURE__ */ new Map();
    for (const t of terms(r.content)) tf.set(t, (tf.get(t) ?? 0) + 1);
    const entry = { key, text: r.content, terms: tf };
    if (c) contentBytes -= c.text.length;
    contentCache.set(f.abs, entry);
    contentBytes += r.content.length;
    stats.contentReads++;
    if (contentBytes > 48 * 1024 * 1024) {
      let i = 0;
      for (const [k, v] of contentCache) {
        if (i++ > contentCache.size / 2) break;
        contentBytes -= v.text.length;
        contentCache.delete(k);
      }
    }
    return entry;
  } catch {
    return null;
  }
}
function rankFiles(idx, query, limit = 12) {
  const q = [...new Set(terms(query))];
  if (!q.length) return [];
  const candidates = idx.files.filter((f) => isProbablyText(f.rel) && f.size <= 4e5).slice(0, 6e3);
  const docs = [];
  const df = /* @__PURE__ */ new Map();
  for (const f of candidates) {
    const c = fileContent(f);
    if (!c) continue;
    let len = 0;
    for (const v of c.terms.values()) len += v;
    docs.push({ f, tf: c.terms, len });
    for (const t of q) if (c.terms.has(t)) df.set(t, (df.get(t) ?? 0) + 1);
  }
  const N = docs.length || 1;
  const avg = docs.reduce((n, d) => n + d.len, 0) / N || 1;
  const k1 = 1.2;
  const bb = 0.75;
  const scored = [];
  for (const d of docs) {
    let s = 0;
    const pathTerms = new Set(terms(d.f.rel));
    const base = path9.basename(d.f.rel).toLowerCase();
    for (const t of q) {
      const tf = d.tf.get(t) ?? 0;
      if (tf) {
        const idf = Math.log(1 + (N - (df.get(t) ?? 0) + 0.5) / ((df.get(t) ?? 0) + 0.5));
        s += idf * (tf * (k1 + 1)) / (tf + k1 * (1 - bb + bb * d.len / avg));
      }
      if (pathTerms.has(t)) s += 2.5;
      if (base.includes(t)) s += 3;
    }
    if (s > 0) scored.push({ rel: d.f.rel, score: s, entry: d.f });
  }
  return scored.sort((a, b2) => b2.score - a.score).slice(0, limit);
}
function snippets(text, query, maxChars) {
  const lines = text.split("\n");
  if (text.length <= maxChars) return { text, ranges: [[1, lines.length]] };
  const q = new Set(terms(query));
  const hits = [];
  lines.forEach((l, i) => {
    const lt = terms(l);
    if (lt.some((t) => q.has(t))) hits.push(i);
  });
  if (!hits.length) {
    const head = lines.slice(0, 40).join("\n");
    return { text: head.slice(0, maxChars), ranges: [[1, Math.min(40, lines.length)]] };
  }
  const ranges = [];
  for (const h of hits) {
    const s = Math.max(0, h - 8);
    const e = Math.min(lines.length - 1, h + 12);
    const last = ranges[ranges.length - 1];
    if (last && s <= last[1] + 2) last[1] = Math.max(last[1], e);
    else ranges.push([s, e]);
  }
  let out = "";
  const used = [];
  for (const [s, e] of ranges) {
    const chunk = lines.slice(s, e + 1).map((l, i) => `${s + i + 1}| ${l}`).join("\n");
    if (out.length + chunk.length + 8 > maxChars) {
      if (!out) out = chunk.slice(0, maxChars);
      break;
    }
    out += (out ? "\n\u2026\n" : "") + chunk;
    used.push([s + 1, e + 1]);
  }
  return { text: out, ranges: used };
}
function treeSummary(idx, maxLines = 60) {
  const dirCounts = /* @__PURE__ */ new Map();
  for (const f of idx.files) {
    const parts = f.rel.split("/");
    for (let i = 1; i < parts.length; i++) {
      const d = parts.slice(0, i).join("/");
      dirCounts.set(d, (dirCounts.get(d) ?? 0) + 1);
    }
  }
  const lines = [];
  const top = idx.files.filter((f) => !f.rel.includes("/")).map((f) => f.rel);
  const dirsSorted = [...dirCounts.entries()].filter(([d]) => d.split("/").length <= 3).sort((a, b2) => a[0].localeCompare(b2[0]));
  for (const [d, n] of dirsSorted) {
    if (lines.length >= maxLines) break;
    const depth = d.split("/").length - 1;
    lines.push(`${"  ".repeat(depth)}${d.split("/").pop()}/ (${n} files)`);
  }
  for (const f of top.slice(0, Math.max(5, maxLines - lines.length))) lines.push(f);
  if (idx.truncated) lines.push("\u2026 (project is large; index truncated)");
  return lines.join("\n");
}
function budgetFor(mode) {
  const s = getSettings().context;
  return s.budgetOverride ?? EFFICIENCY_PROFILES[mode].contextBudget;
}
function buildContextPack(opts) {
  const { project } = opts;
  const mode = opts.mode ?? getSettings().context.mode;
  const budgetChars = (opts.budgetTokens ?? budgetFor(mode)) * 4;
  const sections = [];
  const included = {};
  const skipped = [];
  let used = 0;
  if (opts.includeMemory !== false && project.memory.trim()) {
    const mem = project.memory.trim().slice(0, Math.floor(budgetChars * 0.2));
    sections.push(`<project_memory>
${mem}
</project_memory>`);
    used += mem.length;
  }
  let naiveChars = project.memory.length;
  if (project.folderPath && fs11.existsSync(project.folderPath)) {
    const idx = getIndex(project.id, project.folderPath);
    naiveChars += idx.totalTextBytes;
    if (opts.includeTree !== false) {
      const tree = treeSummary(idx, mode === "economy" ? 25 : mode === "balanced" ? 45 : 80).slice(0, Math.floor(budgetChars * 0.2));
      sections.push(`<project_tree root="${project.folderPath.replace(/"/g, "")}">
${tree}
</project_tree>`);
      used += tree.length;
    }
    const maxFiles = EFFICIENCY_PROFILES[mode].primeSnippets;
    const ranked = rankFiles(idx, opts.query, maxFiles);
    const parts = [];
    for (const r of ranked) {
      const remaining = budgetChars - used;
      if (remaining < 400) break;
      const c = fileContent(r.entry);
      if (!c) continue;
      const hash = sha1(c.text);
      if (opts.alreadySent?.[r.rel] === hash) {
        skipped.push(r.rel);
        continue;
      }
      const perFile = Math.min(remaining - 100, Math.max(800, Math.floor(budgetChars * 0.6 / Math.max(1, ranked.length))));
      const snip = snippets(c.text, opts.query, perFile);
      parts.push(`<file path="${r.rel}" lines="${snip.ranges.map((x) => x.join("-")).join(",")}">
${snip.text}
</file>`);
      used += snip.text.length + 40;
      included[r.rel] = hash;
    }
    if (parts.length) sections.push(`<relevant_files note="Selected excerpts; read full files yourself if needed.">
${parts.join("\n")}
</relevant_files>`);
    if (skipped.length) sections.push(`<unchanged_files note="Already shared earlier in this conversation and unchanged">${skipped.join(", ")}</unchanged_files>`);
  }
  if (!sections.length) return null;
  const text = `<bloxade_context project="${project.name.replace(/"/g, "")}">
${sections.join("\n")}
</bloxade_context>`;
  const estTokens = estimateTokens(text);
  const naiveTokens = estimateTokens(naiveChars);
  return { text, files: included, estTokens, naiveTokens, savedTokens: Math.max(0, naiveTokens - estTokens), skippedUnchanged: skipped };
}
function compressOutput(text, cap) {
  if (text.length <= cap) return { text, saved: 0 };
  const lines = text.split("\n");
  const collapsed = [];
  let prev = null;
  let rep = 0;
  for (const l of lines) {
    if (l === prev) {
      rep++;
      continue;
    }
    if (rep > 0) collapsed.push(`\u2026 (previous line repeated ${rep}\xD7)`);
    rep = 0;
    collapsed.push(l);
    prev = l;
  }
  if (rep > 0) collapsed.push(`\u2026 (previous line repeated ${rep}\xD7)`);
  let out = collapsed.join("\n");
  if (out.length > cap) {
    const head = out.slice(0, Math.floor(cap * 0.6));
    const tail = out.slice(out.length - Math.floor(cap * 0.35));
    const omittedLines = out.slice(head.length, out.length - tail.length).split("\n").length;
    out = `${head}

\u2026 [BLOXADE trimmed ${omittedLines} lines / ${out.length - head.length - tail.length} chars to save context \u2014 call again with a narrower query or path for details] \u2026

${tail}`;
  }
  return { text: out, saved: Math.max(0, estimateTokens(text) - estimateTokens(out)) };
}

// src/server/services/projects.ts
var ICONS = ["cuboid", "gamepad", "rocket", "sparkles", "box", "layers", "zap", "star", "blocks", "code", "flame", "heart"];
function toProject(r) {
  const chats = db().get("SELECT COUNT(*) AS n FROM chats WHERE project_id = ?", r.id)?.n ?? 0;
  const runs = db().get("SELECT COUNT(*) AS n FROM runs WHERE project_id = ?", r.id)?.n ?? 0;
  return {
    id: r.id,
    name: r.name,
    icon: r.icon,
    color: r.color,
    description: r.description,
    folderPath: r.folder_path,
    instructions: r.instructions,
    memory: r.memory,
    memoryUpdatedAt: r.memory_updated_at,
    robloxEnabled: !!r.roblox_enabled,
    defaults: safeJson(r.defaults, {}),
    createdAt: r.created_at,
    updatedAt: r.updated_at,
    stats: { chats, runs }
  };
}
function listProjects() {
  return db().all("SELECT * FROM projects ORDER BY updated_at DESC").map(toProject);
}
function getProject(id) {
  if (!id) return null;
  const r = db().get("SELECT * FROM projects WHERE id = ?", id);
  return r ? toProject(r) : null;
}
function mustProject(id) {
  const p = getProject(id);
  if (!p) throw new HttpError(404, "Project not found");
  return p;
}
var BLOCKED_ROOTS = (() => {
  const list = [os3.homedir(), path10.parse(os3.homedir()).root];
  if (process.platform === "win32") list.push("C:\\Windows", "C:\\Program Files", "C:\\Program Files (x86)");
  else list.push("/", "/etc", "/usr", "/bin", "/System");
  return list.map((p) => path10.resolve(p).toLowerCase());
})();
function validateFolder(input, create = false) {
  if (!input || !String(input).trim()) return null;
  const abs = expandUserPath(String(input));
  if (BLOCKED_ROOTS.includes(abs.toLowerCase()) || BLOCKED_ROOTS.some((r) => r.length > 3 && abs.toLowerCase().startsWith(r + path10.sep) && /windows|program files/i.test(r))) {
    throw new HttpError(400, "Choose a specific project folder \u2014 your whole home folder, a drive root or system folders cannot be used.");
  }
  if (!fs12.existsSync(abs)) {
    if (!create) throw new HttpError(400, `Folder does not exist: ${abs}`);
    fs12.mkdirSync(abs, { recursive: true });
  }
  if (!fs12.statSync(abs).isDirectory()) throw new HttpError(400, "That path is a file, not a folder");
  return abs;
}
function emit2(id) {
  const p = getProject(id);
  if (p) events.emit("project.updated", p);
}
function createProject(body) {
  const name = str(body?.name, "Project name", { min: 1, max: 80 }).trim();
  const id = newId("prj");
  const count = db().get("SELECT COUNT(*) AS n FROM projects")?.n ?? 0;
  const folder = validateFolder(body?.folderPath, !!body?.createFolder);
  db().upsert("projects", {
    id,
    name,
    icon: typeof body?.icon === "string" && body.icon.length < 30 ? body.icon : ICONS[count % ICONS.length],
    color: /^#[0-9a-fA-F]{6}$/.test(body?.color ?? "") ? body.color : ["#7C7FFF", "#3FB98A", "#E58A5B", "#D9608C", "#4FA8E8", "#E0B341"][count % 6],
    description: str(body?.description ?? "", "description", { max: 2e3, optional: true }),
    folder_path: folder,
    instructions: str(body?.instructions ?? "", "instructions", { max: 2e4, optional: true }),
    memory: "",
    memory_updated_at: null,
    roblox_enabled: b(body?.robloxEnabled ?? /roblox/i.test(name + " " + (body?.description ?? ""))),
    defaults: j(body?.defaults ?? {}),
    created_at: now(),
    updated_at: now()
  });
  activity("project", `Created project \u201C${name}\u201D`, folder ?? "No folder linked");
  emit2(id);
  return getProject(id);
}
function updateProject(id, body) {
  const p = mustProject(id);
  const patch = { updated_at: now() };
  if (body.name !== void 0) patch.name = str(body.name, "Project name", { min: 1, max: 80 }).trim();
  if (body.icon !== void 0) patch.icon = String(body.icon).slice(0, 30);
  if (body.color !== void 0 && /^#[0-9a-fA-F]{6}$/.test(body.color)) patch.color = body.color;
  if (body.description !== void 0) patch.description = str(body.description, "description", { max: 2e3, optional: true });
  if (body.instructions !== void 0) patch.instructions = str(body.instructions, "instructions", { max: 2e4, optional: true });
  if (body.memory !== void 0) {
    patch.memory = str(body.memory, "memory", { max: 2e4, optional: true });
    patch.memory_updated_at = now();
  }
  if (body.folderPath !== void 0) {
    patch.folder_path = validateFolder(body.folderPath, !!body.createFolder);
    invalidateProject(id);
  }
  if (body.robloxEnabled !== void 0) patch.roblox_enabled = b(!!body.robloxEnabled);
  if (body.defaults !== void 0) patch.defaults = j({ ...p.defaults, ...body.defaults });
  db().update("projects", id, patch);
  emit2(id);
  return getProject(id);
}
function touchProject(id) {
  db().run("UPDATE projects SET updated_at = ? WHERE id = ?", now(), id);
}
function deleteProject(id) {
  const p = mustProject(id);
  db().tx(() => {
    db().run("UPDATE chats SET project_id = NULL WHERE project_id = ?", id);
    db().run("DELETE FROM file_changes WHERE project_id = ?", id);
    db().run("DELETE FROM projects WHERE id = ?", id);
  });
  invalidateProject(id);
  activity("project", `Deleted project \u201C${p.name}\u201D`, "Chats were kept and moved out of the project. No files were deleted.");
  events.emit("project.deleted", { id });
}
function recordChanges(projectId, changes, source, sourceId) {
  const out = [];
  for (const c of changes.slice(0, 500)) {
    const fc = {
      id: newId("chg"),
      projectId,
      path: c.path,
      change: c.change,
      source,
      sourceId,
      diff: unifiedDiff(c.path, c.beforeHash, c.afterHash),
      createdAt: now(),
      reverted: false
    };
    db().upsert("file_changes", {
      id: fc.id,
      project_id: projectId,
      path: fc.path,
      change: fc.change,
      source,
      source_id: sourceId,
      before_hash: c.beforeHash,
      after_hash: c.afterHash,
      diff: fc.diff,
      created_at: fc.createdAt,
      reverted: 0
    });
    out.push(fc);
  }
  if (out.length) {
    invalidateProject(projectId);
    events.emit("project.changes", { projectId, count: out.length, source, sourceId });
  }
  return out;
}
function listChanges(projectId, opts = {}) {
  const rows = opts.sourceId ? db().all("SELECT * FROM file_changes WHERE project_id = ? AND source_id = ? ORDER BY created_at DESC LIMIT ?", projectId, opts.sourceId, opts.limit ?? 500) : db().all("SELECT * FROM file_changes WHERE project_id = ? ORDER BY created_at DESC LIMIT ?", projectId, opts.limit ?? 300);
  return rows.map((r) => ({ id: r.id, projectId: r.project_id, path: r.path, change: r.change, source: r.source, sourceId: r.source_id, diff: r.diff, createdAt: r.created_at, reverted: !!r.reverted }));
}
function changesBySource(sourceId) {
  return db().all("SELECT * FROM file_changes WHERE source_id = ? ORDER BY created_at ASC", sourceId).map((r) => ({ id: r.id, projectId: r.project_id, path: r.path, change: r.change, source: r.source, sourceId: r.source_id, diff: r.diff, createdAt: r.created_at, reverted: !!r.reverted, beforeHash: r.before_hash }));
}
function revertChange(changeId) {
  const r = db().get("SELECT * FROM file_changes WHERE id = ?", changeId);
  if (!r) throw new HttpError(404, "Change not found");
  if (r.reverted) return;
  const p = mustProject(r.project_id);
  if (!p.folderPath) throw new HttpError(400, "Project has no folder");
  restoreFile(p.folderPath, r.path, r.before_hash);
  db().run("UPDATE file_changes SET reverted = 1 WHERE id = ?", changeId);
  invalidateProject(p.id);
  activity("files", `Reverted ${r.path}`, `Project \u201C${p.name}\u201D`, p.id);
  events.emit("project.changes", { projectId: p.id, count: 1, source: "revert", sourceId: r.source_id });
}

// src/server/services/blocks.ts
var MAX_TOOL_OUTPUT = 2e4;
function toolTitle(name, input) {
  if (!input || typeof input !== "object") return void 0;
  const v = input.file_path ?? input.path ?? input.command ?? input.pattern ?? input.query ?? input.url ?? input.target_file ?? input.description;
  return typeof v === "string" ? truncate(v.replace(/\s+/g, " "), 120) : void 0;
}
var BlockStream = class {
  constructor(initial = [], sink) {
    this.sink = sink;
    this.blocks = initial;
  }
  sink;
  blocks;
  toolOps = 0;
  filesTouched = /* @__PURE__ */ new Set();
  currentActivity = null;
  get text() {
    return this.blocks.filter((b2) => b2.type === "text").map((b2) => b2.text).join("\n\n").trim();
  }
  push(b2) {
    this.blocks.push(b2);
    this.sink?.block(this.blocks.length - 1, b2);
  }
  notice(level, text) {
    this.push({ type: "notice", level, text });
  }
  apply(e) {
    const last = this.blocks[this.blocks.length - 1];
    switch (e.type) {
      case "text":
        if (!e.text) return;
        if (last?.type === "text" && !e.newBlock) {
          last.text += e.text;
          this.sink?.delta(this.blocks.length - 1, "text", e.text);
        } else this.push({ type: "text", text: e.text });
        this.currentActivity = "Writing response";
        return;
      case "thinking":
        if (last?.type === "thinking") {
          last.text += e.text;
          this.sink?.delta(this.blocks.length - 1, "thinking", e.text);
        } else this.push({ type: "thinking", text: e.text });
        this.currentActivity = "Thinking";
        return;
      case "tool_start": {
        this.toolOps++;
        const title = e.title ?? toolTitle(e.name, e.input);
        this.push({ type: "tool", id: e.id, name: e.name, input: e.input, status: "running", title, server: e.server });
        this.currentActivity = `${e.name}${title ? ": " + title : ""}`;
        return;
      }
      case "tool_end": {
        const idx = this.blocks.findIndex((b3) => b3.type === "tool" && b3.id === e.id);
        if (idx < 0) return;
        const b2 = this.blocks[idx];
        b2.status = e.denied ? "denied" : e.isError ? "error" : "done";
        b2.output = e.output.length > MAX_TOOL_OUTPUT ? e.output.slice(0, MAX_TOOL_OUTPUT) + `
\u2026 (${e.output.length - MAX_TOOL_OUTPUT} more characters)` : e.output;
        this.sink?.block(idx, b2);
        return;
      }
      case "notice":
        this.notice(e.level, e.text);
        return;
      case "file_change":
        for (const p of e.paths) this.filesTouched.add(p);
        return;
      default:
        return;
    }
  }
};

// src/server/services/policy.ts
import path11 from "node:path";

// src/server/services/approvals.ts
var pending = /* @__PURE__ */ new Map();
var remembered = /* @__PURE__ */ new Map();
function rememberedAllow(requesterId, key) {
  return remembered.get(requesterId)?.has(key) ?? false;
}
function forgetRequester(requesterId) {
  remembered.delete(requesterId);
  for (const p of pending.values()) {
    if (p.approval.requester.id === requesterId) decide(p.approval.id, { allow: false, remember: "once", message: "Session ended" });
  }
}
function listApprovals() {
  return [...pending.values()].map((p) => p.approval);
}
function requestApproval(input) {
  const { rememberKey, ...rest } = input;
  if (rememberKey && rememberedAllow(rest.requester.id, rememberKey)) return Promise.resolve({ allow: true, remember: "session" });
  const timeoutSec = getSettings().agents.approvalTimeoutSec;
  const approval = { ...rest, id: newId("apr"), createdAt: now(), expiresAt: now() + timeoutSec * 1e3 };
  return new Promise((resolve) => {
    const timer = setTimeout(() => decide(approval.id, { allow: false, remember: "once", message: "No answer \u2014 denied automatically after timeout" }), timeoutSec * 1e3);
    pending.set(approval.id, {
      approval,
      timer,
      resolve: (d) => {
        if (d.allow && d.remember === "session" && rememberKey) {
          if (!remembered.has(rest.requester.id)) remembered.set(rest.requester.id, /* @__PURE__ */ new Set());
          remembered.get(rest.requester.id).add(rememberKey);
        }
        resolve(d);
      }
    });
    events.emit("approval.created", approval);
  });
}
function decide(id, d) {
  const p = pending.get(id);
  if (!p) throw new HttpError(404, "This approval request is no longer pending");
  clearTimeout(p.timer);
  pending.delete(id);
  p.resolve(d);
  events.emit("approval.resolved", { id, allow: d.allow });
  activity("approval", `${d.allow ? "Approved" : "Denied"}: ${p.approval.title}`, `${p.approval.requester.label}${d.message ? " \u2014 " + d.message : ""}`, p.approval.requester.id);
}
function denyAll(reason) {
  for (const id of [...pending.keys()]) decide(id, { allow: false, remember: "once", message: reason });
}

// src/server/services/policy.ts
function makePermissionHandler(ctx) {
  const s = () => getSettings().agents.approvals;
  const requester = { kind: ctx.kind, id: ctx.id, label: ctx.label };
  const ask = async (title, detail, req, rememberKey, kind) => {
    const d = await requestApproval({ kind, title, detail: truncate(detail, 4e3), toolName: req.toolName, input: req.input, requester, rememberKey });
    return { allow: d.allow, message: d.allow ? void 0 : d.message || "The user denied this action in BLOXADE." };
  };
  const byPolicy = async (policy, title, detail, req, rememberKey, kind) => {
    if (policy === "allow") return { allow: true };
    if (policy === "deny") return { allow: false, message: `BLOXADE settings do not allow ${kind === "command" ? "running commands" : "this action"} here.` };
    return ask(title, detail, req, rememberKey, kind);
  };
  return async (req) => {
    if (req.toolName.startsWith("mcp__bloxade_roblox")) return { allow: true };
    if (req.kind === "file_edit") {
      const abs = req.paths.map((p) => path11.resolve(ctx.cwd, p));
      if (!abs.length) return byPolicy(s().edits, "Edit files", req.description, req, "edit:*", "file_edit");
      const roots = [ctx.projectRoot, ...ctx.extraRoots].filter(Boolean);
      const outside = abs.filter((a) => !roots.some((r) => isInside(r, a)));
      if (outside.length) {
        const r = await ask("Edit a file outside the project folder", `${ctx.label} wants to modify:
${outside.join("\n")}`, req, `edit-outside:${outside.join("|")}`, "file_edit");
        if (r.allow) ctx.onEditAllowed?.(abs);
        return r;
      }
      for (const a of abs) {
        const holder = fileLocks.holder(a);
        if (holder && holder.id !== ctx.id) {
          const rel = ctx.projectRoot ? path11.relative(ctx.projectRoot, a) : a;
          const r = await ask(
            "Possible conflicting edit",
            `${ctx.label} wants to edit ${rel}, which is currently being edited by ${holder.label}.
Allowing this may overwrite their work.`,
            req,
            `conflict:${a}`,
            "conflict"
          );
          if (!r.allow) {
            const msg = `${rel} is owned by ${holder.label} right now. Do not edit it; describe the change you need in your final report instead.`;
            ctx.onDenied?.(req, msg);
            return { allow: false, message: msg };
          }
        }
      }
      let decision;
      if (ctx.task) {
        const rels = abs.map((a) => ctx.projectRoot ? path11.relative(ctx.projectRoot, a).split(path11.sep).join("/") : a);
        const allOwned = ctx.task.ownedPaths.length > 0 && rels.every((r) => matchOwned(ctx.task.ownedPaths, r));
        if (allOwned) decision = ctx.task.autoApprove.edits ? { allow: true } : await byPolicy(s().edits, "Edit files", `${ctx.label}: ${rels.join(", ")}`, req, "edit:owned", "file_edit");
        else if (ctx.task.autoApprove.edits && s().unownedEdits !== "deny") decision = { allow: true };
        else decision = await byPolicy(s().unownedEdits, "Edit a file outside this agent\u2019s assignment", `${ctx.label} wants to edit ${rels.join(", ")} (not in its assigned files: ${ctx.task.ownedPaths.join(", ") || "none"})`, req, `edit:${rels.join("|")}`, "file_edit");
      } else {
        decision = await byPolicy(s().edits, "Edit files", `${ctx.label} wants to modify:
${req.paths.join("\n")}`, req, "edit:*", "file_edit");
      }
      if (decision.allow) {
        for (const a of abs) fileLocks.claim(a, { id: ctx.id, label: ctx.label, runId: ctx.task?.runId ?? null });
        ctx.onEditAllowed?.(abs);
      } else ctx.onDenied?.(req, decision.message ?? "denied");
      return decision;
    }
    if (req.kind === "command") {
      if (ctx.task?.autoApprove.commands) return { allow: true };
      const d = await byPolicy(s().commands, "Run a command", `${ctx.label} wants to run:
${req.command || req.description}`, req, "command", "command");
      if (!d.allow) ctx.onDenied?.(req, d.message ?? "denied");
      return d;
    }
    if (ctx.task?.autoApprove.commands) return { allow: true };
    return byPolicy(s().commands === "deny" ? "ask" : s().commands, `Use ${req.toolName}`, `${ctx.label} wants to use ${req.toolName}:
${truncate(JSON.stringify(req.input ?? {}, null, 2), 1500)}`, req, `tool:${req.toolName}`, "tool");
  };
}

// src/server/services/prompts.ts
function systemPrompt(opts) {
  const parts = [];
  parts.push("You are running inside BLOXADE, a local AI development workspace. Format answers in Markdown.");
  if (opts.mode === "chat") {
    parts.push("Mode: Chat \u2014 you have no file, shell or Studio access in this mode. Answer from the conversation and any <bloxade_context> provided. If the user needs changes applied to files or Roblox Studio, tell them to switch to Cowork mode.");
  } else {
    parts.push(`Mode: Cowork \u2014 you may read and edit files in ${opts.cwd}. Change only what the request needs, prefer small targeted edits, and finish with a short summary listing the files you changed.`);
    parts.push("Some actions may require approval from the user in BLOXADE; if one is denied, adapt instead of retrying the same action.");
  }
  if (opts.roblox && opts.mode === "cowork") {
    parts.push(
      "Roblox Studio is connected through the `bloxade_roblox` MCP tools (the official Roblox Studio MCP, routed through BLOXADE\u2019s queue). Call list_roblox_studios once to get the studio_id. Inspect before editing (search_game_tree, script_search, script_grep, script_read); edit scripts with multi_edit; use execute_luau for object/property changes; check get_console_output after changes. Studio write actions may need user approval and are serialized with other agents."
    );
  }
  if (opts.role) parts.push(opts.role);
  if (opts.project) {
    parts.push(`Project: ${opts.project.name}${opts.project.description ? " \u2014 " + opts.project.description : ""}`);
    if (opts.project.instructions.trim()) parts.push(`Project instructions (from the user):
${opts.project.instructions.trim()}`);
  }
  return parts.join("\n\n");
}

// src/server/services/usage.ts
function recordUsage(e) {
  const u = e.usage;
  const verified = !!u?.verified;
  db().upsert("usage_events", {
    id: newId("use"),
    ts: now(),
    provider: e.provider,
    account_id: e.accountId,
    model: e.model,
    kind: e.kind,
    ref_id: e.refId,
    input_tokens: verified ? u?.inputTokens ?? 0 : 0,
    output_tokens: verified ? u?.outputTokens ?? 0 : 0,
    cache_read: verified ? u?.cacheReadTokens ?? 0 : 0,
    cache_write: verified ? u?.cacheWriteTokens ?? 0 : 0,
    reasoning: verified ? u?.reasoningTokens ?? 0 : 0,
    cost_usd: u?.costUsd ?? null,
    verified: verified ? 1 : 0,
    estimated_tokens: Math.round(e.estimatedTokens),
    context_saved: Math.round(e.contextSaved),
    duration_ms: e.durationMs,
    ok: e.ok ? 1 : 0
  });
  events.emit("usage.recorded", { provider: e.provider });
}
function usageSummary(range, live) {
  const span = range === "24h" ? 864e5 : range === "7d" ? 7 * 864e5 : range === "30d" ? 30 * 864e5 : 3650 * 864e5;
  const since = now() - span;
  const t = db().get(
    `SELECT COALESCE(SUM(CASE WHEN verified=1 THEN input_tokens END),0) vi, COALESCE(SUM(CASE WHEN verified=1 THEN output_tokens END),0) vo,
      COALESCE(SUM(CASE WHEN verified=1 THEN cache_read END),0) cr, COALESCE(SUM(CASE WHEN verified=1 THEN cache_write END),0) cw,
      COALESCE(SUM(cost_usd),0) cost, COALESCE(SUM(estimated_tokens),0) est, COALESCE(SUM(context_saved),0) saved, COUNT(*) turns
     FROM usage_events WHERE ts >= ?`,
    since
  );
  const byProvider = db().all(
    `SELECT provider, COUNT(*) turns, COALESCE(SUM(input_tokens),0) input, COALESCE(SUM(output_tokens),0) output, COALESCE(SUM(cost_usd),0) cost
       FROM usage_events WHERE ts >= ? GROUP BY provider`,
    since
  ).map((r) => ({ provider: r.provider, turns: r.turns, input: r.input, output: r.output, costUsd: r.cost }));
  const byModel = db().all(
    `SELECT COALESCE(model,'(default)') model, provider, COUNT(*) turns, COALESCE(SUM(input_tokens),0) input, COALESCE(SUM(output_tokens),0) output
       FROM usage_events WHERE ts >= ? GROUP BY model, provider ORDER BY turns DESC LIMIT 12`,
    since
  ).map((r) => ({ model: r.model, provider: r.provider, turns: r.turns, input: r.input, output: r.output }));
  const bucketMs = range === "24h" ? 36e5 : 864e5;
  const buckets = range === "24h" ? 24 : range === "7d" ? 7 : range === "30d" ? 30 : 30;
  const start = Math.floor((now() - (buckets - 1) * bucketMs) / bucketMs) * bucketMs;
  const rows = db().all(`SELECT CAST(ts / ? AS INTEGER) * ? AS bucket, provider, COUNT(*) n FROM usage_events WHERE ts >= ? GROUP BY bucket, provider`, bucketMs, bucketMs, start);
  const timeline = [];
  for (let i = 0; i < buckets; i++) {
    const bucket = start + i * bucketMs;
    timeline.push({ bucket, claude: rows.find((r) => r.bucket === bucket && r.provider === "claude")?.n ?? 0, codex: rows.find((r) => r.bucket === bucket && r.provider === "codex")?.n ?? 0 });
  }
  const tk = db().get(
    `SELECT SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) completed, SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END) failed,
      SUM(CASE WHEN status='working' THEN 1 ELSE 0 END) running,
      AVG(CASE WHEN status='completed' AND started_at IS NOT NULL AND finished_at IS NOT NULL THEN finished_at - started_at END) avgms
     FROM tasks WHERE created_at >= ?`,
    since
  );
  return {
    range,
    totals: {
      verifiedInput: t.vi,
      verifiedOutput: t.vo,
      verifiedCacheRead: t.cr,
      verifiedCacheWrite: t.cw,
      reportedCostUsd: t.cost,
      estimatedTokens: t.est,
      contextSavedEstimate: t.saved,
      turns: t.turns
    },
    byProvider,
    byModel,
    timeline,
    tasks: { completed: tk?.completed ?? 0, failed: tk?.failed ?? 0, running: tk?.running ?? 0, avgDurationMs: tk?.avgms ?? null },
    active: live,
    accounts: listAccounts().map((a) => ({ id: a.id, name: a.name, provider: a.provider, limits: a.limits ?? null })),
    recentActivity: listActivity(30).map((a) => ({ ts: a.ts, kind: a.kind, label: a.label, detail: a.detail }))
  };
}

// src/server/providers/index.ts
async function runTurn(provider, req) {
  touchAccount(req.account.id);
  const onEvent = req.onEvent;
  const wrapped = {
    ...req,
    onEvent: (e) => {
      if (e.type === "limits") recordLimits(req.account.id, e.limits);
      onEvent(e);
    }
  };
  return provider === "claude" ? runClaudeTurn(wrapped) : runCodexTurn(wrapped);
}
async function complete(provider, req) {
  return runTurn(provider, {
    ...req,
    mode: "chat",
    resume: null,
    forkFrom: null,
    onPermission: async () => ({ allow: false, message: "Tools are disabled for this request" }),
    onEvent: (e) => {
      if (e.type === "text") req.onText?.(e.text);
    }
  });
}

// src/server/roblox/sessions.ts
import { randomBytes as randomBytes2 } from "node:crypto";
var sessions = /* @__PURE__ */ new Map();
function createBridgeSession(caller) {
  const token = randomBytes2(24).toString("hex");
  sessions.set(token, { ...caller, token, createdAt: Date.now(), lastSeen: null, initialized: false });
  return token;
}
function getBridgeSession(token) {
  if (!token) return null;
  return sessions.get(token) ?? null;
}
function revokeBridgeSession(token) {
  if (token) sessions.delete(token);
}
function connectedBridgeSessions() {
  return [...sessions.values()].filter((s) => s.initialized).map((s) => ({ id: s.id, label: s.label, since: s.lastSeen ?? s.createdAt }));
}

// src/server/roblox/manager.ts
import fs13 from "node:fs";

// src/server/roblox/mcpClient.ts
import { EventEmitter as EventEmitter2 } from "node:events";
var log9 = logger("mcp");
function parseCommandLine(line) {
  const expanded = line.replace(/%([^%]+)%/g, (m, n) => process.env[n] ?? m).replace(/\$\{?([A-Z_][A-Z0-9_]*)\}?/g, (m, n) => process.env[n] ?? m);
  const parts = [];
  let cur = "";
  let q = null;
  for (const ch of expanded.trim()) {
    if (q) {
      if (ch === q) q = null;
      else cur += ch;
    } else if (ch === '"' || ch === "'") q = ch;
    else if (/\s/.test(ch)) {
      if (cur) parts.push(cur);
      cur = "";
    } else cur += ch;
  }
  if (cur) parts.push(cur);
  if (!parts.length) throw new Error("No MCP server command configured");
  return { command: parts[0], args: parts.slice(1) };
}
var McpStdioClient = class extends EventEmitter2 {
  constructor(commandLine, label = "Roblox Studio MCP") {
    super();
    this.commandLine = commandLine;
    this.label = label;
  }
  commandLine;
  label;
  proc = null;
  nextId = 1;
  pending = /* @__PURE__ */ new Map();
  stderrTail = [];
  serverInfo = null;
  capabilities = null;
  get alive() {
    return !!this.proc && this.proc.child.exitCode === null;
  }
  async start(timeoutMs = 25e3) {
    const { command, args } = parseCommandLine(this.commandLine);
    this.proc = spawnTracked(command, args, { stdio: ["pipe", "pipe", "pipe"], kind: "mcp", label: this.label });
    const child = this.proc.child;
    onLines(child.stdout, (l) => this.onLine(l));
    onLines(child.stderr, (l) => {
      this.stderrTail.push(l);
      if (this.stderrTail.length > 60) this.stderrTail.shift();
    });
    child.on("exit", (code) => {
      for (const p of this.pending.values()) {
        clearTimeout(p.timer);
        p.reject(new Error(`MCP server exited (code ${code}). ${this.stderrTail.slice(-2).join(" ")}`));
      }
      this.pending.clear();
      this.proc = null;
      this.emit("exit", code);
    });
    await new Promise((resolve, reject) => {
      child.once("spawn", () => resolve());
      child.once("error", (e) => reject(new Error(`Could not start '${command}': ${e.message}`)));
    });
    const init = await this.request(
      "initialize",
      { protocolVersion: "2025-06-18", capabilities: { roots: { listChanged: false } }, clientInfo: { name: "bloxade", title: "BLOXADE", version: VERSION } },
      timeoutMs
    );
    this.serverInfo = init?.serverInfo ?? null;
    this.capabilities = init?.capabilities ?? null;
    this.notify("notifications/initialized", {});
    return init;
  }
  write(obj) {
    const stdin = this.proc?.child.stdin;
    if (!stdin || stdin.destroyed) throw new Error("MCP server is not running");
    stdin.write(JSON.stringify({ jsonrpc: "2.0", ...obj }) + "\n");
  }
  request(method, params, timeoutMs = 6e4) {
    const id = this.nextId++;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`MCP '${method}' timed out after ${Math.round(timeoutMs / 1e3)}s`));
      }, timeoutMs);
      this.pending.set(id, { resolve, reject, timer });
      try {
        this.write({ id, method, params });
      } catch (e) {
        clearTimeout(timer);
        this.pending.delete(id);
        reject(e);
      }
    });
  }
  notify(method, params) {
    try {
      this.write({ method, params });
    } catch {
    }
  }
  onLine(line) {
    const msg = safeJson(line, null);
    if (!msg || typeof msg !== "object") return;
    if (msg.id !== void 0 && msg.method === void 0) {
      const p = this.pending.get(msg.id);
      if (!p) return;
      clearTimeout(p.timer);
      this.pending.delete(msg.id);
      if (msg.error) p.reject(new Error(msg.error.message ?? "MCP error"));
      else p.resolve(msg.result);
      return;
    }
    if (msg.method && msg.id !== void 0) {
      let result = {};
      if (msg.method === "roots/list") result = { roots: [] };
      else if (msg.method === "ping") result = {};
      else if (msg.method === "elicitation/create") result = { action: "decline" };
      else {
        this.write({ id: msg.id, error: { code: -32601, message: `BLOXADE does not support ${msg.method}` } });
        return;
      }
      this.write({ id: msg.id, result });
      return;
    }
    if (msg.method) this.emit("notification", msg.method, msg.params);
  }
  async listTools() {
    const tools = [];
    let cursor;
    for (let i = 0; i < 20; i++) {
      const r = await this.request("tools/list", cursor ? { cursor } : {}, 3e4);
      tools.push(...r?.tools ?? []);
      cursor = r?.nextCursor;
      if (!cursor) break;
    }
    return tools;
  }
  callTool(name, args, timeoutMs) {
    return this.request("tools/call", { name, arguments: args ?? {} }, timeoutMs);
  }
  stop() {
    if (this.proc) {
      log9.info("stopping MCP server");
      killTree(this.proc.child);
    }
    this.proc = null;
  }
};

// src/server/roblox/manager.ts
var log10 = logger("roblox");
var KNOWN_READ_ONLY = /* @__PURE__ */ new Set([
  "list_roblox_studios",
  "get_studio_state",
  "get_console_output",
  "inspect_instance",
  "script_read",
  "script_search",
  "script_grep",
  "search_game_tree",
  "search_asset",
  "screen_capture",
  "http_get",
  "skill",
  "wait_job_finished"
]);
var LONG_RUNNING = /* @__PURE__ */ new Set(["generate_mesh", "generate_material", "generate_procedural_model", "generate_texture", "segment_mesh", "wait_job_finished", "subagent"]);
var RobloxManager = class {
  client = null;
  tools = [];
  state = "disconnected";
  error = null;
  studios = [];
  activeStudioId = null;
  studioState = null;
  lastTest = null;
  connecting = null;
  connectedAt = null;
  writeChain = Promise.resolve();
  writeQueueLen = 0;
  runningWrite = null;
  readsInFlight = 0;
  cache = /* @__PURE__ */ new Map();
  autoApproveCallers = /* @__PURE__ */ new Set();
  isReadOnly(t) {
    if (t.annotations?.readOnlyHint === true) return true;
    if (t.annotations?.readOnlyHint === false || t.annotations?.destructiveHint) return false;
    return KNOWN_READ_ONLY.has(t.name);
  }
  policyFor(t) {
    const p = getSettings().roblox.toolPolicies[t.name];
    if (p) return p;
    return this.isReadOnly(t) ? "allow" : "ask";
  }
  status() {
    const s = getSettings().roblox;
    return {
      enabled: s.enabled,
      state: this.state,
      command: s.command,
      error: this.error,
      serverInfo: this.client?.serverInfo ?? null,
      tools: this.tools.map((t) => ({ name: t.name, description: (t.description ?? "").split("\n")[0].slice(0, 300), readOnly: this.isReadOnly(t), policy: this.policyFor(t) })),
      studios: this.studios,
      activeStudioId: this.activeStudioId,
      studioState: this.studioState,
      lastTest: this.lastTest,
      connectedAgents: connectedBridgeSessions(),
      queue: { pending: this.writeQueueLen, running: this.runningWrite },
      stderrTail: this.client?.stderrTail.slice(-12) ?? [],
      connectedAt: this.connectedAt
    };
  }
  emit() {
    events.emit("roblox.status", this.status());
  }
  setAutoApprove(callerId, on) {
    if (on) this.autoApproveCallers.add(callerId);
    else this.autoApproveCallers.delete(callerId);
  }
  async connect() {
    if (this.state === "connected" && this.client?.alive) return;
    if (this.connecting) return this.connecting;
    this.connecting = this.doConnect().finally(() => this.connecting = null);
    return this.connecting;
  }
  async doConnect() {
    const s = getSettings().roblox;
    if (!s.enabled) throw new Error("Roblox Studio integration is turned off in Settings \u2192 Roblox Studio");
    if (!s.command.trim()) throw new Error("No Roblox Studio MCP command configured (Settings \u2192 Roblox Studio)");
    this.state = "connecting";
    this.error = null;
    this.emit();
    this.client?.stop();
    const client = new McpStdioClient(s.command);
    this.client = client;
    client.on("exit", () => {
      if (this.client !== client) return;
      this.state = "disconnected";
      this.error = this.error ?? "Roblox Studio MCP server stopped";
      this.connectedAt = null;
      this.cache.clear();
      this.emit();
      activity("roblox", "Roblox Studio disconnected", this.error ?? "");
    });
    client.on("notification", (method) => {
      if (method === "notifications/tools/list_changed") void this.refreshTools();
    });
    try {
      await client.start();
      this.tools = await client.listTools();
      this.state = "connected";
      this.connectedAt = now();
      await this.refreshStudios().catch((e) => log10.warn("studio list failed", e.message));
      activity("roblox", "Roblox Studio connected", `${this.tools.length} tools \xB7 ${this.studios.map((x) => x.name).join(", ") || "no open places reported"}`);
    } catch (e) {
      this.state = "error";
      this.error = this.explain(e.message);
      client.stop();
      this.emit();
      throw new Error(this.error);
    }
    this.emit();
  }
  explain(msg) {
    if (/ENOENT|not recognized|cannot find/i.test(msg) || /exited \(code 1\)/.test(msg)) {
      return `${msg}
Make sure Roblox Studio is installed and open, and that \u201CEnable Studio as MCP server\u201D is on (Studio \u2192 Assistant \u2192 \u2026 \u2192 Manage MCP Servers).`;
    }
    if (/timed out/i.test(msg)) return `${msg}
Roblox Studio may be closed or the MCP server toggle is off.`;
    return msg;
  }
  async refreshTools() {
    if (!this.client?.alive) return;
    this.tools = await this.client.listTools();
    this.emit();
  }
  async refreshStudios() {
    if (!this.client?.alive) throw new Error("Not connected");
    if (this.tools.some((t) => t.name === "list_roblox_studios")) {
      const r = await this.client.callTool("list_roblox_studios", {}, 2e4);
      const text = textOf(r);
      try {
        const data = JSON.parse(text);
        this.studios = (data.studios ?? data ?? []).map((x) => ({ id: String(x.id), name: String(x.name ?? x.id) }));
      } catch {
        this.studios = [];
      }
    }
    const pref = getSettings().roblox.defaultStudioId;
    if (!this.activeStudioId || !this.studios.some((x) => x.id === this.activeStudioId)) {
      this.activeStudioId = this.studios.find((x) => x.id === pref)?.id ?? this.studios[0]?.id ?? null;
    }
    if (this.activeStudioId && this.tools.some((t) => t.name === "get_studio_state")) {
      const st = await this.client.callTool("get_studio_state", { studio_id: this.activeStudioId }, 2e4).catch(() => null);
      this.studioState = st ? truncate(textOf(st), 600) : null;
    }
    this.emit();
  }
  selectStudio(id) {
    if (!this.studios.some((s) => s.id === id)) throw new Error("That Studio instance is not connected");
    this.activeStudioId = id;
    this.cache.clear();
    this.emit();
  }
  disconnect() {
    const c = this.client;
    this.client = null;
    c?.stop();
    this.state = "disconnected";
    this.error = null;
    this.tools = [];
    this.connectedAt = null;
    this.cache.clear();
    this.emit();
  }
  async test() {
    const t0 = now();
    try {
      await this.connect();
      await this.refreshStudios();
      const msg = this.studios.length ? `Connected \xB7 ${this.studios.length} Studio instance${this.studios.length === 1 ? "" : "s"}: ${this.studios.map((s) => s.name).join(", ")}` : "MCP server answered, but no open Studio place was reported. Open a place in Roblox Studio.";
      this.lastTest = { ok: this.studios.length > 0, at: now(), latencyMs: now() - t0, message: msg };
    } catch (e) {
      this.lastTest = { ok: false, at: now(), latencyMs: now() - t0, message: e.message };
    }
    this.emit();
    return this.lastTest;
  }
  /** Tools exposed to agents through the BLOXADE bridge (deny-listed tools hidden, studio_id optional). */
  async agentTools() {
    try {
      await this.connect();
    } catch (e) {
      log10.warn("agent requested Studio tools but connection failed", e.message);
      return [];
    }
    return this.tools.filter((t) => this.policyFor(t) !== "deny").map((t) => {
      const schema = t.inputSchema ? JSON.parse(JSON.stringify(t.inputSchema)) : { type: "object", properties: {} };
      if (Array.isArray(schema.required)) schema.required = schema.required.filter((r) => r !== "studio_id");
      const ro = this.isReadOnly(t);
      return {
        name: t.name,
        description: `${t.description ?? ""}${ro ? "" : "\n\n[BLOXADE] Write action: may need user approval and runs in a shared queue with other agents."}${schema.properties?.studio_id ? "\n[BLOXADE] studio_id is optional \u2014 the active Studio instance is used when omitted." : ""}`,
        inputSchema: schema,
        annotations: { ...t.annotations ?? {}, readOnlyHint: ro }
      };
    });
  }
  /** Central entry point for every Studio tool call (agents, chats and the manual console). */
  async call(name, rawArgs, caller) {
    const t0 = now();
    await this.connect();
    const tool = this.tools.find((t) => t.name === name);
    if (!tool) return errorResult(`Unknown Roblox Studio tool '${name}'`);
    const args = { ...rawArgs ?? {} };
    if (tool.inputSchema?.properties?.studio_id && !args.studio_id) {
      if (!this.activeStudioId) await this.refreshStudios().catch(() => void 0);
      if (this.activeStudioId) args.studio_id = this.activeStudioId;
    }
    const readOnly = this.isReadOnly(tool);
    const policy = this.policyFor(tool);
    const summary = summarize(name, args);
    if (policy === "deny" && caller.kind !== "user") {
      this.log(caller, name, summary, "denied", t0);
      return errorResult(`BLOXADE settings block the Roblox Studio tool '${name}'.`);
    }
    const lockKey = name === "multi_edit" && typeof args.file_path === "string" ? `script:${String(args.file_path).replace(/^game\./i, "").toLowerCase()}` : null;
    if (lockKey && caller.kind !== "user") {
      const holder = studioLocks.holder(lockKey);
      if (holder && holder.id !== caller.id) {
        const d = await requestApproval({
          kind: "conflict",
          title: "Conflicting Studio script edit",
          detail: `${caller.label} wants to edit ${args.file_path}, which ${holder.label} is currently editing.`,
          toolName: name,
          input: args,
          requester: { kind: caller.kind, id: caller.id, label: caller.label }
        });
        if (!d.allow) {
          this.log(caller, name, summary, "denied", t0);
          return errorResult(`${args.file_path} is being edited by ${holder.label}. Do not edit it now; describe the change you need in your report.`);
        }
      }
    }
    if (!readOnly && policy === "ask" && caller.kind !== "user" && !this.autoApproveCallers.has(caller.id) && !(caller.runId && this.autoApproveCallers.has(caller.runId))) {
      const d = await requestApproval({
        kind: "studio",
        title: `Roblox Studio: ${name}`,
        detail: `${caller.label} wants to run ${name} in ${this.studios.find((s) => s.id === args.studio_id)?.name ?? "Roblox Studio"}.

${truncate(JSON.stringify(args, null, 2), 3500)}`,
        toolName: name,
        input: args,
        requester: { kind: caller.kind, id: caller.id, label: caller.label },
        rememberKey: `studio:${name}`
      });
      if (!d.allow) {
        this.log(caller, name, summary, "denied", t0);
        return errorResult(d.message || "The user denied this Roblox Studio action.");
      }
    }
    if (lockKey && caller.kind !== "user") studioLocks.claim(lockKey, { id: caller.id, label: caller.label, runId: caller.runId ?? null });
    const cacheKey = readOnly && getSettings().roblox.cacheReads && name !== "get_console_output" && name !== "screen_capture" && name !== "get_studio_state" ? `${name}:${stableStringify(args)}` : null;
    if (cacheKey) {
      const c = this.cache.get(cacheKey);
      if (c && now() - c.at < 3e4) {
        this.log(caller, name, summary, "cached", t0);
        return withNote(c.result, "[BLOXADE] Result served from the shared Studio cache (no change since it was last read).");
      }
    }
    const timeout = LONG_RUNNING.has(name) ? 11 * 6e4 : name === "execute_luau" ? 3 * 6e4 : 2 * 6e4;
    const exec = async () => {
      if (!this.client?.alive) await this.connect();
      return this.client.callTool(name, args, timeout);
    };
    let result;
    try {
      if (readOnly) {
        this.readsInFlight++;
        try {
          result = await exec();
        } finally {
          this.readsInFlight--;
        }
      } else {
        this.writeQueueLen++;
        this.emit();
        const run = this.writeChain.then(async () => {
          this.writeQueueLen--;
          this.runningWrite = `${name} (${caller.label})`;
          this.emit();
          try {
            return await exec();
          } finally {
            this.runningWrite = null;
            this.cache.clear();
            this.emit();
          }
        });
        this.writeChain = run.catch(() => void 0);
        result = await run;
      }
    } catch (e) {
      this.log(caller, name, summary, "error", t0);
      return errorResult(`Roblox Studio call failed: ${e.message}`);
    }
    const cap = getSettings().context.toolOutputCap ?? EFFICIENCY_PROFILES[getSettings().context.mode].toolOutputCap;
    let saved = 0;
    const content = (result.content ?? []).map((c) => {
      if (c?.type === "text" && typeof c.text === "string" && caller.kind !== "user") {
        const r = compressOutput(c.text, cap);
        saved += r.saved;
        return { ...c, text: r.text };
      }
      return c;
    });
    const out = { ...result, content };
    if (cacheKey && !result.isError) this.cache.set(cacheKey, { at: now(), result: out });
    if (name === "list_roblox_studios" && !result.isError) {
      try {
        const data = JSON.parse(textOf(result));
        this.studios = (data.studios ?? []).map((x) => ({ id: String(x.id), name: String(x.name ?? x.id) }));
      } catch {
      }
    }
    this.log(caller, name, summary + (saved ? ` \xB7 trimmed ~${saved} tokens` : ""), result.isError ? "error" : "ok", t0);
    return out;
  }
  log(caller, tool, summary, status, t0) {
    const e = { id: newId("rbx"), ts: now(), caller: caller.label, tool, summary: truncate(summary, 300), status, durationMs: now() - t0 };
    try {
      db().run("INSERT INTO roblox_activity (id, ts, caller, tool, summary, status, duration_ms) VALUES (?, ?, ?, ?, ?, ?, ?)", e.id, e.ts, e.caller, e.tool, e.summary, e.status, e.durationMs);
    } catch {
    }
    events.emit("roblox.activity", e);
  }
  releaseCaller(callerId) {
    studioLocks.release(callerId);
    this.autoApproveCallers.delete(callerId);
  }
  async diagnostics() {
    const s = getSettings().roblox;
    const out = { command: s.command, enabled: s.enabled, state: this.state, error: this.error };
    try {
      const { command, args } = parseCommandLine(s.command);
      out.parsed = { command, args };
      const bat = args.find((a) => /\.bat$|StudioMCP/i.test(a)) ?? (/StudioMCP/i.test(command) ? command : null);
      if (bat) out.launcherExists = fs13.existsSync(bat);
    } catch (e) {
      out.parseError = e.message;
    }
    if (IS_WIN) {
      const r = await runCapture("tasklist", ["/FI", "IMAGENAME eq RobloxStudioBeta.exe", "/NH"], { timeoutMs: 8e3 });
      out.studioProcessRunning = /RobloxStudioBeta\.exe/i.test(r.stdout);
    }
    return out;
  }
  shutdown() {
    this.client?.stop();
    this.client = null;
  }
};
function textOf(r) {
  return (r?.content ?? []).filter((c) => c?.type === "text").map((c) => c.text).join("\n");
}
function errorResult(text) {
  return { content: [{ type: "text", text }], isError: true };
}
function withNote(r, note) {
  return { ...r, content: [...r.content ?? [], { type: "text", text: note }] };
}
function stableStringify(v) {
  if (v && typeof v === "object" && !Array.isArray(v)) return "{" + Object.keys(v).sort().map((k) => JSON.stringify(k) + ":" + stableStringify(v[k])).join(",") + "}";
  return JSON.stringify(v);
}
function summarize(name, args) {
  const pick = args.file_path ?? args.target_file ?? args.path ?? args.instance_path ?? args.query ?? args.keywords ?? args.prompt ?? args.textPrompt ?? (args.code ? String(args.code).split("\n")[0] : null);
  return pick ? truncate(String(pick).replace(/\s+/g, " "), 160) : name;
}
var roblox = new RobloxManager();
function robloxAvailableFor() {
  const s = getSettings().roblox;
  return s.enabled && !!s.command.trim();
}
function listRobloxActivity(limit = 150) {
  return db().all("SELECT * FROM roblox_activity ORDER BY ts DESC LIMIT ?", limit).map((r) => ({ id: r.id, ts: r.ts, caller: r.caller, tool: r.tool, summary: r.summary, status: r.status, durationMs: r.duration_ms }));
}

// src/server/services/chats.ts
var log11 = logger("chat");
var active = /* @__PURE__ */ new Map();
registerSessionCounter(() => {
  const m = /* @__PURE__ */ new Map();
  for (const r of active.values()) m.set(r.accountId, (m.get(r.accountId) ?? 0) + 1);
  return m;
});
function runningChatIds() {
  return [...active.keys()];
}
function toChat(r) {
  return {
    id: r.id,
    title: r.title,
    projectId: r.project_id,
    pinned: !!r.pinned,
    provider: r.provider,
    accountId: r.account_id,
    model: r.model,
    effort: r.effort,
    mode: r.mode,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
    preview: r.preview ?? "",
    running: active.has(r.id),
    branchedFrom: safeJson(r.branched_from, null)
  };
}
function toMessage(r) {
  return {
    id: r.id,
    chatId: r.chat_id,
    role: r.role,
    content: r.content,
    blocks: safeJson(r.blocks, []),
    status: r.status,
    attachments: safeJson(r.attachments, []),
    usage: safeJson(r.usage, null),
    error: r.error,
    provider: r.provider,
    accountId: r.account_id,
    model: r.model,
    effort: r.effort,
    mode: r.mode,
    providerRef: safeJson(r.provider_ref, null),
    createdAt: r.created_at,
    durationMs: r.duration_ms
  };
}
function listChats(opts = {}) {
  const rows = opts.projectId ? db().all("SELECT * FROM chats WHERE project_id = ? ORDER BY pinned DESC, updated_at DESC LIMIT ?", opts.projectId, opts.limit ?? 500) : db().all("SELECT * FROM chats ORDER BY pinned DESC, updated_at DESC LIMIT ?", opts.limit ?? 300);
  return rows.map(toChat);
}
function getChatRow(id) {
  const r = db().get("SELECT * FROM chats WHERE id = ?", id);
  if (!r) throw new HttpError(404, "Chat not found");
  return r;
}
function getChat(id) {
  const r = getChatRow(id);
  const msgs = db().all("SELECT * FROM messages WHERE chat_id = ? ORDER BY seq ASC", id).map(toMessage);
  return { chat: { ...toChat(r), messageCount: msgs.length }, messages: msgs };
}
function searchChats(q) {
  const like = `%${q.replace(/[%_]/g, (m) => "\\" + m)}%`;
  const titleHits = db().all("SELECT * FROM chats WHERE title LIKE ? ESCAPE '\\' ORDER BY updated_at DESC LIMIT 30", like).map(toChat);
  const msgHits = db().all(
    "SELECT chat_id, id, content, role FROM messages WHERE content LIKE ? ESCAPE '\\' ORDER BY created_at DESC LIMIT 60",
    like
  );
  const results = titleHits.map((c) => ({ chat: c, messageId: null, snippet: c.preview ?? "" }));
  const seen = new Set(titleHits.map((c) => c.id));
  for (const m of msgHits) {
    if (seen.has(m.chat_id)) continue;
    const row = db().get("SELECT * FROM chats WHERE id = ?", m.chat_id);
    if (!row) continue;
    seen.add(m.chat_id);
    const i = m.content.toLowerCase().indexOf(q.toLowerCase());
    const snippet = (i > 40 ? "\u2026" : "") + m.content.slice(Math.max(0, i - 40), i + 120).replace(/\s+/g, " ");
    results.push({ chat: toChat(row), messageId: m.id, snippet });
    if (results.length >= 40) break;
  }
  return results;
}
function emitChat(id) {
  const r = db().get("SELECT * FROM chats WHERE id = ?", id);
  if (r) events.emit("chat.updated", toChat(r));
}
function createChat(body) {
  const s = getSettings();
  const project = body?.projectId ? getProject(body.projectId) : null;
  if (body?.projectId && !project) throw new HttpError(404, "Project not found");
  const provider = oneOf(body?.provider ?? project?.defaults.provider ?? s.providers.defaultProvider, ["claude", "codex"], "provider");
  const account = resolveAccount(provider, body?.accountId ?? project?.defaults.accountId ?? null);
  const id = newId("chat");
  const model = safeToken(body?.model ?? project?.defaults.model ?? s.providers.defaultModels[provider] ?? "", "model", true);
  const effort = safeToken(body?.effort ?? project?.defaults.effort ?? s.providers.defaultEfforts[provider] ?? "", "effort", true);
  const mode = oneOf(body?.mode ?? project?.defaults.mode ?? s.providers.defaultMode, ["chat", "cowork"], "mode");
  db().upsert("chats", {
    id,
    title: str(body?.title ?? "New chat", "title", { max: 200 }) || "New chat",
    project_id: project?.id ?? null,
    pinned: 0,
    provider,
    account_id: account?.id ?? null,
    model,
    effort,
    mode,
    created_at: now(),
    updated_at: now(),
    preview: "",
    branched_from: null,
    provider_ref: null,
    context_sent: null
  });
  emitChat(id);
  return toChat(getChatRow(id));
}
function updateChat(id, body) {
  const cur = getChatRow(id);
  const patch = {};
  if (body.title !== void 0) patch.title = str(body.title, "title", { min: 1, max: 200 }).trim();
  if (body.pinned !== void 0) patch.pinned = b(!!body.pinned);
  if (body.projectId !== void 0) {
    if (body.projectId && !getProject(body.projectId)) throw new HttpError(404, "Project not found");
    patch.project_id = body.projectId || null;
    patch.context_sent = null;
  }
  const sessionAffecting = [];
  if (body.provider !== void 0) {
    const p = oneOf(body.provider, ["claude", "codex"], "provider");
    if (p !== cur.provider) sessionAffecting.push("provider");
    patch.provider = p;
  }
  if (body.accountId !== void 0) {
    if (body.accountId !== cur.account_id) sessionAffecting.push("account");
    patch.account_id = body.accountId || null;
  }
  if (body.model !== void 0) patch.model = safeToken(body.model, "model", true);
  if (body.effort !== void 0) patch.effort = safeToken(body.effort, "effort", true);
  if (body.mode !== void 0) patch.mode = oneOf(body.mode, ["chat", "cowork"], "mode");
  if (sessionAffecting.length) {
    patch.provider_ref = j({ reseed: true });
    patch.context_sent = null;
  }
  if (Object.keys(patch).length) db().update("chats", id, { ...patch, updated_at: body.title !== void 0 || body.pinned !== void 0 ? cur.updated_at : now() });
  emitChat(id);
  return toChat(getChatRow(id));
}
function deleteChat(id) {
  getChatRow(id);
  stopChat(id);
  const atts = db().all("SELECT path FROM attachments WHERE chat_id = ?", id);
  db().tx(() => {
    db().run("DELETE FROM messages WHERE chat_id = ?", id);
    db().run("DELETE FROM attachments WHERE chat_id = ?", id);
    db().run("DELETE FROM chats WHERE id = ?", id);
  });
  for (const a of atts) {
    try {
      fs14.rmSync(path12.dirname(a.path), { recursive: true, force: true });
    } catch {
    }
  }
  events.emit("chat.deleted", { id });
}
var TEXT_EXT = /* @__PURE__ */ new Set([".txt", ".md", ".lua", ".luau", ".json", ".ts", ".tsx", ".js", ".jsx", ".py", ".css", ".html", ".xml", ".yaml", ".yml", ".toml", ".csv", ".log", ".rs", ".go", ".java", ".c", ".cpp", ".h", ".cs", ".sh", ".ps1", ".bat", ".sql", ".ini", ".cfg", ".rbxlx", ".rbxmx"]);
var IMAGE_MIME = /* @__PURE__ */ new Set(["image/png", "image/jpeg", "image/gif", "image/webp"]);
function saveAttachment(body) {
  const name = path12.basename(str(body?.name, "name", { min: 1, max: 200 })).replace(/[<>:"|?*\x00-\x1f]/g, "_");
  const mime = typeof body?.mime === "string" ? body.mime.slice(0, 100) : "application/octet-stream";
  const data = Buffer.from(str(body?.data, "data", { min: 1, max: 40 * 1024 * 1024 }), "base64");
  if (data.length > 25 * 1024 * 1024) throw new HttpError(413, "Attachments are limited to 25 MB");
  const id = newId("att");
  const dir = path12.join(dirs.attachments, id);
  fs14.mkdirSync(dir, { recursive: true });
  const file = path12.join(dir, name);
  fs14.writeFileSync(file, data);
  const ext = path12.extname(name).toLowerCase();
  const kind = IMAGE_MIME.has(mime) && data.length < 5 * 1024 * 1024 ? "image" : (mime.startsWith("text/") || TEXT_EXT.has(ext)) && data.length < 400 * 1024 ? "text" : "file";
  db().upsert("attachments", { id, chat_id: body?.chatId ?? null, name, mime, size: data.length, kind, path: file, created_at: now() });
  return { id, name, mime, size: data.length, kind };
}
function attachmentFile(id) {
  const r = db().get("SELECT path, mime, name FROM attachments WHERE id = ?", id);
  if (!r || !fs14.existsSync(r.path)) throw new HttpError(404, "Attachment not found");
  return r;
}
function nextSeq(chatId) {
  return (db().get("SELECT MAX(seq) AS s FROM messages WHERE chat_id = ?", chatId)?.s ?? 0) + 1;
}
function insertMessage(m, seq) {
  db().upsert("messages", {
    id: m.id,
    chat_id: m.chatId,
    seq,
    role: m.role,
    content: m.content,
    blocks: j(m.blocks),
    status: m.status,
    attachments: j(m.attachments),
    usage: j(m.usage ?? null),
    error: m.error ?? null,
    provider: m.provider ?? null,
    account_id: m.accountId ?? null,
    model: m.model ?? null,
    effort: m.effort ?? null,
    mode: m.mode ?? null,
    provider_ref: j(m.providerRef ?? null),
    created_at: m.createdAt,
    duration_ms: m.durationMs ?? null
  });
}
function persistMessage(m) {
  db().update("messages", m.id, {
    content: m.content,
    blocks: j(m.blocks),
    status: m.status,
    usage: j(m.usage ?? null),
    error: m.error ?? null,
    provider_ref: j(m.providerRef ?? null),
    duration_ms: m.durationMs ?? null,
    model: m.model ?? null
  });
}
function resolveAttachments(ids) {
  if (!Array.isArray(ids)) return [];
  return ids.slice(0, 12).map((id) => db().get("SELECT * FROM attachments WHERE id = ?", String(id))).filter(Boolean).map((r) => ({ id: r.id, name: r.name, mime: r.mime, size: r.size, kind: r.kind }));
}
function sendMessage(chatId, body) {
  const row = getChatRow(chatId);
  if (active.has(chatId)) throw new HttpError(409, "This chat is already generating a response. Stop it or wait for it to finish.");
  const text = str(body?.text ?? "", "message", { max: 2e5 });
  const attachments = resolveAttachments(body?.attachmentIds);
  if (!text.trim() && !attachments.length) throw new HttpError(400, "Message is empty");
  for (const a of attachments) db().run("UPDATE attachments SET chat_id = ? WHERE id = ?", chatId, a.id);
  const userMsg = { id: newId("msg"), chatId, role: "user", content: text, blocks: [{ type: "text", text }], status: "complete", attachments, createdAt: now() };
  insertMessage(userMsg, nextSeq(chatId));
  events.emit("chat.message", userMsg);
  if ((row.title === "New chat" || !row.title) && getSettings().general.autoTitle && text.trim()) {
    db().update("chats", chatId, { title: titleFrom(text) });
    emitChat(chatId);
  }
  const ref = safeJson(row.provider_ref, null);
  let opts;
  if (ref?.fork) opts = { resume: null, forkFrom: ref, reseed: false };
  else if (ref?.reseed) opts = { resume: null, forkFrom: null, reseed: true };
  else opts = { resume: ref, forkFrom: null, reseed: false };
  const assistant = startTurn(chatId, userMsg, opts);
  return { userMessage: userMsg, assistantMessage: assistant };
}
function previousAssistant(chatId, beforeSeq) {
  return db().get("SELECT * FROM messages WHERE chat_id = ? AND role = 'assistant' AND seq < ? AND status = 'complete' ORDER BY seq DESC LIMIT 1", chatId, beforeSeq);
}
function forkPointBefore(chatId, seq) {
  const prev = previousAssistant(chatId, seq);
  const ref = prev ? safeJson(prev.provider_ref, null) : null;
  return ref ?? {};
}
function regenerate(chatId) {
  getChatRow(chatId);
  if (active.has(chatId)) throw new HttpError(409, "Wait for the current response to finish");
  const lastUser = db().get("SELECT * FROM messages WHERE chat_id = ? AND role = 'user' ORDER BY seq DESC LIMIT 1", chatId);
  if (!lastUser) throw new HttpError(400, "Nothing to regenerate");
  const forkFrom = forkPointBefore(chatId, lastUser.seq);
  db().run("DELETE FROM messages WHERE chat_id = ? AND seq > ?", chatId, lastUser.seq);
  events.emit("chat.reload", { chatId });
  const assistant = startTurn(chatId, toMessage(lastUser), { resume: null, forkFrom, reseed: false, needsTranscript: !forkFrom.sessionId && !forkFrom.threadId && lastUser.seq > 1 });
  return { assistantMessage: assistant };
}
function editMessage(chatId, messageId, body) {
  getChatRow(chatId);
  if (active.has(chatId)) throw new HttpError(409, "Wait for the current response to finish");
  const msg = db().get("SELECT * FROM messages WHERE id = ? AND chat_id = ?", messageId, chatId);
  if (!msg || msg.role !== "user") throw new HttpError(400, "Only your own messages can be edited");
  const text = str(body?.text, "message", { min: 1, max: 2e5 });
  const forkFrom = forkPointBefore(chatId, msg.seq);
  db().run("DELETE FROM messages WHERE chat_id = ? AND seq > ?", chatId, msg.seq);
  db().update("messages", messageId, { content: text, blocks: j([{ type: "text", text }]) });
  events.emit("chat.reload", { chatId });
  const updated = { ...toMessage(msg), content: text, blocks: [{ type: "text", text }] };
  const assistant = startTurn(chatId, updated, { resume: null, forkFrom, reseed: false, needsTranscript: !forkFrom.sessionId && !forkFrom.threadId && msg.seq > 1 });
  return { assistantMessage: assistant };
}
function branchChat(chatId, messageId) {
  const row = getChatRow(chatId);
  const msg = db().get("SELECT * FROM messages WHERE id = ? AND chat_id = ?", messageId, chatId);
  if (!msg) throw new HttpError(404, "Message not found");
  const upto = msg.role === "assistant" ? msg.seq : msg.seq - 1;
  const rows = db().all("SELECT * FROM messages WHERE chat_id = ? AND seq <= ? ORDER BY seq", chatId, upto);
  const lastAssistant = [...rows].reverse().find((r) => r.role === "assistant" && r.status === "complete");
  const ref = lastAssistant ? safeJson(lastAssistant.provider_ref, null) : null;
  const id = newId("chat");
  db().tx(() => {
    db().upsert("chats", {
      id,
      title: `${row.title} (branch)`.slice(0, 200),
      project_id: row.project_id,
      pinned: 0,
      provider: row.provider,
      account_id: row.account_id,
      model: row.model,
      effort: row.effort,
      mode: row.mode,
      created_at: now(),
      updated_at: now(),
      preview: row.preview,
      branched_from: j({ chatId, messageId }),
      provider_ref: j(ref ? { ...ref, fork: true } : { reseed: rows.length > 0 }),
      context_sent: null
    });
    rows.forEach((r, i) => insertMessage({ ...toMessage(r), id: newId("msg"), chatId: id }, i + 1));
  });
  activity("chat", `Branched \u201C${row.title}\u201D`, `${rows.length} messages copied`, id);
  emitChat(id);
  return toChat(getChatRow(id));
}
function stopChat(chatId) {
  const r = active.get(chatId);
  if (r) r.abort.abort();
}
function stopAllChats() {
  for (const r of active.values()) r.abort.abort();
}
function transcriptFor(chatId, beforeSeq, maxChars) {
  const rows = db().all("SELECT role, content, seq FROM messages WHERE chat_id = ? AND seq < ? ORDER BY seq DESC LIMIT 40", chatId, beforeSeq);
  const lines = [];
  let used = 0;
  for (const r of rows) {
    const t = `${r.role === "user" ? "User" : "Assistant"}: ${r.content.length > 1500 ? r.content.slice(0, 1500) + " \u2026" : r.content}`;
    if (used + t.length > maxChars) break;
    lines.unshift(t);
    used += t.length;
  }
  return lines.length ? `<previous_conversation note="Earlier messages from this BLOXADE chat (compressed)">
${lines.join("\n\n")}
</previous_conversation>

` : "";
}
function buildPrompt(row, user, needsTranscript, userSeq) {
  const project = getProject(row.project_id);
  const s = getSettings();
  let prompt = "";
  let estSaved = 0;
  let packFiles = {};
  if (needsTranscript) prompt += transcriptFor(row.id, userSeq, 12e3);
  if (project && s.context.primeChats) {
    const sent = safeJson(row.context_sent, {});
    const firstTurn = Object.keys(sent).length === 0 && !safeJson(row.provider_ref, null)?.sessionId && !safeJson(row.provider_ref, null)?.threadId;
    const pack = buildContextPack({ project, query: user.content, alreadySent: sent, includeTree: firstTurn, includeMemory: firstTurn });
    if (pack) {
      prompt += pack.text + "\n\n";
      estSaved = pack.savedTokens;
      packFiles = pack.files;
    }
  }
  const images = [];
  const fileNotes = [];
  for (const a of user.attachments) {
    const f = db().get("SELECT path FROM attachments WHERE id = ?", a.id);
    if (!f) continue;
    if (a.kind === "image") images.push({ path: f.path, mime: a.mime });
    else if (a.kind === "text") {
      const content = fs14.readFileSync(f.path, "utf8");
      prompt += `<attachment name="${a.name.replace(/"/g, "")}">
${content.slice(0, 12e4)}
</attachment>

`;
    } else fileNotes.push(`- ${a.name} (${Math.round(a.size / 1024)} KB) saved at: ${f.path}`);
  }
  if (fileNotes.length) prompt += `Attached files:
${fileNotes.join("\n")}
${row.mode === "chat" ? "(Binary files can only be opened by the AI in Cowork mode.)\n" : ""}
`;
  prompt += user.content;
  return { prompt, images, project, estSaved, packFiles };
}
function startTurn(chatId, user, opts) {
  const row = getChatRow(chatId);
  const s = getSettings();
  const account = resolveAccount(row.provider, row.account_id);
  const assistant = {
    id: newId("msg"),
    chatId,
    role: "assistant",
    content: "",
    blocks: [],
    status: "streaming",
    attachments: [],
    createdAt: now(),
    provider: row.provider,
    accountId: account?.id ?? null,
    model: row.model,
    effort: row.effort,
    mode: row.mode
  };
  insertMessage(assistant, nextSeq(chatId));
  events.emit("chat.message", assistant);
  if (!account) {
    assistant.status = "error";
    assistant.error = `No ${row.provider === "claude" ? "Claude" : "Codex"} account is connected. Open Accounts to add one.`;
    persistMessage(assistant);
    events.emit("chat.done", assistant);
    return assistant;
  }
  if (!account.enabled) {
    assistant.status = "error";
    assistant.error = `The account \u201C${account.name}\u201D is disabled. Enable it in Accounts or pick another account.`;
    persistMessage(assistant);
    events.emit("chat.done", assistant);
    return assistant;
  }
  const abort = new AbortController();
  active.set(chatId, { chatId, messageId: assistant.id, accountId: account.id, abort, startedAt: now() });
  emitChat(chatId);
  events.emit("account.updated", { ...account, activeSessions: (account.activeSessions ?? 0) + 1 });
  void (async () => {
    const userSeq = db().get("SELECT seq FROM messages WHERE id = ?", user.id)?.seq ?? 0;
    const { prompt, images, project, estSaved, packFiles } = buildPrompt(row, user, opts.reseed || !!opts.needsTranscript, userSeq);
    const robloxOn = row.mode === "cowork" && !!project?.robloxEnabled && robloxAvailableFor();
    const workspace = path12.join(dirs.workspaces, chatId);
    fs14.mkdirSync(workspace, { recursive: true });
    const cwd = row.mode === "cowork" && project?.folderPath && fs14.existsSync(project.folderPath) ? project.folderPath : workspace;
    const label = `Chat \u201C${row.title === "New chat" ? titleFrom(user.content) : row.title}\u201D`;
    const bridgeToken = robloxOn ? createBridgeSession({ kind: "chat", id: chatId, label }) : null;
    let before = null;
    if (row.mode === "cowork" && project?.folderPath && cwd === project.folderPath) {
      try {
        before = snapshot(project.folderPath).snap;
      } catch (e) {
        log11.warn("snapshot failed", e.message);
      }
    }
    const persist = debounce(() => persistMessage(assistant), 700);
    const stream2 = new BlockStream(assistant.blocks, {
      block: (index, block) => {
        assistant.content = stream2.text;
        events.emit("chat.block", { chatId, messageId: assistant.id, index, block });
        persist();
      },
      delta: (index, kind, text) => {
        assistant.content = stream2.text;
        events.emit("chat.delta", { chatId, messageId: assistant.id, index, kind, text });
        persist();
      }
    });
    if (opts.reseed) stream2.notice("info", "Started a new provider session for this chat (provider or account changed); earlier messages were passed as compressed context.");
    const result = await runTurn(row.provider, {
      account,
      model: row.model,
      effort: row.effort,
      mode: row.mode,
      cwd,
      addDirs: [path12.join(dirs.attachments)],
      systemAppend: systemPrompt({ mode: row.mode, project, roblox: robloxOn, cwd }),
      prompt,
      images,
      resume: opts.resume,
      forkFrom: opts.forkFrom,
      bridgeToken,
      permissionMode: "ask",
      onPermission: makePermissionHandler({ kind: "chat", id: chatId, label, cwd, projectRoot: project?.folderPath ?? null, extraRoots: [workspace, dirs.attachments] }),
      onEvent: (e) => stream2.apply(e),
      signal: abort.signal,
      timeoutMs: s.advanced.turnTimeoutMin * 6e4,
      label
    }).catch((e) => ({ ok: false, cancelled: false, text: "", ref: {}, usage: null, error: e.message, durationMs: 0 }));
    persist.flush();
    revokeBridgeSession(bridgeToken);
    fileLocks.release(chatId);
    roblox.releaseCaller(chatId);
    forgetRequester(chatId);
    active.delete(chatId);
    assistant.content = stream2.text;
    assistant.usage = result.usage ? { ...result.usage, contextTokensSaved: estSaved } : null;
    assistant.durationMs = result.durationMs;
    assistant.providerRef = result.ref;
    assistant.model = result.model ?? row.model;
    if (result.cancelled) {
      assistant.status = "cancelled";
      if (!assistant.blocks.length) stream2.notice("info", "Stopped before any output.");
    } else if (!result.ok) {
      assistant.status = "error";
      assistant.error = result.error ?? "The provider returned an error";
    } else assistant.status = "complete";
    if (before && project?.folderPath) {
      try {
        const after = snapshot(project.folderPath).snap;
        const changes = diffSnapshots(before, after);
        if (changes.length) {
          recordChanges(project.id, changes, "chat", chatId);
          stream2.notice("info", `Changed ${changes.length} file${changes.length === 1 ? "" : "s"}: ${changes.slice(0, 6).map((c) => c.path).join(", ")}${changes.length > 6 ? "\u2026" : ""} \u2014 review in Project \u2192 Files \u2192 Changes.`);
        }
      } catch (e) {
        log11.warn("change detection failed", e.message);
      }
    }
    persistMessage(assistant);
    const chatPatch = { updated_at: now(), preview: preview(stream2.text || user.content) };
    if (result.ref && (result.ref.sessionId || result.ref.threadId) && (result.ok || result.cancelled)) {
      chatPatch.provider_ref = j(result.ref);
      const prevSent = opts.resume ? safeJson(row.context_sent, {}) : {};
      chatPatch.context_sent = j({ ...prevSent, ...packFiles });
    }
    const count = db().get("SELECT COUNT(*) AS n FROM messages WHERE chat_id = ? AND role = 'user'", chatId)?.n ?? 0;
    if (count <= 1 && (row.title === "New chat" || !row.title) && s.general.autoTitle) chatPatch.title = titleFrom(user.content);
    db().update("chats", chatId, chatPatch);
    if (project) touchProject(project.id);
    recordUsage({
      provider: row.provider,
      accountId: account.id,
      model: assistant.model ?? null,
      kind: "chat",
      refId: chatId,
      usage: result.usage,
      estimatedTokens: estimateTokens(prompt) + estimateTokens(stream2.text),
      contextSaved: estSaved,
      durationMs: result.durationMs,
      ok: result.ok
    });
    events.emit("chat.done", assistant);
    emitChat(chatId);
    const acc = resolveAccount(row.provider, account.id);
    if (acc) events.emit("account.updated", acc);
  })().catch((e) => {
    log11.error("chat turn crashed", e);
    active.delete(chatId);
    assistant.status = "error";
    assistant.error = e.message;
    persistMessage(assistant);
    events.emit("chat.done", assistant);
    emitChat(chatId);
  });
  return assistant;
}
function recoverInterrupted() {
  const n = db().run("UPDATE messages SET status = 'error', error = 'Interrupted \u2014 BLOXADE was closed while this response was generating.' WHERE status = 'streaming'");
  if (Number(n.changes)) log11.info(`marked ${n.changes} interrupted messages`);
}
function chatTranscriptForMemory(chatId, maxChars = 16e3) {
  return transcriptFor(chatId, Number.MAX_SAFE_INTEGER, maxChars);
}

// src/server/agents/orchestrator.ts
import fs15 from "node:fs";
import path13 from "node:path";

// src/server/agents/plan.ts
function extractJson(text) {
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const candidates = [fenced?.[1], text];
  for (const c of candidates) {
    if (!c) continue;
    const start = c.indexOf("{");
    const end = c.lastIndexOf("}");
    if (start < 0 || end <= start) continue;
    try {
      return JSON.parse(c.slice(start, end + 1));
    } catch {
    }
  }
  throw new Error("no JSON object found");
}
function overlap(a, b2) {
  return a.some((pa) => b2.some((pb) => matchOwned([pa], pb.replace(/\*.*$/, "")) || matchOwned([pb], pa.replace(/\*.*$/, ""))));
}
function parsePlan(text, maxTasks) {
  const raw = extractJson(text);
  const list = Array.isArray(raw?.tasks) ? raw.tasks : Array.isArray(raw) ? raw : [];
  if (!list.length) throw new Error("plan has no tasks");
  const notes = [];
  let tasks = list.slice(0, maxTasks).map((t, i) => ({
    key: typeof t?.key === "string" && /^[A-Za-z0-9_-]{1,12}$/.test(t.key) ? t.key : `t${i + 1}`,
    title: String(t?.title ?? `Task ${i + 1}`).slice(0, 200),
    description: String(t?.description ?? t?.title ?? "").slice(0, 3e4),
    provider: t?.provider === "claude" || t?.provider === "codex" ? t.provider : "any",
    ownedPaths: Array.isArray(t?.ownedPaths) ? t.ownedPaths.map(String).filter(Boolean).slice(0, 40) : [],
    dependsOn: Array.isArray(t?.dependsOn) ? t.dependsOn.map(String) : []
  }));
  if (list.length > maxTasks) notes.push(`Coordinator proposed ${list.length} tasks; limited to ${maxTasks} by the efficiency mode.`);
  const seen = /* @__PURE__ */ new Set();
  tasks.forEach((t, i) => {
    if (seen.has(t.key)) t.key = `t${i + 1}_${i}`;
    seen.add(t.key);
  });
  const remap = /* @__PURE__ */ new Map();
  tasks.forEach((t, i) => remap.set(t.key, `t${i + 1}`));
  tasks = tasks.map((t) => ({ ...t, key: remap.get(t.key), dependsOn: t.dependsOn.map((d) => remap.get(d)).filter((d) => !!d) }));
  tasks.forEach((t) => t.dependsOn = [...new Set(t.dependsOn.filter((d) => d !== t.key))]);
  const byKey = new Map(tasks.map((t) => [t.key, t]));
  const state = /* @__PURE__ */ new Map();
  const visit = (k) => {
    state.set(k, 1);
    const t = byKey.get(k);
    t.dependsOn = t.dependsOn.filter((d) => {
      if (state.get(d) === 1) {
        notes.push(`Removed circular dependency ${k} \u2192 ${d}.`);
        return false;
      }
      if (!state.get(d)) visit(d);
      return true;
    });
    state.set(k, 2);
  };
  for (const t of tasks) if (!state.get(t.key)) visit(t.key);
  const ancestors = (k, acc = /* @__PURE__ */ new Set()) => {
    for (const d of byKey.get(k)?.dependsOn ?? []) if (!acc.has(d)) {
      acc.add(d);
      ancestors(d, acc);
    }
    return acc;
  };
  for (let i = 0; i < tasks.length; i++) {
    for (let j2 = i + 1; j2 < tasks.length; j2++) {
      const a = tasks[i];
      const b2 = tasks[j2];
      if (!overlap(a.ownedPaths, b2.ownedPaths)) continue;
      if (ancestors(b2.key).has(a.key) || ancestors(a.key).has(b2.key)) continue;
      b2.dependsOn.push(a.key);
      notes.push(`${a.key} and ${b2.key} share files, so ${b2.key} will run after ${a.key}.`);
    }
  }
  const rationale = [String(raw?.rationale ?? "").slice(0, 2e3), ...notes].filter(Boolean).join("\n");
  return { rationale, tasks, notes };
}

// src/server/agents/orchestrator.ts
var log12 = logger("agents");
var activeTasks = /* @__PURE__ */ new Map();
var briefs = /* @__PURE__ */ new Map();
var scheduling = /* @__PURE__ */ new Set();
registerSessionCounter(() => {
  const m = /* @__PURE__ */ new Map();
  for (const t of activeTasks.values()) m.set(t.accountId, (m.get(t.accountId) ?? 0) + 1);
  return m;
});
function activeAgentCount() {
  return activeTasks.size;
}
function toTask(r) {
  return {
    id: r.id,
    runId: r.run_id,
    key: r.key,
    title: r.title,
    description: r.description,
    status: r.status,
    agentName: r.agent_name,
    assignment: safeJson(r.assignment, { provider: "claude", accountId: null, model: "", effort: "" }),
    dependsOn: safeJson(r.depends_on, []),
    ownedPaths: safeJson(r.owned_paths, []),
    filesTouched: safeJson(r.files_touched, []),
    toolOps: r.tool_ops,
    summary: r.summary,
    error: r.error,
    attempts: r.attempts,
    blocks: safeJson(r.blocks, []),
    usage: safeJson(r.usage, null),
    createdAt: r.created_at,
    startedAt: r.started_at,
    finishedAt: r.finished_at,
    review: safeJson(r.review, null),
    currentActivity: liveActivity.get(r.id) ?? null
  };
}
var liveActivity = /* @__PURE__ */ new Map();
function toRun(r, withBlocks = false) {
  const tasks = db().all("SELECT * FROM tasks WHERE run_id = ? ORDER BY key", r.id).map(toTask).map((t) => withBlocks ? t : { ...t, blocks: [] });
  return {
    id: r.id,
    projectId: r.project_id,
    prompt: r.prompt,
    status: r.status,
    strategy: r.strategy,
    efficiency: r.efficiency,
    coordinator: safeJson(r.coordinator, { provider: "claude", accountId: null, model: "", effort: "" }),
    rationale: r.rationale,
    report: r.report,
    error: r.error,
    createdAt: r.created_at,
    startedAt: r.started_at,
    finishedAt: r.finished_at,
    tasks: tasks.sort((a, b2) => Number(a.key.replace(/\D/g, "")) - Number(b2.key.replace(/\D/g, ""))),
    autoApprove: safeJson(r.auto_approve, { edits: true, commands: false, studioWrites: false })
  };
}
function listRuns(projectId, limit = 50) {
  const rows = projectId ? db().all("SELECT * FROM runs WHERE project_id = ? ORDER BY created_at DESC LIMIT ?", projectId, limit) : db().all("SELECT * FROM runs ORDER BY created_at DESC LIMIT ?", limit);
  return rows.map((r) => toRun(r));
}
function getRun(id, withBlocks = false) {
  const r = db().get("SELECT * FROM runs WHERE id = ?", id);
  if (!r) throw new HttpError(404, "Run not found");
  return toRun(r, withBlocks);
}
function getTask(id) {
  const r = db().get("SELECT * FROM tasks WHERE id = ?", id);
  if (!r) throw new HttpError(404, "Task not found");
  return toTask(r);
}
function emitRun(id) {
  try {
    events.emit("run.updated", getRun(id));
  } catch {
  }
}
function setRun(id, patch) {
  db().update("runs", id, patch);
  emitRun(id);
}
function setTask(id, patch) {
  db().update("tasks", id, patch);
  const t = getTask(id);
  events.emit("task.updated", { ...t, blocks: void 0 });
}
function availableProviders() {
  const out = [];
  for (const p of ["claude", "codex"]) {
    if (listAccounts().some((a) => a.provider === p && a.enabled && a.status !== "signed_out" && a.status !== "cli_missing") && findCli(p)) out.push(p);
  }
  return out;
}
function defaultAssignment(provider, accountId, overrides) {
  const s = getSettings().providers;
  return {
    provider,
    accountId,
    model: overrides?.[provider]?.model ?? s.defaultModels[provider] ?? "",
    effort: overrides?.[provider]?.effort ?? s.defaultEfforts[provider] ?? ""
  };
}
function assignAgents(tasks, overrides) {
  const routing = getSettings().agents.routing;
  let avail = availableProviders();
  if (routing === "claude-only") avail = avail.filter((p) => p === "claude");
  if (routing === "codex-only") avail = avail.filter((p) => p === "codex");
  if (!avail.length) avail = [getSettings().providers.defaultProvider];
  const load = { claude: 0, codex: 0 };
  const accountLoad = /* @__PURE__ */ new Map();
  const counters = { claude: 0, codex: 0 };
  return tasks.map((t) => {
    let provider;
    if (t.provider !== "any" && avail.includes(t.provider)) provider = t.provider;
    else if (routing === "prefer-claude" && avail.includes("claude")) provider = "claude";
    else if (routing === "prefer-codex" && avail.includes("codex")) provider = "codex";
    else provider = avail.length === 1 ? avail[0] : load.claude <= load.codex ? avail.includes("claude") ? "claude" : avail[0] : avail.includes("codex") ? "codex" : avail[0];
    load[provider]++;
    const accounts = listAccounts().filter((a) => a.provider === provider && a.enabled && a.status !== "signed_out");
    const acc = accounts.sort((a, b2) => (accountLoad.get(a.id) ?? 0) - (accountLoad.get(b2.id) ?? 0) || Number(b2.isDefault) - Number(a.isDefault))[0] ?? resolveAccount(provider);
    if (acc) accountLoad.set(acc.id, (accountLoad.get(acc.id) ?? 0) + 1);
    counters[provider]++;
    return { assignment: defaultAssignment(provider, acc?.id ?? null, overrides), agentName: `${provider === "claude" ? "Claude" : "Codex"} Agent ${counters[provider]}` };
  });
}
function parseAssignment(v, fallbackProvider) {
  const provider = oneOf(v?.provider ?? fallbackProvider, ["claude", "codex"], "provider");
  const acc = resolveAccount(provider, v?.accountId ?? null);
  return { provider, accountId: acc?.id ?? null, model: safeToken(v?.model ?? getSettings().providers.defaultModels[provider] ?? "", "model", true), effort: safeToken(v?.effort ?? "", "effort", true) };
}
function createRun(body) {
  const prompt = str(body?.prompt, "Request", { min: 1, max: 5e4 });
  const project = body?.projectId ? getProject(body.projectId) : null;
  if (body?.projectId && !project) throw new HttpError(404, "Project not found");
  const s = getSettings();
  const efficiency = oneOf(body?.efficiency ?? s.context.mode, ["economy", "balanced", "performance", "max"], "efficiency");
  const strategy = oneOf(body?.strategy ?? "auto", ["auto", "manual"], "strategy");
  const coordinator = parseAssignment(body?.coordinator, s.providers.defaultProvider);
  const autoApprove = { edits: body?.autoApprove?.edits ?? true, commands: !!body?.autoApprove?.commands, studioWrites: !!body?.autoApprove?.studioWrites };
  const id = newId("run");
  db().upsert("runs", {
    id,
    project_id: project?.id ?? null,
    prompt,
    status: strategy === "auto" ? "planning" : "ready",
    strategy,
    efficiency,
    coordinator: j(coordinator),
    rationale: null,
    report: null,
    error: null,
    auto_approve: j(autoApprove),
    created_at: now(),
    started_at: null,
    finished_at: null
  });
  if (strategy === "manual") {
    const list = Array.isArray(body?.tasks) && body.tasks.length ? body.tasks : [{ title: truncate(prompt.split("\n")[0], 80), description: prompt }];
    list.slice(0, 12).forEach((t, i) => insertTask(id, `t${i + 1}`, t, parseAssignment(t.assignment ?? coordinator, coordinator.provider)));
    setRun(id, { rationale: "Manual plan." });
  }
  activity("agents", `New agent run${project ? ` in \u201C${project.name}\u201D` : ""}`, truncate(prompt, 200), id);
  emitRun(id);
  if (strategy === "auto") void plan(id, !!body?.autoStart, body?.agentDefaults);
  else if (body?.autoStart) startRun(id);
  return getRun(id);
}
function insertTask(runId, key, t, assignment, agentName, deps = []) {
  const counter = db().get("SELECT COUNT(*) AS n FROM tasks WHERE run_id = ? AND json_extract(assignment, '$.provider') = ?", runId, assignment.provider)?.n ?? 0;
  db().upsert("tasks", {
    id: newId("task"),
    run_id: runId,
    key,
    title: truncate(str(t.title ?? key, "title", { max: 300 }) || key, 200),
    description: str(t.description ?? "", "description", { max: 3e4, optional: true }),
    status: "pending",
    agent_name: agentName ?? `${assignment.provider === "claude" ? "Claude" : "Codex"} Agent ${counter + 1}`,
    assignment: j(assignment),
    depends_on: j(Array.isArray(t.dependsOn) ? t.dependsOn.map(String) : deps),
    owned_paths: j(Array.isArray(t.ownedPaths) ? t.ownedPaths.map(String).slice(0, 40) : []),
    files_touched: "[]",
    tool_ops: 0,
    summary: null,
    error: null,
    attempts: 0,
    blocks: "[]",
    usage: null,
    review: null,
    provider_ref: null,
    created_at: now(),
    started_at: null,
    finished_at: null
  });
}
function runCwd(runId, projectFolder) {
  if (projectFolder && fs15.existsSync(projectFolder)) return projectFolder;
  const d = path13.join(dirs.workspaces, runId);
  fs15.mkdirSync(d, { recursive: true });
  return d;
}
function projectBrief(runId, project, prompt, mode) {
  const cached = briefs.get(runId);
  if (cached !== void 0) return cached;
  if (!project) {
    briefs.set(runId, "");
    return "";
  }
  const pack = buildContextPack({ project, query: prompt, mode, includeTree: true, includeMemory: true, budgetTokens: Math.min(EFFICIENCY_PROFILES[mode].contextBudget, 9e3) });
  const text = pack?.text ?? "";
  briefs.set(runId, text);
  return text;
}
async function plan(runId, autoStart, agentDefaults) {
  const run = getRun(runId);
  const project = getProject(run.projectId);
  const profile = EFFICIENCY_PROFILES[run.efficiency];
  const avail = availableProviders();
  const accounts = listAccounts().filter((a) => a.enabled);
  const brief = projectBrief(runId, project, run.prompt, run.efficiency);
  const agentsText = avail.length ? avail.map((p) => `${p}: ${accounts.filter((a) => a.provider === p).length} account(s) available`).join("\n") : "Only one provider is available.";
  const planningPrompt = [
    "You are the BLOXADE coordinator. Split the user request into the smallest sensible set of subtasks for coding agents that work at the same time on the same project.",
    "Rules:",
    `- Use as FEW tasks as possible (maximum ${profile.maxTasks}). If one agent can do it well, return exactly ONE task. Never split just to use more agents.`,
    '- Every task owns a distinct set of paths ("ownedPaths": project-relative files, folders ending with "/", or globs; for Roblox Studio scripts use "studio:<dot.path>", e.g. "studio:ServerScriptService.ShopServer"). Two tasks that can run in parallel must never own the same path.',
    '- Use "dependsOn" (list of task keys) when a task needs another task\u2019s result \u2014 e.g. tests or integration checks after implementation.',
    '- "provider" is "claude", "codex" or "any".',
    '- Each "description" must be a complete, self-contained instruction for an agent that has NOT seen the user request: goal, exact location, and the interfaces/names it must agree on with sibling tasks.',
    "- Do not inspect files yourself; the project context below is all you need for planning.",
    "Respond with ONLY a JSON object, no prose, in this shape:",
    '{"rationale":"one or two sentences","tasks":[{"key":"t1","title":"short title","description":"\u2026","provider":"any","ownedPaths":["src/shop/"],"dependsOn":[]}]}',
    `<available_agents>
${agentsText}
</available_agents>`,
    brief ? brief : "<project_context>No project folder linked.</project_context>",
    `<user_request>
${run.prompt}
</user_request>`
  ].join("\n\n");
  const acc = resolveAccount(run.coordinator.provider, run.coordinator.accountId);
  let planned = null;
  let note = "";
  if (!acc) {
    note = `No ${PROVIDER_LABEL[run.coordinator.provider]} account available for the coordinator, so the request was planned as a single task.`;
  } else {
    const t0 = now();
    const res = await complete(run.coordinator.provider, {
      account: acc,
      model: run.coordinator.model,
      effort: run.coordinator.effort || "low",
      cwd: runCwd(runId, null),
      prompt: planningPrompt,
      signal: new AbortController().signal,
      timeoutMs: 8 * 6e4,
      label: "Coordinator (planning)"
    });
    recordUsage({ provider: run.coordinator.provider, accountId: acc.id, model: res.model ?? run.coordinator.model, kind: "coordinator", refId: runId, usage: res.usage, estimatedTokens: estimateTokens(planningPrompt) + estimateTokens(res.text), contextSaved: 0, durationMs: now() - t0, ok: res.ok });
    if (res.ok) {
      try {
        planned = parsePlan(res.text, profile.maxTasks);
      } catch (e) {
        note = `The coordinator\u2019s plan could not be parsed (${e.message}); planned as a single task.`;
      }
    } else note = `Coordinator failed: ${res.error}. Planned as a single task.`;
  }
  if (!planned) planned = { rationale: note, tasks: [{ key: "t1", title: truncate(run.prompt.split("\n")[0], 80), description: run.prompt, provider: "any", ownedPaths: [], dependsOn: [] }] };
  else if (note) planned.rationale = `${planned.rationale}
${note}`;
  try {
    getRun(runId);
  } catch {
    return;
  }
  const assigned = assignAgents(planned.tasks, agentDefaults);
  db().tx(() => {
    db().run("DELETE FROM tasks WHERE run_id = ?", runId);
    planned.tasks.forEach((t, i) => insertTask(runId, t.key, t, assigned[i].assignment, assigned[i].agentName, t.dependsOn));
  });
  setRun(runId, { status: "ready", rationale: planned.rationale });
  activity("agents", `Plan ready: ${planned.tasks.length} task${planned.tasks.length === 1 ? "" : "s"}`, planned.rationale, runId);
  if (autoStart) startRun(runId);
}
function startRun(id) {
  const run = getRun(id);
  if (!["ready", "paused", "failed", "completed"].includes(run.status)) throw new HttpError(409, `Run is ${run.status}`);
  if (!run.tasks.length) throw new HttpError(400, "This run has no tasks");
  setRun(id, { status: "running", started_at: run.startedAt ?? now(), finished_at: null, error: null });
  if (run.autoApprove.studioWrites) roblox.setAutoApprove(id, true);
  schedule(id);
}
function pauseRun(id) {
  const run = getRun(id);
  if (run.status !== "running") throw new HttpError(409, "Only running runs can be paused");
  setRun(id, { status: "paused" });
  activity("agents", "Run paused", "Working agents finish their current task; no new tasks start.", id);
}
function cancelRun(id) {
  const run = getRun(id);
  for (const t of run.tasks) {
    if (t.status === "working") activeTasks.get(t.id)?.abort.abort();
    if (t.status === "pending" || t.status === "blocked") setTask(t.id, { status: "cancelled", finished_at: now() });
  }
  setRun(id, { status: "cancelled", finished_at: now() });
  roblox.releaseCaller(id);
}
function deleteRun(id) {
  const run = getRun(id);
  if (run.tasks.some((t) => t.status === "working")) throw new HttpError(409, "Stop the run before deleting it");
  db().run("DELETE FROM tasks WHERE run_id = ?", id);
  db().run("DELETE FROM runs WHERE id = ?", id);
  briefs.delete(id);
  events.emit("run.deleted", { id });
}
function updateTask(taskId, body) {
  const t = getTask(taskId);
  if (t.status === "working") throw new HttpError(409, "This task is running");
  const patch = {};
  if (body.title !== void 0) patch.title = str(body.title, "title", { min: 1, max: 200 });
  if (body.description !== void 0) patch.description = str(body.description, "description", { max: 3e4, optional: true });
  if (body.assignment !== void 0) patch.assignment = j(parseAssignment({ ...t.assignment, ...body.assignment }, t.assignment.provider));
  if (body.ownedPaths !== void 0) patch.owned_paths = j(body.ownedPaths.map(String).filter(Boolean).slice(0, 40));
  if (body.dependsOn !== void 0) patch.depends_on = j(body.dependsOn.map(String));
  if (body.agentName !== void 0) patch.agent_name = str(body.agentName, "agent name", { min: 1, max: 60 });
  setTask(taskId, patch);
  emitRun(t.runId);
  return getTask(taskId);
}
function addTask(runId, body) {
  const run = getRun(runId);
  const key = `t${run.tasks.reduce((m, t) => Math.max(m, Number(t.key.replace(/\D/g, "")) || 0), 0) + 1}`;
  insertTask(runId, key, body, parseAssignment(body?.assignment ?? run.coordinator, run.coordinator.provider));
  emitRun(runId);
  if (run.status === "running") schedule(runId);
  return getRun(runId);
}
function removeTask(taskId) {
  const t = getTask(taskId);
  if (t.status === "working") throw new HttpError(409, "Stop the task first");
  db().run("DELETE FROM tasks WHERE id = ?", taskId);
  emitRun(t.runId);
}
function stopTask(taskId) {
  const a = activeTasks.get(taskId);
  if (!a) throw new HttpError(409, "Task is not running");
  a.abort.abort();
}
function retryTask(taskId) {
  const t = getTask(taskId);
  if (!["failed", "cancelled", "blocked", "completed"].includes(t.status)) throw new HttpError(409, `Task is ${t.status}`);
  setTask(taskId, { status: "pending", finished_at: null, review: null });
  const run = getRun(t.runId);
  for (const other of run.tasks) if (other.status === "blocked" && other.dependsOn.includes(t.key)) setTask(other.id, { status: "pending" });
  if (run.status !== "running") setRun(run.id, { status: "running", finished_at: null });
  schedule(t.runId);
}
function acceptTask(taskId) {
  const t = getTask(taskId);
  if (t.status !== "reviewing") throw new HttpError(409, "Task is not waiting for review");
  setTask(taskId, { status: "completed", review: null });
  activity("agents", `Accepted changes from ${t.agentName}`, t.title, t.runId);
  schedule(t.runId);
}
function revertTask(taskId) {
  const t = getTask(taskId);
  if (t.status === "working") throw new HttpError(409, "Stop the task first");
  const changes = changesBySource(taskId).filter((c) => !c.reverted).reverse();
  for (const c of changes) revertChange(c.id);
  setTask(taskId, { status: "cancelled", error: `Changes reverted by user (${changes.length} file${changes.length === 1 ? "" : "s"})`, review: null, finished_at: now() });
  activity("agents", `Reverted ${changes.length} change(s) from ${t.agentName}`, t.title, t.runId);
  schedule(t.runId);
}
function overlaps(a, b2) {
  if (!a.length || !b2.length) return false;
  return a.some((pa) => b2.some((pb) => matchOwned([pa], pb.replace(/\*.*$/, "")) || matchOwned([pb], pa.replace(/\*.*$/, ""))));
}
function schedule(runId) {
  if (scheduling.has(runId)) return;
  scheduling.add(runId);
  try {
    const run = getRun(runId);
    const profile = EFFICIENCY_PROFILES[run.efficiency];
    const byKey = new Map(run.tasks.map((t) => [t.key, t]));
    for (const t of run.tasks) {
      if (t.status !== "pending") continue;
      const bad = t.dependsOn.map((k) => byKey.get(k)).find((d) => d && ["failed", "cancelled", "blocked"].includes(d.status));
      if (bad) setTask(t.id, { status: "blocked", error: `Waiting on ${bad.key} (${bad.title}), which ${bad.status === "blocked" ? "is blocked" : bad.status}` });
    }
    const fresh = getRun(runId);
    const working = fresh.tasks.filter((t) => t.status === "working");
    const pending2 = fresh.tasks.filter((t) => t.status === "pending");
    const reviewing = fresh.tasks.filter((t) => t.status === "reviewing");
    if (fresh.status === "running") {
      const limit = getSettings().agents.maxConcurrent ?? profile.maxConcurrentAgents;
      let slots = limit - working.length;
      const runningPaths = working.map((t) => t.ownedPaths);
      for (const t of pending2) {
        if (slots <= 0) break;
        const depsDone = t.dependsOn.every((k) => byKey.get(k)?.status === "completed" || !byKey.has(k));
        if (!depsDone) continue;
        if (runningPaths.some((p) => overlaps(p, t.ownedPaths))) continue;
        runningPaths.push(t.ownedPaths);
        slots--;
        void runTask(t.id);
      }
    }
    const after = getRun(runId);
    const stillActive = after.tasks.some((t) => t.status === "working" || t.status === "pending");
    if (!stillActive && !reviewing.length && after.status === "running") void finalize(runId);
  } finally {
    scheduling.delete(runId);
  }
}
function taskPrompt(run, task, brief) {
  const deps = task.dependsOn.map((k) => run.tasks.find((t) => t.key === k)).filter(Boolean).map((d) => `### ${d.key} \u2014 ${d.title} (${d.agentName})
Files changed: ${d.filesTouched.join(", ") || "none"}
${truncate(d.summary ?? "", 2500)}`);
  const siblings = run.tasks.filter((t) => t.id !== task.id).map((t) => `- ${t.key} ${t.title} \u2014 ${t.agentName} \u2014 owns: ${t.ownedPaths.join(", ") || "(unspecified)"}`);
  return [
    `You are ${task.agentName}, one of ${run.tasks.length} BLOXADE agent${run.tasks.length === 1 ? "" : "s"} working on this request:`,
    `<overall_goal>
${run.prompt}
</overall_goal>`,
    `<your_task key="${task.key}">
${task.title}

${task.description}
</your_task>`,
    task.ownedPaths.length ? `You own these paths \u2014 change files only inside them:
${task.ownedPaths.map((p) => `- ${p}`).join("\n")}` : "Keep your changes as small and focused as possible.",
    siblings.length ? `Other agents (do not edit their paths):
${siblings.join("\n")}` : "",
    deps.length ? `<completed_dependencies note="Results you can build on \u2014 do not redo this work">
${deps.join("\n\n")}
</completed_dependencies>` : "",
    task.attempts > 0 && task.error ? `Previous attempt failed with: ${truncate(task.error, 800)}
Avoid repeating the same mistake.` : "",
    brief,
    'When finished, reply with:\n## Summary\n(what you did, files/scripts changed)\n## Notes for other agents\n(changes you need outside your paths, or "None")'
  ].filter(Boolean).join("\n\n");
}
async function runTask(taskId) {
  let task = getTask(taskId);
  const run = getRun(task.runId);
  const project = getProject(run.projectId);
  const s = getSettings();
  const account = resolveAccount(task.assignment.provider, task.assignment.accountId);
  if (!account) {
    setTask(taskId, { status: "failed", error: `No ${PROVIDER_LABEL[task.assignment.provider]} account available`, finished_at: now() });
    schedule(run.id);
    return;
  }
  const abort = new AbortController();
  activeTasks.set(taskId, { abort, accountId: account.id, runId: run.id });
  setTask(taskId, { status: "working", started_at: now(), finished_at: null, attempts: task.attempts + 1, blocks: "[]", review: null });
  task = getTask(taskId);
  activity("agents", `${task.agentName} started \u201C${task.title}\u201D`, `${PROVIDER_LABEL[account.provider]} \xB7 ${account.name}`, run.id);
  const cwd = runCwd(run.id, project?.folderPath);
  const label = `${task.agentName} (${task.key})`;
  const robloxOn = !!project?.robloxEnabled && robloxAvailableFor();
  const bridgeToken = robloxOn ? createBridgeSession({ kind: "task", id: taskId, label, runId: run.id }) : null;
  if (robloxOn && run.autoApprove.studioWrites) roblox.setAutoApprove(taskId, true);
  let before = null;
  if (project?.folderPath && cwd === project.folderPath) {
    try {
      before = snapshot(project.folderPath).snap;
    } catch (e) {
      log12.warn("snapshot failed", e.message);
    }
  }
  const brief = projectBrief(run.id, project, run.prompt, run.efficiency);
  const prompt = taskPrompt(run, task, brief);
  const blocks = [];
  const pushMeta = debounce(() => {
    db().update("tasks", taskId, { blocks: j(blocks), tool_ops: stream2.toolOps, files_touched: j([...touchedRel()]) });
    liveActivity.set(taskId, stream2.currentActivity);
    events.emit("task.updated", { ...getTask(taskId), blocks: void 0 });
  }, 800);
  const stream2 = new BlockStream(blocks, {
    block: (index, block) => {
      events.emit("task.block", { taskId, index, block });
      pushMeta();
    },
    delta: (index, kind, text2) => {
      events.emit("task.delta", { taskId, index, kind, text: text2 });
      pushMeta();
    }
  });
  const touchedAbs = /* @__PURE__ */ new Set();
  const touchedRel = () => {
    const out = /* @__PURE__ */ new Set();
    for (const p of [...touchedAbs, ...stream2.filesTouched]) out.add(project?.folderPath ? path13.relative(project.folderPath, path13.resolve(cwd, p)).split(path13.sep).join("/") : p);
    return out;
  };
  const result = await runTurn(task.assignment.provider, {
    account,
    model: task.assignment.model,
    effort: task.assignment.effort,
    mode: "cowork",
    cwd,
    systemAppend: systemPrompt({ mode: "cowork", project, roblox: robloxOn, cwd, role: `You are ${task.agentName}, a BLOXADE agent. Work only on your assigned task and paths.` }),
    prompt,
    resume: null,
    forkFrom: null,
    bridgeToken,
    permissionMode: "ask",
    onPermission: makePermissionHandler({
      kind: "task",
      id: taskId,
      label,
      cwd,
      projectRoot: project?.folderPath ?? null,
      extraRoots: [cwd],
      task: { runId: run.id, ownedPaths: task.ownedPaths.filter((p) => !p.startsWith("studio:")), autoApprove: run.autoApprove },
      onEditAllowed: (abs) => abs.forEach((a) => touchedAbs.add(a))
    }),
    onEvent: (e) => stream2.apply(e),
    signal: abort.signal,
    timeoutMs: s.advanced.turnTimeoutMin * 6e4,
    label
  }).catch((e) => ({ ok: false, cancelled: false, text: "", ref: {}, usage: null, error: e.message, durationMs: 0 }));
  pushMeta.flush();
  activeTasks.delete(taskId);
  liveActivity.delete(taskId);
  revokeBridgeSession(bridgeToken);
  fileLocks.release(taskId);
  roblox.releaseCaller(taskId);
  forgetRequester(taskId);
  let changedRel = [];
  let conflicts = [];
  if (before && project?.folderPath) {
    try {
      const after = snapshot(project.folderPath).snap;
      const all = diffSnapshots(before, after);
      const touched = touchedRel();
      const ownedFs = task.ownedPaths.filter((p) => !p.startsWith("studio:"));
      const otherWorking = getRun(run.id).tasks.filter((t) => t.status === "working" && t.id !== taskId);
      const mine = all.filter((c) => touched.has(c.path) || ownedFs.length && matchOwned(ownedFs, c.path) && !otherWorking.some((o) => matchOwned(o.ownedPaths, c.path)));
      if (mine.length) recordChanges(project.id, mine, "task", taskId);
      changedRel = mine.map((c) => c.path);
      if (ownedFs.length) conflicts = changedRel.filter((p) => !matchOwned(ownedFs, p));
      const others = getRun(run.id).tasks.filter((t) => t.id !== taskId);
      for (const p of changedRel) if (others.some((o) => o.filesTouched.includes(p)) && !conflicts.includes(p)) conflicts.push(p);
    } catch (e) {
      log12.warn("change attribution failed", e.message);
    }
  }
  const text = result.text || stream2.text;
  const summaryMatch = text.match(/##\s*Summary\s*([\s\S]*)/i);
  const summary = truncate((summaryMatch ? summaryMatch[1] : text).trim(), 6e3);
  const profile = EFFICIENCY_PROFILES[run.efficiency];
  let status;
  let error = null;
  let review = null;
  if (result.cancelled) {
    status = "cancelled";
    error = "Stopped by user";
  } else if (!result.ok) {
    error = result.error ?? "Agent failed";
    status = task.attempts <= profile.retries ? "pending" : "failed";
    if (status === "pending") stream2.notice("warning", `Attempt ${task.attempts} failed \u2014 retrying (${profile.label} mode allows ${profile.retries} retr${profile.retries === 1 ? "y" : "ies"}).`);
  } else if (conflicts.length || s.agents.requireReview && changedRel.length) {
    status = "reviewing";
    review = { reason: conflicts.length ? "Changed files outside its assignment or files another agent also changed" : "Review required by your settings", conflicts };
  } else status = "completed";
  db().update("tasks", taskId, {
    status,
    error,
    summary,
    review: j(review),
    files_touched: j(changedRel.length ? changedRel : [...touchedRel()]),
    blocks: j(blocks),
    tool_ops: stream2.toolOps,
    usage: j(result.usage),
    provider_ref: j(result.ref),
    finished_at: status === "pending" ? null : now()
  });
  events.emit("task.updated", { ...getTask(taskId), blocks: void 0 });
  emitRun(run.id);
  recordUsage({
    provider: task.assignment.provider,
    accountId: account.id,
    model: result.model ?? task.assignment.model,
    kind: "task",
    refId: taskId,
    usage: result.usage,
    estimatedTokens: estimateTokens(prompt) + estimateTokens(text),
    contextSaved: 0,
    durationMs: result.durationMs,
    ok: result.ok
  });
  activity("agents", `${task.agentName} ${status === "completed" ? "completed" : status === "reviewing" ? "needs review for" : status === "pending" ? "will retry" : status} \u201C${task.title}\u201D`, error ?? `${changedRel.length} file(s) changed`, run.id);
  schedule(run.id);
}
async function finalize(runId) {
  const run = getRun(runId);
  if (run.status !== "running") return;
  const profile = EFFICIENCY_PROFILES[run.efficiency];
  const done = run.tasks.filter((t) => t.status === "completed");
  const failed = run.tasks.filter((t) => t.status !== "completed");
  const fmtDur = (t) => t.startedAt && t.finishedAt ? `${Math.max(1, Math.round((t.finishedAt - t.startedAt) / 1e3))}s` : "";
  const deterministic = [
    `## Result`,
    `${done.length} of ${run.tasks.length} task${run.tasks.length === 1 ? "" : "s"} completed.`,
    `## Tasks`,
    ...run.tasks.map((t) => `- ${t.status === "completed" ? "\u2705" : t.status === "failed" ? "\u274C" : t.status === "cancelled" ? "\u23F9\uFE0F" : "\u26A0\uFE0F"} **${t.key} \xB7 ${t.title}** \u2014 ${t.agentName} (${PROVIDER_LABEL[t.assignment.provider]}) ${fmtDur(t)}${t.error ? `
  - ${t.error}` : ""}${t.summary ? `
  - ${truncate(t.summary.split("\n").filter(Boolean)[0] ?? "", 220)}` : ""}`),
    `## Files changed`,
    [...new Set(run.tasks.flatMap((t) => t.filesTouched))].map((f) => `- \`${f}\``).join("\n") || "- None in the project folder"
  ].join("\n");
  let report = deterministic;
  if (profile.verification !== "none" && done.length) {
    const acc = resolveAccount(run.coordinator.provider, run.coordinator.accountId);
    if (acc) {
      const material = run.tasks.map((t) => `### ${t.key} ${t.title} \u2014 ${t.agentName} \u2014 ${t.status}
Files: ${t.filesTouched.join(", ") || "none"}
${truncate(t.summary ?? t.error ?? "", profile.verification === "review" ? 3500 : 1500)}`).join("\n\n");
      const reviewAsk = profile.verification === "review" ? 'Check the summaries for integration problems between the tasks (mismatched names, missing wiring, unhandled requests in "Notes for other agents") and list concrete follow-ups.' : "Keep it short.";
      const p = `You are the BLOXADE coordinator. Write ONE unified final report (Markdown) for the user about this multi-agent run. Start with "## Result" (2\u20134 sentences), then "## What changed", then "## Follow-ups" if any. ${reviewAsk} Do not invent work that is not in the summaries.

<user_request>
${run.prompt}
</user_request>

<task_results>
${material}
</task_results>`;
      const t0 = now();
      const res = await complete(run.coordinator.provider, { account: acc, model: run.coordinator.model, effort: run.coordinator.effort || "low", cwd: runCwd(runId, null), prompt: p, signal: new AbortController().signal, timeoutMs: 6 * 6e4, label: "Coordinator (report)" });
      recordUsage({ provider: run.coordinator.provider, accountId: acc.id, model: res.model ?? run.coordinator.model, kind: "coordinator", refId: runId, usage: res.usage, estimatedTokens: estimateTokens(p) + estimateTokens(res.text), contextSaved: 0, durationMs: now() - t0, ok: res.ok });
      if (res.ok && res.text.trim()) report = `${res.text.trim()}

---

<details><summary>Task details</summary>

${deterministic}

</details>`;
    }
  }
  const status = failed.length ? "failed" : "completed";
  setRun(runId, { status, report, finished_at: now() });
  roblox.releaseCaller(runId);
  briefs.delete(runId);
  activity("agents", `Run ${status}`, `${done.length}/${run.tasks.length} tasks completed`, runId);
  if (getSettings().context.autoMemory && run.projectId && done.length) void updateMemoryFromRun(runId).catch((e) => log12.warn("memory update failed", e.message));
}
async function updateMemoryFromRun(runId) {
  const run = getRun(runId);
  const project = getProject(run.projectId);
  if (!project || !run.report) return;
  const acc = resolveAccount(run.coordinator.provider, run.coordinator.accountId);
  if (!acc) return;
  const p = `Update this project memory with durable facts from the run report (architecture, names, conventions, decisions). Keep it under 350 words, bullet points, no fluff. Return ONLY the new memory text.

<current_memory>
${project.memory || "(empty)"}
</current_memory>

<run_report>
${truncate(run.report, 6e3)}
</run_report>`;
  const res = await complete(run.coordinator.provider, { account: acc, model: run.coordinator.model, effort: "low", cwd: runCwd(runId, null), prompt: p, signal: new AbortController().signal, timeoutMs: 4 * 6e4, label: "Memory update" });
  recordUsage({ provider: run.coordinator.provider, accountId: acc.id, model: res.model ?? null, kind: "memory", refId: runId, usage: res.usage, estimatedTokens: estimateTokens(p), contextSaved: 0, durationMs: res.durationMs, ok: res.ok });
  if (res.ok && res.text.trim()) updateProject(project.id, { memory: res.text.trim().slice(0, 2e4) });
}
function recoverRuns() {
  db().run("UPDATE tasks SET status = 'failed', error = 'Interrupted \u2014 BLOXADE was closed while this task was running', finished_at = ? WHERE status = 'working'", now());
  db().run("UPDATE runs SET status = 'paused' WHERE status = 'running'");
  db().run("UPDATE runs SET status = 'failed', error = 'Interrupted during planning' WHERE status = 'planning'");
}
function stopAllTasks() {
  for (const t of activeTasks.values()) t.abort.abort();
}

// src/server/roblox/bridge.ts
var log13 = logger("bridge");
async function handleBridgeMessage(token, msg) {
  const session = getBridgeSession(token);
  const id = msg?.id;
  const reply = (result) => id === void 0 ? null : { jsonrpc: "2.0", id, result };
  const fail = (code, message) => id === void 0 ? null : { jsonrpc: "2.0", id, error: { code, message } };
  if (!session) return fail(-32001, "BLOXADE bridge session expired or invalid");
  session.lastSeen = Date.now();
  const method = msg?.method;
  try {
    switch (method) {
      case "initialize":
        session.initialized = true;
        return reply({
          protocolVersion: msg.params?.protocolVersion ?? "2025-06-18",
          capabilities: { tools: { listChanged: false } },
          serverInfo: { name: "bloxade-roblox", version: VERSION },
          instructions: "Roblox Studio tools provided through BLOXADE. Calls are queued and may require user approval. studio_id may be omitted to target the active Studio place."
        });
      case "notifications/initialized":
      case "notifications/cancelled":
        return null;
      case "ping":
        return reply({});
      case "tools/list": {
        const tools = await roblox.agentTools();
        return reply({ tools });
      }
      case "tools/call": {
        const name = String(msg.params?.name ?? "");
        const result = await roblox.call(name, msg.params?.arguments ?? {}, session);
        return reply(result);
      }
      case "resources/list":
        return reply({ resources: [] });
      case "prompts/list":
        return reply({ prompts: [] });
      default:
        if (id === void 0) return null;
        return fail(-32601, `Method not found: ${method}`);
    }
  } catch (e) {
    log13.warn("bridge call failed", { method, error: e.message });
    if (method === "tools/call") return reply({ content: [{ type: "text", text: `BLOXADE bridge error: ${e.message}` }], isError: true });
    return fail(-32e3, e.message);
  }
}

// src/server/api.ts
function buildRoutes(opts) {
  const r = new Router();
  r.get("/api/health", () => ({ ok: true, app: "bloxade", version: VERSION, uptimeMs: Date.now() - runtime.startedAt }));
  r.get("/api/events", ({ res }) => events.attach(res), { raw: true });
  r.get("/api/bootstrap", async () => {
    const clis = { claude: cachedCli("claude"), codex: cachedCli("codex") };
    if (!clis.claude.checkedAt) clis.claude = await detectCli("claude");
    if (!clis.codex.checkedAt) clis.codex = await detectCli("codex");
    return {
      version: VERSION,
      settings: getSettings(),
      accounts: listAccounts(),
      projects: listProjects(),
      chats: listChats({ limit: 300 }),
      clis,
      roblox: roblox.status(),
      approvals: listApprovals(),
      platform: process.platform,
      dataDir: DATA_DIR,
      runningChats: runningChatIds()
    };
  });
  r.get("/api/settings", () => getSettings());
  r.put("/api/settings", ({ body }) => updateSettings(body));
  r.get("/api/system/diagnostics", async () => ({
    version: VERSION,
    node: process.version,
    platform: `${process.platform} ${os4.release()} (${process.arch})`,
    dataDir: DATA_DIR,
    port: runtime.port,
    uptimeMs: Date.now() - runtime.startedAt,
    dbBytes: db().sizeBytes(),
    sseClients: events.clientCount,
    processes: listProcesses(),
    clis: { claude: await detectCli("claude", true), codex: await detectCli("codex", true) },
    git: (await runCapture("git", ["--version"], { timeoutMs: 8e3 })).stdout.trim() || "not found",
    roblox: await roblox.diagnostics(),
    context: cacheStats(),
    memory: process.memoryUsage()
  }));
  r.get("/api/system/logs", ({ query }) => recentLogs(Number(query.get("limit") ?? 300), query.get("level") || void 0));
  r.post("/api/system/open-data", ({ body }) => {
    const which = oneOf(body?.which ?? "data", ["data", "logs"], "which");
    openFolder(which === "logs" ? dirs.logs : dirs.data);
  });
  r.post("/api/system/open-url", ({ body }) => openUrl(str(body?.url, "url", { min: 8, max: 4e3 })));
  r.post("/api/system/clear-history", ({ body }) => {
    const what = oneOf(body?.what ?? "chats", ["chats", "usage", "activity", "runs", "cache"], "what");
    if (what === "chats") {
      stopAllChats();
      db().tx(() => {
        db().run("DELETE FROM messages");
        db().run("DELETE FROM chats");
        db().run("DELETE FROM attachments");
      });
      fs16.rmSync(dirs.attachments, { recursive: true, force: true });
      fs16.mkdirSync(dirs.attachments, { recursive: true });
    } else if (what === "usage") db().run("DELETE FROM usage_events");
    else if (what === "activity") {
      db().run("DELETE FROM activity");
      db().run("DELETE FROM roblox_activity");
    } else if (what === "runs") {
      stopAllTasks();
      db().run("DELETE FROM tasks");
      db().run("DELETE FROM runs");
    } else kvDelete("");
    events.emit("history.cleared", { what });
  });
  r.post("/api/system/shutdown", () => {
    setTimeout(opts.shutdown, 200);
    return { ok: true };
  });
  r.post("/api/fs/browse", ({ body }) => {
    const raw = typeof body?.path === "string" && body.path.trim() ? body.path : os4.homedir();
    const abs = expandUserPath(raw);
    let entries = [];
    try {
      entries = fs16.readdirSync(abs, { withFileTypes: true });
    } catch {
      throw new HttpError(404, `Cannot open ${abs}`);
    }
    const list = entries.filter((e) => e.isDirectory() && !e.name.startsWith("$") && e.name !== "node_modules").map((e) => e.name).sort((a, b2) => a.localeCompare(b2));
    const parent = path14.dirname(abs) === abs ? null : path14.dirname(abs);
    const drives = IS_WIN ? "CDEFGHIJ".split("").map((d) => `${d}:\\`).filter((d) => fs16.existsSync(d)) : [];
    return { path: abs, parent, dirs: list.slice(0, 500), drives, home: os4.homedir() };
  });
  r.post("/api/fs/native-pick", async () => {
    if (!IS_WIN) throw new HttpError(400, "The native folder dialog is only available on Windows");
    const ps = "Add-Type -AssemblyName System.Windows.Forms; $f = New-Object System.Windows.Forms.FolderBrowserDialog; $f.Description = 'Choose a project folder for BLOXADE'; $f.ShowNewFolderButton = $true; $top = New-Object System.Windows.Forms.Form; $top.TopMost = $true; if ($f.ShowDialog($top) -eq 'OK') { $f.SelectedPath }";
    const out = await runCapture("powershell.exe", ["-NoProfile", "-STA", "-Command", ps], { timeoutMs: 10 * 6e4 });
    return { path: out.stdout.trim() || null };
  });
  r.get("/api/providers", async ({ query }) => {
    const force = query.get("refresh") === "1";
    return { claude: await detectCli("claude", force), codex: await detectCli("codex", force) };
  });
  r.get("/api/models", ({ query }) => {
    const provider = oneOf(query.get("provider"), ["claude", "codex"], "provider");
    return cachedCatalog(provider);
  });
  r.post("/api/models/refresh", async ({ body }) => {
    const provider = oneOf(body?.provider, ["claude", "codex"], "provider");
    const acc = resolveAccount(provider, body?.accountId ?? null);
    return refreshCatalog(provider, acc);
  });
  r.get("/api/accounts", () => listAccounts());
  r.post("/api/accounts", ({ body }) => createAccount(body));
  r.patch("/api/accounts/:id", ({ params, body }) => updateAccount(params.id, body));
  r.delete("/api/accounts/:id", ({ params, query }) => deleteAccount(params.id, query.get("removeProfile") === "1"));
  r.post("/api/accounts/:id/refresh", ({ params }) => refreshStatus(params.id));
  r.post("/api/accounts/:id/default", ({ params }) => setDefault(params.id));
  r.post("/api/accounts/:id/login", ({ params, body }) => startLogin(params.id, body?.method === "device" ? "device" : "browser"));
  r.post("/api/accounts/:id/login/cancel", ({ params }) => cancelLogin(params.id));
  r.post("/api/accounts/:id/logout", ({ params }) => logout(params.id));
  r.post("/api/accounts/:id/terminal", ({ params }) => openTerminal(params.id));
  r.get("/api/chats", ({ query }) => listChats({ projectId: query.get("projectId"), limit: Number(query.get("limit") ?? 300) }));
  r.post("/api/chats", ({ body }) => createChat(body));
  r.get("/api/chats/:id", ({ params }) => getChat(params.id));
  r.patch("/api/chats/:id", ({ params, body }) => updateChat(params.id, body));
  r.delete("/api/chats/:id", ({ params }) => deleteChat(params.id));
  r.post("/api/chats/:id/messages", ({ params, body }) => sendMessage(params.id, body));
  r.post("/api/chats/:id/stop", ({ params }) => stopChat(params.id));
  r.post("/api/chats/:id/regenerate", ({ params }) => regenerate(params.id));
  r.post("/api/chats/:id/messages/:mid/edit", ({ params, body }) => editMessage(params.id, params.mid, body));
  r.post("/api/chats/:id/branch", ({ params, body }) => branchChat(params.id, str(body?.messageId, "messageId", { min: 1 })));
  r.post("/api/chats/:id/memory", async ({ params }) => {
    const { chat } = getChat(params.id);
    if (!chat.projectId) throw new HttpError(400, "This chat is not part of a project");
    const project = mustProject(chat.projectId);
    const acc = resolveAccount(chat.provider, chat.accountId);
    if (!acc) throw new HttpError(400, "No account available");
    const transcript = chatTranscriptForMemory(chat.id);
    const prompt = `Update the project memory with durable facts from this conversation (decisions, names, architecture, conventions, open TODOs). Under 350 words, concise bullet points. Return ONLY the full updated memory.

<current_memory>
${project.memory || "(empty)"}
</current_memory>

${transcript}`;
    const res = await complete(chat.provider, { account: acc, model: chat.model, effort: "low", cwd: path14.join(dirs.workspaces, chat.id), prompt, signal: new AbortController().signal, timeoutMs: 5 * 6e4, label: "Memory summary" });
    recordUsage({ provider: chat.provider, accountId: acc.id, model: res.model ?? chat.model, kind: "memory", refId: chat.id, usage: res.usage, estimatedTokens: estimateTokens(prompt), contextSaved: 0, durationMs: res.durationMs, ok: res.ok });
    if (!res.ok) throw new HttpError(502, res.error ?? "Summary failed");
    return updateProject(project.id, { memory: res.text.trim().slice(0, 2e4) });
  });
  r.get("/api/search", ({ query }) => {
    const q = (query.get("q") ?? "").trim();
    if (q.length < 2) return [];
    return searchChats(q);
  });
  r.post("/api/attachments", ({ body }) => saveAttachment(body));
  r.get(
    "/api/attachments/:id",
    ({ params, res }) => {
      const f = attachmentFile(params.id);
      res.writeHead(200, { "Content-Type": mimeFor(f.path) === "application/octet-stream" ? f.mime : mimeFor(f.path), "Cache-Control": "private, max-age=3600", "Content-Disposition": `inline; filename="${encodeURIComponent(f.name)}"`, "X-Content-Type-Options": "nosniff" });
      fs16.createReadStream(f.path).pipe(res);
    },
    { raw: true }
  );
  r.get("/api/projects", () => listProjects());
  r.post("/api/projects", ({ body }) => createProject(body));
  r.get("/api/projects/:id", ({ params }) => mustProject(params.id));
  r.patch("/api/projects/:id", ({ params, body }) => updateProject(params.id, body));
  r.delete("/api/projects/:id", ({ params }) => deleteProject(params.id));
  r.get("/api/projects/:id/files", ({ params, query }) => {
    const p = mustProject(params.id);
    if (!p.folderPath) throw new HttpError(400, "Link a folder to this project first");
    return listDir(p.folderPath, query.get("path") ?? "");
  });
  r.get("/api/projects/:id/file", ({ params, query }) => {
    const p = mustProject(params.id);
    if (!p.folderPath) throw new HttpError(400, "Link a folder to this project first");
    const abs = safeResolve(p.folderPath, query.get("path") ?? "");
    if (!fs16.existsSync(abs) || !fs16.statSync(abs).isFile()) throw new HttpError(404, "File not found");
    return readText(abs, 1024 * 1024);
  });
  r.get("/api/projects/:id/stats", ({ params }) => {
    const p = mustProject(params.id);
    if (!p.folderPath || !fs16.existsSync(p.folderPath)) return { files: 0, textBytes: 0, truncated: false, estTokensAll: 0 };
    const idx = getIndex(p.id, p.folderPath, true);
    return { files: idx.files.length, textBytes: idx.totalTextBytes, truncated: idx.truncated, estTokensAll: estimateTokens(idx.totalTextBytes) };
  });
  r.post("/api/projects/:id/context-preview", ({ params, body }) => {
    const p = mustProject(params.id);
    invalidateProject(p.id);
    return buildContextPack({ project: p, query: str(body?.query ?? "", "query", { max: 5e3 }), mode: body?.mode });
  });
  r.get("/api/projects/:id/changes", ({ params, query }) => listChanges(params.id, { sourceId: query.get("sourceId") ?? void 0 }));
  r.post("/api/changes/:id/revert", ({ params }) => revertChange(params.id));
  r.post("/api/projects/:id/open-folder", ({ params }) => {
    const p = mustProject(params.id);
    if (!p.folderPath) throw new HttpError(400, "No folder linked");
    openFolder(p.folderPath);
  });
  r.get("/api/runs", ({ query }) => listRuns(query.get("projectId"), Number(query.get("limit") ?? 50)));
  r.post("/api/runs", ({ body }) => createRun(body));
  r.get("/api/runs/:id", ({ params }) => getRun(params.id));
  r.delete("/api/runs/:id", ({ params }) => deleteRun(params.id));
  r.post("/api/runs/:id/start", ({ params }) => startRun(params.id));
  r.post("/api/runs/:id/pause", ({ params }) => pauseRun(params.id));
  r.post("/api/runs/:id/resume", ({ params }) => startRun(params.id));
  r.post("/api/runs/:id/cancel", ({ params }) => cancelRun(params.id));
  r.post("/api/runs/:id/tasks", ({ params, body }) => addTask(params.id, body));
  r.get("/api/tasks/:id", ({ params }) => getTask(params.id));
  r.patch("/api/tasks/:id", ({ params, body }) => updateTask(params.id, body));
  r.delete("/api/tasks/:id", ({ params }) => removeTask(params.id));
  r.post("/api/tasks/:id/stop", ({ params }) => stopTask(params.id));
  r.post("/api/tasks/:id/retry", ({ params }) => retryTask(params.id));
  r.post("/api/tasks/:id/accept", ({ params }) => acceptTask(params.id));
  r.post("/api/tasks/:id/revert", ({ params }) => revertTask(params.id));
  r.get("/api/approvals", () => listApprovals());
  r.post("/api/approvals/:id", ({ params, body }) => decide(params.id, { allow: !!body?.allow, remember: body?.remember === "session" ? "session" : "once", message: body?.message }));
  r.get("/api/roblox/status", () => roblox.status());
  r.post("/api/roblox/connect", async () => {
    await roblox.connect();
    return roblox.status();
  });
  r.post("/api/roblox/disconnect", () => {
    roblox.disconnect();
    return roblox.status();
  });
  r.post("/api/roblox/test", () => roblox.test());
  r.post("/api/roblox/refresh", async () => {
    await roblox.refreshTools();
    await roblox.refreshStudios();
    return roblox.status();
  });
  r.post("/api/roblox/studio", ({ body }) => {
    roblox.selectStudio(str(body?.studioId, "studioId", { min: 1 }));
    return roblox.status();
  });
  r.post("/api/roblox/call", async ({ body }) => roblox.call(str(body?.tool, "tool", { min: 1, max: 100 }), body?.args ?? {}, { kind: "user", id: "user", label: "You (Studio console)" }));
  r.get("/api/roblox/activity", ({ query }) => listRobloxActivity(Number(query.get("limit") ?? 150)));
  r.get("/api/roblox/diagnostics", () => roblox.diagnostics());
  r.post("/api/bridge/rpc", async ({ req, body, res }) => {
    const token = req.headers["x-bloxade-bridge-token"];
    const response = await handleBridgeMessage(Array.isArray(token) ? token[0] : token, body);
    sendJson(res, 200, { response });
  });
  r.get("/api/activity", ({ query }) => listActivity(Number(query.get("limit") ?? 200), query.get("before") ? Number(query.get("before")) : void 0));
  r.get("/api/usage", ({ query }) => {
    const range = oneOf(query.get("range") ?? "7d", ["24h", "7d", "30d", "all"], "range");
    return usageSummary(range, { agents: activeAgentCount(), chats: runningChatIds().length, sessions: listProcesses().filter((p) => p.kind === "claude" || p.kind === "codex-app-server").length });
  });
  return r;
}

// src/server/main.ts
var log14 = logger("server");
var server = null;
var stopping = false;
function shutdown(code = 0) {
  if (stopping) return;
  stopping = true;
  log14.info("shutting down");
  try {
    denyAll("BLOXADE is shutting down");
    stopAllChats();
    stopAllTasks();
    stopAllCodex();
    roblox.shutdown();
    events.closeAll();
    killAll();
    server?.close();
    db().close();
  } catch (e) {
    log14.warn("error during shutdown", e);
  }
  setTimeout(() => process.exit(code), 300).unref();
}
async function startServer(opts = {}) {
  ensureDirs();
  db();
  const settings = getSettings();
  recoverInterrupted();
  recoverRuns();
  const host = opts.host ?? "127.0.0.1";
  const port = opts.port ?? Number(process.env.BLOXADE_PORT || settings.advanced.port || 3e3);
  runtime.port = port;
  const router = buildRoutes({ shutdown: () => shutdown(0) });
  router.allowedHosts = /* @__PURE__ */ new Set([`127.0.0.1:${port}`, `localhost:${port}`, `[::1]:${port}`]);
  server = createServer(router, PUBLIC_DIR);
  server.keepAliveTimeout = 65e3;
  server.requestTimeout = 0;
  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(port, host, () => resolve());
  });
  log14.info(`BLOXADE ${VERSION} listening on http://${host}:${port}`, { data: DATA_DIR, public: PUBLIC_DIR });
  for (const sig of ["SIGINT", "SIGTERM", "SIGHUP", "SIGBREAK"]) process.on(sig, () => shutdown(0));
  process.on("uncaughtException", (e) => log14.error("uncaught exception", e));
  process.on("unhandledRejection", (e) => log14.error("unhandled rejection", e));
  if (!opts.background) {
    void (async () => {
      const [c1, c2] = await Promise.all([detectCli("claude"), detectCli("codex")]);
      log14.info("CLI detection", { claude: c1.found ? c1.version : "missing", codex: c2.found ? c2.version : "missing" });
      events.emit("providers.updated", { claude: c1, codex: c2 });
      await refreshAllAccounts();
      for (const p of ["claude", "codex"]) {
        if ((p === "claude" ? c1 : c2).found && listAccounts().some((a) => a.provider === p)) {
          const cat = await refreshCatalog(p, resolveAccount(p));
          events.emit("models.updated", cat);
        }
      }
      if (getSettings().roblox.enabled && getSettings().roblox.autoConnect) roblox.connect().catch((e) => log14.warn("Studio auto-connect failed", e.message));
    })().catch((e) => log14.warn("warm-up failed", e));
  }
  return { port, url: `http://127.0.0.1:${port}` };
}
function launchPreferences() {
  ensureDirs();
  const s = getSettings();
  return { port: s.advanced.port || 3e3, openBrowser: s.general.openBrowserOnStart };
}
var isMain = (() => {
  try {
    return import.meta.url === pathToFileURL(process.argv[1] ?? "").href;
  } catch {
    return false;
  }
})();
if (isMain && process.env.BLOXADE_NO_AUTOSTART !== "1") {
  startServer().catch((e) => {
    console.error("\nBLOXADE could not start:", e.message);
    process.exit(1);
  });
}
export {
  launchPreferences,
  shutdown,
  startServer
};
