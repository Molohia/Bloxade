# Downloads a private, portable Node.js LTS runtime for BLOXADE (no admin rights, no system changes).
# The archive's SHA-256 is verified against the official SHASUMS256.txt from nodejs.org.
param(
  [Parameter(Mandatory = $true)][string]$Dest
)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

try {
  $arch = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { 'arm64' } else { 'x64' }
  Write-Host "  Looking up the current Node.js LTS release..."
  $index = Invoke-RestMethod -Uri 'https://nodejs.org/dist/index.json' -UseBasicParsing
  $release = $index | Where-Object { $_.lts -and ($_.files -contains "win-$arch-zip") -and ([int]($_.version.TrimStart('v').Split('.')[0]) -ge 22) } | Select-Object -First 1
  if (-not $release) { throw "No suitable Node.js LTS build found for win-$arch" }
  $ver = $release.version
  $name = "node-$ver-win-$arch"
  $url = "https://nodejs.org/dist/$ver/$name.zip"
  $tmp = Join-Path $env:TEMP ("bloxade-node-" + [guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Force -Path $tmp | Out-Null
  $zip = Join-Path $tmp "$name.zip"

  Write-Host "  Downloading Node.js $ver ($arch)..."
  Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing

  Write-Host "  Verifying checksum..."
  $sums = (Invoke-WebRequest -Uri "https://nodejs.org/dist/$ver/SHASUMS256.txt" -UseBasicParsing).Content
  $line = ($sums -split "`n") | Where-Object { $_ -match [regex]::Escape("$name.zip") } | Select-Object -First 1
  if (-not $line) { throw "Checksum for $name.zip not found" }
  $expected = ($line -split '\s+')[0].Trim().ToLower()
  $actual = (Get-FileHash -Algorithm SHA256 -Path $zip).Hash.ToLower()
  if ($expected -ne $actual) { throw "Checksum mismatch for $name.zip (expected $expected, got $actual)" }

  Write-Host "  Extracting..."
  Expand-Archive -Path $zip -DestinationPath $tmp -Force
  New-Item -ItemType Directory -Force -Path $Dest | Out-Null
  $target = Join-Path $Dest 'node'
  if (Test-Path $target) { Remove-Item -Recurse -Force $target }
  Move-Item -Path (Join-Path $tmp $name) -Destination $target
  Remove-Item -Recurse -Force $tmp
  Write-Host "  Node.js $ver is ready (private to BLOXADE)."
  exit 0
}
catch {
  Write-Host ""
  Write-Host "  Could not download Node.js automatically: $($_.Exception.Message)" -ForegroundColor Red
  Write-Host "  Install Node.js LTS from https://nodejs.org and run START_BLOXADE.bat again." -ForegroundColor Yellow
  exit 1
}
