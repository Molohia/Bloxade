import { createRequire as __bxCreateRequire } from 'node:module'; const require = __bxCreateRequire(import.meta.url);

// src/bridge/mcp-bridge.ts
import http from "node:http";
var base = process.env.BLOXADE_URL || "http://127.0.0.1:3000";
var token = process.env.BLOXADE_BRIDGE_TOKEN || "";
var url = new URL("/api/bridge/rpc", base);
function post(body) {
  return new Promise((resolve, reject) => {
    const req = http.request(
      { hostname: url.hostname, port: url.port, path: url.pathname, method: "POST", headers: { "content-type": "application/json", "x-bloxade-bridge-token": token, host: `${url.hostname}:${url.port}` }, timeout: 15 * 6e4 },
      (res) => {
        const chunks = [];
        res.on("data", (c) => chunks.push(c));
        res.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
      }
    );
    req.on("error", reject);
    req.on("timeout", () => req.destroy(new Error("BLOXADE did not answer in time")));
    req.end(body);
  });
}
function write(obj) {
  process.stdout.write(JSON.stringify(obj) + "\n");
}
var buf = "";
process.stdin.setEncoding("utf8");
process.stdin.on("data", (chunk) => {
  buf += chunk;
  let i;
  while ((i = buf.indexOf("\n")) >= 0) {
    const line = buf.slice(0, i).trim();
    buf = buf.slice(i + 1);
    if (line) void handle(line);
  }
});
process.stdin.on("end", () => process.exit(0));
async function handle(line) {
  let msg;
  try {
    msg = JSON.parse(line);
  } catch {
    return;
  }
  try {
    const text = await post(line);
    if (!text.trim()) return;
    const resp = JSON.parse(text);
    if (resp && resp.response !== void 0) {
      if (resp.response !== null) write(resp.response);
    } else if (resp?.error && msg?.id !== void 0) {
      write({ jsonrpc: "2.0", id: msg.id, error: { code: -32e3, message: String(resp.error) } });
    }
  } catch (e) {
    if (msg?.id !== void 0) write({ jsonrpc: "2.0", id: msg.id, error: { code: -32e3, message: `BLOXADE is not reachable: ${e.message}` } });
  }
}
