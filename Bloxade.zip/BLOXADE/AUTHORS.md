# BLOXADE — Creator and Attribution

## Project creator and owner

**Blox_soward** is the creator and project owner of **BLOXADE**, an independent AI development workspace for Roblox Studio.

| Platform | Public handle |
|---|---|
| Roblox | **Blox_soward** |
| Discord | **knz1w** |
| GitHub | **molohia** — https://github.com/molohia |

These three handles are supplied by the project owner as their public creator identities. They are not a legal name, a claim about the authorship of every third-party dependency, or evidence of an affiliation with Roblox, Anthropic, or OpenAI.

## Recommended public credit

> **BLOXADE** — created by **Blox_soward** (Roblox), also known as **knz1w** on Discord and **molohia** on GitHub.

## Before publishing

- Publishing all three handles together links these identities. Keep only the ones you want to associate publicly.
- Do not add private emails, passwords, session tokens, or account files to the repository.
- Credit third-party libraries and tools according to their actual licenses; do not imply they were developed by the BLOXADE creator.
- Choose a license before promising that others can freely copy, modify, or redistribute BLOXADE. This archive does not include one.

BLOXADE is an independent project and is not an official Roblox, Anthropic, or OpenAI product.
