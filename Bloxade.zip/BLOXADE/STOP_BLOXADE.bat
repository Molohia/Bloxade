@echo off
setlocal
set "PORT=%~1"
if "%PORT%"=="" set "PORT=3000"
powershell -NoProfile -Command "try { Invoke-RestMethod -Method Post -Uri 'http://127.0.0.1:%PORT%/api/system/shutdown' -Headers @{ 'X-Bloxade' = '1' } -ContentType 'application/json' -Body '{}' | Out-Null; Write-Host '  BLOXADE stopped.' } catch { Write-Host '  BLOXADE is not running on port %PORT%.' }"
timeout /t 2 >nul
endlocal
