# BLOXADE — Full Project Description

## Overview

**BLOXADE** is a Windows-oriented, local-first AI coding and game-development workspace designed around Roblox Studio. Instead of switching between several AI chat websites, terminals, scripts, and Studio tools, a developer can organize Roblox projects, connect supported AI coding accounts, chat with assistants, delegate work to multiple agents, and interact with an open Roblox Studio place through its official Model Context Protocol (MCP) server.

**Project creator / owner:** Blox_soward (Roblox) · knz1w (Discord) · molohia (GitHub).

BLOXADE is an independent software project. It is not an official Roblox, Anthropic, or OpenAI application, and it is not itself a Roblox game.

## Why BLOXADE exists

Roblox projects frequently involve many different jobs: designing gameplay, implementing Luau systems, building interfaces, troubleshooting scripts, inspecting the place hierarchy, testing behavior, and managing files. BLOXADE aims to put these activities into one practical workspace, with special attention to multiple AI accounts, parallel tasks, controlled Studio access, and visibility into changes and usage.

The goal is to help developers spend less time manually moving context between tools and more time building and reviewing their experiences. AI-generated changes still require developer oversight and testing.

## Who it is for

- Roblox developers who want to use Claude Code and/or OpenAI Codex for coding and development tasks.
- Solo creators who need project organization and help breaking down large features.
- Developers experimenting with multiple AI accounts and coordinated agents.
- Teams or individuals who want an inspectable history of AI edits, permissions, and usage rather than opaque automation.

## Main capabilities represented in the source

### 1. AI conversations and coding modes

The interface supports persistent chats, streaming replies, formatted Markdown and code, attachments, conversation search, and actions such as editing, branching, and regenerating messages. **Chat** is intended for conversation without project-tool access. **Cowork** is the mode for project files and Roblox Studio tools, with approval rules for sensitive operations.

### 2. Claude Code and Codex accounts

BLOXADE integrates with the installed **Claude Code CLI** and **Codex CLI/app-server** rather than replacing them with its own AI model. The account manager is designed for multiple accounts, with separate local profile directories and the providers' official authentication flows. Model discovery and available reasoning/effort options are based on what the installed CLIs report.

An account subscription does not automatically include separate API credits; use and limits depend on each provider's plan, CLI behavior, and terms. BLOXADE is not intended to bypass provider restrictions.

### 3. Projects and file management

Each project can be associated with a local folder. Project pages include instructions, memory, file browsing, model defaults, tracked changes, diffs, and revert actions. This helps agents work with the relevant files instead of repeatedly receiving an entire codebase.

### 4. Multi-agent orchestration

The coordinator can divide a request into tasks, assign tasks to available Claude or Codex accounts, express dependencies, and execute eligible work in parallel. The implementation includes file ownership rules, locking, conflict handling, task inspection, review/accept/revert, retries, and a combined run report.

**Important:** The current project does **not** implement per-agent Git worktrees. Its protections are based on application-level ownership, locks, approvals, and snapshots. Agents can still conflict if they modify the same resources outside those protections, so review and backups remain important.

### 5. Roblox Studio MCP integration

BLOXADE is designed to connect to Roblox Studio's **official MCP server**. Its backend is an MCP client of Studio and provides an MCP bridge to supported AI agents. The Roblox connection page exposes status, diagnostics, tools, a console, and an activity log. The backend includes per-tool Allow/Ask/Block policies, a serialized write queue, script locks, a read cache, and trimmed tool output.

This allows agents to inspect an open place and, when authorized, make supported changes using Studio tools. The actual available actions depend on the Studio MCP version and connection status. **Always back up a place before allowing automated edits.**

### 6. Efficiency and usage visibility

The project defines Economy, Balanced, Performance, and Maximum Quality modes, with different budgets and task behaviors. Context selection and output compression aim to reduce unnecessary tokens. Usage reporting distinguishes values returned by the CLIs from estimates made by BLOXADE; it cannot guarantee a particular bill or quota.

### 7. Local user interface and settings

The web interface includes pages for onboarding, chats, accounts, projects, agents, Roblox Studio, activity, usage, and settings. It offers multiple themes and accent customization. The server listens on the local machine rather than being a public cloud service.

## Technical structure

| Path | Purpose |
|---|---|
| `src/web/` | React/TypeScript application: pages, reusable components, state, styling |
| `src/server/` | Local Node.js backend, HTTP API, persistence, account and project services |
| `src/server/providers/` | Claude Code and Codex CLI integrations |
| `src/server/agents/` | Coordinator, planning, task execution, task state and review |
| `src/server/roblox/` | Roblox Studio MCP connection, tool handling and agent bridge |
| `src/server/services/` | Chats, accounts, projects, file tracking, context, approvals and usage |
| `src/bridge/` | MCP bridge source used to connect agent CLIs to BLOXADE |
| `src/shared/` | Shared TypeScript contracts and types |
| `app/` | Built server, frontend assets, MCP bridge and runtime launcher |
| `scripts/` | Build and Node setup utilities |
| `tests/` | Unit/integration tests and mock CLI/Studio fixtures |
| `START_BLOXADE.bat` | Windows one-click launcher |
| `STOP_BLOXADE.bat` | Windows stop command |
| `README.md` | Setup instructions and primary feature reference |
| `PROGRESS.md` | Recorded implementation status and known limitations |
| `TESTING.md` | Automated tests and Windows manual test checklist |

**Technology:** React, TypeScript, Vite, Tailwind CSS, Zustand, Node.js, SQLite, Server-Sent Events, Claude Code CLI, Codex app-server, and Roblox Studio MCP. The package targets Node.js 22.13+ for development/runtime and includes a Windows bootstrap script for a local Node installation.

## Typical user workflow

1. Open Roblox Studio and load the place to work on.
2. Enable Studio's MCP server in the Roblox Studio Assistant settings.
3. Start BLOXADE with `START_BLOXADE.bat` and open its local browser interface.
4. Connect Claude Code and/or Codex accounts through their official sign-in flows.
5. Add a project folder and project-specific instructions.
6. Open the Roblox connection page and test the Studio connection.
7. Use a Cowork chat for a focused task, or create an agent run for a larger feature.
8. Review permission prompts, file diffs, task reports, and Studio changes.
9. Test gameplay in Roblox Studio and keep a backup/version-control history.

## Current status and honest limitations

The included `PROGRESS.md` marks the main planned implementation phases complete. `TESTING.md` documents 34 tests and reports manual checks against certain Claude and Roblox flows; its Codex turn coverage relies on a protocol test fixture because the build environment could not perform ChatGPT sign-in. This archive has **not** been independently run on the recipient's Windows/Roblox environment as part of this documentation update.

Known limitations documented by the project include:

- No per-agent Git worktree isolation.
- Pausing an agent run does not freeze a currently executing task; it prevents new tasks from starting.
- File changes made through shell commands cannot always be preemptively restricted to a particular path; they are checked after execution.
- Codex login may need to be completed one account at a time because of its local sign-in port.
- Real account usage, models, quotas, and Studio capabilities depend on the installed tools and their versions.

## Privacy, safety and publishing

The README states that the app stores data locally under `%LOCALAPPDATA%\BLOXADE`, binds to `127.0.0.1`, and delegates sign-in to the official CLIs. Do not assume that local-only execution removes all risk: connected AI providers may receive prompts and project context, and Cowork/Studio actions may edit files or places. Review permissions, keep backups, and avoid committing secrets.

**Creator attribution:**

- Roblox: **Blox_soward**
- Discord: **knz1w**
- GitHub: **molohia**

Listing these handles publicly is optional. Including all three makes it easier for others to find the creator, but it also links the identities. No personal email address or legal name is required.

No `LICENSE` file was present in the supplied archive. Before public distribution, the creator should decide whether the code is source-available, private, or open-source under a chosen license. Do not assume a license or copyright year not provided by the creator.

## GitHub repository description (suggested)

> BLOXADE is a local-first AI development workspace for Roblox Studio, combining Claude Code, Codex, multi-agent task coordination, project management, and MCP-powered Studio tools. Created by Blox_soward / knz1w / molohia.

**Suggested GitHub topics:** `roblox`, `roblox-studio`, `mcp`, `claude-code`, `codex`, `ai-agents`, `multi-agent`, `typescript`, `react`, `developer-tools`.

## Ownership and acknowledgment

**BLOXADE — created and owned by Blox_soward.** Roblox: `Blox_soward` · Discord: `knz1w` · GitHub: `molohia`.

Roblox, Claude, ChatGPT, Codex and other referenced product names belong to their respective owners. BLOXADE does not claim official endorsement or affiliation.
